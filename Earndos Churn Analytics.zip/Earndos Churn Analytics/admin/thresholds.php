<?php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

// admin/thresholds.php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Admin verification
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_sms_permissions'])) {
        try {
            $allowed_levels = $_POST['allowed_levels'] ?? [];

            // Reset all to 0 first
            $pdo->exec("UPDATE membership_levels SET allow_sms_alerts = 0");

            // Update selected levels
            if (!empty($allowed_levels)) {
                $in = str_repeat('?,', count($allowed_levels) - 1) . '?';
                $stmt = $pdo->prepare("UPDATE membership_levels SET allow_sms_alerts = 1 WHERE id IN ($in)");
                $stmt->execute($allowed_levels);
            }

            $_SESSION['success'] = "SMS alert permissions updated successfully";
        } catch (PDOException $e) {
            $_SESSION['error'] = "Error updating SMS permissions: " . $e->getMessage();
        }
    } 
    elseif (isset($_POST['update_threshold_settings'])) {
        try {
            $default_threshold = (float)$_POST['default_threshold'];
            $check_interval = (int)$_POST['check_interval'];
            $enable_alerts = isset($_POST['enable_alerts']) ? 1 : 0;

            $stmt = $pdo->prepare("INSERT INTO config (setting, value) VALUES (?, ?) 
                                  ON DUPLICATE KEY UPDATE value = VALUES(value)");

            $stmt->execute(['default_alert_threshold', $default_threshold]);
            $stmt->execute(['threshold_check_interval', $check_interval]);
            $stmt->execute(['enable_threshold_alerts', $enable_alerts]);

            $_SESSION['success'] = "Threshold settings updated successfully";
        } catch (PDOException $e) {
            $_SESSION['error'] = "Error updating threshold settings: " . $e->getMessage();
        }
    }

    header("Location: thresholds.php");
    exit;
}

// Get all membership levels
$membership_levels = $pdo->query("SELECT id, name, allow_sms_alerts FROM membership_levels ORDER BY standard_price DESC")
                        ->fetchAll();

// Get current settings
$settings = [];
$stmt = $pdo->query("SELECT setting, value FROM config 
                     WHERE setting IN ('default_alert_threshold', 'threshold_check_interval', 'enable_threshold_alerts')");
while ($row = $stmt->fetch()) {
    $settings[$row['setting']] = $row['value'];
}

// Get threshold statistics
$stats = $pdo->query("
    SELECT 
        COUNT(DISTINCT user_id) as total_users,
        AVG(threshold) as avg_threshold,
        MIN(threshold) as min_threshold,
        MAX(threshold) as max_threshold
    FROM user_alert_thresholds
")->fetch();

// Get recent threshold changes
$recent_changes = $pdo->query("
    SELECT u.username, t.threshold, t.created_at, s.name as stream_name
    FROM user_alert_thresholds t
    JOIN users u ON t.user_id = u.id
    LEFT JOIN streams s ON t.stream_id = s.id
    ORDER BY t.created_at DESC
    LIMIT 10
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Threshold Settings | Admin Panel</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Font Awesome for consistent icons across pages -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
            xintegrity="sha512-1ycn6IcaQQ40ZefMdHjAcUwaGDvPwdOaUcsU5XrU+pL87B7fC3J0P2Kqj1Z5M5YqD65B2L52B7y42j5P5c+A=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Feather Icons for new tab icons -->
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>

    <style>
        /* Define your color variables */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
            --light-green: #90EE90; /* Light green color */
        }

        /* Body and main layout styling */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--gray-100);
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer if added */
        }
        .site-wrapper { /* New wrapper for sticky footer logic */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container-fluid {
            padding: 0; /* Remove padding to make sidebar stick to edge */
            flex-grow: 1; /* Allow container-fluid to take up remaining height */
        }
        .row {
            margin: 0; /* Remove row margins to prevent unwanted space */
            flex-grow: 1;
        }
        /* Main content area */
        main {
            padding: 20px !important; /* Important to override Bootstrap default */
            background-color: var(--gray-100); /* Content area background */
            flex-grow: 1;
        }
        .d-flex.justify-content-between.flex-wrap.flex-md-nowrap.align-items-center {
            padding-top: 1.5rem !important; /* Bootstrap pt-3 */
            padding-bottom: 1rem !important; /* Bootstrap pb-2 */
            margin-bottom: 1.5rem !important; /* Bootstrap mb-3 */
        }

        /* Admin Sidebar basic styling */
        .admin-sidebar {
            background-color: var(--dark);
            color: var(--white);
            padding: 20px;
            /* Fixed position for desktop view */
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: 250px; /* Fixed width for the sidebar */
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .admin-sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary);
            font-size: 1.8rem;
            font-weight: 700;
        }
        .admin-sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .admin-sidebar ul li {
            margin-bottom: 10px;
        }
        .admin-sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--gray-300);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        .admin-sidebar ul li a:hover,
        .admin-sidebar ul li a.active {
            background-color: var(--gray-700);
            color: var(--white);
        }
        .admin-sidebar ul li a i {
            width: 20px;
            height: 20px;
        }

        /* Specific styles for thresholds.php content */
        .stat-card {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            margin-bottom: 15px;
            border: 1px solid var(--gray-200); /* Added border */
        }
        .stat-value {
            font-size: 24px;
            font-weight: bold;
            color: var(--secondary); /* Changed to secondary color variable */
        }
        .stat-label {
            color: var(--gray-600); /* Changed to gray-600 color variable */
            font-size: 14px;
        }
        .threshold-slider {
            width: 100%;
        }
        /* Card styles */
        .card {
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05); /* Soft shadow */
        }
        .card-body {
            padding: 25px;
        }
        .form-control, .form-select {
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            padding: 10px 15px;
            color: var(--gray-800);
            background-color: var(--white);
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(58, 195, 184, 0.25);
        }
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: background-color 0.2s, border-color 0.2s;
        }
        .btn-primary:hover {
            background-color: #2da89e;
            border-color: #2da89e;
        }
        .alert {
            border-radius: 8px;
            font-weight: 500;
        }

        /* Responsive adjustments: Sidebar becomes standard column on mobile */
        @media (max-width: 767.98px) {
            .admin-sidebar {
                position: relative; /* Remove fixed positioning on small screens */
                width: 100%; /* Take full width on small screens */
                height: auto; /* Adjust height based on content */
                box-shadow: none; /* Remove shadow to blend better */
            }
            main {
                margin-left: 0 !important; /* Remove desktop margin on small screens */
            }
            .navbar-mobile-toggle { /* Ensure this is hidden as it's not needed now */
                display: none !important;
            }
        }

        @media (min-width: 768px) { /* Applies to md and larger screens */
            .main-content-area {
                margin-left: 250px; /* Offset for the fixed sidebar */
            }
            /* Hide the mobile toggle navbar on desktop */
            .navbar-mobile-toggle {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <!-- Mobile Navbar/Toggle is not included as per instruction to ignore mobile changes. -->
        <!-- The layout will now simply stack on small screens. -->

        <div class="container-fluid">
            <div class="row">
                <!-- Admin Sidebar -->
                <!-- The d-md-block class makes it a block element from md breakpoint up, making it visible -->
                <!-- The 'collapse' class is removed to ensure it's always visible on desktop -->
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block admin-sidebar">
                    <div class="position-sticky pt-3">
                        <h2>Admin Panel</h2>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i data-feather="users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_levels.php">
                                    <i data-feather="award"></i> Membership Levels
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="payment_settings.php">
                                    <i data-feather="dollar-sign"></i> Payment Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="transactions.php">
                                    <i data-feather="credit-card"></i> Transactions
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="affiliates.php">
                                    <i data-feather="link"></i> Affiliates
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="helpdesk.php">
                                    <i data-feather="life-buoy"></i> Helpdesk
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="gift_management.php">
                                    <i data-feather="gift"></i> Gift Management
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="thresholds.php">
                                    <i data-feather="sliders"></i> Thresholds
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_admin.php">
                                    <i data-feather="user-check"></i> Membership+
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="teams.php">
                                    <i data-feather="users"></i> Teams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="streams_management.php">
                                    <i data-feather="video"></i> Streams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="cashouts.php" style="color: var(--light-green);">
                                    <i data-feather="dollar-sign"></i> Cashouts
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="email_settings.php">
                                    <i data-feather="mail"></i> Email Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="notifications.php">
                                    <i data-feather="bell"></i> Notifications
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="ai_settings.php">
                                    <i data-feather="cpu"></i> AI Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="niches.php">
                                    <i data-feather="grid"></i> Niches
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../dashboard.php">
                                    <i data-feather="home"></i> Back to Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">
                                    <i data-feather="log-out"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- End Admin Sidebar -->
                
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content-area">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Alert Threshold Settings</h1>
                    </div>
                    
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= $_SESSION['success'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?= $_SESSION['error'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['error']); ?>
                    <?php endif; ?>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5>SMS Alert Permissions</h5>
                                </div>
                                <div class="card-body">
                                    <form method="POST">
                                        <p class="text-muted">Select which membership levels can use SMS alerts:</p>
                                        <?php foreach ($membership_levels as $level): ?>
                                            <div class="form-check mb-2">
                                                <input class="form-check-input" type="checkbox" 
                                                       name="allowed_levels[]" value="<?= $level['id'] ?>"
                                                       id="level_<?= $level['id'] ?>"
                                                       <?= $level['allow_sms_alerts'] ? 'checked' : '' ?>>
                                                <label class="form-check-label" for="level_<?= $level['id'] ?>">
                                                    <?= htmlspecialchars($level['name']) ?>
                                                </label>
                                            </div>
                                        <?php endforeach; ?>
                                        <button type="submit" name="update_sms_permissions" class="btn btn-primary mt-3">
                                            Save SMS Permissions
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5>Global Threshold Settings</h5>
                                </div>
                                <div class="card-body">
                                    <form method="POST">
                                        <div class="mb-3">
                                            <label class="form-label">Default Alert Threshold</label>
                                            <input type="range" class="form-range threshold-slider mb-2" 
                                                   min="0" max="100" step="1" 
                                                   name="default_threshold" 
                                                   value="<?= $settings['default_alert_threshold'] ?? 50 ?>"
                                                   oninput="document.getElementById('thresholdValue').innerText = this.value">
                                            <div class="d-flex justify-content-between">
                                                <small>0%</small>
                                                <span class="fw-bold" id="thresholdValue">
                                                    <?= $settings['default_alert_threshold'] ?? 50 ?>
                                                </span>%
                                                <small>100%</small>
                                            </div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Check Interval</label>
                                            <select class="form-select" name="check_interval">
                                                <option value="5" <?= ($settings['threshold_check_interval'] ?? 15) == 5 ? 'selected' : '' ?>>5 minutes</option>
                                                <option value="15" <?= ($settings['threshold_check_interval'] ?? 15) == 15 ? 'selected' : '' ?>>15 minutes</option>
                                                <option value="30" <?= ($settings['threshold_check_interval'] ?? 15) == 30 ? 'selected' : '' ?>>30 minutes</option>
                                                <option value="60" <?= ($settings['threshold_check_interval'] ?? 15) == 60 ? 'selected' : '' ?>>1 hour</option>
                                            </select>
                                        </div>
                                        
                                        <div class="form-check mb-3">
                                            <input class="form-check-input" type="checkbox" 
                                                   name="enable_alerts" id="enableAlerts"
                                                   <?= ($settings['enable_threshold_alerts'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label" for="enableAlerts">
                                                Enable Threshold Alerts
                                            </label>
                                        </div>
                                        
                                        <button type="submit" name="update_threshold_settings" class="btn btn-primary">
                                            Save Global Settings
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5>Threshold Statistics</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="stat-card">
                                                <div class="stat-value"><?= round($stats['avg_threshold'] ?? 50, 1) ?>%</div>
                                                <div class="stat-label">Average Threshold</div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="stat-card">
                                                <div class="stat-value"><?= $stats['total_users'] ?? 0 ?></div>
                                                <div class="stat-label">Active Users</div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="stat-card">
                                                <div class="stat-value"><?= $stats['min_threshold'] ?? 0 ?>%</div>
                                                <div class="stat-label">Minimum</div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="stat-card">
                                                <div class="stat-value"><?= $stats['max_threshold'] ?? 100 ?>%</div>
                                                <div class="stat-label">Maximum</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h5>Recent Threshold Changes</h5>
                                </div>
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table table-hover mb-0">
                                            <thead>
                                                <tr>
                                                    <th>User</th>
                                                    <th>Threshold</th>
                                                    <th>Stream</th>
                                                    <th>When</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($recent_changes as $change): ?>
                                                    <tr>
                                                        <td><?= htmlspecialchars($change['username']) ?></td>
                                                        <td><?= $change['threshold'] ?>%</td>
                                                        <td><?= $change['stream_name'] ?? 'Global' ?></td>
                                                        <td><?= date('M j, H:i', strtotime($change['created_at'])) ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize Feather Icons
        feather.replace();
    </script>
</body>
</html>
