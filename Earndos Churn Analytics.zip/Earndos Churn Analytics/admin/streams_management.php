<?php
// admin/streams_management.php
require_once '../includes/db.php';
require_once '../includes/functions.php'; // Assuming this file exists and contains necessary functions

// Admin verification
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit;
}

// Handle all form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();
        
        if (isset($_POST['delete_stream'])) {
            // Handle stream deletion
            $stream_id = intval($_POST['stream_id']);
            
            // Delete related records first
            $tables = ['contacts', 'cohorts', 'competitors', 'features', 'team_streams']; // Assuming these tables have stream_id
            foreach ($tables as $table) {
                $stmt = $pdo->prepare("DELETE FROM $table WHERE stream_id = ?");
                $stmt->execute([$stream_id]);
            }
            
            // Delete the stream
            $stmt = $pdo->prepare("DELETE FROM streams WHERE id = ?");
            $stmt->execute([$stream_id]);
            
            $_SESSION['success'] = "Stream and all related data deleted successfully";
        } 
        elseif (isset($_POST['save_stream'])) {
            // Handle stream creation/update
            $stream_id = isset($_POST['stream_id']) ? intval($_POST['stream_id']) : 0;
            $name = trim($_POST['name'] ?? '');
            $website_url = trim($_POST['website_url'] ?? '');
            $is_app = isset($_POST['is_app']) ? 1 : 0;
            $description = trim($_POST['description'] ?? '');
            $color_code = trim($_POST['color_code'] ?? '#3366ff');
            $niche_id = isset($_POST['niche_id']) && $_POST['niche_id'] !== '' ? intval($_POST['niche_id']) : null;
            $team_id = isset($_POST['team_id']) && $_POST['team_id'] !== '' ? intval($_POST['team_id']) : null;
            $acquisition_cost = isset($_POST['acquisition_cost']) ? floatval($_POST['acquisition_cost']) : 0;
            $revenue_per_user = isset($_POST['revenue_per_user']) ? floatval($_POST['revenue_per_user']) : 0;
            $marketing_channel = trim($_POST['marketing_channel'] ?? '');
            $currency = trim($_POST['currency'] ?? 'USD');

            if (empty($name)) {
                throw new Exception("Stream name is required");
            }

            if ($stream_id > 0) {
                // Update existing stream
                $stmt = $pdo->prepare("UPDATE streams SET 
                    name = ?, website_url = ?, is_app = ?, description = ?, 
                    color_code = ?, niche_id = ?, team_id = ?, acquisition_cost = ?,
                    revenue_per_user = ?, marketing_channel = ?, currency = ?
                    WHERE id = ?");
                $stmt->execute([
                    $name, $website_url, $is_app, $description, 
                    $color_code, $niche_id, $team_id, $acquisition_cost,
                    $revenue_per_user, $marketing_channel, $currency, $stream_id
                ]);
                $action = "updated";
            } else {
                // Create new stream
                $tracking_code = bin2hex(random_bytes(16));
                $stmt = $pdo->prepare("INSERT INTO streams 
                    (user_id, name, website_url, is_app, description, color_code, 
                    niche_id, team_id, tracking_code, acquisition_cost, 
                    revenue_per_user, marketing_channel, currency) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $_SESSION['user_id'], $name, $website_url, $is_app, $description, 
                    $color_code, $niche_id, $team_id, $tracking_code, $acquisition_cost,
                    $revenue_per_user, $marketing_channel, $currency
                ]);
                $stream_id = $pdo->lastInsertId();
                $action = "created";
            }
            
            $_SESSION['success'] = "Stream $action successfully";
        }
        elseif (isset($_POST['save_contact'])) {
            // Handle contact creation/update
            $contact_id = isset($_POST['contact_id']) ? intval($_POST['contact_id']) : 0;
            $stream_id = intval($_POST['stream_id']);
            $username = trim($_POST['username'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $external_id = trim($_POST['external_id'] ?? '');
            
            // Reconstruct custom_data from array of key-value pairs
            $custom_data_array = [];
            if (isset($_POST['custom_data']) && is_array($_POST['custom_data'])) {
                foreach ($_POST['custom_data'] as $field) {
                    if (!empty($field['key'])) {
                        $custom_data_array[$field['key']] = $field['value'] ?? '';
                    }
                }
            }
            $custom_data = json_encode($custom_data_array);


            if (empty($username) && empty($email)) {
                throw new Exception("At least username or email is required");
            }

            if ($contact_id > 0) {
                // Update existing contact
                $stmt = $pdo->prepare("UPDATE contacts SET 
                    username = ?, email = ?, external_id = ?, custom_data = ?
                    WHERE id = ? AND stream_id = ?");
                $stmt->execute([$username, $email, $external_id, $custom_data, $contact_id, $stream_id]);
                $action = "updated";
            } else {
                // Create new contact
                $stmt = $pdo->prepare("INSERT INTO contacts 
                    (stream_id, username, email, external_id, custom_data) 
                    VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$stream_id, $username, $email, $external_id, $custom_data]);
                $contact_id = $pdo->lastInsertId();
                $action = "created";
            }
            
            // Handle cohort assignments
            if (isset($_POST['cohort_ids'])) {
                // Remove existing cohort assignments
                $stmt = $pdo->prepare("DELETE FROM contact_cohorts WHERE contact_id = ?");
                $stmt->execute([$contact_id]);
                
                // Add new assignments
                foreach ($_POST['cohort_ids'] as $cohort_id) {
                    $cohort_id = intval($cohort_id);
                    $stmt = $pdo->prepare("INSERT INTO contact_cohorts (contact_id, cohort_id) VALUES (?, ?)");
                    $stmt->execute([$contact_id, $cohort_id]);
                }
            } else {
                // If no cohorts selected, ensure existing ones are removed
                $stmt = $pdo->prepare("DELETE FROM contact_cohorts WHERE contact_id = ?");
                $stmt->execute([$contact_id]);
            }
            
            $_SESSION['success'] = "Contact $action successfully";
        }
        elseif (isset($_POST['delete_contact'])) {
            $contact_id = intval($_POST['contact_id']);
            $stream_id = intval($_POST['stream_id']);
            $pdo->prepare("DELETE FROM contact_cohorts WHERE contact_id = ?")->execute([$contact_id]);
            $pdo->prepare("DELETE FROM contacts WHERE id = ? AND stream_id = ?")->execute([$contact_id, $stream_id]);
            $_SESSION['success'] = "Contact deleted successfully.";
        }
        elseif (isset($_POST['save_cohort'])) {
            // Handle cohort creation/update
            $cohort_id = isset($_POST['cohort_id']) ? intval($_POST['cohort_id']) : 0;
            $stream_id = intval($_POST['stream_id']);
            $name = trim($_POST['name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $cost_per_user = isset($_POST['cost_per_user']) ? floatval($_POST['cost_per_user']) : null;
            $revenue_per_user = isset($_POST['revenue_per_user']) ? floatval($_POST['revenue_per_user']) : null;

            if (empty($name)) {
                throw new Exception("Cohort name is required");
            }

            if ($cohort_id > 0) {
                // Update existing cohort
                $stmt = $pdo->prepare("UPDATE cohorts SET 
                    name = ?, description = ?, cost_per_user = ?, revenue_per_user = ?
                    WHERE id = ? AND stream_id = ?");
                $stmt->execute([$name, $description, $cost_per_user, $revenue_per_user, $cohort_id, $stream_id]);
                $action = "updated";
            } else {
                // Create new cohort
                $stmt = $pdo->prepare("INSERT INTO cohorts 
                    (stream_id, name, description, cost_per_user, revenue_per_user, created_by) 
                    VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$stream_id, $name, $description, $cost_per_user, $revenue_per_user, $_SESSION['user_id']]);
                $cohort_id = $pdo->lastInsertId();
                $action = "created";
            }
            
            $_SESSION['success'] = "Cohort $action successfully";
        }
        elseif (isset($_POST['delete_cohort'])) {
            $cohort_id = intval($_POST['cohort_id']);
            $stream_id = intval($_POST['stream_id']);
            $pdo->prepare("DELETE FROM contact_cohorts WHERE cohort_id = ?")->execute([$cohort_id]);
            $pdo->prepare("DELETE FROM cohorts WHERE id = ? AND stream_id = ?")->execute([$cohort_id, $stream_id]);
            $_SESSION['success'] = "Cohort and its member associations deleted successfully.";
        }
        elseif (isset($_POST['import_contacts'])) {
            // Handle CSV import
            $stream_id = intval($_POST['import_stream_id']);
            $cohort_id = isset($_POST['import_cohort_id']) && $_POST['import_cohort_id'] !== '' ? intval($_POST['import_cohort_id']) : null;
            
            if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
                throw new Exception("Please upload a valid CSV file");
            }
            
            $file = $_FILES['csv_file']['tmp_name'];
            $handle = fopen($file, 'r');
            $header = fgetcsv($handle);
            
            if (!$header) {
                throw new Exception("Invalid CSV format: Missing header row.");
            }
            
            $imported = 0;
            $skipped = 0;
            
            while (($data = fgetcsv($handle)) !== false) {
                if (count($header) !== count($data)) {
                    $skipped++;
                    continue; // Skip rows that don't match header count
                }
                $row = array_combine($header, $data);
                
                // Basic validation
                if (empty($row['email']) && empty($row['username'])) {
                    $skipped++;
                    continue;
                }
                
                // Prepare contact data
                $username = trim($row['username'] ?? '');
                $email = trim($row['email'] ?? '');
                $external_id = trim($row['external_id'] ?? '');
                
                // Remove standard fields from custom data
                $custom_data = $row;
                unset($custom_data['username'], $custom_data['email'], $custom_data['external_id']);
                
                // Insert contact
                $stmt = $pdo->prepare("INSERT INTO contacts 
                    (stream_id, username, email, external_id, custom_data) 
                    VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$stream_id, $username, $email, $external_id, json_encode($custom_data)]);
                $contact_id = $pdo->lastInsertId();
                $imported++;
                
                // Add to cohort if specified
                if ($cohort_id) {
                    $stmt = $pdo->prepare("INSERT INTO contact_cohorts (contact_id, cohort_id) VALUES (?, ?)");
                    $stmt->execute([$contact_id, $cohort_id]);
                }
            }
            
            fclose($handle);
            $_SESSION['success'] = "Imported $imported contacts, skipped $skipped invalid rows";
        }
        
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = $e->getMessage();
    }
    
    // Redirect to the current stream if stream_id is set
    $redirect_url = "streams_management.php";
    if (isset($_POST['stream_id']) && !empty($_POST['stream_id'])) {
        $redirect_url .= "?stream_id=" . intval($_POST['stream_id']);
        if (isset($_POST['current_tab'])) {
            $redirect_url .= "#" . htmlspecialchars($_POST['current_tab']); // Redirect to the active tab
        }
    }
    header("Location: $redirect_url");
    exit;
}

// Get all streams with stats
$streams = $pdo->query("
    SELECT s.*, 
           n.name as niche_name,
           t.name as team_name,
           u.username as owner_name,
           (SELECT COUNT(*) FROM contacts WHERE stream_id = s.id) as contact_count,
           (SELECT COUNT(*) FROM cohorts WHERE stream_id = s.id) as cohort_count
    FROM streams s
    LEFT JOIN niches n ON s.niche_id = n.id
    LEFT JOIN teams t ON s.team_id = t.id
    LEFT JOIN users u ON s.user_id = u.id
    ORDER BY s.created_at DESC
")->fetchAll();

// Get all niches for dropdowns
$niches = $pdo->query("SELECT id, name FROM niches WHERE is_active = 1 ORDER BY name")->fetchAll();

// Get all teams for dropdowns
$teams_list = $pdo->query("SELECT id, name FROM teams ORDER BY name")->fetchAll(); // Renamed to avoid conflict

// Get current stream details if viewing/editing
$current_stream = null;
$stream_contacts = [];
$stream_cohorts = [];
$current_contact = null;
$current_cohort = null;

if (isset($_GET['stream_id'])) {
    $stream_id_param = intval($_GET['stream_id']);
    
    // Get stream details
    $stmt = $pdo->prepare("
        SELECT s.*, n.name as niche_name, t.name as team_name, u.username as owner_name
        FROM streams s
        LEFT JOIN niches n ON s.niche_id = n.id
        LEFT JOIN teams t ON s.team_id = t.id
        LEFT JOIN users u ON s.user_id = u.id
        WHERE s.id = ?
    ");
    $stmt->execute([$stream_id_param]);
    $current_stream = $stmt->fetch();
    
    if ($current_stream) {
        // Get contacts for this stream
        $stream_contacts = $pdo->prepare("
            SELECT c.*, 
                   (SELECT GROUP_CONCAT(co.name SEPARATOR ', ') 
                    FROM contact_cohorts cc 
                    JOIN cohorts co ON cc.cohort_id = co.id 
                    WHERE cc.contact_id = c.id) as cohort_names
            FROM contacts c
            WHERE c.stream_id = ?
            ORDER BY c.created_at DESC
        ");
        $stream_contacts->execute([$stream_id_param]);
        $stream_contacts = $stream_contacts->fetchAll();
        
        // Get cohorts for this stream
        $stream_cohorts = $pdo->prepare("
            SELECT c.*, 
                   (SELECT COUNT(*) FROM contact_cohorts WHERE cohort_id = c.id) as member_count
            FROM cohorts c
            WHERE c.stream_id = ?
            ORDER BY c.created_at DESC
        ");
        $stream_cohorts->execute([$stream_id_param]);
        $stream_cohorts = $stream_cohorts->fetchAll();
        
        // Get specific contact if requested (for editing)
        if (isset($_GET['contact_id'])) {
            $contact_id_param = intval($_GET['contact_id']);
            $stmt = $pdo->prepare("SELECT * FROM contacts WHERE id = ? AND stream_id = ?");
            $stmt->execute([$contact_id_param, $stream_id_param]);
            $current_contact = $stmt->fetch();
            
            if ($current_contact) {
                // Get cohort assignments for this contact
                $stmt = $pdo->prepare("SELECT cohort_id FROM contact_cohorts WHERE contact_id = ?");
                $stmt->execute([$contact_id_param]);
                $current_contact['cohort_ids'] = $stmt->fetchAll(PDO::FETCH_COLUMN);
            }
        }
        
        // Get specific cohort if requested (for editing)
        if (isset($_GET['cohort_id'])) {
            $cohort_id_param = intval($_GET['cohort_id']);
            $stmt = $pdo->prepare("SELECT * FROM cohorts WHERE id = ? AND stream_id = ?");
            $stmt->execute([$cohort_id_param, $stream_id_param]);
            $current_cohort = $stmt->fetch();
            
            if ($current_cohort) {
                // Get members of this cohort
                $stmt = $pdo->prepare("
                    SELECT c.* FROM contacts c
                    JOIN contact_cohorts cc ON c.id = cc.contact_id
                    WHERE cc.cohort_id = ?
                    ORDER BY c.username, c.email
                ");
                $stmt->execute([$cohort_id_param]);
                $current_cohort['members'] = $stmt->fetchAll();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Streams Management | Admin Panel</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Font Awesome for consistent icons across pages -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
            xintegrity="sha512-1ycn6IcaQQ40ZefMdHjAcUwaGDvPwdOaUcsU5XrU+pL87B7fC3J0P2Kqj1Z5M5YqD65B2L52B7y42j5P5c+A=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Feather Icons for new tab icons -->
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <!-- Select2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@1.5.2/dist/select2-bootstrap4.min.css">

    <style>
        /* Define your color variables */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
            --light-green: #90EE90; /* Light green color */
        }

        /* Body and main layout styling */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--gray-100);
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer if added */
        }
        .site-wrapper { /* New wrapper for sticky footer logic */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container-fluid {
            padding: 0; /* Remove padding to make sidebar stick to edge */
            flex-grow: 1; /* Allow container-fluid to take up remaining height */
        }
        .row {
            margin: 0; /* Remove row margins to prevent unwanted space */
            flex-grow: 1;
        }
        /* Main content area */
        main {
            padding: 20px !important; /* Important to override Bootstrap default */
            background-color: var(--gray-100); /* Content area background */
            flex-grow: 1;
        }
        .d-flex.justify-content-between.flex-wrap.flex-md-nowrap.align-items-center {
            padding-top: 1.5rem !important; /* Bootstrap pt-3 */
            padding-bottom: 1rem !important; /* Bootstrap pb-2 */
            margin-bottom: 1.5rem !important; /* Bootstrap mb-3 */
        }

        /* Admin Sidebar basic styling */
        .admin-sidebar {
            background-color: var(--dark);
            color: var(--white);
            padding: 20px;
            /* Fixed position for desktop view */
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: 250px; /* Fixed width for the sidebar */
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .admin-sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary);
            font-size: 1.8rem;
            font-weight: 700;
        }
        .admin-sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .admin-sidebar ul li {
            margin-bottom: 10px;
        }
        .admin-sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--gray-300);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        .admin-sidebar ul li a:hover,
        .admin-sidebar ul li a.active {
            background-color: var(--gray-700);
            color: var(--white);
        }
        .admin-sidebar ul li a i {
            width: 20px;
            height: 20px;
        }

        /* Specific styles for streams_management.php content */
        .table-container { overflow-x: auto; }
        .stats-card { 
            transition: all 0.3s ease; 
            border: 1px solid var(--gray-200); /* Added border for consistency */
        }
        .stats-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.1); }
        .nav-tabs .nav-link.active { font-weight: bold; border-bottom: 3px solid var(--primary); }
        .select2-container { width: 100% !important; }
        .color-preview { width: 20px; height: 20px; display: inline-block; border: 1px solid #dee2e6; vertical-align: middle; }
        .stream-header { border-left: 5px solid; padding-left: 15px; }
        .custom-data-field { margin-bottom: 10px; }
        .custom-data-actions { margin-top: 15px; }

        /* Card styles */
        .card {
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05); /* Soft shadow */
        }
        .card-body {
            padding: 25px;
        }
        .form-control, .form-select {
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            padding: 10px 15px;
            color: var(--gray-800);
            background-color: var(--white);
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(58, 195, 184, 0.25);
        }
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: background-color 0.2s, border-color 0.2s;
        }
        .btn-primary:hover {
            background-color: #2da89e;
            border-color: #2da89e;
        }
        .alert {
            border-radius: 8px;
            font-weight: 500;
        }

        /* Responsive adjustments: Sidebar becomes standard column on mobile */
        @media (max-width: 767.98px) {
            .admin-sidebar {
                position: relative; /* Remove fixed positioning on small screens */
                width: 100%; /* Take full width on small screens */
                height: auto; /* Adjust height based on content */
                box-shadow: none; /* Remove shadow to blend better */
            }
            main {
                margin-left: 0 !important; /* Remove desktop margin on small screens */
            }
            .navbar-mobile-toggle { /* Ensure this is hidden as it's not needed now */
                display: none !important;
            }
        }

        @media (min-width: 768px) { /* Applies to md and larger screens */
            .main-content-area {
                margin-left: 250px; /* Offset for the fixed sidebar */
            }
            /* Hide the mobile toggle navbar on desktop */
            .navbar-mobile-toggle {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <!-- Mobile Navbar/Toggle is not included as per instruction to ignore mobile changes. -->
        <!-- The layout will now simply stack on small screens. -->

        <div class="container-fluid">
            <div class="row">
                <!-- Admin Sidebar -->
                <!-- The d-md-block class makes it a block element from md breakpoint up, making it visible -->
                <!-- The 'collapse' class is removed to ensure it's always visible on desktop -->
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block admin-sidebar">
                    <div class="position-sticky pt-3">
                        <h2>Admin Panel</h2>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i data-feather="users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_levels.php">
                                    <i data-feather="award"></i> Membership Levels
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="payment_settings.php">
                                    <i data-feather="dollar-sign"></i> Payment Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="transactions.php">
                                    <i data-feather="credit-card"></i> Transactions
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="affiliates.php">
                                    <i data-feather="link"></i> Affiliates
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="helpdesk.php">
                                    <i data-feather="life-buoy"></i> Helpdesk
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="gift_management.php">
                                    <i data-feather="gift"></i> Gift Management
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="thresholds.php">
                                    <i data-feather="sliders"></i> Thresholds
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_admin.php">
                                    <i data-feather="user-check"></i> Membership+
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="teams.php">
                                    <i data-feather="users"></i> Teams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="streams_management.php">
                                    <i data-feather="video"></i> Streams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="cashouts.php" style="color: var(--light-green);">
                                    <i data-feather="dollar-sign"></i> Cashouts
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="email_settings.php">
                                    <i data-feather="mail"></i> Email Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="notifications.php">
                                    <i data-feather="bell"></i> Notifications
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="ai_settings.php">
                                    <i data-feather="cpu"></i> AI Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="niches.php">
                                    <i data-feather="grid"></i> Niches
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../dashboard.php">
                                    <i data-feather="home"></i> Back to Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">
                                    <i data-feather="log-out"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- End Admin Sidebar -->
                
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content-area">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Streams Management</h1>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createStreamModal">
                            <i class="bi bi-plus-circle"></i> New Stream
                        </button>
                    </div>
                    
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?= $_SESSION['error'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['error']); ?>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= $_SESSION['success'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    
                    <?php if ($current_stream): ?>
                        <!-- Stream Detail View -->
                        <div class="card mb-4">
                            <div class="card-header stream-header" style="border-color: <?= htmlspecialchars($current_stream['color_code']) ?>">
                                <h3 class="mb-0">
                                    <?= htmlspecialchars($current_stream['name']) ?>
                                    <span class="badge bg-<?= $current_stream['is_app'] ? 'info' : 'primary' ?> ms-2">
                                        <?= $current_stream['is_app'] ? 'App' : 'Website' ?>
                                    </span>
                                </h3>
                            </div>
                            <div class="card-body">
                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <p><strong>Description:</strong> <?= htmlspecialchars($current_stream['description']) ?></p>
                                        <p><strong>URL:</strong> 
                                            <?= $current_stream['website_url'] ? 
                                                '<a href="'.htmlspecialchars($current_stream['website_url']).'" target="_blank">'.htmlspecialchars($current_stream['website_url']).'</a>' : 
                                                'N/A' ?>
                                        </p>
                                        <p><strong>Tracking Code:</strong> <code><?= htmlspecialchars($current_stream['tracking_code']) ?></code></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p><strong>Niche:</strong> <?= htmlspecialchars($current_stream['niche_name'] ?? 'Not specified') ?></p>
                                        <p><strong>Team:</strong> <?= htmlspecialchars($current_stream['team_name'] ?? 'Not assigned') ?></p>
                                        <p><strong>Owner:</strong> <?= htmlspecialchars($current_stream['owner_name']) ?></p>
                                        <p><strong>Created:</strong> <?= date('M j, Y', strtotime($current_stream['created_at'])) ?></p>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <div class="card stats-card bg-primary text-white">
                                            <div class="card-body text-center">
                                                <h5 class="card-title">Contacts</h5>
                                                <p class="card-text display-4"><?= $current_stream['contact_count'] ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <div class="card stats-card bg-success text-white">
                                            <div class="card-body text-center">
                                                <h5 class="card-title">Cohorts</h5>
                                                <p class="card-text display-4"><?= $current_stream['cohort_count'] ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <div class="card stats-card bg-info text-white">
                                            <div class="card-body text-center">
                                                <h5 class="card-title">Revenue/User</h5>
                                                <p class="card-text display-4"><?= htmlspecialchars($current_stream['currency']) ?> <?= number_format($current_stream['revenue_per_user'], 2) ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <ul class="nav nav-tabs mb-4" id="streamTabs" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="contacts-tab" data-bs-toggle="tab" data-bs-target="#contacts" type="button" role="tab">Contacts</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="cohorts-tab" data-bs-toggle="tab" data-bs-target="#cohorts" type="button" role="tab">Cohorts</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="settings-tab" data-bs-toggle="tab" data-bs-target="#settings" type="button" role="tab">Stream Settings</button>
                                    </li>
                                </ul>
                                
                                <div class="tab-content" id="streamTabsContent">
                                    <!-- Contacts Tab -->
                                    <div class="tab-pane fade show active" id="contacts" role="tabpanel">
                                        <div class="d-flex justify-content-between mb-3">
                                            <h4>Contacts</h4>
                                            <div>
                                                <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#createContactModal">
                                                    <i class="bi bi-plus-circle"></i> New Contact
                                                </button>
                                                <button class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#importContactsModal">
                                                    <i class="bi bi-upload"></i> Import CSV
                                                </button>
                                            </div>
                                        </div>
                                        
                                        <div class="table-responsive">
                                            <table class="table table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Username</th>
                                                        <th>Email</th>
                                                        <th>External ID</th>
                                                        <th>Cohorts</th>
                                                        <th>Created</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php if (empty($stream_contacts)): ?>
                                                        <tr>
                                                            <td colspan="7" class="text-center py-4">No contacts found</td>
                                                        </tr>
                                                    <?php else: ?>
                                                        <?php foreach ($stream_contacts as $contact): ?>
                                                            <tr>
                                                                <td><?= $contact['id'] ?></td>
                                                                <td><?= htmlspecialchars($contact['username']) ?></td>
                                                                <td><?= htmlspecialchars($contact['email']) ?></td>
                                                                <td><?= htmlspecialchars($contact['external_id']) ?></td>
                                                                <td><?= htmlspecialchars($contact['cohort_names']) ?></td>
                                                                <td><?= date('M j, Y', strtotime($contact['created_at'])) ?></td>
                                                                <td>
                                                                    <a href="?stream_id=<?= $current_stream['id'] ?>&contact_id=<?= $contact['id'] ?>#contacts" class="btn btn-sm btn-primary">
                                                                        <i class="bi bi-pencil"></i> Edit
                                                                    </a>
                                                                    <form method="POST" style="display: inline-block;">
                                                                        <input type="hidden" name="stream_id" value="<?= $current_stream['id'] ?>">
                                                                        <input type="hidden" name="contact_id" value="<?= $contact['id'] ?>">
                                                                        <input type="hidden" name="current_tab" value="contacts"> <!-- Keep active tab -->
                                                                        <button type="submit" name="delete_contact" class="btn btn-sm btn-danger" 
                                                                                onclick="return confirm('Are you sure you want to delete this contact?')">
                                                                            <i class="bi bi-trash"></i> Delete
                                                                        </button>
                                                                    </form>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    
                                    <!-- Cohorts Tab -->
                                    <div class="tab-pane fade" id="cohorts" role="tabpanel">
                                        <div class="d-flex justify-content-between mb-3">
                                            <h4>Cohorts</h4>
                                            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#createCohortModal">
                                                <i class="bi bi-plus-circle"></i> New Cohort
                                            </button>
                                        </div>
                                        
                                        <div class="table-responsive">
                                            <table class="table table-striped table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Description</th>
                                                        <th>Members</th>
                                                        <th>Cost/User</th>
                                                        <th>Revenue/User</th>
                                                        <th>Created</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php if (empty($stream_cohorts)): ?>
                                                        <tr>
                                                            <td colspan="8" class="text-center py-4">No cohorts found</td>
                                                        </tr>
                                                    <?php else: ?>
                                                        <?php foreach ($stream_cohorts as $cohort): ?>
                                                            <tr>
                                                                <td><?= $cohort['id'] ?></td>
                                                                <td><?= htmlspecialchars($cohort['name']) ?></td>
                                                                <td><?= htmlspecialchars($cohort['description']) ?></td>
                                                                <td><?= $cohort['member_count'] ?></td>
                                                                <td><?= htmlspecialchars($current_stream['currency']) ?> <?= number_format($cohort['cost_per_user'] ?? 0, 2) ?></td>
                                                                <td><?= htmlspecialchars($current_stream['currency']) ?> <?= number_format($cohort['revenue_per_user'] ?? 0, 2) ?></td>
                                                                <td><?= date('M j, Y', strtotime($cohort['created_at'])) ?></td>
                                                                <td>
                                                                    <a href="?stream_id=<?= $current_stream['id'] ?>&cohort_id=<?= $cohort['id'] ?>#cohorts" class="btn btn-sm btn-primary">
                                                                        <i class="bi bi-pencil"></i> Edit
                                                                    </a>
                                                                    <form method="POST" style="display: inline-block;">
                                                                        <input type="hidden" name="stream_id" value="<?= $current_stream['id'] ?>">
                                                                        <input type="hidden" name="cohort_id" value="<?= $cohort['id'] ?>">
                                                                        <input type="hidden" name="current_tab" value="cohorts"> <!-- Keep active tab -->
                                                                        <button type="submit" name="delete_cohort" class="btn btn-sm btn-danger" 
                                                                                onclick="return confirm('Are you sure you want to delete this cohort? All member associations will be removed.')">
                                                                            <i class="bi bi-trash"></i> Delete
                                                                        </button>
                                                                    </form>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    
                                    <!-- Settings Tab -->
                                    <div class="tab-pane fade" id="settings" role="tabpanel">
                                        <form method="POST">
                                            <input type="hidden" name="stream_id" value="<?= $current_stream['id'] ?>">
                                            <input type="hidden" name="current_tab" value="settings"> <!-- Keep active tab -->
                                            
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label class="form-label">Stream Name</label>
                                                    <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($current_stream['name']) ?>" required>
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="form-label">Color Code</label>
                                                    <div class="input-group">
                                                        <span class="input-group-text color-preview" style="background-color: <?= htmlspecialchars($current_stream['color_code']) ?>"></span>
                                                        <input type="color" class="form-control form-control-color" name="color_code" value="<?= htmlspecialchars($current_stream['color_code']) ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label class="form-label">Niche</label>
                                                    <select class="form-select" name="niche_id">
                                                        <option value="">-- Select Niche --</option>
                                                        <?php foreach ($niches as $niche): ?>
                                                            <option value="<?= $niche['id'] ?>" <?= $niche['id'] == $current_stream['niche_id'] ? 'selected' : '' ?>>
                                                                <?= htmlspecialchars($niche['name']) ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="form-label">Team</label>
                                                    <select class="form-select" name="team_id">
                                                        <option value="">-- Select Team --</option>
                                                        <?php foreach ($teams_list as $team): // Use $teams_list here ?>
                                                            <option value="<?= $team['id'] ?>" <?= $team['id'] == $current_stream['team_id'] ? 'selected' : '' ?>>
                                                                <?= htmlspecialchars($team['name']) ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label class="form-label">Acquisition Cost (<?= htmlspecialchars($current_stream['currency']) ?>)</label>
                                                    <input type="number" class="form-control" name="acquisition_cost" step="0.01" value="<?= htmlspecialchars($current_stream['acquisition_cost']) ?>">
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="form-label">Revenue per User (<?= htmlspecialchars($current_stream['currency']) ?>)</label>
                                                    <input type="number" class="form-control" name="revenue_per_user" step="0.01" value="<?= htmlspecialchars($current_stream['revenue_per_user']) ?>">
                                                </div>
                                            </div>
                                            
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label class="form-label">Marketing Channel</label>
                                                    <input type="text" class="form-control" name="marketing_channel" value="<?= htmlspecialchars($current_stream['marketing_channel']) ?>">
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="form-label">Currency</label>
                                                    <select class="form-select" name="currency">
                                                        <option value="USD" <?= $current_stream['currency'] == 'USD' ? 'selected' : '' ?>>USD</option>
                                                        <option value="EUR" <?= $current_stream['currency'] == 'EUR' ? 'selected' : '' ?>>EUR</option>
                                                        <option value="GBP" <?= $current_stream['currency'] == 'GBP' ? 'selected' : '' ?>>GBP</option>
                                                        <!-- Add more currencies as needed -->
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="mb-3 form-check">
                                                <input type="checkbox" class="form-check-input" name="is_app" id="isApp" <?= $current_stream['is_app'] ? 'checked' : '' ?>>
                                                <label class="form-check-label" for="isApp">This is a mobile app (no website URL needed)</label>
                                            </div>
                                            
                                            <div class="mb-3" id="websiteUrlGroup">
                                                <label class="form-label">Website URL</label>
                                                <input type="url" class="form-control" name="website_url" value="<?= htmlspecialchars($current_stream['website_url']) ?>">
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Description</label>
                                                <textarea class="form-control" name="description" rows="3"><?= htmlspecialchars($current_stream['description']) ?></textarea>
                                            </div>
                                            
                                            <div class="d-flex justify-content-end">
                                                <button type="submit" name="save_stream" class="btn btn-primary">
                                                    <i class="bi bi-save"></i> Save Changes
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <a href="streams_management.php" class="btn btn-secondary mb-4 mt-3">
                            <i class="bi bi-arrow-left"></i> Back to All Streams
                        </a>
                        
                        <!-- Contact Edit/Create Modal -->
                        <div class="modal fade" id="createContactModal" tabindex="-1" aria-labelledby="createContactModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <form method="POST">
                                        <input type="hidden" name="stream_id" value="<?= htmlspecialchars($current_stream['id']) ?>">
                                        <input type="hidden" name="current_tab" value="contacts"> <!-- To return to contacts tab -->
                                        <?php if ($current_contact): ?>
                                            <input type="hidden" name="contact_id" value="<?= htmlspecialchars($current_contact['id']) ?>">
                                        <?php endif; ?>
                                        
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="createContactModalLabel">
                                                <?= $current_contact ? 'Edit Contact' : 'Create New Contact' ?>
                                            </h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label class="form-label">Username</label>
                                                    <input type="text" class="form-control" name="username" value="<?= $current_contact ? htmlspecialchars($current_contact['username']) : '' ?>">
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="form-label">Email</label>
                                                    <input type="email" class="form-control" name="email" value="<?= $current_contact ? htmlspecialchars($current_contact['email']) : '' ?>">
                                                </div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">External ID</label>
                                                <input type="text" class="form-control" name="external_id" value="<?= $current_contact ? htmlspecialchars($current_contact['external_id']) : '' ?>">
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Cohorts</label>
                                                <select class="form-select select2-cohorts" name="cohort_ids[]" multiple="multiple">
                                                    <?php foreach ($stream_cohorts as $cohort): ?>
                                                        <option value="<?= $cohort['id'] ?>" 
                                                            <?= ($current_contact && in_array($cohort['id'], $current_contact['cohort_ids'] ?? [])) ? 'selected' : '' ?>>
                                                            <?= htmlspecialchars($cohort['name']) ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>

                                            <!-- Custom Data Fields -->
                                            <div class="mb-3">
                                                <label class="form-label">Custom Data</label>
                                                <div id="customDataFields">
                                                    <?php 
                                                    $contact_custom_data = ($current_contact && $current_contact['custom_data']) ? json_decode($current_contact['custom_data'], true) : [];
                                                    if (!empty($contact_custom_data)) {
                                                        $field_idx = 0;
                                                        foreach ($contact_custom_data as $key => $value): ?>
                                                            <div class="custom-data-field row g-2">
                                                                <div class="col-md-5">
                                                                    <input type="text" class="form-control" name="custom_data[<?= $field_idx ?>][key]" 
                                                                            value="<?= htmlspecialchars($key) ?>" placeholder="Field name">
                                                                </div>
                                                                <div class="col-md-5">
                                                                    <input type="text" class="form-control" name="custom_data[<?= $field_idx ?>][value]" 
                                                                            value="<?= htmlspecialchars($value) ?>" placeholder="Field value">
                                                                </div>
                                                                <div class="col-md-2">
                                                                    <button type="button" class="btn btn-danger w-100 remove-field">
                                                                        <i class="bi bi-trash"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        <?php 
                                                            $field_idx++;
                                                        endforeach;
                                                    } else {
                                                        // Add one empty field by default if no custom data exists
                                                        echo '<div class="custom-data-field row g-2">
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control" name="custom_data[0][key]" placeholder="Field name">
                                                            </div>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control" name="custom_data[0][value]" placeholder="Field value">
                                                            </div>
                                                            <div class="col-md-2">
                                                                <button type="button" class="btn btn-danger w-100 remove-field">
                                                                    <i class="bi bi-trash"></i>
                                                                </button>
                                                            </div>
                                                        </div>';
                                                    }
                                                    ?>
                                                </div>
                                                <div class="custom-data-actions mt-2">
                                                    <button type="button" id="addCustomField" class="btn btn-sm btn-secondary">
                                                        <i class="bi bi-plus-circle"></i> Add Custom Field
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" name="save_contact" class="btn btn-primary">
                                                <?= $current_contact ? 'Update' : 'Create' ?> Contact
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <!-- Cohort Edit/Create Modal -->
                        <div class="modal fade" id="createCohortModal" tabindex="-1" aria-labelledby="createCohortModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="POST">
                                        <input type="hidden" name="stream_id" value="<?= htmlspecialchars($current_stream['id']) ?>">
                                        <input type="hidden" name="current_tab" value="cohorts"> <!-- To return to cohorts tab -->
                                        <?php if ($current_cohort): ?>
                                            <input type="hidden" name="cohort_id" value="<?= htmlspecialchars($current_cohort['id']) ?>">
                                        <?php endif; ?>
                                        
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="createCohortModalLabel">
                                                <?= $current_cohort ? 'Edit Cohort' : 'Create New Cohort' ?>
                                            </h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label class="form-label">Cohort Name</label>
                                                <input type="text" class="form-control" name="name" 
                                                       value="<?= $current_cohort ? htmlspecialchars($current_cohort['name']) : '' ?>" required>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Description</label>
                                                <textarea class="form-control" name="description" rows="3"><?= 
                                                    $current_cohort ? htmlspecialchars($current_cohort['description']) : '' ?></textarea>
                                            </div>
                                            
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label class="form-label">Cost per User (<?= htmlspecialchars($current_stream['currency']) ?>)</label>
                                                    <input type="number" class="form-control" name="cost_per_user" step="0.01" 
                                                           value="<?= $current_cohort ? htmlspecialchars($current_cohort['cost_per_user']) : '' ?>">
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="form-label">Revenue per User (<?= htmlspecialchars($current_stream['currency']) ?>)</label>
                                                    <input type="number" class="form-control" name="revenue_per_user" step="0.01" 
                                                           value="<?= $current_cohort ? htmlspecialchars($current_cohort['revenue_per_user']) : '' ?>">
                                                </div>
                                            </div>
                                            
                                            <?php if ($current_cohort && !empty($current_cohort['members'])): ?>
                                                <div class="mb-3">
                                                    <h6>Current Members (<?= count($current_cohort['members']) ?>)</h6>
                                                    <ul class="list-group">
                                                        <?php foreach ($current_cohort['members'] as $member): ?>
                                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                                <?= htmlspecialchars($member['username'] ?: $member['email']) ?>
                                                                <span class="badge bg-primary rounded-pill">
                                                                    <?= date('M j, Y', strtotime($member['created_at'])) ?>
                                                                </span>
                                                            </li>
                                                        <?php endforeach; ?>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" name="save_cohort" class="btn btn-primary">
                                                <?= $current_cohort ? 'Update' : 'Create' ?> Cohort
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <!-- Import Contacts Modal -->
                        <div class="modal fade" id="importContactsModal" tabindex="-1" aria-labelledby="importContactsModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="POST" enctype="multipart/form-data">
                                        <input type="hidden" name="import_stream_id" value="<?= htmlspecialchars($current_stream['id']) ?>">
                                        <input type="hidden" name="current_tab" value="contacts"> <!-- To return to contacts tab -->
                                        
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="importContactsModalLabel">Import Contacts from CSV</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label class="form-label">CSV File</label>
                                                <input type="file" class="form-control" name="csv_file" accept=".csv" required>
                                                <small class="text-muted">CSV should contain headers: username, email, external_id and any custom fields</small>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Assign to Cohort (optional)</label>
                                                <select class="form-select" name="import_cohort_id">
                                                    <option value="">-- Select Cohort --</option>
                                                    <?php foreach ($stream_cohorts as $cohort): ?>
                                                        <option value="<?= $cohort['id'] ?>"><?= htmlspecialchars($cohort['name']) ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            
                                            <div class="alert alert-info">
                                                <h6>CSV Format Example:</h6>
                                                <pre>username,email,external_id,custom_field1,custom_field2
john_doe,john@example.com,12345,value1,value2
jane_smith,jane@example.com,67890,valueA,valueB</pre>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" name="import_contacts" class="btn btn-primary">
                                                <i class="bi bi-upload"></i> Import Contacts
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    <?php else: ?>
                        <!-- Stream List View -->
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">All Streams</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Type</th>
                                                <th>Niche</th>
                                                <th>Team</th>
                                                <th>Contacts</th>
                                                <th>Cohorts</th>
                                                <th>Owner</th>
                                                <th>Created</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($streams)): ?>
                                                <tr>
                                                    <td colspan="10" class="text-center py-4">No streams found</td>
                                                </tr>
                                            <?php else: ?>
                                                <?php foreach ($streams as $stream): ?>
                                                <tr>
                                                    <td><?= $stream['id'] ?></td>
                                                    <td>
                                                        <a href="?stream_id=<?= $stream['id'] ?>" class="text-decoration-none">
                                                            <?= htmlspecialchars($stream['name']) ?>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-<?= $stream['is_app'] ? 'info' : 'primary' ?>">
                                                            <?= $stream['is_app'] ? 'App' : 'Website' ?>
                                                        </span>
                                                    </td>
                                                    <td><?= htmlspecialchars($stream['niche_name'] ?? 'N/A') ?></td>
                                                    <td><?= htmlspecialchars($stream['team_name'] ?? 'N/A') ?></td>
                                                    <td><?= $stream['contact_count'] ?></td>
                                                    <td><?= $stream['cohort_count'] ?></td>
                                                    <td><?= htmlspecialchars($stream['owner_name']) ?></td>
                                                    <td><?= date('M j, Y', strtotime($stream['created_at'])) ?></td>
                                                    <td>
                                                        <a href="?stream_id=<?= $stream['id'] ?>" class="btn btn-sm btn-primary">
                                                            <i class="bi bi-eye"></i> View
                                                        </a>
                                                        <form method="POST" style="display: inline-block;">
                                                            <input type="hidden" name="stream_id" value="<?= $stream['id'] ?>">
                                                            <button type="submit" name="delete_stream" class="btn btn-sm btn-danger" 
                                                                    onclick="return confirm('Are you sure you want to delete this stream and ALL its data?')">
                                                                <i class="bi bi-trash"></i> Delete
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Create Stream Modal (Always present at the bottom of the main content part) -->
                    <div class="modal fade" id="createStreamModal" tabindex="-1" aria-labelledby="createStreamModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form method="POST">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="createStreamModalLabel">Create New Stream</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label class="form-label">Stream Name</label>
                                            <input type="text" class="form-control" name="name" required>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Color Code</label>
                                            <div class="input-group">
                                                <span class="input-group-text color-preview" style="background-color: #3366ff;"></span>
                                                <input type="color" class="form-control form-control-color" name="color_code" value="#3366ff">
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label class="form-label">Niche</label>
                                                <select class="form-select" name="niche_id">
                                                    <option value="">-- Select Niche --</option>
                                                    <?php foreach ($niches as $niche): ?>
                                                        <option value="<?= $niche['id'] ?>"><?= htmlspecialchars($niche['name']) ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">Team</label>
                                                <select class="form-select" name="team_id">
                                                    <option value="">-- Select Team --</option>
                                                    <?php foreach ($teams_list as $team): // Use $teams_list here ?>
                                                        <option value="<?= $team['id'] ?>"><?= htmlspecialchars($team['name']) ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label class="form-label">Acquisition Cost (USD)</label>
                                                <input type="number" class="form-control" name="acquisition_cost" step="0.01" value="0.00">
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">Revenue per User (USD)</label>
                                                <input type="number" class="form-control" name="revenue_per_user" step="0.01" value="0.00">
                                            </div>
                                        </div>
                                        
                                        <div class="mb-3 form-check">
                                            <input type="checkbox" class="form-check-input" name="is_app" id="createIsApp">
                                            <label class="form-check-label" for="createIsApp">This is a mobile app (no website URL needed)</label>
                                        </div>
                                        
                                        <div class="mb-3" id="createWebsiteUrlGroup">
                                            <label class="form-label">Website URL</label>
                                            <input type="url" class="form-control" name="website_url">
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Description</label>
                                            <textarea class="form-control" name="description" rows="3"></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" name="save_stream" class="btn btn-primary">Create Stream</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </main>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Feather Icons
            feather.replace();

            // Initialize Select2 for cohorts in contact modal
            $('#createContactModal .select2-cohorts, .tab-pane#contacts .select2-cohorts').select2({
                theme: 'bootstrap4',
                placeholder: "Select cohorts",
                dropdownParent: $('#createContactModal') // Important for modals
            });
            // Re-initialize select2 for existing elements if needed after DOM updates
            $(document).on('shown.bs.tab', 'a[data-bs-toggle="tab"]', function (e) {
                $('.select2-cohorts', e.target.closest('.tab-pane')).select2({
                    theme: 'bootstrap4',
                    placeholder: "Select cohorts",
                    dropdownParent: e.target.closest('.modal') || $(document.body)
                });
            });


            // Toggle website URL field based on app checkbox in Stream Settings tab
            const isAppCheckbox = document.getElementById('isApp');
            const websiteUrlGroup = document.getElementById('websiteUrlGroup');
            
            if (isAppCheckbox && websiteUrlGroup) {
                isAppCheckbox.addEventListener('change', function() {
                    websiteUrlGroup.style.display = this.checked ? 'none' : 'block';
                });
                // Initial state on load
                websiteUrlGroup.style.display = isAppCheckbox.checked ? 'none' : 'block';
            }
            
            // Toggle website URL field based on app checkbox in Create Stream Modal
            const createIsApp = document.getElementById('createIsApp');
            const createWebsiteUrlGroup = document.getElementById('createWebsiteUrlGroup');
            
            if (createIsApp && createWebsiteUrlGroup) {
                createIsApp.addEventListener('change', function() {
                    createWebsiteUrlGroup.style.display = this.checked ? 'none' : 'block';
                });
                // Initial state on load
                createWebsiteUrlGroup.style.display = createIsApp.checked ? 'none' : 'block';
            }
            
            // Dynamic custom fields functionality in Contact modal
            let fieldCounter = 0; // Initialize for new fields
            const customDataFieldsContainer = document.getElementById('customDataFields');

            // Set initial fieldCounter based on existing fields when modal opens
            $('#createContactModal').on('show.bs.modal', function () {
                fieldCounter = customDataFieldsContainer.querySelectorAll('.custom-data-field').length;
                if (fieldCounter === 0) { // If no fields, add one empty
                    addEmptyCustomField();
                }
            });

            function addEmptyCustomField() {
                const newField = document.createElement('div');
                newField.className = 'custom-data-field row g-2';
                newField.innerHTML = `
                    <div class="col-md-5">
                        <input type="text" class="form-control" name="custom_data[${fieldCounter}][key]" placeholder="Field name">
                    </div>
                    <div class="col-md-5">
                        <input type="text" class="form-control" name="custom_data[${fieldCounter}][value]" placeholder="Field value">
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-danger w-100 remove-field">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                `;
                customDataFieldsContainer.appendChild(newField);
                fieldCounter++;
            }
            
            document.getElementById('addCustomField')?.addEventListener('click', addEmptyCustomField);
            
            // Remove custom field handler
            document.addEventListener('click', function(e) {
                if (e.target.classList.contains('remove-field') || e.target.closest('.remove-field')) {
                    (e.target.closest('.remove-field') || e.target).closest('.custom-data-field').remove();
                }
            });
            
            // Initialize color preview for Create Stream Modal
            const createColorInput = document.querySelector('#createStreamModal input[name="color_code"]');
            const createColorPreview = document.querySelector('#createStreamModal .color-preview');
            if (createColorInput && createColorPreview) {
                createColorInput.addEventListener('input', function() {
                    createColorPreview.style.backgroundColor = this.value;
                });
            }

            // Initialize color preview for Stream Settings tab
            const streamSettingsColorInput = document.querySelector('#settings input[name="color_code"]');
            const streamSettingsColorPreview = document.querySelector('#settings .color-preview');
            if (streamSettingsColorInput && streamSettingsColorPreview) {
                streamSettingsColorInput.addEventListener('input', function() {
                    streamSettingsColorPreview.style.backgroundColor = this.value;
                });
            }

            // Handle default tab selection when opening stream details
            const currentHash = window.location.hash;
            if (currentHash && document.getElementById('streamTabs')) {
                const triggerTab = document.querySelector(`#streamTabs button[data-bs-target="${currentHash}"]`);
                if (triggerTab) {
                    new bootstrap.Tab(triggerTab).show();
                }
            }
        });
    </script>
</body>
</html>
