<?php
// admin/affiliates.php
require_once '../includes/db.php';

// Admin verification
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit;
}

// Define the base URL for notifications
// Ensure this matches your actual application's base URL
$baseURL = 'https://earndos.com/io/';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_rewards'])) {
        // Update affiliate rewards
        foreach ($_POST['percentage'] as $membership_id => $percentage) {
            $percentage = floatval($percentage);
            $membership_id = intval($membership_id);
           
            $stmt = $pdo->prepare("REPLACE INTO affiliate_rewards (membership_id, percentage) VALUES (?, ?)");
            $stmt->execute([$membership_id, $percentage]);
        }
       
        $_SESSION['success'] = "Affiliate rewards updated successfully";
    } elseif (isset($_POST['update_threshold'])) {
        // Update withdrawal threshold
        $threshold = floatval($_POST['threshold']);
       
        $stmt = $pdo->prepare("REPLACE INTO config (setting, value) VALUES ('affiliate_threshold', ?)");
        $stmt->execute([$threshold]);
       
        $_SESSION['success'] = "Withdrawal threshold updated";
    } elseif (isset($_POST['update_cashout_status'])) {
        // Update cashout status
        $cashout_id = intval($_POST['cashout_id']);
        $status = $_POST['status'];
        $comments = trim($_POST['comments']);
       
        $stmt = $pdo->prepare("UPDATE affiliate_cashouts SET status = ?, comments = ?, processed_date = NOW() WHERE id = ?");
        $stmt->execute([$status, $comments, $cashout_id]);
       
        // Send notification email if status changed to processed/paid/revoked
        if (in_array($status, ['processed', 'paid', 'revoked'])) {
            $stmt = $pdo->prepare("SELECT u.email, u.id FROM affiliate_cashouts ac JOIN users u ON ac.user_id = u.id WHERE ac.id = ?");
            $stmt->execute([$cashout_id]);
            $cashout_info = $stmt->fetch(PDO::FETCH_ASSOC);
           
            if ($cashout_info) {
                $email = $cashout_info['email'];
                $user_id = $cashout_info['id'];
                $subject = "Your cashout request has been $status";
                $message = "Your cashout request #{$cashout_id} has been updated to status: {$status}";
                if (!empty($comments)) {
                    $message .= "\n\nAdmin comments: {$comments}";
                }
                
                // Construct the related URL for the notification
                $related_url = $baseURL . 'cashout.php';

                // Send email using your email function (placeholder: mail() or PHPMailer)
                // Example using PHP mail():
                // mail($email, $subject, $message, "From: noreply@yourdomain.com");

                // Insert notification
                $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type, related_id, related_url) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$user_id, $subject, $message, 'affiliate', $cashout_id, $related_url]);
            }
        }
       
        $_SESSION['success'] = "Cashout status updated";
    }
   
    header('Location: affiliates.php');
    exit;
}

// Get all membership levels with affiliate rewards
$stmt = $pdo->query("
    SELECT ml.id, ml.name, ml.promo_price, ar.percentage
    FROM membership_levels ml
    LEFT JOIN affiliate_rewards ar ON ml.id = ar.membership_id
    ORDER BY ml.promo_price DESC
");
$membership_levels = $stmt->fetchAll();

// Get withdrawal threshold
$stmt = $pdo->query("SELECT value FROM config WHERE setting = 'affiliate_threshold'");
$threshold = $stmt->fetchColumn() ?? 50;

// Get pending cashouts
$stmt = $pdo->query("
    SELECT ac.*, u.username, u.email,
            up.method, up.paypal_email, up.bank_name, up.account_name, up.account_number, up.usdt_wallet
    FROM affiliate_cashouts ac
    JOIN users u ON ac.user_id = u.id
    LEFT JOIN user_payment_methods up ON u.id = up.user_id
    WHERE ac.status = 'pending'
    ORDER BY ac.request_date DESC
");
$pending_cashouts = $stmt->fetchAll();

// Get all cashout history
$stmt = $pdo->query("
    SELECT ac.*, u.username, u.email
    FROM affiliate_cashouts ac
    JOIN users u ON ac.user_id = u.id
    WHERE ac.status != 'pending'
    ORDER BY ac.processed_date DESC
    LIMIT 100
");
$cashout_history = $stmt->fetchAll();

// Get top affiliates
$stmt = $pdo->query("
    SELECT u.id, u.username, u.email,
            SUM(ae.amount) as total_earnings,
            COUNT(ar.id) as total_referrals
    FROM users u
    LEFT JOIN affiliate_earnings ae ON u.id = ae.user_id
    LEFT JOIN affiliate_referrals ar ON u.id = ar.referrer_id
    GROUP BY u.id
    HAVING total_earnings > 0
    ORDER BY total_earnings DESC
    LIMIT 50
");
$top_affiliates = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Affiliate Management | Admin Panel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
          integrity="sha512-1ycn6IcaQQ40ZefMdHjAcUwaGDvPwdOaUcsU5XrU+pL87B7fC3J0P2Kqj1Z5M5YqD65B2L52B7y42j5P5c+A=="
          crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>

    <style>
        /* Define your color variables */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
            --light-green: #90EE90; /* Light green color */
        }

        /* Body and main layout styling */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--gray-100);
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer if added */
        }
        .site-wrapper { /* New wrapper for sticky footer logic */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container-fluid {
            padding: 0; /* Remove padding to make sidebar stick to edge */
            flex-grow: 1; /* Allow container-fluid to take up remaining height */
        }
        .row {
            margin: 0; /* Remove row margins to prevent unwanted space */
            flex-grow: 1;
        }
        /* Main content area */
        main {
            padding: 20px !important; /* Important to override Bootstrap default */
            background-color: var(--gray-100); /* Content area background */
            flex-grow: 1;
        }
        .d-flex.justify-content-between.flex-wrap.flex-md-nowrap.align-items-center {
            padding-top: 1.5rem !important; /* Bootstrap pt-3 */
            padding-bottom: 1rem !important; /* Bootstrap pb-2 */
            margin-bottom: 1.5rem !important; /* Bootstrap mb-3 */
        }

        /* Admin Sidebar basic styling */
        .admin-sidebar {
            background-color: var(--dark);
            color: var(--white);
            padding: 20px;
            /* Fixed position for desktop view */
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: 250px; /* Fixed width for the sidebar */
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .admin-sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary);
            font-size: 1.8rem;
            font-weight: 700;
        }
        .admin-sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .admin-sidebar ul li {
            margin-bottom: 10px;
        }
        .admin-sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--gray-300);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        .admin-sidebar ul li a:hover,
        .admin-sidebar ul li a.active {
            background-color: var(--gray-700);
            color: var(--white);
        }
        .admin-sidebar ul li a i {
            width: 20px;
            height: 20px;
        }

        /* Specific styles for affiliates.php content */
        .table-container {
            overflow-x: auto;
        }
        .badge-paid { background-color: #28a745; }
        .badge-pending { background-color: #ffc107; color: #000; }
        .badge-revoked { background-color: #dc3545; }
        .badge-processed { background-color: #17a2b8; }
        .payment-method {
            font-weight: bold;
        }
        .payment-details {
            font-size: 0.9rem;
            color: #666;
        }
        /* Card styles */
        .card {
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05); /* Soft shadow */
        }
        .card-body {
            padding: 25px;
        }
        .form-control, .form-select {
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            padding: 10px 15px;
            color: var(--gray-800);
            background-color: var(--white);
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(58, 195, 184, 0.25);
        }
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: background-color 0.2s, border-color 0.2s;
        }
        .btn-primary:hover {
            background-color: #2da89e;
            border-color: #2da89e;
        }
        .alert {
            border-radius: 8px;
            font-weight: 500;
        }

        /* Responsive adjustments: Sidebar becomes standard column on mobile */
        @media (max-width: 767.98px) {
            .admin-sidebar {
                position: relative; /* Remove fixed positioning on small screens */
                width: 100%; /* Take full width on small screens */
                height: auto; /* Adjust height based on content */
                box-shadow: none; /* Remove shadow to blend better */
            }
            main {
                margin-left: 0 !important; /* Remove desktop margin on small screens */
            }
            .navbar-mobile-toggle { /* Ensure this is hidden as it's not needed now */
                display: none !important;
            }
        }

        @media (min-width: 768px) { /* Applies to md and larger screens */
            .main-content-area {
                margin-left: 250px; /* Offset for the fixed sidebar */
            }
            /* Hide the mobile toggle navbar on desktop */
            .navbar-mobile-toggle {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <div class="container-fluid">
            <div class="row">
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block admin-sidebar">
                    <div class="position-sticky pt-3">
                        <h2>Admin Panel</h2>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i data-feather="users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_levels.php">
                                    <i data-feather="award"></i> Membership Levels
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="payment_settings.php">
                                    <i data-feather="dollar-sign"></i> Payment Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="affiliates.php">
                                    <i data-feather="link"></i> Affiliates
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="transactions.php">
                                    <i data-feather="credit-card"></i> Transactions
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="helpdesk.php">
                                    <i data-feather="life-buoy"></i> Helpdesk
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="gift_management.php">
                                    <i data-feather="gift"></i> Gift Management
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="thresholds.php">
                                    <i data-feather="sliders"></i> Thresholds
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_admin.php">
                                    <i data-feather="user-check"></i> Membership+
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="teams.php">
                                    <i data-feather="users"></i> Teams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="streams_management.php">
                                    <i data-feather="video"></i> Streams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="cashouts.php" style="color: var(--light-green);">
                                    <i data-feather="dollar-sign"></i> Cashouts
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="email_settings.php">
                                    <i data-feather="mail"></i> Email Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="notifications.php">
                                    <i data-feather="bell"></i> Notifications
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="ai_settings.php">
                                    <i data-feather="cpu"></i> AI Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="niches.php">
                                    <i data-feather="grid"></i> Niches
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../dashboard.php">
                                    <i data-feather="home"></i> Back to Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">
                                    <i data-feather="log-out"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content-area">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Affiliate Management</h1>
                    </div>
                   
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= $_SESSION['success'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                   
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title">Affiliate Rewards</h5>
                                </div>
                                <div class="card-body">
                                    <form method="POST">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Membership Level</th>
                                                    <th>Monthly Price</th>
                                                    <th>Reward %</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($membership_levels as $level): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars($level['name']) ?></td>
                                                    <td>$<?= number_format($level['promo_price'], 2) ?></td>
                                                    <td>
                                                        <input type="number" name="percentage[<?= $level['id'] ?>]"
                                                               value="<?= $level['percentage'] ?? 0 ?>" min="0" max="100" step="0.1"
                                                               class="form-control form-control-sm" style="width: 80px;">
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                        <button type="submit" name="update_rewards" class="btn btn-primary btn-sm">Update Rewards</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                       
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title">Withdrawal Settings</h5>
                                </div>
                                <div class="card-body">
                                    <form method="POST" class="row g-3">
                                        <div class="col-md-8">
                                            <label for="threshold" class="form-label">Minimum Withdrawal Amount</label>
                                            <div class="input-group">
                                                <span class="input-group-text">$</span>
                                                <input type="number" class="form-control" id="threshold" name="threshold"
                                                       value="<?= $threshold ?>" min="10" step="0.01" required>
                                            </div>
                                        </div>
                                        <div class="col-md-4 d-flex align-items-end">
                                            <button type="submit" name="update_threshold" class="btn btn-primary">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="card-title">Pending Cashout Requests</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-container">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>User</th>
                                            <th>Amount</th>
                                            <th>Payment Method</th>
                                            <th>Request Date</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($pending_cashouts as $cashout): ?>
                                        <tr>
                                            <td><?= $cashout['id'] ?></td>
                                            <td>
                                                <?= htmlspecialchars($cashout['username']) ?><br>
                                                <small><?= htmlspecialchars($cashout['email']) ?></small>
                                            </td>
                                            <td>$<?= number_format($cashout['amount'], 2) ?></td>
                                            <td>
                                                <span class="payment-method text-uppercase"><?= $cashout['method'] ?></span>
                                                <div class="payment-details">
                                                    <?php if ($cashout['method'] === 'paypal'): ?>
                                                        <?= htmlspecialchars($cashout['paypal_email']) ?>
                                                    <?php elseif ($cashout['method'] === 'bank'): ?>
                                                        <?= htmlspecialchars($cashout['bank_name']) ?><br>
                                                        <?= htmlspecialchars($cashout['account_name']) ?><br>
                                                        <?= htmlspecialchars($cashout['account_number']) ?>
                                                    <?php elseif ($cashout['method'] === 'usdt'): ?>
                                                        <?= htmlspecialchars($cashout['usdt_wallet']) ?>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td><?= date('M j, Y', strtotime($cashout['request_date'])) ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                                        data-bs-target="#processCashoutModal"
                                                        data-id="<?= $cashout['id'] ?>">
                                                    Process
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                   
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="card-title">Cashout History</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-container">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>User</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Request Date</th>
                                            <th>Processed Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($cashout_history as $cashout): ?>
                                        <tr>
                                            <td><?= $cashout['id'] ?></td>
                                            <td>
                                                <?= htmlspecialchars($cashout['username']) ?><br>
                                                <small><?= htmlspecialchars($cashout['email']) ?></small>
                                            </td>
                                            <td>$<?= number_format($cashout['amount'], 2) ?></td>
                                            <td>
                                                <span class="badge badge-<?= strtolower($cashout['status']) ?>">
                                                    <?= ucfirst($cashout['status']) ?>
                                                </span>
                                            </td>
                                            <td><?= date('M j, Y', strtotime($cashout['request_date'])) ?></td>
                                            <td><?= $cashout['processed_date'] ? date('M j, Y', strtotime($cashout['processed_date'])) : '-' ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                   
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Top Affiliates</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-container">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Total Earnings</th>
                                            <th>Total Referrals</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($top_affiliates as $affiliate): ?>
                                        <tr>
                                            <td>
                                                <?= htmlspecialchars($affiliate['username']) ?><br>
                                                <small><?= htmlspecialchars($affiliate['email']) ?></small>
                                            </td>
                                            <td>$<?= number_format($affiliate['total_earnings'], 2) ?></td>
                                            <td><?= $affiliate['total_referrals'] ?></td>
                                            <td>
                                                <a href="user_affiliates.php?id=<?= $affiliate['id'] ?>" class="btn btn-sm btn-info">
                                                    View Details
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div> <div class="modal fade" id="processCashoutModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="cashout_id" id="cashout_id">
                    <div class="modal-header">
                        <h5 class="modal-title">Process Cashout Request</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="processed">Processed</option>
                                <option value="paid">Paid</option>
                                <option value="revoked">Revoked</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="comments" class="form-label">Comments</label>
                            <textarea class="form-control" id="comments" name="comments" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_cashout_status" class="btn btn-primary">Update Status</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize Feather Icons
        feather.replace();

        // Handle process cashout modal
        const processModal = document.getElementById('processCashoutModal');
        if (processModal) {
            processModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                const cashoutId = button.getAttribute('data-id');
                document.getElementById('cashout_id').value = cashoutId;
            });
        }
    </script>
</body>
</html>