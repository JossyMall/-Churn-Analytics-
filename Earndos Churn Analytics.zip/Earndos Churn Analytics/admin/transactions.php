<?php
// admin/transactions.php
require_once '../includes/db.php';

// Admin verification
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit;
}

// Handle filters
$filters = [];
$where = [];
$params = [];

// Payment method filter
if (!empty($_GET['method']) && in_array($_GET['method'], ['paypal', 'flutterwave', 'usdt', 'bank'])) {
    $where[] = "t.payment_method = ?";
    $params[] = $_GET['method'];
    $filters['method'] = $_GET['method'];
}

// Status filter
if (!empty($_GET['status']) && in_array($_GET['status'], ['pending', 'completed', 'failed', 'refunded'])) {
    $where[] = "t.status = ?";
    $params[] = $_GET['status'];
    $filters['status'] = $_GET['status'];
}

// Date range filter
if (!empty($_GET['date_from'])) {
    $where[] = "t.created_at >= ?";
    $params[] = $_GET['date_from'];
    $filters['date_from'] = $_GET['date_from'];
}

if (!empty($_GET['date_to'])) {
    $where[] = "t.created_at <= ?";
    $params[] = $_GET['date_to'] . ' 23:59:59';
    $filters['date_to'] = $_GET['date_to'];
}

// Subscription type filter
if (!empty($_GET['type']) && in_array($_GET['type'], ['monthly', 'yearly'])) {
    $where[] = "t.is_yearly = ?";
    $params[] = ($_GET['type'] === 'yearly') ? 1 : 0;
    $filters['type'] = $_GET['type'];
}

// Build query
$query = "SELECT t.*, u.username, u.email, ml.name as membership_name 
           FROM transactions t
           JOIN users u ON t.user_id = u.id
           LEFT JOIN membership_levels ml ON t.membership_id = ml.id";

if (!empty($where)) {
    $query .= " WHERE " . implode(" AND ", $where);
}

$query .= " ORDER BY t.created_at DESC LIMIT 500";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$transactions = $stmt->fetchAll();

// Get stats
$statsQuery = "SELECT 
    COUNT(*) as total_count,
    SUM(amount) as total_amount,
    SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as completed_amount,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count,
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_count,
    SUM(CASE WHEN status = 'refunded' THEN 1 ELSE 0 END) as refunded_count
    FROM transactions";

if (!empty($where)) {
    $statsQuery .= " WHERE " . implode(" AND ", $where);
}

$stmt = $pdo->prepare($statsQuery);
$stmt->execute($params);
$stats = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transactions | Admin Panel</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Font Awesome for consistent icons across pages -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
            xintegrity="sha512-1ycn6IcaQQ40ZefMdHjAcUwaGDvPwdOaUcsU5XrU+pL87B7fC3J0P2Kqj1Z5M5YqD65B2L52B7y42j5P5c+A=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Feather Icons for new tab icons -->
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>

    <style>
        /* Define your color variables */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
            --light-green: #90EE90; /* Light green color */
        }

        /* Body and main layout styling */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--gray-100);
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer if added */
        }
        .site-wrapper { /* New wrapper for sticky footer logic */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container-fluid {
            padding: 0; /* Remove padding to make sidebar stick to edge */
            flex-grow: 1; /* Allow container-fluid to take up remaining height */
        }
        .row {
            margin: 0; /* Remove row margins to prevent unwanted space */
            flex-grow: 1;
        }
        /* Main content area */
        main {
            padding: 20px !important; /* Important to override Bootstrap default */
            background-color: var(--gray-100); /* Content area background */
            flex-grow: 1;
        }
        .d-flex.justify-content-between.flex-wrap.flex-md-nowrap.align-items-center {
            padding-top: 1.5rem !important; /* Bootstrap pt-3 */
            padding-bottom: 1rem !important; /* Bootstrap pb-2 */
            margin-bottom: 1.5rem !important; /* Bootstrap mb-3 */
        }

        /* Admin Sidebar basic styling */
        .admin-sidebar {
            background-color: var(--dark);
            color: var(--white);
            padding: 20px;
            /* Fixed position for desktop view */
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: 250px; /* Fixed width for the sidebar */
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .admin-sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary);
            font-size: 1.8rem;
            font-weight: 700;
        }
        .admin-sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .admin-sidebar ul li {
            margin-bottom: 10px;
        }
        .admin-sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--gray-300);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        .admin-sidebar ul li a:hover,
        .admin-sidebar ul li a.active {
            background-color: var(--gray-700);
            color: var(--white);
        }
        .admin-sidebar ul li a i {
            width: 20px;
            height: 20px;
        }

        /* Specific styles for transactions.php content */
        .badge-pending { background-color: #ffc107; color: #000; }
        .badge-completed { background-color: #28a745; }
        .badge-failed { background-color: #dc3545; }
        .badge-refunded { background-color: #6c757d; }
        .filter-card {
            background-color: #f8f9fa;
        }
        .stat-card {
            border-left: 4px solid #0d6efd;
        }
        .transaction-row:hover {
            background-color: #f8f9fa;
        }
        /* Card styles */
        .card {
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05); /* Soft shadow */
        }
        .card-body {
            padding: 25px;
        }
        .form-control, .form-select {
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            padding: 10px 15px;
            color: var(--gray-800);
            background-color: var(--white);
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(58, 195, 184, 0.25);
        }
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: background-color 0.2s, border-color 0.2s;
        }
        .btn-primary:hover {
            background-color: #2da89e;
            border-color: #2da89e;
        }
        .alert {
            border-radius: 8px;
            font-weight: 500;
        }

        /* Responsive adjustments: Sidebar becomes standard column on mobile */
        @media (max-width: 767.98px) {
            .admin-sidebar {
                position: relative; /* Remove fixed positioning on small screens */
                width: 100%; /* Take full width on small screens */
                height: auto; /* Adjust height based on content */
                box-shadow: none; /* Remove shadow to blend better */
            }
            main {
                margin-left: 0 !important; /* Remove desktop margin on small screens */
            }
            .navbar-mobile-toggle { /* Ensure this is hidden as it's not needed now */
                display: none !important;
            }
        }

        @media (min-width: 768px) { /* Applies to md and larger screens */
            .main-content-area {
                margin-left: 250px; /* Offset for the fixed sidebar */
            }
            /* Hide the mobile toggle navbar on desktop */
            .navbar-mobile-toggle {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <!-- Mobile Navbar/Toggle is not included as per instruction to ignore mobile changes. -->
        <!-- The layout will now simply stack on small screens. -->

        <div class="container-fluid">
            <div class="row">
                <!-- Admin Sidebar -->
                <!-- The d-md-block class makes it a block element from md breakpoint up, making it visible -->
                <!-- The 'collapse' class is removed to ensure it's always visible on desktop -->
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block admin-sidebar">
                    <div class="position-sticky pt-3">
                        <h2>Admin Panel</h2>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i data-feather="users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_levels.php">
                                    <i data-feather="award"></i> Membership Levels
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="payment_settings.php">
                                    <i data-feather="dollar-sign"></i> Payment Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="transactions.php">
                                    <i data-feather="credit-card"></i> Transactions
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="affiliates.php">
                                    <i data-feather="link"></i> Affiliates
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="helpdesk.php">
                                    <i data-feather="life-buoy"></i> Helpdesk
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="gift_management.php">
                                    <i data-feather="gift"></i> Gift Management
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="thresholds.php">
                                    <i data-feather="sliders"></i> Thresholds
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_admin.php">
                                    <i data-feather="user-check"></i> Membership+
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="teams.php">
                                    <i data-feather="users"></i> Teams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="streams_management.php">
                                    <i data-feather="video"></i> Streams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="cashouts.php" style="color: var(--light-green);">
                                    <i data-feather="dollar-sign"></i> Cashouts
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="email_settings.php">
                                    <i data-feather="mail"></i> Email Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="notifications.php">
                                    <i data-feather="bell"></i> Notifications
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="ai_settings.php">
                                    <i data-feather="cpu"></i> AI Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="niches.php">
                                    <i data-feather="grid"></i> Niches
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../dashboard.php">
                                    <i data-feather="home"></i> Back to Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">
                                    <i data-feather="log-out"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- End Admin Sidebar -->
                
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content-area">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Transaction History</h1>
                    </div>
                    
                    <div class="card filter-card mb-4">
                        <div class="card-body">
                            <form method="GET" class="row g-3">
                                <div class="col-md-3">
                                    <label for="method" class="form-label">Payment Method</label>
                                    <select class="form-select" id="method" name="method">
                                        <option value="">All Methods</option>
                                        <option value="paypal" <?= ($filters['method'] ?? '') === 'paypal' ? 'selected' : '' ?>>PayPal</option>
                                        <option value="flutterwave" <?= ($filters['method'] ?? '') === 'flutterwave' ? 'selected' : '' ?>>Flutterwave</option>
                                        <option value="usdt" <?= ($filters['method'] ?? '') === 'usdt' ? 'selected' : '' ?>>USDT</option>
                                        <option value="bank" <?= ($filters['method'] ?? '') === 'bank' ? 'selected' : '' ?>>Bank Transfer</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" id="status" name="status">
                                        <option value="">All Statuses</option>
                                        <option value="pending" <?= ($filters['status'] ?? '') === 'pending' ? 'selected' : '' ?>>Pending</option>
                                        <option value="completed" <?= ($filters['status'] ?? '') === 'completed' ? 'selected' : '' ?>>Completed</option>
                                        <option value="failed" <?= ($filters['status'] ?? '') === 'failed' ? 'selected' : '' ?>>Failed</option>
                                        <option value="refunded" <?= ($filters['status'] ?? '') === 'refunded' ? 'selected' : '' ?>>Refunded</option>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label for="type" class="form-label">Subscription</label>
                                    <select class="form-select" id="type" name="type">
                                        <option value="">All Types</option>
                                        <option value="monthly" <?= ($filters['type'] ?? '') === 'monthly' ? 'selected' : '' ?>>Monthly</option>
                                        <option value="yearly" <?= ($filters['type'] ?? '') === 'yearly' ? 'selected' : '' ?>>Yearly</option>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label for="date_from" class="form-label">From Date</label>
                                    <input type="date" class="form-control" id="date_from" name="date_from" value="<?= $filters['date_from'] ?? '' ?>">
                                </div>
                                <div class="col-md-2">
                                    <label for="date_to" class="form-label">To Date</label>
                                    <input type="date" class="form-control" id="date_to" name="date_to" value="<?= $filters['date_to'] ?? '' ?>">
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">Apply Filters</button>
                                    <a href="transactions.php" class="btn btn-outline-secondary">Reset</a>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-md-3">
                            <div class="card stat-card h-100">
                                <div class="card-body">
                                    <h6 class="card-title">Total Transactions</h6>
                                    <p class="card-text h4"><?= number_format($stats['total_count']) ?></p>
                                    <small class="text-muted">$<?= number_format($stats['total_amount'], 2) ?></small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card stat-card h-100">
                                <div class="card-body">
                                    <h6 class="card-title">Completed</h6>
                                    <p class="card-text h4"><?= number_format($stats['completed_count']) ?></p>
                                    <small class="text-muted">$<?= number_format($stats['completed_amount'], 2) ?></small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card stat-card h-100">
                                <div class="card-body">
                                    <h6 class="card-title">Pending</h6>
                                    <p class="card-text h4"><?= number_format($stats['pending_count']) ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card stat-card h-100">
                                <div class="card-body">
                                    <h6 class="card-title">Failed/Refunded</h6>
                                    <p class="card-text h4"><?= number_format($stats['failed_count'] + $stats['refunded_count']) ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>User</th>
                                            <th>Membership</th>
                                            <th>Amount</th>
                                            <th>Method</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($transactions as $txn): ?>
                                        <tr class="transaction-row">
                                            <td><?= $txn['id'] ?></td>
                                            <td>
                                                <strong><?= htmlspecialchars($txn['username']) ?></strong><br>
                                                <small><?= htmlspecialchars($txn['email']) ?></small>
                                            </td>
                                            <td><?= htmlspecialchars($txn['membership_name'] ?? 'N/A') ?></td>
                                            <td>$<?= number_format($txn['amount'], 2) ?></td>
                                            <td><?= ucfirst($txn['payment_method']) ?></td>
                                            <td>
                                                <span class="badge badge-<?= strtolower($txn['status']) ?>">
                                                    <?= ucfirst($txn['status']) ?>
                                                </span>
                                                <?php if ($txn['is_yearly']): ?>
                                                    <br><small class="text-muted">Yearly</small>
                                                <?php else: ?>
                                                    <br><small class="text-muted">Monthly</small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?= date('M j, Y', strtotime($txn['created_at'])) ?><br>
                                                <small><?= date('g:i a', strtotime($txn['created_at'])) ?></small>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" 
                                                        data-bs-target="#transactionModal" 
                                                        data-id="<?= $txn['id'] ?>"
                                                        data-username="<?= htmlspecialchars($txn['username']) ?>"
                                                        data-email="<?= htmlspecialchars($txn['email']) ?>"
                                                        data-membership="<?= htmlspecialchars($txn['membership_name'] ?? 'N/A') ?>"
                                                        data-amount="$<?= number_format($txn['amount'], 2) ?>"
                                                        data-method="<?= ucfirst($txn['payment_method']) ?>"
                                                        data-status="<?= ucfirst($txn['status']) ?>"
                                                        data-type="<?= $txn['is_yearly'] ? 'Yearly' : 'Monthly' ?>"
                                                        data-date="<?= date('M j, Y g:i a', strtotime($txn['created_at'])) ?>"
                                                        data-txnid="<?= htmlspecialchars($txn['transaction_id'] ?? 'N/A') ?>"
                                                        data-proof="<?= htmlspecialchars($txn['bank_proof'] ?? '') ?>">
                                                    Details
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <!-- Transaction Details Modal -->
    <div class="modal fade" id="transactionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Transaction #<span id="modalTxnId"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h6>User Information</h6>
                            <p>
                                <strong id="modalUsername"></strong><br>
                                <span id="modalEmail"></span>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <h6>Transaction Details</h6>
                            <p>
                                <strong>Amount:</strong> <span id="modalAmount"></span><br>
                                <strong>Method:</strong> <span id="modalMethod"></span><br>
                                <strong>Status:</strong> <span id="modalStatus"></span><br>
                                <strong>Type:</strong> <span id="modalType"></span>
                            </p>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h6>Membership</h6>
                            <p id="modalMembership"></p>
                        </div>
                        <div class="col-md-6">
                            <h6>Date & Time</h6>
                            <p id="modalDate"></p>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <h6>Transaction ID</h6>
                        <p id="modalTxnID" class="font-monospace"></p>
                    </div>
                    
                    <div id="proofSection" class="mb-3" style="display: none;">
                        <h6>Bank Transfer Proof</h6>
                        <a id="proofLink" href="#" target="_blank" class="d-block mb-2">
                            <img id="proofThumbnail" src="" alt="Proof" style="max-height: 150px;">
                        </a>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize Feather Icons
        feather.replace();

        // Handle transaction modal
        const transactionModal = document.getElementById('transactionModal');
        if (transactionModal) {
            transactionModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                document.getElementById('modalTxnId').textContent = button.getAttribute('data-id');
                document.getElementById('modalUsername').textContent = button.getAttribute('data-username');
                document.getElementById('modalEmail').textContent = button.getAttribute('data-email');
                document.getElementById('modalMembership').textContent = button.getAttribute('data-membership');
                document.getElementById('modalAmount').textContent = button.getAttribute('data-amount');
                document.getElementById('modalMethod').textContent = button.getAttribute('data-method');
                document.getElementById('modalStatus').textContent = button.getAttribute('data-status');
                document.getElementById('modalType').textContent = button.getAttribute('data-type');
                document.getElementById('modalDate').textContent = button.getAttribute('data-date');
                document.getElementById('modalTxnID').textContent = button.getAttribute('data-txnid');
                
                const proof = button.getAttribute('data-proof');
                const proofSection = document.getElementById('proofSection');
                if (proof) {
                    proofSection.style.display = 'block';
                    document.getElementById('proofLink').href = '../uploads/' + proof;
                    document.getElementById('proofThumbnail').src = '../uploads/' + proof;
                } else {
                    proofSection.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>
