<?php
// admin/gift_management.php
require_once '../includes/db.php';

// Admin verification
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit;
}

// Handle all form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();
        
        if (isset($_POST['delete_gift'])) {
            // Handle gift deletion
            $gift_id = intval($_POST['gift_id']);
            
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_gifts WHERE gift_id = ?");
            $stmt->execute([$gift_id]);
            $count = $stmt->fetchColumn();
            
            if ($count > 0) {
                throw new Exception("Cannot delete gift - users have already earned it");
            }
            
            $stmt = $pdo->prepare("DELETE FROM membership_gifts WHERE id = ?");
            $stmt->execute([$gift_id]);
            
            $_SESSION['success'] = "Gift deleted successfully";
        } 
        elseif (isset($_POST['save_gift'])) {
            // Handle gift creation/update
            $gift_id = isset($_POST['gift_id']) ? intval($_POST['gift_id']) : 0;
            $name = trim($_POST['name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $duration = intval($_POST['duration'] ?? 0);
            $is_global = isset($_POST['is_global']) ? 1 : 0;
            $membership_id = $is_global ? null : (isset($_POST['membership_id']) ? intval($_POST['membership_id']) : null);
            $icon = trim($_POST['icon'] ?? 'bi-gift');

            if (empty($name) || empty($description) || $duration <= 0) {
                throw new Exception("Please fill all required fields correctly");
            }

            if ($gift_id > 0) {
                // Update existing gift
                $stmt = $pdo->prepare("UPDATE membership_gifts SET 
                    name = ?, description = ?, duration_months = ?, 
                    membership_id = ?, is_global = ?, icon = ?
                    WHERE id = ?");
                $stmt->execute([$name, $description, $duration, $membership_id, $is_global, $icon, $gift_id]);
                $action = "updated";
            } else {
                // Create new gift
                $stmt = $pdo->prepare("INSERT INTO membership_gifts 
                    (name, description, duration_months, membership_id, is_global, icon) 
                    VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $description, $duration, $membership_id, $is_global, $icon]);
                $gift_id = $pdo->lastInsertId();
                $action = "created";
            }
            
            $_SESSION['success'] = "Gift $action successfully";
        }
        elseif (isset($_POST['assign_gift'])) {
            // Handle manual gift assignment to users
            $gift_id = intval($_POST['assign_gift_id']);
            $user_ids = $_POST['user_ids'] ?? [];
            
            if (empty($user_ids)) {
                throw new Exception("Please select at least one user");
            }
            
            foreach ($user_ids as $user_id) {
                $user_id = intval($user_id);
                // Check if user already has this gift
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_gifts WHERE user_id = ? AND gift_id = ?");
                $stmt->execute([$user_id, $gift_id]);
                $exists = $stmt->fetchColumn();
                
                if (!$exists) {
                    $stmt = $pdo->prepare("INSERT INTO user_gifts (user_id, gift_id, earned_date) VALUES (?, ?, NOW())");
                    $stmt->execute([$user_id, $gift_id]);
                    
                    // Create notification for user
                    $stmt = $pdo->prepare("SELECT name FROM membership_gifts WHERE id = ?");
                    $stmt->execute([$gift_id]);
                    $gift_name = $stmt->fetchColumn();
                    
                    $message = "You've earned a new gift: $gift_name";
                    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, 'New Gift Earned', ?)");
                    $stmt->execute([$user_id, $message]);
                }
            }
            
            $_SESSION['success'] = "Gift assigned to selected users";
        }
        
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = $e->getMessage();
    }
    
    header("Location: gift_management.php");
    exit;
}

// Get all gifts with membership info and earned counts
$stmt = $pdo->query("
    SELECT g.*, 
           m.name as membership_name,
           (SELECT COUNT(*) FROM user_gifts WHERE gift_id = g.id) as earned_count
    FROM membership_gifts g
    LEFT JOIN membership_levels m ON g.membership_id = m.id
    ORDER BY g.duration_months ASC
");
$gifts = $stmt->fetchAll();

// Get membership levels for dropdowns
$membership_levels = $pdo->query("SELECT id, name FROM membership_levels WHERE is_active = 1")->fetchAll();

// Get all users for manual assignment
$users = $pdo->query("SELECT id, username, email FROM users ORDER BY username")->fetchAll();

// Get gift assignment stats
$gift_stats = $pdo->query("
    SELECT g.id, g.name, COUNT(ug.id) as assignments,
           GROUP_CONCAT(DISTINCT u.username ORDER BY u.username SEPARATOR ', ') as usernames
    FROM membership_gifts g
    LEFT JOIN user_gifts ug ON g.id = ug.gift_id
    LEFT JOIN users u ON ug.user_id = u.id
    GROUP BY g.id
")->fetchAll(PDO::FETCH_GROUP|PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gift Management | Admin Panel</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Font Awesome for consistent icons across pages -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
            xintegrity="sha512-1ycn6IcaQQ40ZefMdHjAcUwaGDvPwdOaUcsU5XrU+pL87B7fC3J0P2Kqj1Z5M5YqD65B2L52B7y42j5P5c+A=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Feather Icons for new tab icons -->
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <!-- Select2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">

    <style>
        /* Define your color variables */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
            --light-green: #90EE90; /* Light green color */
        }

        /* Body and main layout styling */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--gray-100);
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer if added */
        }
        .site-wrapper { /* New wrapper for sticky footer logic */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container-fluid {
            padding: 0; /* Remove padding to make sidebar stick to edge */
            flex-grow: 1; /* Allow container-fluid to take up remaining height */
        }
        .row {
            margin: 0; /* Remove row margins to prevent unwanted space */
            flex-grow: 1;
        }
        /* Main content area */
        main {
            padding: 20px !important; /* Important to override Bootstrap default */
            background-color: var(--gray-100); /* Content area background */
            flex-grow: 1;
        }
        .d-flex.justify-content-between.flex-wrap.flex-md-nowrap.align-items-center {
            padding-top: 1.5rem !important; /* Bootstrap pt-3 */
            padding-bottom: 1rem !important; /* Bootstrap pb-2 */
            margin-bottom: 1.5rem !important; /* Bootstrap mb-3 */
        }

        /* Admin Sidebar basic styling */
        .admin-sidebar {
            background-color: var(--dark);
            color: var(--white);
            padding: 20px;
            /* Fixed position for desktop view */
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: 250px; /* Fixed width for the sidebar */
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .admin-sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary);
            font-size: 1.8rem;
            font-weight: 700;
        }
        .admin-sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .admin-sidebar ul li {
            margin-bottom: 10px;
        }
        .admin-sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--gray-300);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        .admin-sidebar ul li a:hover,
        .admin-sidebar ul li a.active {
            background-color: var(--gray-700);
            color: var(--white);
        }
        .admin-sidebar ul li a i {
            width: 20px;
            height: 20px;
        }

        /* Specific styles for gift_management.php content */
        .table-container { overflow-x: auto; }
        .badge-global { background-color: var(--info); } /* Using info color for consistency */
        .badge-specific { background-color: var(--gray-500); } /* Using gray for specific */
        .gift-icon { font-size: 1.5rem; }
        .stats-card { transition: all 0.3s ease; }
        .stats-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.1); }
        .icon-preview { font-size: 2rem; margin-right: 10px; }
        .nav-tabs .nav-link.active { font-weight: bold; }
        .select2-container { width: 100% !important; }

        /* Card styles */
        .card {
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05); /* Soft shadow */
        }
        .card-body {
            padding: 25px;
        }
        .form-control, .form-select {
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            padding: 10px 15px;
            color: var(--gray-800);
            background-color: var(--white);
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(58, 195, 184, 0.25);
        }
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: background-color 0.2s, border-color 0.2s;
        }
        .btn-primary:hover {
            background-color: #2da89e;
            border-color: #2da89e;
        }
        .alert {
            border-radius: 8px;
            font-weight: 500;
        }

        /* Responsive adjustments: Sidebar becomes standard column on mobile */
        @media (max-width: 767.98px) {
            .admin-sidebar {
                position: relative; /* Remove fixed positioning on small screens */
                width: 100%; /* Take full width on small screens */
                height: auto; /* Adjust height based on content */
                box-shadow: none; /* Remove shadow to blend better */
            }
            main {
                margin-left: 0 !important; /* Remove desktop margin on small screens */
            }
            .navbar-mobile-toggle { /* Ensure this is hidden as it's not needed now */
                display: none !important;
            }
        }

        @media (min-width: 768px) { /* Applies to md and larger screens */
            .main-content-area {
                margin-left: 250px; /* Offset for the fixed sidebar */
            }
            /* Hide the mobile toggle navbar on desktop */
            .navbar-mobile-toggle {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <!-- Mobile Navbar/Toggle is not included as per instruction to ignore mobile changes. -->
        <!-- The layout will now simply stack on small screens. -->

        <div class="container-fluid">
            <div class="row">
                <!-- Admin Sidebar -->
                <!-- The d-md-block class makes it a block element from md breakpoint up, making it visible -->
                <!-- The 'collapse' class is removed to ensure it's always visible on desktop -->
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block admin-sidebar">
                    <div class="position-sticky pt-3">
                        <h2>Admin Panel</h2>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i data-feather="users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_levels.php">
                                    <i data-feather="award"></i> Membership Levels
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="payment_settings.php">
                                    <i data-feather="dollar-sign"></i> Payment Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="transactions.php">
                                    <i data-feather="credit-card"></i> Transactions
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="affiliates.php">
                                    <i data-feather="link"></i> Affiliates
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="helpdesk.php">
                                    <i data-feather="life-buoy"></i> Helpdesk
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="gift_management.php">
                                    <i data-feather="gift"></i> Gift Management
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="thresholds.php">
                                    <i data-feather="sliders"></i> Thresholds
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_admin.php">
                                    <i data-feather="user-check"></i> Membership+
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="teams.php">
                                    <i data-feather="users"></i> Teams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="streams_management.php">
                                    <i data-feather="video"></i> Streams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="cashouts.php" style="color: var(--light-green);">
                                    <i data-feather="dollar-sign"></i> Cashouts
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="email_settings.php">
                                    <i data-feather="mail"></i> Email Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="notifications.php">
                                    <i data-feather="bell"></i> Notifications
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="ai_settings.php">
                                    <i data-feather="cpu"></i> AI Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="niches.php">
                                    <i data-feather="grid"></i> Niches
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../dashboard.php">
                                    <i data-feather="home"></i> Back to Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">
                                    <i data-feather="log-out"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- End Admin Sidebar -->
                
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content-area">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Membership Gift Management</h1>
                    </div>
                    
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?= $_SESSION['error'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['error']); ?>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= $_SESSION['success'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    
                    <ul class="nav nav-tabs mb-4" id="giftTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="gifts-tab" data-bs-toggle="tab" data-bs-target="#gifts" type="button" role="tab">Gift Definitions</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="assignments-tab" data-bs-toggle="tab" data-bs-target="#assignments" type="button" role="tab">Manual Assignments</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="stats-tab" data-bs-toggle="tab" data-bs-target="#stats" type="button" role="tab">Statistics</button>
                        </li>
                    </ul>
                    
                    <div class="tab-content" id="giftTabsContent">
                        <!-- Gift Definitions Tab -->
                        <div class="tab-pane fade show active" id="gifts" role="tabpanel">
                            <div class="card mb-4">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">Gift Definitions</h5>
                                    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#createGiftModal">
                                        <i class="bi bi-plus-circle"></i> New Gift
                                    </button>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Icon</th>
                                                    <th>Gift Name</th>
                                                    <th>Description</th>
                                                    <th>Duration</th>
                                                    <th>Type</th>
                                                    <th>Earned By</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if (empty($gifts)): ?>
                                                    <tr>
                                                        <td colspan="8" class="text-center py-4">No gifts found</td>
                                                    </tr>
                                                <?php else: ?>
                                                    <?php foreach ($gifts as $gift): ?>
                                                    <tr>
                                                        <td><?= $gift['id'] ?></td>
                                                        <td><i class="bi <?= htmlspecialchars($gift['icon'] ?? 'bi-gift') ?> gift-icon"></i></td>
                                                        <td><?= htmlspecialchars($gift['name']) ?></td>
                                                        <td><?= htmlspecialchars($gift['description']) ?></td>
                                                        <td><?= $gift['duration_months'] ?> months</td>
                                                        <td>
                                                            <?php if ($gift['is_global']): ?>
                                                                <span class="badge bg-primary">Global</span>
                                                            <?php else: ?>
                                                                <span class="badge bg-secondary"><?= htmlspecialchars($gift['membership_name'] ?? 'Specific') ?></span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?= $gift['earned_count'] ?> user(s)</td>
                                                        <td>
                                                            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" 
                                                                    data-bs-target="#editGiftModal" 
                                                                    data-gift-id="<?= $gift['id'] ?>"
                                                                    data-gift-name="<?= htmlspecialchars($gift['name']) ?>"
                                                                    data-gift-description="<?= htmlspecialchars($gift['description']) ?>"
                                                                    data-gift-duration="<?= $gift['duration_months'] ?>"
                                                                    data-gift-icon="<?= htmlspecialchars($gift['icon'] ?? 'bi-gift') ?>"
                                                                    data-gift-isglobal="<?= $gift['is_global'] ?>"
                                                                    data-gift-membership="<?= $gift['membership_id'] ?>">
                                                                <i class="bi bi-pencil"></i> Edit
                                                            </button>
                                                            <form method="POST" style="display: inline-block;">
                                                                <input type="hidden" name="gift_id" value="<?= $gift['id'] ?>">
                                                                <button type="submit" name="delete_gift" class="btn btn-sm btn-danger" 
                                                                        onclick="return confirm('Are you sure you want to delete this gift?')">
                                                                    <i class="bi bi-trash"></i> Delete
                                                                </button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Manual Assignments Tab -->
                        <div class="tab-pane fade" id="assignments" role="tabpanel">
                            <div class="card">
                                <div class="card-header">
                                    <h5>Manual Gift Assignments</h5>
                                </div>
                                <div class="card-body">
                                    <form method="POST">
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label class="form-label">Select Gift</label>
                                                <select name="assign_gift_id" class="form-select select2-gifts" required>
                                                    <option value="">-- Select Gift --</option>
                                                    <?php foreach ($gifts as $gift): ?>
                                                        <option value="<?= $gift['id'] ?>">
                                                            <?= htmlspecialchars($gift['name']) ?> 
                                                            (<?= $gift['is_global'] ? 'Global' : htmlspecialchars($gift['membership_name'] ?? 'Specific') ?>)
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">Select Users</label>
                                                <select name="user_ids[]" class="form-select select2-users" multiple="multiple" required>
                                                    <?php foreach ($users as $user): ?>
                                                        <option value="<?= $user['id'] ?>">
                                                            <?= htmlspecialchars($user['username']) ?> (<?= htmlspecialchars($user['email']) ?>)
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-end">
                                            <button type="submit" name="assign_gift" class="btn btn-primary">
                                                <i data-feather="gift"></i> Assign Gift
                                            </button>
                                        </div>
                                    </form>
                                    
                                    <hr>
                                    
                                    <h5 class="mt-4">Recent Assignments</h5>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Gift</th>
                                                    <th>Assigned To</th>
                                                    <th>Date Assigned</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                $recent_assignments = $pdo->query("
                                                    SELECT g.name as gift_name, u.username, u.email, ug.earned_date
                                                    FROM user_gifts ug
                                                    JOIN membership_gifts g ON ug.gift_id = g.id
                                                    JOIN users u ON ug.user_id = u.id
                                                    ORDER BY ug.earned_date DESC
                                                    LIMIT 10
                                                ")->fetchAll();
                                                
                                                if (empty($recent_assignments)): ?>
                                                    <tr>
                                                        <td colspan="3" class="text-center py-4">No recent assignments</td>
                                                    </tr>
                                                <?php else: ?>
                                                    <?php foreach ($recent_assignments as $assignment): ?>
                                                    <tr>
                                                        <td><?= htmlspecialchars($assignment['gift_name']) ?></td>
                                                        <td>
                                                            <?= htmlspecialchars($assignment['username']) ?>
                                                            <small class="text-muted">(<?= htmlspecialchars($assignment['email']) ?>)</small>
                                                        </td>
                                                        <td><?= date('M j, Y H:i', strtotime($assignment['earned_date'])) ?></td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Statistics Tab -->
                        <div class="tab-pane fade" id="stats" role="tabpanel">
                            <div class="row">
                                <div class="col-md-4 mb-4">
                                    <div class="card stats-card bg-primary text-white">
                                        <div class="card-body">
                                            <div class="d-flex align-items-center">
                                                <i data-feather="gift" class="icon-preview"></i>
                                                <div>
                                                    <h5 class="card-title mb-0">Total Gifts</h5>
                                                    <p class="card-text display-6 mb-0"><?= count($gifts) ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-4">
                                    <div class="card stats-card bg-success text-white">
                                        <div class="card-body">
                                            <div class="d-flex align-items-center">
                                                <i data-feather="users" class="icon-preview"></i>
                                                <div>
                                                    <h5 class="card-title mb-0">Total Assignments</h5>
                                                    <p class="card-text display-6 mb-0">
                                                        <?= array_sum(array_column($gifts, 'earned_count')) ?>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-4">
                                    <div class="card stats-card bg-info text-white">
                                        <div class="card-body">
                                            <div class="d-flex align-items-center">
                                                <i data-feather="user-check" class="icon-preview"></i>
                                                <div>
                                                    <h5 class="card-title mb-0">Unique Users</h5>
                                                    <p class="card-text display-6 mb-0">
                                                        <?= $pdo->query("SELECT COUNT(DISTINCT user_id) FROM user_gifts")->fetchColumn() ?>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card">
                                <div class="card-header">
                                    <h5>Gift Distribution</h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Gift</th>
                                                    <th>Type</th>
                                                    <th>Assignments</th>
                                                    <th>Users</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($gifts as $gift): ?>
                                                <tr>
                                                    <td>
                                                        <i class="bi <?= htmlspecialchars($gift['icon'] ?? 'bi-gift') ?>"></i>
                                                        <?= htmlspecialchars($gift['name']) ?>
                                                    </td>
                                                    <td>
                                                        <?php if ($gift['is_global']): ?>
                                                            <span class="badge bg-primary">Global</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-secondary">Specific</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?= $gift['earned_count'] ?></td>
                                                    <td>
                                                        <?php if ($gift['earned_count'] > 0): ?>
                                                            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" 
                                                                    data-bs-target="#giftUsersModal" 
                                                                    data-gift-id="<?= $gift['id'] ?>"
                                                                    data-gift-name="<?= htmlspecialchars($gift['name']) ?>">
                                                                View Users
                                                            </button>
                                                        <?php else: ?>
                                                            <span class="text-muted">None</span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <!-- Create Gift Modal -->
    <div class="modal fade" id="createGiftModal" tabindex="-1" aria-labelledby="createGiftModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="createGiftModalLabel">Create New Gift</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Gift Name</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Icon Class</label>
                            <div class="input-group">
                                <span class="input-group-text"><i id="iconPreview" class="bi-gift"></i></span>
                                <input type="text" class="form-control" name="icon" value="bi-gift">
                            </div>
                            <small class="text-muted">Use Bootstrap Icons class (e.g. bi-gift, bi-trophy)</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Duration (months)</label>
                            <input type="number" class="form-control" name="duration" min="1" value="1" required>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" name="is_global" id="isGlobal" checked>
                            <label class="form-check-label" for="isGlobal">Available to all premium members</label>
                        </div>
                        <div class="mb-3" id="membershipGroup" style="display: none;">
                            <label class="form-label">Specific Membership Level</label>
                            <select class="form-select select2-memberships" name="membership_id">
                                <option value="">-- Select Membership Level --</option>
                                <?php foreach ($membership_levels as $level): ?>
                                    <option value="<?= $level['id'] ?>"><?= htmlspecialchars($level['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="save_gift" class="btn btn-primary">Create Gift</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Gift Modal -->
    <div class="modal fade" id="editGiftModal" tabindex="-1" aria-labelledby="editGiftModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="gift_id" id="editGiftId">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editGiftModalLabel">Edit Gift</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Gift Name</label>
                            <input type="text" class="form-control" name="name" id="editGiftName" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Icon Class</label>
                            <div class="input-group">
                                <span class="input-group-text"><i id="editIconPreview" class="bi-gift"></i></span>
                                <input type="text" class="form-control" name="icon" id="editGiftIcon">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" id="editGiftDescription" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Duration (months)</label>
                            <input type="number" class="form-control" name="duration" id="editGiftDuration" min="1" required>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" name="is_global" id="editIsGlobal">
                            <label class="form-check-label" for="editIsGlobal">Available to all premium members</label>
                        </div>
                        <div class="mb-3" id="editMembershipGroup">
                            <label class="form-label">Specific Membership Level</label>
                            <select class="form-select select2-memberships" name="membership_id" id="editMembershipId">
                                <option value="">-- Select Membership Level --</option>
                                <?php foreach ($membership_levels as $level): ?>
                                    <option value="<?= $level['id'] ?>"><?= htmlspecialchars($level['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="save_gift" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Gift Users Modal -->
    <div class="modal fade" id="giftUsersModal" tabindex="-1" aria-labelledby="giftUsersModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="giftUsersModalLabel">Users Who Earned This Gift</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="giftUsersContent">
                        Loading...
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Feather Icons
            feather.replace(); // This line was added!

            // Initialize Select2
            $('.select2-gifts').select2();
            $('.select2-users').select2({
                placeholder: "Select users",
                allowClear: true
            });
            $('.select2-memberships').select2({
                placeholder: "Select membership level",
                allowClear: true
            });
            
            // Handle icon preview in create modal
            document.querySelector('#createGiftModal input[name="icon"]').addEventListener('input', function() {
                document.getElementById('iconPreview').className = this.value;
            });
            
            // Toggle membership selection based on global checkbox in create modal
            const globalCheckbox = document.getElementById('isGlobal');
            const membershipGroup = document.getElementById('membershipGroup');
            
            if (globalCheckbox && membershipGroup) {
                globalCheckbox.addEventListener('change', function() {
                    membershipGroup.style.display = this.checked ? 'none' : 'block';
                });
                // Initial state on load
                membershipGroup.style.display = globalCheckbox.checked ? 'none' : 'block';
            }
            
            // Handle edit modal population
            const editGiftModal = document.getElementById('editGiftModal');
            if (editGiftModal) {
                editGiftModal.addEventListener('show.bs.modal', function(event) {
                    const button = event.relatedTarget;
                    
                    document.getElementById('editGiftId').value = button.getAttribute('data-gift-id');
                    document.getElementById('editGiftName').value = button.getAttribute('data-gift-name');
                    document.getElementById('editGiftIcon').value = button.getAttribute('data-gift-icon');
                    document.getElementById('editIconPreview').className = button.getAttribute('data-gift-icon');
                    document.getElementById('editGiftDescription').value = button.getAttribute('data-gift-description');
                    document.getElementById('editGiftDuration').value = button.getAttribute('data-gift-duration');
                    
                    const isGlobal = button.getAttribute('data-gift-isglobal') === '1';
                    document.getElementById('editIsGlobal').checked = isGlobal;
                    document.getElementById('editMembershipGroup').style.display = isGlobal ? 'none' : 'block';
                    
                    const membershipId = button.getAttribute('data-gift-membership');
                    if (membershipId) {
                        // For Select2, you might need to set the value programmatically and then trigger change
                        $('#editMembershipId').val(membershipId).trigger('change');
                    } else {
                        $('#editMembershipId').val('').trigger('change'); // Clear if not set
                    }
                });
            }
            
            // Toggle membership selection in edit modal
            const editIsGlobalCheckbox = document.getElementById('editIsGlobal');
            const editMembershipGroup = document.getElementById('editMembershipGroup');
            if (editIsGlobalCheckbox && editMembershipGroup) {
                editIsGlobalCheckbox.addEventListener('change', function() {
                    editMembershipGroup.style.display = this.checked ? 'none' : 'block';
                });
            }
            
            // Handle gift users modal (AJAX call to fetch users for a specific gift)
            const giftUsersModal = document.getElementById('giftUsersModal');
            if (giftUsersModal) {
                giftUsersModal.addEventListener('show.bs.modal', function(event) {
                    const button = event.relatedTarget;
                    const giftId = button.getAttribute('data-gift-id');
                    const giftName = button.getAttribute('data-gift-name');
                    
                    const modalTitle = giftUsersModal.querySelector('.modal-title');
                    modalTitle.textContent = `Users Who Earned "${giftName}"`;
                    
                    // Fetch users via AJAX
                    const giftUsersContent = document.getElementById('giftUsersContent');
                    giftUsersContent.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>'; // Loading indicator

                    fetch(`ajax/get_gift_users.php?gift_id=${giftId}`) // Assuming you have this AJAX endpoint
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok ' + response.statusText);
                            }
                            return response.text();
                        })
                        .then(data => {
                            giftUsersContent.innerHTML = data;
                        })
                        .catch(error => {
                            giftUsersContent.innerHTML = `<div class="alert alert-danger">Error loading data: ${error.message}</div>`;
                            console.error('Fetch error:', error);
                        });
                });
            }
        });
    </script>
</body>
</html>
