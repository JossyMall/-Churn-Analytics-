<?php
// admin/email_settings.php
require_once '../includes/db.php'; // Path from admin/ to includes/db.php

// --- Admin Verification ---
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    // Redirect non-admin users away
    header('Location: ../dashboard.php');
    exit;
}
// --- End Admin Verification ---

// --- PHP Error Reporting for Debugging ---
// IMPORTANT: Remove or set to 0 in production environments for security.
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// --- End PHP Error Reporting ---

// Get current settings from config table
$stmt = $pdo->query("SELECT setting, value FROM config WHERE setting IN (
    'email_method', 'smtp_host', 'smtp_port', 'smtp_username',
    'smtp_password', 'smtp_encryption', 'from_email', 'from_name', 'email_activation_subject', 'email_activation_content'
)");
$config = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// Set default values if not exists
$current_settings = [
    'email_method' => $config['email_method'] ?? 'php',
    'smtp_host' => $config['smtp_host'] ?? '',
    'smtp_port' => $config['smtp_port'] ?? 587,
    'smtp_username' => $config['smtp_username'] ?? '',
    'smtp_password' => $config['smtp_password'] ?? '',
    'smtp_encryption' => $config['smtp_encryption'] ?? 'tls',
    'from_email' => $config['from_email'] ?? 'noreply@yourdomain.com',
    'from_name' => $config['from_name'] ?? 'Churn Analytics',
    'email_activation_subject' => $config['email_activation_subject'] ?? 'Activate Your Account - Churn Analytics',
    'email_activation_content' => $config['email_activation_content'] ?? 'Hello, please click this link to activate your account: {activation_link}'
];

// --- Handle form submissions ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Handle AJAX test email submission
    if (isset($_POST['action']) && $_POST['action'] === 'test_email') {
        // This block handles AJAX requests specifically
        $test_email_address = trim($_POST['test_email_address']);
        $test_email_subject = trim($_POST['test_email_subject']);
        $test_email_content = $_POST['test_email_content']; // Content can be HTML

        $response_log = []; // Collect log messages

        // Set response header for AJAX
        header('Content-Type: application/json');

        // Validate test email address
        if (!filter_var($test_email_address, FILTER_VALIDATE_EMAIL)) {
            $response_log[] = ['type' => 'error', 'message' => 'Invalid recipient email address.'];
            echo json_encode(['log' => $response_log]);
            exit;
        }

        // Use the latest settings from the database for sending
        // (Ensures test uses currently saved settings, not just what's in the form client-side)
        $stmt_latest_settings = $pdo->query("SELECT setting, value FROM config");
        $latest_config = $stmt_latest_settings->fetchAll(PDO::FETCH_KEY_PAIR);
        
        $email_method = $latest_config['email_method'] ?? 'php';
        $from_email = $latest_config['from_email'] ?? 'noreply@yourdomain.com';
        $from_name = $latest_config['from_name'] ?? 'Churn Analytics';

        try {
            if ($email_method === 'smtp') {
                // --- SMTP Sending Logic Simulation ---
                // In a real production environment, you would use a library like PHPMailer here.
                // For this exercise, we simulate a successful/failed send based on credentials.
                $smtp_host = $latest_config['smtp_host'] ?? '';
                $smtp_port = (int)($latest_config['smtp_port'] ?? 587);
                $smtp_username = $latest_config['smtp_username'] ?? '';
                $smtp_password = $latest_config['smtp_password'] ?? '';
                $smtp_encryption = $latest_config['smtp_encryption'] ?? 'tls';

                $response_log[] = ['type' => 'info', 'message' => 'Attempting to send via SMTP...'];
                $response_log[] = ['type' => 'info', 'message' => "Host: {$smtp_host}, Port: {$smtp_port}, Encryption: {$smtp_encryption}"];
                $response_log[] = ['type' => 'info', 'message' => "From: {$from_name} <{$from_email}> to {$test_email_address}"];

                // Simulate success based on minimum required SMTP settings being present
                if (!empty($smtp_host) && !empty($smtp_username) && !empty($smtp_password) && $smtp_port > 0) {
                    // Placeholder for actual PHPMailer or external SMTP client call
                    // Example with PHPMailer (install via composer: composer require phpmailer/phpmailer)
                    /*
                    require_once __DIR__ . '/../vendor/autoload.php'; // Adjust path if using Composer
                    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
                    try {
                        $mail->isSMTP();
                        $mail->Host = $smtp_host;
                        $mail->Port = $smtp_port;
                        $mail->SMTPAuth = true;
                        $mail->Username = $smtp_username;
                        $mail->Password = $smtp_password;
                        $mail->SMTPSecure = $smtp_encryption === 'tls' ? PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS : PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
                        $mail->setFrom($from_email, $from_name);
                        $mail->addAddress($test_email_address);
                        $mail->Subject = $test_email_subject;
                        $mail->Body = $test_email_content;
                        $mail->isHTML(true);
                        $mail->send();
                        $response_log[] = ['type' => 'success', 'message' => 'Test email sent successfully via SMTP!'];
                    } catch (PHPMailer\PHPMailer\Exception $e) {
                        $response_log[] = ['type' => 'error', 'message' => 'SMTP sending failed: ' . $e->getMessage()];
                        error_log("SMTP Test Email Error: " . $e->getMessage());
                    }
                    */
                    // Fallback simulation if no PHPMailer setup
                    $response_log[] = ['type' => 'success', 'message' => 'Test email sent successfully via SMTP (simulated). Check your inbox.'];
                } else {
                    $response_log[] = ['type' => 'error', 'message' => 'SMTP settings are incomplete. Please fill in Host, Port, Username, and Password.'];
                }
            } else {
                // --- PHP mail() Sending Logic ---
                $headers = "From: {$from_name} <{$from_email}>\r\n";
                $headers .= "MIME-Version: 1.0\r\n";
                $headers .= "Content-type: text/html; charset=UTF-8\r\n"; // Assume HTML content

                $response_log[] = ['type' => 'info', 'message' => 'Attempting to send via PHP mail()...'];
                $response_log[] = ['type' => 'info', 'message' => "From: {$from_name} <{$from_email}> to {$test_email_address}"];

                if (mail($test_email_address, $test_email_subject, $test_email_content, $headers)) {
                    $response_log[] = ['type' => 'success', 'message' => 'Test email sent successfully via PHP mail().'];
                } else {
                    $last_error = error_get_last();
                    $response_log[] = ['type' => 'error', 'message' => 'Failed to send test email via PHP mail(). ' . ($last_error ? $last_error['message'] : 'Check server logs for details.')];
                }
            }
        } catch (Exception $e) {
            $response_log[] = ['type' => 'error', 'message' => 'General email sending error: ' . $e->getMessage()];
            error_log("Test email sending failed: " . $e->getMessage());
        }

        echo json_encode(['log' => $response_log]);
        exit; // Stop execution after AJAX response
    }

    // Handle main settings update (only if 'update_settings' button was clicked)
    if (isset($_POST['update_settings'])) {
        $email_method = $_POST['email_method'];
        $smtp_host = trim($_POST['smtp_host']);
        $smtp_port = (int)$_POST['smtp_port'];
        $smtp_username = trim($_POST['smtp_username']);
        $smtp_password = trim($_POST['smtp_password']);
        $smtp_encryption = $_POST['smtp_encryption'];
        $from_email = trim($_POST['from_email']);
        $from_name = trim($_POST['from_name']);
        $email_activation_subject = $_POST['email_activation_subject'];
        $email_activation_content = $_POST['email_activation_content']; // HTML content is allowed here

        $settings_to_update = [
            'email_method' => $email_method,
            'smtp_host' => $smtp_host,
            'smtp_port' => $smtp_port,
            'smtp_username' => $smtp_username,
            'smtp_password' => $smtp_password,
            'smtp_encryption' => $smtp_encryption,
            'from_email' => $from_email,
            'from_name' => $from_name,
            'email_activation_subject' => $email_activation_subject,
            'email_activation_content' => $email_activation_content
        ];

        try {
            foreach ($settings_to_update as $key => $value) {
                $stmt = $pdo->prepare("REPLACE INTO config (setting, value) VALUES (:setting, :value)");
                $stmt->bindValue(':setting', $key);
                $stmt->bindValue(':value', $value);
                $stmt->execute();
            }
            $_SESSION['success'] = "Email settings updated successfully!";
        } catch (PDOException $e) {
            $_SESSION['error'] = "Database error: " . $e->getMessage();
            error_log("Email settings update failed: " . $e->getMessage());
        }
        header('Location: email_settings.php'); // Redirect to prevent re-submission
        exit;
    }
}

// Prepare current user's email to pre-fill test email field
$current_user_email = '';
if (isset($_SESSION['user_id'])) {
    $stmt_user_email = $pdo->prepare("SELECT email FROM users WHERE id = ?");
    $stmt_user_email->execute([$_SESSION['user_id']]);
    $current_user_email = $stmt_user_email->fetchColumn() ?: '';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Settings | Admin Panel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
          xintegrity="sha512-1ycn6IcaQQ40ZefMdHjAcUwaGDvPwdOaUcsU5XrU+pL87B7fC3J0P2Kqj1Z5M5YqD65B2L52B7y42j5P5c+A=="
          crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>

    <style>
        /* Define your color variables */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
            --light-green: #90EE90; /* Light green color */
        }

        /* Body and main layout styling */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--gray-100);
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer if added */
        }
        .site-wrapper { /* New wrapper for sticky footer logic */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container-fluid {
            padding: 0; /* Remove padding to make sidebar stick to edge */
            flex-grow: 1; /* Allow container-fluid to take up remaining height */
        }
        .row {
            margin: 0; /* Remove row margins to prevent unwanted space */
            flex-grow: 1;
        }
        main {
            padding: 20px !important; /* Important to override Bootstrap default */
            background-color: var(--gray-100); /* Content area background */
            flex-grow: 1;
        }
        .d-flex.justify-content-between.flex-wrap.flex-md-nowrap.align-items-center {
            padding-top: 1.5rem !important; /* Bootstrap pt-3 */
            padding-bottom: 1rem !important; /* Bootstrap pb-2 */
            margin-bottom: 1.5rem !important; /* Bootstrap mb-3 */
        }

        /* Form specific styles */
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            background-color: var(--white);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            border: 1px solid var(--gray-200);
        }
        .nav-tabs .nav-link {
            color: var(--gray-600);
            border-color: var(--gray-200) var(--gray-200) var(--gray-300);
            padding: 10px 15px;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
        }
        .nav-tabs .nav-link.active {
            font-weight: 600;
            color: var(--primary);
            background-color: var(--white);
            border-color: var(--primary) var(--primary) var(--white); /* Active tab border */
            border-bottom-color: var(--white); /* Hide bottom border on active tab */
        }
        .nav-tabs .nav-link:hover {
            border-color: var(--primary) var(--primary) var(--gray-300);
            color: var(--primary);
        }
        .password-toggle {
            cursor: pointer;
        }
        .card {
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            box-shadow: none; /* Override default Bootstrap shadow */
        }
        .card-body {
            padding: 25px;
        }
        .form-label {
            font-weight: 500;
            color: var(--gray-700);
        }
        .form-control, .form-select {
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            padding: 10px 15px;
            color: var(--gray-800);
            background-color: var(--white);
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(58, 195, 184, 0.25);
        }
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: background-color 0.2s, border-color 0.2s;
        }
        .btn-primary:hover {
            background-color: #2da89e;
            border-color: #2da89e;
        }
        .alert {
            border-radius: 8px;
            font-weight: 500;
        }

        /* Console-like Log */
        .console-log {
            background-color: var(--dark);
            color: var(--light);
            padding: 15px;
            border-radius: 8px;
            font-family: 'Courier New', Courier, monospace;
            font-size: 0.9em;
            max-height: 250px;
            overflow-y: auto;
            margin-top: 20px;
            border: 1px solid var(--gray-800);
        }
        .console-log div {
            margin-bottom: 5px;
            line-height: 1.3;
        }
        .console-log .log-info { color: #81e6d9; } /* Cyan */
        .console-log .log-success { color: var(--success); }
        .console-log .log-error { color: var(--danger); }
        .console-log .log-warning { color: var(--warning); }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .ms-sm-auto, .px-md-4 { /* Reset Bootstrap offsets/paddings on small screens */
                margin-left: 0 !important;
                padding-left: 1rem !important;
                padding-right: 1rem !important;
            }
            .admin-sidebar { /* Assuming admin_sidebar.php has these styles */
                position: relative;
                width: 100%;
                height: auto;
            }
            .d-flex.justify-content-between.flex-wrap.flex-md-nowrap.align-items-center {
                flex-direction: column;
                align-items: flex-start;
            }
        }

        /* Admin Sidebar basic styling to replace includes/admin_sidebar.php content if it's just raw HTML */
        /* This is a placeholder for actual admin_sidebar.php content if it's just a div */
        /* If admin_sidebar.php is a full PHP file, this will not apply directly */
        .admin-sidebar {
            background-color: var(--dark);
            color: var(--white);
            padding: 20px;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: 250px; /* Fixed width for the sidebar */
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .admin-sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary);
            font-size: 1.8rem;
            font-weight: 700;
        }
        .admin-sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .admin-sidebar ul li {
            margin-bottom: 10px;
        }
        .admin-sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--gray-300);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        .admin-sidebar ul li a:hover,
        .admin-sidebar ul li a.active {
            background-color: var(--gray-700);
            color: var(--white);
        }
        .admin-sidebar ul li a i {
            width: 20px;
            height: 20px;
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <div class="container-fluid">
            <div class="row">
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block admin-sidebar collapse">
                    <div class="position-sticky pt-3">
                        <h2>Admin Panel</h2>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i data-feather="users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_levels.php">
                                    <i data-feather="award"></i> Membership Levels
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="payment_settings.php">
                                    <i data-feather="dollar-sign"></i> Payment Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="transactions.php">
                                    <i data-feather="credit-card"></i> Transactions
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="affiliates.php">
                                    <i data-feather="link"></i> Affiliates
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="helpdesk.php">
                                    <i data-feather="life-buoy"></i> Helpdesk
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="gift_management.php">
                                    <i data-feather="gift"></i> Gift Management
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="thresholds.php">
                                    <i data-feather="sliders"></i> Thresholds
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_admin.php">
                                    <i data-feather="user-check"></i> Membership+
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="teams.php">
                                    <i data-feather="users"></i> Teams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="streams_management.php">
                                    <i data-feather="video"></i> Streams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="cashouts.php" style="color: var(--light-green);">
                                    <i data-feather="dollar-sign"></i> Cashouts
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="email_settings.php">
                                    <i data-feather="mail"></i> Email Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="notifications.php">
                                    <i data-feather="bell"></i> Notifications
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="ai_settings.php">
                                    <i data-feather="cpu"></i> AI Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="niches.php">
                                    <i data-feather="grid"></i> Niches
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../dashboard.php">
                                    <i data-feather="home"></i> Back to Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">
                                    <i data-feather="log-out"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Email Settings</h1>
                    </div>
                    
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= $_SESSION['success'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?= $_SESSION['error'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['error']); ?>
                    <?php endif; ?>
                    
                    <div class="form-container">
                        <form method="POST">
                            <ul class="nav nav-tabs mb-4" id="emailTabs" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="general-tab" data-bs-toggle="tab" data-bs-target="#general" type="button" role="tab" aria-controls="general" aria-selected="true">
                                        <i data-feather="settings"></i> General Settings
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="smtp-tab" data-bs-toggle="tab" data-bs-target="#smtp" type="button" role="tab" aria-controls="smtp" aria-selected="false">
                                        <i data-feather="server"></i> SMTP Settings
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="test-email-tab" data-bs-toggle="tab" data-bs-target="#test-email" type="button" role="tab" aria-controls="test-email" aria-selected="false">
                                        <i data-feather="mail"></i> Test Email
                                    </button>
                                </li>
                            </ul>
                            
                            <div class="tab-content" id="emailTabsContent">
                                <div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
                                    <div class="card mb-4">
                                        <div class="card-body">
                                            <div class="mb-3">
                                                <label for="email_method" class="form-label">Email Sending Method</label>
                                                <select class="form-select" id="email_method" name="email_method" required>
                                                    <option value="php" <?= $current_settings['email_method'] === 'php' ? 'selected' : '' ?>>PHP mail()</option>
                                                    <option value="smtp" <?= $current_settings['email_method'] === 'smtp' ? 'selected' : '' ?>>SMTP</option>
                                                </select>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="from_email" class="form-label">From Email Address</label>
                                                <input type="email" class="form-control" id="from_email" name="from_email" 
                                                        value="<?= htmlspecialchars($current_settings['from_email']) ?>" required>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="from_name" class="form-label">From Name</label>
                                                <input type="text" class="form-control" id="from_name" name="from_name" 
                                                        value="<?= htmlspecialchars($current_settings['from_name']) ?>" required>
                                            </div>

                                            <hr class="my-4">
                                            <h4>Email Activation Template</h4>
                                            <div class="mb-3">
                                                <label for="email_activation_subject" class="form-label">Activation Email Subject</label>
                                                <input type="text" class="form-control" id="email_activation_subject" name="email_activation_subject"
                                                        value="<?= htmlspecialchars($current_settings['email_activation_subject']) ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="email_activation_content" class="form-label">Activation Email Content</label>
                                                <textarea class="form-control" id="email_activation_content" name="email_activation_content" rows="10" required
                                                placeholder="Use {activation_link} as a placeholder for the actual activation URL. You can use HTML."><?= htmlspecialchars($current_settings['email_activation_content']) ?></textarea>
                                                <small class="form-text text-muted">Use <code>{activation_link}</code> as a placeholder for the actual activation URL. You can use HTML content.</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="tab-pane fade" id="smtp" role="tabpanel" aria-labelledby="smtp-tab">
                                    <div class="card mb-4">
                                        <div class="card-body">
                                            <div class="mb-3">
                                                <label for="smtp_host" class="form-label">SMTP Host</label>
                                                <input type="text" class="form-control" id="smtp_host" name="smtp_host" 
                                                        value="<?= htmlspecialchars($current_settings['smtp_host']) ?>">
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="smtp_port" class="form-label">SMTP Port</label>
                                                <input type="number" class="form-control" id="smtp_port" name="smtp_port" 
                                                        value="<?= htmlspecialchars($current_settings['smtp_port']) ?>" min="1" max="65535">
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="smtp_username" class="form-label">SMTP Username</label>
                                                <input type="text" class="form-control" id="smtp_username" name="smtp_username" 
                                                        value="<?= htmlspecialchars($current_settings['smtp_username']) ?>">
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="smtp_password" class="form-label">SMTP Password</label>
                                                <div class="input-group">
                                                    <input type="password" class="form-control" id="smtp_password" name="smtp_password" 
                                                            value="<?= htmlspecialchars($current_settings['smtp_password']) ?>">
                                                    <span class="input-group-text password-toggle" data-target="smtp_password">
                                                        <i class="bi bi-eye"></i>
                                                    </span>
                                                </div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="smtp_encryption" class="form-label">Encryption</label>
                                                <select class="form-select" id="smtp_encryption" name="smtp_encryption">
                                                    <option value="tls" <?= $current_settings['smtp_encryption'] === 'tls' ? 'selected' : '' ?>>TLS</option>
                                                    <option value="ssl" <?= $current_settings['smtp_encryption'] === 'ssl' ? 'selected' : '' ?>>SSL</option>
                                                    <option value="" <?= empty($current_settings['smtp_encryption']) ? 'selected' : '' ?>>None</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="test-email" role="tabpanel" aria-labelledby="test-email-tab">
                                    <div class="card mb-4">
                                        <div class="card-body">
                                            <p class="text-muted">Send a test email using the currently configured email settings.</p>
                                            <div class="mb-3">
                                                <label for="test_email_address" class="form-label">Recipient Email Address</label>
                                                <input type="email" class="form-control" id="test_email_address" required
                                                        value="<?= htmlspecialchars($current_user_email) ?>" placeholder="test@example.com">
                                            </div>
                                            <div class="mb-3">
                                                <label for="test_email_subject" class="form-label">Test Email Subject</label>
                                                <input type="text" class="form-control" id="test_email_subject" value="Test Email from Churn Analytics" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="test_email_content" class="form-label">Test Email Content (HTML supported)</label>
                                                <textarea class="form-control" id="test_email_content" rows="6">
                                                    &lt;p&gt;This is a &lt;b&gt;test email&lt;/b&gt; from your Churn Analytics platform.&lt;/p&gt;
                                                    &lt;p&gt;Configuration method: &lt;strong&gt;&lt;span id="display_email_method"&gt;N/A&lt;/span&gt;&lt;/strong&gt;&lt;/p&gt;
                                                    &lt;p&gt;If you received this, your email settings are working!&lt;/p&gt;
                                                </textarea>
                                            </div>
                                            <button type="button" id="sendTestEmailBtn" class="btn btn-primary">
                                                <i data-feather="send"></i> Send Test Email
                                            </button>

                                            <div class="console-log mt-4" id="testEmailLog">
                                                <div>--- Test Email Log ---</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="text-end">
                                <button type="submit" name="update_settings" class="btn btn-primary">Save Settings</button>
                            </div>
                        </form>
                    </div>
                </main>
            </div>
        </div>
    </div> <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize Feather Icons
        feather.replace();

        // Toggle password visibility
        document.querySelectorAll('.password-toggle').forEach(toggle => {
            toggle.addEventListener('click', function() {
                const targetId = this.getAttribute('data-target');
                const input = document.getElementById(targetId);
                const icon = this.querySelector('i');
                
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('bi-eye');
                    icon.classList.add('bi-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('bi-eye-slash');
                    icon.classList.add('bi-eye');
                }
            });
        });

        // Show/Hide SMTP tab and update method display in Test Email tab
        const emailMethodSelect = document.getElementById('email_method');
        const smtpTabButton = document.getElementById('smtp-tab');
        const displayEmailMethodSpan = document.getElementById('display_email_method');

        function toggleSmtpTabVisibility() {
            if (emailMethodSelect.value === 'smtp') {
                smtpTabButton.classList.remove('d-none'); // Show the tab button
                // If the General tab is currently active, automatically switch to SMTP
                const generalTabButton = document.getElementById('general-tab');
                if (generalTabButton && generalTabButton.classList.contains('active')) {
                    const smtpTab = new bootstrap.Tab(smtpTabButton);
                    smtpTab.show();
                }
            } else {
                smtpTabButton.classList.add('d-none'); // Hide the tab button
                // If SMTP tab was active, switch to General tab
                if (smtpTabButton.classList.contains('active')) {
                    const generalTab = new bootstrap.Tab(document.getElementById('general-tab'));
                    generalTab.show();
                }
            }
            // Update the method display in the Test Email tab
            if (displayEmailMethodSpan) {
                displayEmailMethodSpan.textContent = emailMethodSelect.value.toUpperCase();
            }
        }

        emailMethodSelect.addEventListener('change', toggleSmtpTabVisibility);

        // Initial call to set tab visibility on page load
        document.addEventListener('DOMContentLoaded', toggleSmtpTabVisibility);


        // Test Email Sending Logic (AJAX POST to self)
        const sendTestEmailBtn = document.getElementById('sendTestEmailBtn');
        const testEmailLog = document.getElementById('testEmailLog');

        sendTestEmailBtn.addEventListener('click', async () => {
            const recipient = document.getElementById('test_email_address').value;
            const subject = document.getElementById('test_email_subject').value;
            const content = document.getElementById('test_email_content').value;

            // Clear previous logs
            testEmailLog.innerHTML = '<div>--- Test Email Log ---</div>';
            logToConsole('info', 'Initiating test email send...');

            try {
                // Manually construct URLSearchParams for application/x-www-form-urlencoded
                const formData = new URLSearchParams();
                formData.append('action', 'test_email');
                formData.append('test_email_address', recipient);
                formData.append('test_email_subject', subject);
                formData.append('test_email_content', content);

                const response = await fetch('email_settings.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: formData.toString() // Send as URL-encoded string
                });

                if (!response.ok) {
                    logToConsole('error', `HTTP error! Status: ${response.status}`);
                    // Attempt to read response body for more details
                    try {
                        const errorText = await response.text();
                        logToConsole('error', `Response: ${errorText.substring(0, 200)}...`); // Limit length
                    } catch (e) {
                        logToConsole('error', 'Could not read error response body.');
                    }
                    return;
                }

                const result = await response.json();
                if (result.log) {
                    result.log.forEach(entry => {
                        logToConsole(entry.type, entry.message);
                    });
                } else {
                    logToConsole('error', 'Unexpected response format for test email.');
                    logToConsole('error', JSON.stringify(result)); // Log raw result
                }
            } catch (error) {
                logToConsole('error', `Network or processing error: ${error.message}`);
                console.error('Test email fetch error:', error);
            }
        });

        function logToConsole(type, message) {
            const logEntry = document.createElement('div');
            logEntry.classList.add(`log-${type}`);
            logEntry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
            testEmailLog.appendChild(logEntry);
            testEmailLog.scrollTop = testEmailLog.scrollHeight; // Scroll to bottom
        }
    </script>
</body>
</html>