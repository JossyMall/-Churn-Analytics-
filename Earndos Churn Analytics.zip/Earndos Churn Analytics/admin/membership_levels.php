<?php
// admin/membership_levels.php
require_once '../includes/db.php';

// Admin verification
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_membership'])) {
        // Add new membership level
        $name = trim($_POST['name']);
        $standard_price = floatval($_POST['standard_price']);
        $promo_price = floatval($_POST['promo_price']);
        $yearly_discount = floatval($_POST['yearly_discount']);
        $max_streams = intval($_POST['max_streams']);
        $max_contacts = intval($_POST['max_contacts']);
        $features = trim($_POST['features']);
        
        $stmt = $pdo->prepare("INSERT INTO membership_levels 
                               (name, standard_price, promo_price, yearly_discount, max_streams, max_contacts, features) 
                               VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $standard_price, $promo_price, $yearly_discount, $max_streams, $max_contacts, $features]);
        
        $_SESSION['success'] = "Membership level added successfully";
    } elseif (isset($_POST['update_membership'])) {
        // Update membership level
        $id = intval($_POST['id']);
        $name = trim($_POST['name']);
        $standard_price = floatval($_POST['standard_price']);
        $promo_price = floatval($_POST['promo_price']);
        $yearly_discount = floatval($_POST['yearly_discount']);
        $max_streams = intval($_POST['max_streams']);
        $max_contacts = intval($_POST['max_contacts']);
        $features = trim($_POST['features']);
        
        $stmt = $pdo->prepare("UPDATE membership_levels SET 
                               name = ?, standard_price = ?, promo_price = ?, yearly_discount = ?,
                               max_streams = ?, max_contacts = ?, features = ?
                               WHERE id = ?");
        $stmt->execute([$name, $standard_price, $promo_price, $yearly_discount, $max_streams, $max_contacts, $features, $id]);
        
        $_SESSION['success'] = "Membership level updated successfully";
    } elseif (isset($_POST['delete_membership'])) {
        // Delete membership level
        $id = intval($_POST['id']);
        $transfer_to = intval($_POST['transfer_to']);
        
        // Begin transaction
        $pdo->beginTransaction();
        
        try {
            // Update users with deleted membership to new membership
            $stmt = $pdo->prepare("UPDATE users SET membership_id = ? WHERE membership_id = ?");
            $stmt->execute([$transfer_to, $id]);
            
            // Delete the membership level
            $stmt = $pdo->prepare("DELETE FROM membership_levels WHERE id = ?");
            $stmt->execute([$id]);
            
            $pdo->commit();
            $_SESSION['success'] = "Membership level deleted and users transferred";
        } catch (Exception $e) {
            $pdo->rollBack();
            $_SESSION['error'] = "Error deleting membership level: " . $e->getMessage();
        }
    } elseif (isset($_POST['toggle_status'])) {
        // Toggle membership status
        $id = intval($_POST['id']);
        
        $stmt = $pdo->prepare("UPDATE membership_levels SET is_active = NOT is_active WHERE id = ?");
        $stmt->execute([$id]);
        
        $_SESSION['success'] = "Membership status updated";
    }
    
    header('Location: membership_levels.php');
    exit;
}

// Get all membership levels
$stmt = $pdo->query("SELECT * FROM membership_levels ORDER BY standard_price");
$membership_levels = $stmt->fetchAll();

// Get membership levels for transfer dropdown
$stmt = $pdo->query("SELECT id, name FROM membership_levels ORDER BY name");
$transfer_options = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Membership Levels | Admin Panel</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Font Awesome for consistent icons across pages -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
            xintegrity="sha512-1ycn6IcaQQ40ZefMdHjAcUwaGDvPwdOaUcsU5XrU+pL87B7fC3J0P2Kqj1Z5M5YqD65B2L52B7y42j5P5c+A=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Feather Icons for new tab icons -->
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>

    <style>
        /* Define your color variables */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
            --light-green: #90EE90; /* Light green color */
        }

        /* Body and main layout styling */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--gray-100);
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer if added */
        }
        .site-wrapper { /* New wrapper for sticky footer logic */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container-fluid {
            padding: 0; /* Remove padding to make sidebar stick to edge */
            flex-grow: 1; /* Allow container-fluid to take up remaining height */
        }
        .row {
            margin: 0; /* Remove row margins to prevent unwanted space */
            flex-grow: 1;
        }
        /* Main content area */
        main {
            padding: 20px !important; /* Important to override Bootstrap default */
            background-color: var(--gray-100); /* Content area background */
            flex-grow: 1;
        }
        .d-flex.justify-content-between.flex-wrap.flex-md-nowrap.align-items-center {
            padding-top: 1.5rem !important; /* Bootstrap pt-3 */
            padding-bottom: 1rem !important; /* Bootstrap pb-2 */
            margin-bottom: 1.5rem !important; /* Bootstrap mb-3 */
        }

        /* Admin Sidebar basic styling */
        .admin-sidebar {
            background-color: var(--dark);
            color: var(--white);
            padding: 20px;
            /* Fixed position for desktop view */
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: 250px; /* Fixed width for the sidebar */
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .admin-sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary);
            font-size: 1.8rem;
            font-weight: 700;
        }
        .admin-sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .admin-sidebar ul li {
            margin-bottom: 10px;
        }
        .admin-sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--gray-300);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        .admin-sidebar ul li a:hover,
        .admin-sidebar ul li a.active {
            background-color: var(--gray-700);
            color: var(--white);
        }
        .admin-sidebar ul li a i {
            width: 20px;
            height: 20px;
        }

        /* Specific styles for membership_levels.php content */
        .action-btns .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }
        .form-container {
            max-width: 800px;
            margin: 0 auto;
        }
        .table-container {
            overflow-x: auto;
        }
        .features-list {
            max-height: 150px;
            overflow-y: auto;
        }
        /* Card styles */
        .card {
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05); /* Soft shadow */
        }
        .card-body {
            padding: 25px;
        }
        .form-control, .form-select {
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            padding: 10px 15px;
            color: var(--gray-800);
            background-color: var(--white);
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(58, 195, 184, 0.25);
        }
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: background-color 0.2s, border-color 0.2s;
        }
        .btn-primary:hover {
            background-color: #2da89e;
            border-color: #2da89e;
        }
        .alert {
            border-radius: 8px;
            font-weight: 500;
        }

        /* Responsive adjustments: Sidebar becomes standard column on mobile */
        @media (max-width: 767.98px) {
            .admin-sidebar {
                position: relative; /* Remove fixed positioning on small screens */
                width: 100%; /* Take full width on small screens */
                height: auto; /* Adjust height based on content */
                box-shadow: none; /* Remove shadow to blend better */
            }
            main {
                margin-left: 0 !important; /* Remove desktop margin on small screens */
            }
            .navbar-mobile-toggle { /* Ensure this is hidden as it's not needed now */
                display: none !important;
            }
        }

        @media (min-width: 768px) { /* Applies to md and larger screens */
            .main-content-area {
                margin-left: 250px; /* Offset for the fixed sidebar */
            }
            /* Hide the mobile toggle navbar on desktop */
            .navbar-mobile-toggle {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <!-- Mobile Navbar/Toggle is not included as per instruction to ignore mobile changes. -->
        <!-- The layout will now simply stack on small screens. -->

        <div class="container-fluid">
            <div class="row">
                <!-- Admin Sidebar -->
                <!-- The d-md-block class makes it a block element from md breakpoint up, making it visible -->
                <!-- The 'collapse' class is removed to ensure it's always visible on desktop -->
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block admin-sidebar">
                    <div class="position-sticky pt-3">
                        <h2>Admin Panel</h2>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i data-feather="users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="membership_levels.php">
                                    <i data-feather="award"></i> Membership Levels
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="payment_settings.php">
                                    <i data-feather="dollar-sign"></i> Payment Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="affiliates.php">
                                    <i data-feather="link"></i> Affiliates
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="transactions.php">
                                    <i data-feather="credit-card"></i> Transactions
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="helpdesk.php">
                                    <i data-feather="life-buoy"></i> Helpdesk
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="gift_management.php">
                                    <i data-feather="gift"></i> Gift Management
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="thresholds.php">
                                    <i data-feather="sliders"></i> Thresholds
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_admin.php">
                                    <i data-feather="user-check"></i> Membership+
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="teams.php">
                                    <i data-feather="users"></i> Teams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="streams_management.php">
                                    <i data-feather="video"></i> Streams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="cashouts.php" style="color: var(--light-green);">
                                    <i data-feather="dollar-sign"></i> Cashouts
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="email_settings.php">
                                    <i data-feather="mail"></i> Email Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="notifications.php">
                                    <i data-feather="bell"></i> Notifications
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="ai_settings.php">
                                    <i data-feather="cpu"></i> AI Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="niches.php">
                                    <i data-feather="grid"></i> Niches
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../dashboard.php">
                                    <i data-feather="home"></i> Back to Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">
                                    <i data-feather="log-out"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- End Admin Sidebar -->
                
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content-area">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Membership Levels</h1>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMembershipModal">
                            <i class="bi bi-plus-lg"></i> Add Level
                        </button>
                    </div>
                    
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= $_SESSION['success'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?= $_SESSION['error'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['error']); ?>
                    <?php endif; ?>
                    
                    <div class="table-container">
                        <table class="table table-striped table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Pricing</th>
                                    <th>Limits</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($membership_levels as $level): ?>
                                <tr>
                                    <td><?= $level['id'] ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($level['name']) ?></strong>
                                        <div class="features-list small text-muted mt-1">
                                            <?= nl2br(htmlspecialchars($level['features'])) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-column">
                                            <span>Standard: $<?= number_format($level['standard_price'], 2) ?>/mo</span>
                                            <span>Promo: $<?= number_format($level['promo_price'], 2) ?>/mo</span>
                                            <span>Yearly Discount: <?= $level['yearly_discount'] ?>%</span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-column">
                                            <span>Streams: <?= $level['max_streams'] ?></span>
                                            <span>Contacts: <?= $level['max_contacts'] ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?= $level['is_active'] ? 'success' : 'danger' ?>">
                                            <?= $level['is_active'] ? 'Active' : 'Inactive' ?>
                                        </span>
                                    </td>
                                    <td class="action-btns">
                                        <button class="btn btn-sm btn-warning" data-bs-toggle="modal" 
                                            data-bs-target="#editMembershipModal" 
                                            data-id="<?= $level['id'] ?>"
                                            data-name="<?= htmlspecialchars($level['name']) ?>"
                                            data-standard_price="<?= $level['standard_price'] ?>"
                                            data-promo_price="<?= $level['promo_price'] ?>"
                                            data-yearly_discount="<?= $level['yearly_discount'] ?>"
                                            data-max_streams="<?= $level['max_streams'] ?>"
                                            data-max_contacts="<?= $level['max_contacts'] ?>"
                                            data-features="<?= htmlspecialchars($level['features']) ?>">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="id" value="<?= $level['id'] ?>">
                                            <button type="submit" name="toggle_status" class="btn btn-sm btn-<?= $level['is_active'] ? 'danger' : 'success' ?>">
                                                <i class="bi bi-power"></i>
                                            </button>
                                        </form>
                                        <button class="btn btn-sm btn-danger" data-bs-toggle="modal" 
                                            data-bs-target="#deleteMembershipModal" 
                                            data-id="<?= $level['id'] ?>"
                                            data-name="<?= htmlspecialchars($level['name']) ?>">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <!-- Add Membership Modal -->
    <div class="modal fade" id="addMembershipModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Add New Membership Level</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="name" class="form-label">Name</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="standard_price" class="form-label">Standard Price (Monthly)</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" class="form-control" id="standard_price" name="standard_price" 
                                            min="0" step="0.01" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="promo_price" class="form-label">Promotional Price (Monthly)</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" class="form-control" id="promo_price" name="promo_price" 
                                            min="0" step="0.01" required>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="yearly_discount" class="form-label">Yearly Discount (%)</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="yearly_discount" name="yearly_discount" 
                                            min="0" max="100" step="0.1" value="0">
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="max_streams" class="form-label">Max Streams</label>
                                <input type="number" class="form-control" id="max_streams" name="max_streams" 
                                        min="1" value="1" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="max_contacts" class="form-label">Max Contacts</label>
                                <input type="number" class="form-control" id="max_contacts" name="max_contacts" 
                                        min="1" value="50" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="features" class="form-label">Features (one per line)</label>
                            <textarea class="form-control" id="features" name="features" rows="5" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="add_membership" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Membership Modal -->
    <div class="modal fade" id="editMembershipModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="id" id="edit_id">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Membership Level</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_name" class="form-label">Name</label>
                                <input type="text" class="form-control" id="edit_name" name="name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_standard_price" class="form-label">Standard Price (Monthly)</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" class="form-control" id="edit_standard_price" name="standard_price" 
                                            min="0" step="0.01" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_promo_price" class="form-label">Promotional Price (Monthly)</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" class="form-control" id="edit_promo_price" name="promo_price" 
                                            min="0" step="0.01" required>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_yearly_discount" class="form-label">Yearly Discount (%)</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="edit_yearly_discount" name="yearly_discount" 
                                            min="0" max="100" step="0.1">
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_max_streams" class="form-label">Max Streams</label>
                                <input type="number" class="form-control" id="edit_max_streams" name="max_streams" 
                                        min="1" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_max_contacts" class="form-label">Max Contacts</label>
                                <input type="number" class="form-control" id="edit_max_contacts" name="max_contacts" 
                                        min="1" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_features" class="form-label">Features (one per line)</label>
                            <textarea class="form-control" id="edit_features" name="features" rows="5" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="update_membership" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Membership Modal -->
    <div class="modal fade" id="deleteMembershipModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="id" id="delete_id">
                    <div class="modal-header">
                        <h5 class="modal-title">Confirm Delete</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>You are about to delete membership level: <strong id="delete_name"></strong></p>
                        <p>All users with this membership will be transferred to:</p>
                        <select class="form-select" name="transfer_to" required>
                            <?php foreach ($transfer_options as $option): ?>
                                <!-- Exclude the currently selected membership from transfer options -->
                                <?php if ($option['id'] != ($level['id'] ?? null)): ?> 
                                    <option value="<?= $option['id'] ?>"><?= htmlspecialchars($option['name']) ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                        <div class="alert alert-danger mt-3">
                            <strong>Warning:</strong> This action cannot be undone!
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="delete_membership" class="btn btn-danger">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize Feather Icons
        feather.replace();

        // Handle edit modal data
        const editModal = document.getElementById('editMembershipModal');
        if (editModal) {
            editModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                document.getElementById('edit_id').value = button.getAttribute('data-id');
                document.getElementById('edit_name').value = button.getAttribute('data-name');
                document.getElementById('edit_standard_price').value = button.getAttribute('data-standard_price');
                document.getElementById('edit_promo_price').value = button.getAttribute('data-promo_price');
                document.getElementById('edit_yearly_discount').value = button.getAttribute('data-yearly_discount');
                document.getElementById('edit_max_streams').value = button.getAttribute('data-max_streams');
                document.getElementById('edit_max_contacts').value = button.getAttribute('data-max_contacts');
                document.getElementById('edit_features').value = button.getAttribute('data-features');
            });
        }

        // Handle delete modal data
        const deleteModal = document.getElementById('deleteMembershipModal');
        if (deleteModal) {
            deleteModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                const membershipIdToDelete = button.getAttribute('data-id');
                const membershipNameToDelete = button.getAttribute('data-name');
                
                document.getElementById('delete_id').value = membershipIdToDelete;
                document.getElementById('delete_name').textContent = membershipNameToDelete;

                // Populate the transfer_to dropdown, excluding the current membership being deleted
                const transferSelect = deleteModal.querySelector('select[name="transfer_to"]');
                transferSelect.innerHTML = ''; // Clear existing options
                
                // Assuming `transfer_options` is available globally or passed via data attribute if needed
                // For this example, we re-fetch from PHP variable which is available
                const phpTransferOptions = <?= json_encode($transfer_options) ?>; // PHP array converted to JS
                
                phpTransferOptions.forEach(option => {
                    if (option.id != membershipIdToDelete) { // Ensure we don't allow transfer to self
                        const opt = document.createElement('option');
                        opt.value = option.id;
                        opt.textContent = option.name;
                        transferSelect.appendChild(opt);
                    }
                });

                // If no other options are left (e.g., only one membership level exists), disable delete
                if (transferSelect.options.length === 0) {
                    deleteModal.querySelector('.modal-footer button[type="submit"]').disabled = true;
                    deleteModal.querySelector('.modal-body').insertAdjacentHTML('beforeend', '<div class="alert alert-warning mt-3">Cannot delete the last remaining membership level.</div>');
                } else {
                    deleteModal.querySelector('.modal-footer button[type="submit"]').disabled = false;
                }
            });
        }
    </script>
</body>
</html>
