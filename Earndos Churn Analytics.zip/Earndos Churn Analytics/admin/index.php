<?php
// admin/index.php
require_once '../includes/db.php'; // Path from admin/ to includes/db.php

// --- Admin Verification ---
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT username, is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    // Redirect non-admin users away
    header('Location: ../dashboard.php');
    exit;
}
// --- End Admin Verification ---

// --- PHP Error Reporting for Debugging ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// --- End PHP Error Reporting ---

// --- Fetch Aggregate Data for Admin Dashboard ---

// 1. Overall User and Resource Counts
$total_users = $pdo->query("SELECT COUNT(id) FROM users")->fetchColumn();
$total_streams = $pdo->query("SELECT COUNT(id) FROM streams")->fetchColumn();
$total_contacts = $pdo->query("SELECT COUNT(id) FROM contacts")->fetchColumn();
$total_active_memberships = $pdo->query("SELECT COUNT(id) FROM user_subscriptions WHERE is_active = 1 AND end_date > NOW()")->fetchColumn();

// 2. Global Churn Metrics Summary
$global_churn_summary = [
    'high_risk_count' => 0,
    'medium_risk_count' => 0,
    'low_risk_count' => 0,
    'total_scored_contacts' => 0,
    'churned_count' => 0,
    'resurrected_count' => 0,
    'risk_distribution_percentages' => ['high' => 0, 'medium' => 0, 'low' => 0],
];

try {
    $stmt_scores = $pdo->query("
        SELECT cs.contact_id, cs.score
        FROM churn_scores cs
        WHERE (cs.contact_id, cs.scored_at) IN (
            SELECT contact_id, MAX(scored_at) FROM churn_scores GROUP BY contact_id
        )
    ");
    $latest_global_scores = $stmt_scores->fetchAll(PDO::FETCH_ASSOC);

    foreach ($latest_global_scores as $score_data) {
        $score = $score_data['score'];
        $global_churn_summary['total_scored_contacts']++;
        if ($score > 70) {
            $global_churn_summary['high_risk_count']++;
        } elseif ($score > 40) {
            $global_churn_summary['medium_risk_count']++;
        } else {
            $global_churn_summary['low_risk_count']++;
        }
    }

    if ($global_churn_summary['total_scored_contacts'] > 0) {
        $global_churn_summary['risk_distribution_percentages']['high'] = round(($global_churn_summary['high_risk_count'] / $global_churn_summary['total_scored_contacts']) * 100, 1);
        $global_churn_summary['risk_distribution_percentages']['medium'] = round(($global_churn_summary['medium_risk_count'] / $global_churn_summary['total_scored_contacts']) * 100, 1);
        $global_churn_summary['risk_distribution_percentages']['low'] = 100 - ($global_churn_summary['risk_distribution_percentages']['high'] + $global_churn_summary['risk_distribution_percentages']['medium']);
    }

    $global_churn_summary['churned_count'] = $pdo->query("SELECT COUNT(DISTINCT contact_id) FROM churned_users")->fetchColumn();
    $global_churn_summary['resurrected_count'] = $pdo->query("SELECT COUNT(DISTINCT contact_id) FROM resurrected_users")->fetchColumn();

} catch (PDOException $e) {
    error_log("Admin Dashboard - Churn Summary Error: " . $e->getMessage());
    // Data remains default empty/zero
}

// 3. Monthly New User Registrations (Last 12 months)
$monthly_new_users_labels = [];
$monthly_new_users_data = [];
try {
    $stmt_new_users = $pdo->query("
        SELECT DATE_FORMAT(created_at, '%Y-%m') AS month_year, COUNT(id) AS user_count
        FROM users
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
        GROUP BY month_year
        ORDER BY month_year ASC
    ");
    $raw_new_users = $stmt_new_users->fetchAll(PDO::FETCH_ASSOC);

    $period = new DatePeriod(
        new DateTime('-11 months first day of this month'),
        new DateInterval('P1M'),
        new DateTime('first day of next month')
    );
    $formatted_new_users_tmp = [];
    foreach ($period as $dt) { $formatted_new_users_tmp[$dt->format('Y-m')] = 0; }
    foreach ($raw_new_users as $row) { $formatted_new_users_tmp[$row['month_year']] = (int)$row['user_count']; }
    foreach ($formatted_new_users_tmp as $month_key => $count) {
        $monthly_new_users_labels[] = (new DateTime($month_key . '-01'))->format('M Y');
        $monthly_new_users_data[] = $count;
    }
} catch (PDOException $e) {
    error_log("Admin Dashboard - New Users Chart Error: " . $e->getMessage());
}

// 4. Monthly New Contact Acquisition (Last 12 months)
$monthly_new_contacts_labels = [];
$monthly_new_contacts_data = [];
try {
    $stmt_new_contacts = $pdo->query("
        SELECT DATE_FORMAT(created_at, '%Y-%m') AS month_year, COUNT(id) AS contact_count
        FROM contacts
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
        GROUP BY month_year
        ORDER BY month_year ASC
    ");
    $raw_new_contacts = $stmt_new_contacts->fetchAll(PDO::FETCH_ASSOC);

    $period = new DatePeriod(
        new DateTime('-11 months first day of this month'),
        new DateInterval('P1M'),
        new DateTime('first day of next month')
    );
    $formatted_new_contacts_tmp = [];
    foreach ($period as $dt) { $formatted_new_contacts_tmp[$dt->format('Y-m')] = 0; }
    foreach ($raw_new_contacts as $row) { $formatted_new_contacts_tmp[$row['month_year']] = (int)$row['contact_count']; }
    foreach ($formatted_new_contacts_tmp as $month_key => $count) {
        $monthly_new_contacts_labels[] = (new DateTime($month_key . '-01'))->format('M Y');
        $monthly_new_contacts_data[] = $count;
    }
} catch (PDOException $e) {
    error_log("Admin Dashboard - New Contacts Chart Error: " . $e->getMessage());
}


// 5. Monthly Average Churn Rate (Last 12 months, aggregated across all contacts)
$monthly_avg_churn_labels = [];
$monthly_avg_churn_data = [];
try {
    $stmt_avg_churn = $pdo->query("
        SELECT
            DATE_FORMAT(cs.scored_at, '%Y-%m') AS month_year,
            AVG(cs.score) AS average_score
        FROM churn_scores cs
        GROUP BY month_year
        ORDER BY month_year ASC
    ");
    $raw_avg_churn = $stmt_avg_churn->fetchAll(PDO::FETCH_ASSOC);

    $period = new DatePeriod(
        new DateTime('-11 months first day of this month'),
        new DateInterval('P1M'),
        new DateTime('first day of next month')
    );
    $formatted_avg_churn_tmp = [];
    foreach ($period as $dt) { $formatted_avg_churn_tmp[$dt->format('Y-m')] = 0.0; }
    foreach ($raw_avg_churn as $row) { $formatted_avg_churn_tmp[$row['month_year']] = (float)$row['average_score']; }
    foreach ($formatted_avg_churn_tmp as $month_key => $score) {
        $monthly_avg_churn_labels[] = (new DateTime($month_key . '-01'))->format('M Y');
        $monthly_avg_churn_data[] = round($score, 1);
    }
} catch (PDOException $e) {
    error_log("Admin Dashboard - Monthly Avg Churn Chart Error: " . $e->getMessage());
}

// 6. Top 5 Most Used Features (Overall)
$top_features_data = [];
try {
    // Get churn_metrics ID for 'feature_usage'
    $stmt_feature_metric_id = $pdo->query("SELECT id FROM churn_metrics WHERE name = 'feature_usage'");
    $feature_metric_id = $stmt_feature_metric_id->fetchColumn();

    if ($feature_metric_id) {
        $stmt_top_features = $pdo->prepare("
            SELECT md.value AS feature_name_or_url, COUNT(md.id) AS usage_count
            FROM metric_data md
            WHERE md.metric_id = :feature_metric_id
            GROUP BY feature_name_or_url
            ORDER BY usage_count DESC
            LIMIT 5
        ");
        $stmt_top_features->bindValue(':feature_metric_id', $feature_metric_id, PDO::PARAM_INT);
        $stmt_top_features->execute();
        $top_features_data = $stmt_top_features->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    error_log("Admin Dashboard - Top Features Error: " . $e->getMessage());
}

// 7. Financial Summary (Total Membership Revenue, Total Affiliate Payouts)
// Corrected to use 'amount' column for transactions table as per schema
$total_membership_revenue = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE status = 'completed'")->fetchColumn();
$total_affiliate_payouts = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM affiliate_cashouts WHERE status = 'paid'")->fetchColumn();


// 8. Global Churn Index (Most recent for the entire platform or average of user churn indices)
// For simplicity, let's just get the average of the latest churn_index values for all users.
$global_churn_index = $pdo->query("
    SELECT COALESCE(AVG(index_value), 0) FROM churn_index
    WHERE (user_id, month) IN (
        SELECT user_id, MAX(month) FROM churn_index GROUP BY user_id
    )
")->fetchColumn();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Churn Analytics</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <!-- Bootstrap Icons (if used) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Font Awesome for consistent icons across pages -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
          xintegrity="sha512-1ycn6IcaQQ40ZefMdHjAcUwaGDvPwdOaUcsU5XrU+pL87B7fC3J0P2Kqj1Z5M5YqD65B2L52B7y42j5P5c+A=="
          crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Feather Icons -->
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        /* Define your color variables */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
        }

        /* Body and main layout styling */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--gray-100);
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer if needed */
        }
        .site-wrapper { /* Main wrapper for the entire page content */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container-fluid {
            padding: 0; /* Remove padding to make sidebar stick to edge */
            flex-grow: 1; /* Allow container-fluid to take up remaining height */
        }
        .row {
            margin: 0; /* Remove row margins to prevent unwanted space */
            flex-grow: 1;
        }
        main {
            padding: 20px !important; /* Important to override Bootstrap default */
            background-color: var(--gray-100); /* Content area background */
            flex-grow: 1;
        }
        .d-flex.justify-content-between.flex-wrap.flex-md-nowrap.align-items-center {
            padding-top: 1.5rem !important; /* Bootstrap pt-3 */
            padding-bottom: 1rem !important; /* Bootstrap pb-2 */
            margin-bottom: 1.5rem !important; /* Bootstrap mb-3 */
        }

        /* Admin Sidebar styling */
        .admin-sidebar {
            background-color: var(--dark);
            color: var(--white);
            padding: 20px;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: 250px;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .admin-sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary);
            font-size: 1.8rem;
            font-weight: 700;
        }
        .admin-sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .admin-sidebar ul li {
            margin-bottom: 10px;
        }
        .admin-sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--gray-300);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        .admin-sidebar ul li a:hover,
        .admin-sidebar ul li a.active {
            background-color: var(--gray-700);
            color: var(--white);
        }
        .admin-sidebar ul li a i {
            width: 20px;
            height: 20px;
        }
        .nav-link-cashouts { /* Custom class for cashouts link */
            background-color: #e6ffe6 !important;
            color: var(--success) !important;
            font-weight: 600;
        }
        .nav-link-cashouts:hover {
            background-color: #d0ffd0 !important;
        }

        /* Admin Dashboard Grid (Summary Cards) */
        .admin-summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .summary-card {
            background-color: var(--white);
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            border: 1px solid var(--gray-200);
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            min-height: 140px;
        }
        .summary-card h3 {
            font-size: 1rem;
            color: var(--gray-600);
            margin-bottom: 10px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .summary-card p {
            font-size: 2.5em;
            font-weight: 700;
            color: var(--dark);
            line-height: 1;
        }
        .summary-card .icon-small {
            font-size: 1.5em;
            color: var(--primary);
            margin-bottom: 5px;
        }
        .summary-card.green p { color: var(--success); }
        .summary-card.red p { color: var(--danger); }
        .summary-card.blue p { color: var(--info); }


        /* Admin Dashboard Chart Section */
        .chart-section {
            background-color: var(--white);
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            border: 1px solid var(--gray-200);
            margin-bottom: 30px;
        }
        .chart-section h2 {
            font-size: 1.8em;
            color: var(--dark);
            text-align: center;
            margin-bottom: 25px;
            border-bottom: none;
            padding-bottom: 0;
        }
        .chart-container {
            position: relative;
            height: 350px; /* Fixed height for charts */
            width: 100%;
        }
        .chart-container canvas {
            max-height: 100%;
            max-width: 100%;
        }
        .no-data-message {
            text-align: center;
            color: var(--gray-500);
            font-style: italic;
            padding: 50px 0;
        }

        /* Global Churn Risk Distribution Bar */
        .churn-risk-distribution {
            background-color: var(--white);
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            border: 1px solid var(--gray-200);
            margin-bottom: 30px;
        }
        .churn-risk-distribution h2 {
            font-size: 1.8em;
            color: var(--dark);
            text-align: center;
            margin-bottom: 25px;
            border-bottom: none;
            padding-bottom: 0;
        }
        .metric-bar-container {
            width: 100%;
            height: 30px;
            background-color: var(--gray-200);
            border-radius: 15px;
            overflow: hidden;
            display: flex;
            margin-bottom: 20px;
        }
        .metric-segment {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-size: 0.85rem;
            font-weight: 600;
            text-shadow: 0 0 2px rgba(0,0,0,0.3);
            white-space: nowrap;
            box-sizing: border-box;
            padding: 0 5px;
        }
        .segment-high-risk { background-color: var(--danger); }
        .segment-medium-risk { background-color: var(--warning); }
        .segment-low-risk { background-color: var(--success); }
        .metric-legend {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 15px;
        }
        .legend-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
            color: var(--gray-700);
        }
        .legend-color-box {
            width: 18px;
            height: 18px;
            border-radius: 4px;
        }

        /* Top Features List */
        .top-features-list {
            background-color: var(--white);
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            border: 1px solid var(--gray-200);
            margin-bottom: 30px;
        }
        .top-features-list h2 {
            font-size: 1.8em;
            color: var(--dark);
            text-align: center;
            margin-bottom: 25px;
            border-bottom: none;
            padding-bottom: 0;
        }
        .features-list ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .features-list li {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid var(--gray-100);
            font-size: 1.1em;
            color: var(--gray-800);
        }
        .features-list li:last-child {
            border-bottom: none;
        }
        .features-list li span:first-child {
            font-weight: 600;
        }
        .features-list li span:last-child {
            color: var(--primary);
            font-weight: 700;
        }

        /* Financial Summary */
        .financial-summary {
            background-color: var(--white);
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            border: 1px solid var(--gray-200);
            margin-bottom: 30px;
        }
        .financial-summary h2 {
            font-size: 1.8em;
            color: var(--dark);
            text-align: center;
            margin-bottom: 25px;
            border-bottom: none;
            padding-bottom: 0;
        }
        .financial-cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        .financial-card {
            background-color: var(--gray-100);
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            border: 1px solid var(--gray-200);
        }
        .financial-card h3 {
            font-size: 1em;
            color: var(--gray-600);
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .financial-card p {
            font-size: 2.2em;
            font-weight: 700;
            color: var(--dark);
            line-height: 1;
        }
        .financial-card.revenue p { color: var(--success); }
        .financial-card.payouts p { color: var(--danger); }


        /* Responsive adjustments */
        @media (max-width: 768px) {
            .col-md-9.ms-sm-auto.col-lg-10.px-md-4 {
                margin-left: 0 !important;
                padding-left: 1rem !important;
                padding-right: 1rem !important;
            }
            .admin-sidebar {
                position: relative;
                width: 100%;
                height: auto;
                box-shadow: none;
                padding: 15px;
            }
            .admin-summary-grid, .admin-dashboard-grid, .financial-cards-grid {
                grid-template-columns: 1fr;
            }
            .d-flex.justify-content-between.flex-wrap.flex-md-nowrap.align-items-center {
                flex-direction: column;
                align-items: flex-start;
                padding-top: 1rem !important;
            }
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <div class="container-fluid">
            <div class="row">
                <!-- Admin Sidebar -->
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block admin-sidebar collapse">
                    <div class="position-sticky pt-3">
                        <h2>Admin Panel</h2>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link active" href="index.php">
                                    <i data-feather="home"></i> Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i data-feather="users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_levels.php">
                                    <i data-feather="award"></i> Membership Levels
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="payment_settings.php">
                                    <i data-feather="dollar-sign"></i> Payment Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="transactions.php">
                                    <i data-feather="credit-card"></i> Transactions
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="affiliates.php">
                                    <i data-feather="link"></i> Affiliates
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="helpdesk.php">
                                    <i data-feather="life-buoy"></i> Helpdesk
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="gift_management.php">
                                    <i data-feather="gift"></i> Gift Management
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="thresholds.php">
                                    <i data-feather="sliders"></i> Thresholds
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_admin.php">
                                    <i data-feather="user-check"></i> Member Admin
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="teams.php">
                                    <i data-feather="users"></i> Teams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="streams_management.php">
                                    <i data-feather="monitor"></i> Streams Management
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link nav-link-cashouts" href="cashouts.php">
                                    <i data-feather="dollar-sign"></i> Cashouts
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="email_settings.php">
                                    <i data-feather="mail"></i> Email Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="notifications.php">
                                    <i data-feather="bell"></i> Notifications
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="ai_settings.php">
                                    <i data-feather="cpu"></i> AI Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="niches.php">
                                    <i data-feather="grid"></i> Niches
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../dashboard.php">
                                    <i data-feather="home"></i> Back to User Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">
                                    <i data-feather="log-out"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- End Admin Sidebar -->
                
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Admin Dashboard</h1>
                    </div>
                    
                    <p class="mb-4">Welcome, <strong><?= htmlspecialchars($user['username'] ?? 'Admin') ?></strong>! Here's an overview of your Churn Analytics platform's performance.</p>

                    <!-- Summary Cards -->
                    <div class="admin-summary-grid">
                        <div class="summary-card">
                            <i data-feather="users" class="icon-small"></i>
                            <h3>Total Users</h3>
                            <p><?= $total_users ?></p>
                        </div>
                        <div class="summary-card">
                            <i data-feather="monitor" class="icon-small"></i>
                            <h3>Total Streams</h3>
                            <p><?= $total_streams ?></p>
                        </div>
                        <div class="summary-card">
                            <i data-feather="user-check" class="icon-small"></i>
                            <h3>Total Contacts</h3>
                            <p><?= $total_contacts ?></p>
                        </div>
                        <div class="summary-card">
                            <i data-feather="award" class="icon-small"></i>
                            <h3>Active Memberships</h3>
                            <p><?= $total_active_memberships ?></p>
                        </div>
                        <div class="summary-card green">
                            <i data-feather="bar-chart-2" class="icon-small"></i>
                            <h3>Global Churn Index</h3>
                            <p><?= number_format($global_churn_index, 1) ?></p>
                        </div>
                    </div>

                    <!-- Global Churn Risk Distribution -->
                    <div class="churn-risk-distribution">
                        <h2>Global Contact Risk Distribution</h2>
                        <?php if ($global_churn_summary['total_scored_contacts'] > 0): ?>
                            <div class="metric-bar-container">
                                <div class="metric-segment segment-low-risk" style="width: <?= $global_churn_summary['risk_distribution_percentages']['low'] ?>%;">
                                    <?php if ($global_churn_summary['risk_distribution_percentages']['low'] > 10): ?>
                                        <?= $global_churn_summary['risk_distribution_percentages']['low'] ?>% Low
                                    <?php endif; ?>
                                </div>
                                <div class="metric-segment segment-medium-risk" style="width: <?= $global_churn_summary['risk_distribution_percentages']['medium'] ?>%;">
                                    <?php if ($global_churn_summary['risk_distribution_percentages']['medium'] > 10): ?>
                                        <?= $global_churn_summary['risk_distribution_percentages']['medium'] ?>% Medium
                                    <?php endif; ?>
                                </div>
                                <div class="metric-segment segment-high-risk" style="width: <?= $global_churn_summary['risk_distribution_percentages']['high'] ?>%;">
                                    <?php if ($global_churn_summary['risk_distribution_percentages']['high'] > 10): ?>
                                        <?= $global_churn_summary['risk_distribution_percentages']['high'] ?>% High
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="metric-legend">
                                <div class="legend-item"><span class="legend-color-box segment-low-risk"></span> Low Risk</div>
                                <div class="legend-item"><span class="legend-color-box segment-medium-risk"></span> Medium Risk</div>
                                <div class="legend-item"><span class="legend-color-box segment-high-risk"></span> High Risk</div>
                            </div>
                            <div class="admin-summary-grid mt-4">
                                <div class="summary-card red">
                                    <h3>Total High Risk</h3>
                                    <p><?= $global_churn_summary['high_risk_count'] ?></p>
                                </div>
                                <div class="summary-card orange">
                                    <h3>Total Medium Risk</h3>
                                    <p><?= $global_churn_summary['medium_risk_count'] ?></p>
                                </div>
                                <div class="summary-card green">
                                    <h3>Total Low Risk</h3>
                                    <p><?= $global_churn_summary['low_risk_count'] ?></p>
                                </div>
                                <div class="summary-card red">
                                    <h3>Total Churned</h3>
                                    <p><?= $global_churn_summary['churned_count'] ?></p>
                                </div>
                                <div class="summary-card green">
                                    <h3>Total Resurrected</h3>
                                    <p><?= $global_churn_summary['resurrected_count'] ?></p>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="no-data-message">No contact data available for risk distribution.</div>
                        <?php endif; ?>
                    </div>

                    <!-- Monthly New User Registrations Chart -->
                    <div class="chart-section">
                        <h2>Monthly New User Registrations</h2>
                        <?php if (!empty($monthly_new_users_data) && array_sum($monthly_new_users_data) > 0): ?>
                            <div class="chart-container">
                                <canvas id="monthlyNewUsersChart"></canvas>
                            </div>
                        <?php else: ?>
                            <div class="no-data-message">No user registration data available for this chart.</div>
                        <?php endif; ?>
                    </div>

                    <!-- Monthly New Contact Acquisition Chart -->
                    <div class="chart-section">
                        <h2>Monthly New Contact Acquisition</h2>
                        <?php if (!empty($monthly_new_contacts_data) && array_sum($monthly_new_contacts_data) > 0): ?>
                            <div class="chart-container">
                                <canvas id="monthlyNewContactsChart"></canvas>
                            </div>
                        <?php else: ?>
                            <div class="no-data-message">No new contact acquisition data available for this chart.</div>
                        <?php endif; ?>
                    </div>

                    <!-- Monthly Average Churn Rate Chart -->
                    <div class="chart-section">
                        <h2>Monthly Average Churn Rate</h2>
                        <?php if (!empty($monthly_avg_churn_data) && array_sum($monthly_avg_churn_data) > 0): ?>
                            <div class="chart-container">
                                <canvas id="monthlyAvgChurnChart"></canvas>
                            </div>
                        <?php else: ?>
                            <div class="no-data-message">No churn rate data available for this chart.</div>
                        <?php endif; ?>
                    </div>

                    <!-- Top 5 Most Used Features -->
                    <div class="top-features-list">
                        <h2>Top 5 Most Used Features (Overall)</h2>
                        <?php if (!empty($top_features_data)): ?>
                            <div class="features-list">
                                <ul>
                                    <?php foreach ($top_features_data as $feature): ?>
                                        <li>
                                            <span><?= htmlspecialchars($feature['feature_name_or_url']) ?></span>
                                            <span><?= number_format($feature['usage_count']) ?> uses</span>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php else: ?>
                            <div class="no-data-message">No feature usage data available.</div>
                        <?php endif; ?>
                    </div>

                    <!-- Financial Summary -->
                    <div class="financial-summary">
                        <h2>Financial Overview</h2>
                        <div class="financial-cards-grid">
                            <div class="financial-card revenue">
                                <h3>Total Membership Revenue</h3>
                                <p>$<?= number_format($total_membership_revenue, 2) ?></p>
                            </div>
                            <div class="financial-card payouts">
                                <h3>Total Affiliate Payouts</h3>
                                <p>$<?= number_format($total_affiliate_payouts, 2) ?></p>
                            </div>
                        </div>
                    </div>

                </main>
            </div>
        </div>
    </div> <!-- End site-wrapper -->

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize Feather Icons
        feather.replace();

        // Chart.js configuration for all charts
        const baseChartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    titleColor: 'var(--gray-800)',
                    bodyColor: 'var(--gray-700)',
                    borderColor: 'var(--gray-200)',
                    borderWidth: 1,
                    cornerRadius: 8,
                    displayColors: false,
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${context.parsed.y}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { color: 'var(--gray-600)' }
                },
                y: {
                    beginAtZero: true,
                    grid: { color: 'var(--gray-200)' },
                    ticks: {
                        color: 'var(--gray-600)',
                        callback: function(value) {
                            if (value % 1 === 0) return value; // Show integers only
                        }
                    }
                }
            }
        };

        // Monthly New User Registrations Chart
        const monthlyNewUsersCtx = document.getElementById('monthlyNewUsersChart');
        if (monthlyNewUsersCtx) {
            new Chart(monthlyNewUsersCtx, {
                type: 'line',
                data: {
                    labels: <?= json_encode($monthly_new_users_labels) ?>,
                    datasets: [{
                        label: 'New Users',
                        data: <?= json_encode($monthly_new_users_data) ?>,
                        borderColor: 'var(--primary)',
                        backgroundColor: 'rgba(58, 195, 184, 0.1)',
                        fill: true,
                        tension: 0.3,
                        pointRadius: 5,
                        pointBackgroundColor: 'var(--primary)',
                        pointBorderColor: 'var(--white)',
                        pointBorderWidth: 2
                    }]
                },
                options: {
                    ...baseChartOptions,
                    plugins: {
                        ...baseChartOptions.plugins,
                        tooltip: {
                             ...baseChartOptions.plugins.tooltip,
                             callbacks: {
                                label: function(context) { return `New Users: ${context.parsed.y}`; }
                            }
                        }
                    }
                }
            });
        }

        // Monthly New Contact Acquisition Chart
        const monthlyNewContactsCtx = document.getElementById('monthlyNewContactsChart');
        if (monthlyNewContactsCtx) {
            new Chart(monthlyNewContactsCtx, {
                type: 'line',
                data: {
                    labels: <?= json_encode($monthly_new_contacts_labels) ?>,
                    datasets: [{
                        label: 'New Contacts',
                        data: <?= json_encode($monthly_new_contacts_data) ?>,
                        borderColor: 'var(--info)',
                        backgroundColor: 'rgba(66, 153, 225, 0.1)',
                        fill: true,
                        tension: 0.3,
                        pointRadius: 5,
                        pointBackgroundColor: 'var(--info)',
                        pointBorderColor: 'var(--white)',
                        pointBorderWidth: 2
                    }]
                },
                options: {
                    ...baseChartOptions,
                    plugins: {
                        ...baseChartOptions.plugins,
                        tooltip: {
                             ...baseChartOptions.plugins.tooltip,
                             callbacks: {
                                label: function(context) { return `New Contacts: ${context.parsed.y}`; }
                            }
                        }
                    }
                }
            });
        }

        // Monthly Average Churn Rate Chart
        const monthlyAvgChurnCtx = document.getElementById('monthlyAvgChurnChart');
        if (monthlyAvgChurnCtx) {
            new Chart(monthlyAvgChurnCtx, {
                type: 'line',
                data: {
                    labels: <?= json_encode($monthly_avg_churn_labels) ?>,
                    datasets: [{
                        label: 'Avg. Churn Rate (%)',
                        data: <?= json_encode($monthly_avg_churn_data) ?>,
                        borderColor: 'var(--danger)',
                        backgroundColor: 'rgba(229, 62, 62, 0.1)',
                        fill: true,
                        tension: 0.3,
                        pointRadius: 5,
                        pointBackgroundColor: 'var(--danger)',
                        pointBorderColor: 'var(--white)',
                        pointBorderWidth: 2
                    }]
                },
                options: {
                    ...baseChartOptions,
                    scales: {
                        ...baseChartOptions.scales,
                        y: {
                            ...baseChartOptions.scales.y,
                            max: 100, // Churn rate is 0-100%
                            ticks: {
                                ...baseChartOptions.scales.y.ticks,
                                callback: function(value) { return value + '%'; }
                            }
                        }
                    },
                     plugins: {
                        ...baseChartOptions.plugins,
                        tooltip: {
                             ...baseChartOptions.plugins.tooltip,
                             callbacks: {
                                label: function(context) { return `Avg. Churn Rate: ${context.parsed.y}%`; }
                            }
                        }
                    }
                }
            });
        }
    </script>
</body>
</html>
