<?php
// admin/settings.php
require_once '../includes/db.php';

// Admin verification
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit;
}

// Handle form submission for AI Settings
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_ai_settings'])) {
    $ai_model = $_POST['ai_model'];
    $deepseek_key = trim($_POST['deepseek_key']);
    $openai_key = trim($_POST['openai_key']);
    $analysis_frequency = (int)$_POST['analysis_frequency'];
    $churn_threshold = (float)$_POST['churn_threshold'];

    // Update config values
    $settings = [
        'ai_model' => $ai_model,
        'deepseek_key' => $deepseek_key,
        'openai_key' => $openai_key,
        'analysis_frequency' => $analysis_frequency,
        'churn_threshold' => $churn_threshold
    ];

    foreach ($settings as $key => $value) {
        $stmt = $pdo->prepare("REPLACE INTO config (setting, value) VALUES (?, ?)");
        $stmt->execute([$key, $value]);
    }

    $_SESSION['success'] = "AI settings updated successfully";
    header('Location: settings.php?tab=ai-settings'); // Redirect back to the AI settings tab
    exit;
}

// Get current AI settings
$stmt = $pdo->query("SELECT setting, value FROM config WHERE setting IN ('ai_model', 'deepseek_key', 'openai_key', 'analysis_frequency', 'churn_threshold')");
$config = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// Set default values if not exists
$current_ai_settings = [
    'ai_model' => $config['ai_model'] ?? 'deepseek',
    'deepseek_key' => $config['deepseek_key'] ?? '',
    'openai_key' => $config['openai_key'] ?? '',
    'analysis_frequency' => $config['analysis_frequency'] ?? 7,
    'churn_threshold' => $config['churn_threshold'] ?? 50
];

// List of cron jobs to display
$cron_jobs = [
    'winback_campaigns.php' => 'Run Winback Campaigns',
    'subscription_check.php' => 'Check Subscriptions',
    'cleanup_logs.php' => 'Clean Up Logs',
    'churn_scoring.php' => 'Perform Churn Scoring',
    'alert_threshold.php' => 'Process Alert Thresholds',
    'affiliate_earnings.php' => 'Calculate Affiliate Earnings',
];

// Determine active tab
$active_tab = $_GET['tab'] ?? 'ai-settings'; // Default to AI settings tab
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings | Admin Panel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
                integrity="sha512-1ycn6IcaQQ40ZefMdHjAcUwaGDvPwdOaUcsU5XrU+pL87B7fC3J0P2Kqj1Z5M5YqD65B2L52B7y42j5P5c+A=="
                crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>

    <style>
        /* Define your color variables */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
            --light-green: #90EE90; /* Light green color */
        }

        /* Body and main layout styling */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--gray-100);
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer if added */
        }
        .site-wrapper { /* New wrapper for sticky footer logic */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container-fluid {
            padding: 0; /* Remove padding to make sidebar stick to edge */
            flex-grow: 1; /* Allow container-fluid to take up remaining height */
        }
        .row {
            margin: 0; /* Remove row margins to prevent unwanted space */
            flex-grow: 1;
        }
        /* Main content area */
        main {
            padding: 20px !important; /* Important to override Bootstrap default */
            background-color: var(--gray-100); /* Content area background */
            flex-grow: 1;
        }
        .d-flex.justify-content-between.flex-wrap.flex-md-nowrap.align-items-center {
            padding-top: 1.5rem !important; /* Bootstrap pt-3 */
            padding-bottom: 1rem !important; /* Bootstrap pb-2 */
            margin-bottom: 1.5rem !important; /* Bootstrap mb-3 */
        }

        /* Admin Sidebar basic styling */
        .admin-sidebar {
            background-color: var(--dark);
            color: var(--white);
            padding: 20px;
            /* Fixed position for desktop view */
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: 250px; /* Fixed width for the sidebar */
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .admin-sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary);
            font-size: 1.8rem;
            font-weight: 700;
        }
        .admin-sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .admin-sidebar ul li {
            margin-bottom: 10px;
        }
        .admin-sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--gray-300);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        .admin-sidebar ul li a:hover,
        .admin-sidebar ul li a.active {
            background-color: var(--gray-700);
            color: var(--white);
        }
        .admin-sidebar ul li a i {
            width: 20px;
            height: 20px;
        }

        /* Specific styles for settings.php content */
        .form-container {
            max-width: 800px;
            margin: 0 auto;
        }
        .api-key-group .input-group-text {
            cursor: pointer;
        }
        /* Card styles */
        .card {
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05); /* Soft shadow */
        }
        .card-body {
            padding: 25px;
        }
        .form-control, .form-select {
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            padding: 10px 15px;
            color: var(--gray-800);
            background-color: var(--white);
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(58, 195, 184, 0.25);
        }
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: background-color 0.2s, border-color 0.2s;
        }
        .btn-primary:hover {
            background-color: #2da89e;
            border-color: #2da89e;
        }
        .alert {
            border-radius: 8px;
            font-weight: 500;
        }

        /* Cron Job specific styles */
        .cron-job-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            margin-bottom: 10px;
            background-color: var(--white);
        }
        .cron-job-output {
            background-color: var(--gray-800);
            color: var(--success);
            padding: 15px;
            border-radius: 8px;
            font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, Courier, monospace;
            font-size: 0.85em;
            white-space: pre-wrap;
            margin-top: 10px;
            max-height: 300px;
            overflow-y: auto;
            border: 1px solid var(--gray-700);
        }
        .cron-job-output.error {
            color: var(--danger);
        }


        /* Responsive adjustments: Sidebar becomes standard column on mobile */
        @media (max-width: 767.98px) {
            .admin-sidebar {
                position: relative; /* Remove fixed positioning on small screens */
                width: 100%; /* Take full width on small screens */
                height: auto; /* Adjust height based on content */
                box-shadow: none; /* Remove shadow to blend better */
            }
            main {
                margin-left: 0 !important; /* Remove desktop margin on small screens */
            }
            .navbar-mobile-toggle { /* Ensure this is hidden as it's not needed now */
                display: none !important;
            }
        }

        @media (min-width: 768px) { /* Applies to md and larger screens */
            .main-content-area {
                margin-left: 250px; /* Offset for the fixed sidebar */
            }
            /* Hide the mobile toggle navbar on desktop */
            .navbar-mobile-toggle {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <div class="container-fluid">
            <div class="row">
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block admin-sidebar">
                    <div class="position-sticky pt-3">
                        <h2>Admin Panel</h2>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i data-feather="users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_levels.php">
                                    <i data-feather="award"></i> Membership Levels
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="payment_settings.php">
                                    <i data-feather="dollar-sign"></i> Payment Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="transactions.php">
                                    <i data-feather="credit-card"></i> Transactions
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="affiliates.php">
                                    <i data-feather="link"></i> Affiliates
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="helpdesk.php">
                                    <i data-feather="life-buoy"></i> Helpdesk
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="gift_management.php">
                                    <i data-feather="gift"></i> Gift Management
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="thresholds.php">
                                    <i data-feather="sliders"></i> Thresholds
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_admin.php">
                                    <i data-feather="user-check"></i> Membership+
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="teams.php">
                                    <i data-feather="users"></i> Teams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="streams_management.php">
                                    <i data-feather="video"></i> Streams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="cashouts.php" style="color: var(--light-green);">
                                    <i data-feather="dollar-sign"></i> Cashouts
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="email_settings.php">
                                    <i data-feather="mail"></i> Email Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="settings.php">
                                    <i data-feather="settings"></i> General Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="niches.php">
                                    <i data-feather="grid"></i> Niches
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../dashboard.php">
                                    <i data-feather="home"></i> Back to Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">
                                    <i data-feather="log-out"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content-area">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Admin Settings</h1>
                    </div>
                    
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= $_SESSION['success'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>

                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?= $_SESSION['error'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['error']); ?>
                    <?php endif; ?>
                    
                    <ul class="nav nav-tabs mb-4" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link <?= $active_tab === 'ai-settings' ? 'active' : '' ?>" id="ai-settings-tab" data-bs-toggle="tab" data-bs-target="#ai-settings" type="button" role="tab" aria-controls="ai-settings" aria-selected="<?= $active_tab === 'ai-settings' ? 'true' : 'false' ?>">AI Settings</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link <?= $active_tab === 'cron-jobs' ? 'active' : '' ?>" id="cron-jobs-tab" data-bs-toggle="tab" data-bs-target="#cron-jobs" type="button" role="tab" aria-controls="cron-jobs" aria-selected="<?= $active_tab === 'cron-jobs' ? 'true' : 'false' ?>">Cron Jobs</button>
                        </li>
                    </ul>

                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade <?= $active_tab === 'ai-settings' ? 'show active' : '' ?>" id="ai-settings" role="tabpanel" aria-labelledby="ai-settings-tab">
                            <div class="form-container">
                                <form method="POST">
                                    <div class="card mb-4">
                                        <div class="card-header">
                                            <h5 class="card-title">AI Model Configuration</h5>
                                        </div>
                                        <div class="card-body">
                                            <div class="mb-3">
                                                <label for="ai_model" class="form-label">Primary AI Model</label>
                                                <select class="form-select" id="ai_model" name="ai_model" required>
                                                    <option value="deepseek" <?= $current_ai_settings['ai_model'] === 'deepseek' ? 'selected' : '' ?>>DeepSeek</option>
                                                    <option value="openai" <?= $current_ai_settings['ai_model'] === 'openai' ? 'selected' : '' ?>>OpenAI (ChatGPT)</option>
                                                    <option value="both" <?= $current_ai_settings['ai_model'] === 'both' ? 'selected' : '' ?>>Use Both (Fallback)</option>
                                                </select>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="deepseek_key" class="form-label">DeepSeek API Key</label>
                                                <div class="input-group api-key-group">
                                                    <input type="password" class="form-control" id="deepseek_key" name="deepseek_key" 
                                                            value="<?= htmlspecialchars($current_ai_settings['deepseek_key']) ?>">
                                                    <span class="input-group-text toggle-password" data-target="deepseek_key">
                                                        <i class="bi bi-eye"></i>
                                                    </span>
                                                </div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="openai_key" class="form-label">OpenAI API Key</label>
                                                <div class="input-group api-key-group">
                                                    <input type="password" class="form-control" id="openai_key" name="openai_key" 
                                                            value="<?= htmlspecialchars($current_ai_settings['openai_key']) ?>">
                                                    <span class="input-group-text toggle-password" data-target="openai_key">
                                                        <i class="bi bi-eye"></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="card mb-4">
                                        <div class="card-header">
                                            <h5 class="card-title">Analysis Settings</h5>
                                        </div>
                                        <div class="card-body">
                                            <div class="mb-3">
                                                <label for="analysis_frequency" class="form-label">Analysis Frequency (Days)</label>
                                                <input type="number" class="form-control" id="analysis_frequency" name="analysis_frequency" 
                                                        min="1" max="30" value="<?= $current_ai_settings['analysis_frequency'] ?>" required>
                                                <small class="text-muted">How often to re-analyze users with new activity</small>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="churn_threshold" class="form-label">Churn Alert Threshold (%)</label>
                                                <input type="number" class="form-control" id="churn_threshold" name="churn_threshold" 
                                                        min="1" max="100" step="0.1" value="<?= $current_ai_settings['churn_threshold'] ?>" required>
                                                <small class="text-muted">Probability threshold for sending alerts</small>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="text-end">
                                        <button type="submit" name="update_ai_settings" class="btn btn-primary">Save AI Settings</button>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="tab-pane fade <?= $active_tab === 'cron-jobs' ? 'show active' : '' ?>" id="cron-jobs" role="tabpanel" aria-labelledby="cron-jobs-tab">
                            <div class="form-container">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="card-title">Manually Run Cron Jobs</h5>
                                        <p class="card-text text-muted">Click a button to execute the corresponding cron job. Output will be displayed below.</p>
                                    </div>
                                    <div class="card-body">
                                        <?php foreach ($cron_jobs as $file => $description): ?>
                                            <div class="cron-job-item">
                                                <span><strong><?= htmlspecialchars($description) ?></strong> (<code>cron/<?= htmlspecialchars($file) ?></code>)</span>
                                                <button type="button" class="btn btn-sm btn-info run-cron-btn" data-cron-file="<?= htmlspecialchars($file) ?>">
                                                    <i class="bi bi-play-fill"></i> Run Now
                                                </button>
                                            </div>
                                            <div id="output-<?= str_replace('.', '-', $file) ?>" class="cron-job-output d-none mb-3"></div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <script>
        // Initialize Feather Icons
        feather.replace();

        // Toggle API key visibility
        document.querySelectorAll('.toggle-password').forEach(toggle => {
            toggle.addEventListener('click', function() {
                const targetId = this.getAttribute('data-target');
                const input = document.getElementById(targetId);
                const icon = this.querySelector('i');
                
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('bi-eye');
                    icon.classList.add('bi-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('bi-eye-slash');
                    icon.classList.add('bi-eye');
                }
            });
        });

        // Handle Cron Job execution
        $(document).ready(function() {
            $('.run-cron-btn').on('click', function() {
                const button = $(this);
                const cronFile = button.data('cron-file');
                const outputDivId = 'output-' + cronFile.replace('.', '-');
                const outputDiv = $('#' + outputDivId);

                // Disable button and show loading spinner
                button.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Running...');
                outputDiv.empty().removeClass('d-none alert-danger').addClass('alert-info').text('Executing ' + cronFile + '...');

                $.ajax({
                    url: 'run_cron.php', // New PHP script to handle execution
                    method: 'POST',
                    data: { cron_file: cronFile },
                    success: function(response) {
                        // Display output
                        outputDiv.text(response.output);
                        if (response.status === 'success') {
                            outputDiv.removeClass('alert-info').addClass('alert-success');
                        } else {
                            outputDiv.removeClass('alert-info').addClass('alert-danger error');
                        }
                    },
                    error: function(xhr, status, error) {
                        // Display error
                        outputDiv.removeClass('alert-info').addClass('alert-danger error').text('Error running cron job: ' + error + ' - ' + xhr.responseText);
                    },
                    complete: function() {
                        // Re-enable button
                        button.prop('disabled', false).html('<i class="bi bi-play-fill"></i> Run Now');
                    }
                });
            });

            // Handle tab switching to update URL
            $('button[data-bs-toggle="tab"]').on('shown.bs.tab', function (e) {
                const newTab = $(e.target).attr('data-bs-target').replace('#', '');
                const url = new URL(window.location.href);
                url.searchParams.set('tab', newTab);
                window.history.pushState({ path: url.href }, '', url.href);
            });

            // Set active tab based on URL on page load
            const urlParams = new URLSearchParams(window.location.search);
            const initialTab = urlParams.get('tab') || 'ai-settings';
            $(`#${initialTab}-tab`).tab('show');
        });
    </script>
</body>
</html>