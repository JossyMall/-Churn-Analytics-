<?php
// admin/payment_settings.php
require_once '../includes/db.php';

// Admin verification
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_gateways'])) {
        // Update payment gateways
        $paypal_client_id = trim($_POST['paypal_client_id']);
        $paypal_secret = trim($_POST['paypal_secret']);
        $flutterwave_public_key = trim($_POST['flutterwave_public_key']);
        $flutterwave_secret_key = trim($_POST['flutterwave_secret_key']);
        $usdt_wallet = trim($_POST['usdt_wallet']);
        
        $stmt = $pdo->prepare("UPDATE payment_gateways SET 
                               paypal_client_id = ?, paypal_secret = ?,
                               flutterwave_public_key = ?, flutterwave_secret_key = ?,
                               usdt_wallet = ? 
                               WHERE id = 1");
        $stmt->execute([$paypal_client_id, $paypal_secret, $flutterwave_public_key, 
                       $flutterwave_secret_key, $usdt_wallet]);
        
        $_SESSION['success'] = "Payment gateways updated successfully";
    } elseif (isset($_POST['add_bank_account'])) {
        // Add new bank account
        $bank_name = trim($_POST['bank_name']);
        $account_name = trim($_POST['account_name']);
        $account_number = trim($_POST['account_number']);
        $routing_number = trim($_POST['routing_number']);
        $swift_code = trim($_POST['swift_code']);
        $iban = trim($_POST['iban']);
        
        $stmt = $pdo->prepare("INSERT INTO bank_accounts 
                               (bank_name, account_name, account_number, routing_number, swift_code, iban) 
                               VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$bank_name, $account_name, $account_number, $routing_number, $swift_code, $iban]);
        
        $_SESSION['success'] = "Bank account added successfully";
    } elseif (isset($_POST['update_bank_status'])) {
        // Update bank account status
        $bank_id = (int)$_POST['bank_id'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        $stmt = $pdo->prepare("UPDATE bank_accounts SET is_active = ? WHERE id = ?");
        $stmt->execute([$is_active, $bank_id]);
        
        $_SESSION['success'] = "Bank account status updated";
    } elseif (isset($_POST['delete_bank_account'])) {
        // Delete bank account
        $bank_id = (int)$_POST['bank_id'];

        try {
            $stmt = $pdo->prepare("DELETE FROM bank_accounts WHERE id = ?");
            $stmt->execute([$bank_id]);
            $_SESSION['success'] = "Bank account deleted successfully";
        } catch (PDOException $e) {
            $_SESSION['error'] = "Error deleting bank account: " . $e->getMessage();
        }
    }
    
    header('Location: payment_settings.php');
    exit;
}

// Get payment gateway settings
$stmt = $pdo->query("SELECT * FROM payment_gateways WHERE id = 1");
$gateways = $stmt->fetch();

// Get bank accounts
$stmt = $pdo->query("SELECT * FROM bank_accounts ORDER BY is_active DESC, bank_name");
$bank_accounts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Settings | Admin Panel</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Font Awesome for consistent icons across pages -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
            xintegrity="sha512-1ycn6IcaQQ40ZefMdHjAcUwaGDvPwdOaUcsU5XrU+pL87B7fC3J0P2Kqj1Z5M5YqD65B2L52B7y42j5P5c+A=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Feather Icons for new tab icons -->
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>

    <style>
        /* Define your color variables */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
            --light-green: #90EE90; /* Light green color */
        }

        /* Body and main layout styling */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--gray-100);
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer if added */
        }
        .site-wrapper { /* New wrapper for sticky footer logic */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container-fluid {
            padding: 0; /* Remove padding to make sidebar stick to edge */
            flex-grow: 1; /* Allow container-fluid to take up remaining height */
        }
        .row {
            margin: 0; /* Remove row margins to prevent unwanted space */
            flex-grow: 1;
        }
        /* Main content area */
        main {
            padding: 20px !important; /* Important to override Bootstrap default */
            background-color: var(--gray-100); /* Content area background */
            flex-grow: 1;
        }
        .d-flex.justify-content-between.flex-wrap.flex-md-nowrap.align-items-center {
            padding-top: 1.5rem !important; /* Bootstrap pt-3 */
            padding-bottom: 1rem !important; /* Bootstrap pb-2 */
            margin-bottom: 1.5rem !important; /* Bootstrap mb-3 */
        }

        /* Admin Sidebar basic styling */
        .admin-sidebar {
            background-color: var(--dark);
            color: var(--white);
            padding: 20px;
            /* Fixed position for desktop view */
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: 250px; /* Fixed width for the sidebar */
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .admin-sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary);
            font-size: 1.8rem;
            font-weight: 700;
        }
        .admin-sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .admin-sidebar ul li {
            margin-bottom: 10px;
        }
        .admin-sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--gray-300);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        .admin-sidebar ul li a:hover,
        .admin-sidebar ul li a.active {
            background-color: var(--gray-700);
            color: var(--white);
        }
        .admin-sidebar ul li a i {
            width: 20px;
            height: 20px;
        }

        /* Specific styles for payment_settings.php content */
        .gateway-card {
            border-left: 4px solid var(--info); /* Using Bootstrap info color for consistency */
        }
        .bank-account {
            border-left: 4px solid var(--success); /* Using Bootstrap success color */
        }
        .bank-account.inactive {
            border-left-color: var(--gray-500); /* Using Bootstrap gray for inactive */
            opacity: 0.8;
        }
        .form-container {
            max-width: 800px;
            margin: 0 auto;
        }
        .nav-tabs .nav-link.active {
            font-weight: 500;
        }
        /* Card styles */
        .card {
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05); /* Soft shadow */
        }
        .card-body {
            padding: 25px;
        }
        .form-control, .form-select {
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            padding: 10px 15px;
            color: var(--gray-800);
            background-color: var(--white);
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(58, 195, 184, 0.25);
        }
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: background-color 0.2s, border-color 0.2s;
        }
        .btn-primary:hover {
            background-color: #2da89e;
            border-color: #2da89e;
        }
        .alert {
            border-radius: 8px;
            font-weight: 500;
        }

        /* Responsive adjustments: Sidebar becomes standard column on mobile */
        @media (max-width: 767.98px) {
            .admin-sidebar {
                position: relative; /* Remove fixed positioning on small screens */
                width: 100%; /* Take full width on small screens */
                height: auto; /* Adjust height based on content */
                box-shadow: none; /* Remove shadow to blend better */
            }
            main {
                margin-left: 0 !important; /* Remove desktop margin on small screens */
            }
            .navbar-mobile-toggle { /* Ensure this is hidden as it's not needed now */
                display: none !important;
            }
        }

        @media (min-width: 768px) { /* Applies to md and larger screens */
            .main-content-area {
                margin-left: 250px; /* Offset for the fixed sidebar */
            }
            /* Hide the mobile toggle navbar on desktop */
            .navbar-mobile-toggle {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <!-- Mobile Navbar/Toggle is not included as per instruction to ignore mobile changes. -->
        <!-- The layout will now simply stack on small screens. -->

        <div class="container-fluid">
            <div class="row">
                <!-- Admin Sidebar -->
                <!-- The d-md-block class makes it a block element from md breakpoint up, making it visible -->
                <!-- The 'collapse' class is removed to ensure it's always visible on desktop -->
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block admin-sidebar">
                    <div class="position-sticky pt-3">
                        <h2>Admin Panel</h2>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i data-feather="users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_levels.php">
                                    <i data-feather="award"></i> Membership Levels
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="payment_settings.php">
                                    <i data-feather="dollar-sign"></i> Payment Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="transactions.php">
                                    <i data-feather="credit-card"></i> Transactions
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="affiliates.php">
                                    <i data-feather="link"></i> Affiliates
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="helpdesk.php">
                                    <i data-feather="life-buoy"></i> Helpdesk
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="gift_management.php">
                                    <i data-feather="gift"></i> Gift Management
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="thresholds.php">
                                    <i data-feather="sliders"></i> Thresholds
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_admin.php">
                                    <i data-feather="user-check"></i> Membership+
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="teams.php">
                                    <i data-feather="users"></i> Teams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="streams_management.php">
                                    <i data-feather="video"></i> Streams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="cashouts.php" style="color: var(--light-green);">
                                    <i data-feather="dollar-sign"></i> Cashouts
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="email_settings.php">
                                    <i data-feather="mail"></i> Email Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="notifications.php">
                                    <i data-feather="bell"></i> Notifications
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="ai_settings.php">
                                    <i data-feather="cpu"></i> AI Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="niches.php">
                                    <i data-feather="grid"></i> Niches
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../dashboard.php">
                                    <i data-feather="home"></i> Back to Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">
                                    <i data-feather="log-out"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- End Admin Sidebar -->
                
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content-area">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Payment Settings</h1>
                    </div>
                    
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= $_SESSION['success'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    
                    <ul class="nav nav-tabs mb-4" id="paymentTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="gateways-tab" data-bs-toggle="tab" data-bs-target="#gateways" type="button" role="tab">
                                Payment Gateways
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="bank-tab" data-bs-toggle="tab" data-bs-target="#bank" type="button" role="tab">
                                Bank Accounts
                            </button>
                        </li>
                    </ul>
                    
                    <div class="tab-content" id="paymentTabsContent">
                        <div class="tab-pane fade show active" id="gateways" role="tabpanel">
                            <div class="card gateway-card mb-4">
                                <div class="card-header">
                                    <h5 class="card-title">Payment Gateway Settings</h5>
                                </div>
                                <div class="card-body">
                                    <form method="POST">
                                        <div class="row mb-4">
                                            <div class="col-md-6">
                                                <h6 class="border-bottom pb-2 mb-3">PayPal</h6>
                                                <div class="mb-3">
                                                    <label for="paypal_client_id" class="form-label">Client ID</label>
                                                    <input type="text" class="form-control" id="paypal_client_id" name="paypal_client_id" 
                                                            value="<?= htmlspecialchars($gateways['paypal_client_id'] ?? '') ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="paypal_secret" class="form-label">Secret Key</label>
                                                    <input type="password" class="form-control" id="paypal_secret" name="paypal_secret" 
                                                            value="<?= htmlspecialchars($gateways['paypal_secret'] ?? '') ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <h6 class="border-bottom pb-2 mb-3">Flutterwave</h6>
                                                <div class="mb-3">
                                                    <label for="flutterwave_public_key" class="form-label">Public Key</label>
                                                    <input type="text" class="form-control" id="flutterwave_public_key" name="flutterwave_public_key" 
                                                            value="<?= htmlspecialchars($gateways['flutterwave_public_key'] ?? '') ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="flutterwave_secret_key" class="form-label">Secret Key</label>
                                                    <input type="password" class="form-control" id="flutterwave_secret_key" name="flutterwave_secret_key" 
                                                            value="<?= htmlspecialchars($gateways['flutterwave_secret_key'] ?? '') ?>">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h6 class="border-bottom pb-2 mb-3">USDT</h6>
                                                <div class="mb-3">
                                                    <label for="usdt_wallet" class="form-label">Wallet Address</label>
                                                    <input type="text" class="form-control" id="usdt_wallet" name="usdt_wallet" 
                                                            value="<?= htmlspecialchars($gateways['usdt_wallet'] ?? '') ?>">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="text-end mt-4">
                                            <button type="submit" name="update_gateways" class="btn btn-primary">Update Gateways</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                        <div class="tab-pane fade" id="bank" role="tabpanel">
                            <div class="card mb-4">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h5 class="card-title">Bank Accounts</h5>
                                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addBankModal">
                                        <i class="bi bi-plus-lg"></i> Add Account
                                    </button>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Bank Name</th>
                                                    <th>Account Details</th>
                                                    <th>Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($bank_accounts as $bank): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars($bank['bank_name']) ?></td>
                                                    <td>
                                                        <strong><?= htmlspecialchars($bank['account_name']) ?></strong><br>
                                                        <small class="text-muted">
                                                            Account: <?= htmlspecialchars($bank['account_number']) ?><br>
                                                            <?php if ($bank['routing_number']): ?>
                                                                Routing: <?= htmlspecialchars($bank['routing_number']) ?><br>
                                                            <?php endif; ?>
                                                            <?php if ($bank['swift_code']): ?>
                                                                SWIFT: <?= htmlspecialchars($bank['swift_code']) ?><br>
                                                            <?php endif; ?>
                                                            <?php if ($bank['iban']): ?>
                                                                IBAN: <?= htmlspecialchars($bank['iban']) ?>
                                                            <?php endif; ?>
                                                        </small>
                                                    </td>
                                                    <td>
                                                        <form method="POST">
                                                            <input type="hidden" name="bank_id" value="<?= $bank['id'] ?>">
                                                            <div class="form-check form-switch">
                                                                <input class="form-check-input" type="checkbox" role="switch" 
                                                                        id="status<?= $bank['id'] ?>" name="is_active" 
                                                                        <?= $bank['is_active'] ? 'checked' : '' ?> 
                                                                        onchange="this.form.submit()">
                                                                <label class="form-check-label" for="status<?= $bank['id'] ?>">
                                                                    <?= $bank['is_active'] ? 'Active' : 'Inactive' ?>
                                                                </label>
                                                            </div>
                                                            <input type="hidden" name="update_bank_status">
                                                        </form>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" 
                                                                data-bs-target="#deleteBankModal" 
                                                                data-id="<?= $bank['id'] ?>"
                                                                data-name="<?= htmlspecialchars($bank['bank_name']) ?>">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div> <!-- End site-wrapper -->

    <!-- Add Bank Account Modal -->
    <div class="modal fade" id="addBankModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Bank Account</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="bank_name" class="form-label">Bank Name</label>
                            <input type="text" class="form-control" id="bank_name" name="bank_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="account_name" class="form-label">Account Name</label>
                            <input type="text" class="form-control" id="account_name" name="account_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="account_number" class="form-label">Account Number</label>
                            <input type="text" class="form-control" id="account_number" name="account_number" required>
                        </div>
                        <div class="mb-3">
                            <label for="routing_number" class="form-label">Routing Number (ABA)</label>
                            <input type="text" class="form-control" id="routing_number" name="routing_number">
                        </div>
                        <div class="mb-3">
                            <label for="swift_code" class="form-label">SWIFT Code</label>
                            <input type="text" class="form-control" id="swift_code" name="swift_code">
                        </div>
                        <div class="mb-3">
                            <label for="iban" class="form-label">IBAN</label>
                            <input type="text" class="form-control" id="iban" name="iban">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="add_bank_account" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Bank Account Modal -->
    <div class="modal fade" id="deleteBankModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="bank_id" id="deleteBankId">
                    <div class="modal-header">
                        <h5 class="modal-title">Confirm Delete</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Are you sure you want to delete this bank account?</p>
                        <p><strong id="deleteBankName"></strong></p>
                        <div class="alert alert-danger">
                            <strong>Warning:</strong> This action cannot be undone!
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="delete_bank_account" class="btn btn-danger">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize Feather Icons
        feather.replace();

        // Handle delete bank modal
        const deleteBankModal = document.getElementById('deleteBankModal');
        if (deleteBankModal) {
            deleteBankModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                document.getElementById('deleteBankId').value = button.getAttribute('data-id');
                document.getElementById('deleteBankName').textContent = button.getAttribute('data-name');
            });
        }

        // Toggle password visibility - Renamed from .toggle-password to .password-toggle for consistency
        document.querySelectorAll('.password-toggle').forEach(toggle => {
            toggle.addEventListener('click', function() {
                const targetId = this.getAttribute('data-target'); // Assumes data-target="#id_of_input"
                const input = document.getElementById(targetId);
                const icon = this.querySelector('i');
                
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('bi-eye');
                    icon.classList.add('bi-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('bi-eye-slash');
                    icon.classList.add('bi-eye');
                }
            });
        });

        // Add `data-target` to the password input fields' toggle icons to use the JS correctly
        // This is a manual addition for client-side JavaScript to work.
        // For PayPal Secret Key
        const paypalSecretInput = document.getElementById('paypal_secret');
        if (paypalSecretInput) {
            const paypalToggleSpan = paypalSecretInput.closest('.input-group')?.querySelector('.input-group-text');
            if (paypalToggleSpan) {
                paypalToggleSpan.classList.add('password-toggle');
                paypalToggleSpan.setAttribute('data-target', 'paypal_secret');
                paypalToggleSpan.innerHTML = '<i class="bi bi-eye"></i>'; // Ensure icon is present
            }
        }

        // For Flutterwave Secret Key
        const flutterwaveSecretInput = document.getElementById('flutterwave_secret_key');
        if (flutterwaveSecretInput) {
            const flutterwaveToggleSpan = flutterwaveSecretInput.closest('.input-group')?.querySelector('.input-group-text');
            if (flutterwaveToggleSpan) {
                flutterwaveToggleSpan.classList.add('password-toggle');
                flutterwaveToggleSpan.setAttribute('data-target', 'flutterwave_secret_key');
                flutterwaveToggleSpan.innerHTML = '<i class="bi bi-eye"></i>'; // Ensure icon is present
            }
        }
    </script>
</body>
</html>
