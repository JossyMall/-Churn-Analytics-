<?php
// admin/membership_admin.php
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0'); // Shows parse errors at startup
ini_set('log_errors', '1'); // Ensures errors are logged
ini_set('error_log', '/var/www/www-root/data/www/earndos.com/io/php_app_errors.log'); // DIRECTS ERRORS HERE
require_once '../includes/db.php';

// Admin verification
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['assign_membership'])) {
        $user_id = (int)$_POST['user_id'];
        $membership_id = (int)$_POST['membership_id'];
        $is_yearly = isset($_POST['is_yearly']) ? 1 : 0;
        $duration_days = $is_yearly ? 365 : 30;
        
        // Get membership details
        $stmt = $pdo->prepare("SELECT * FROM membership_levels WHERE id = ?");
        $stmt->execute([$membership_id]);
        $membership = $stmt->fetch();
        
        if ($membership) {
            $amount = $is_yearly ? 
                ($membership['promo_price'] * 12 * (1 - ($membership['yearly_discount']/100))) : 
                $membership['promo_price'];
            
            $start_date = new DateTime();
            $end_date = clone $start_date;
            $end_date->add(new DateInterval("P{$duration_days}D"));
            
            // Check if user already has an active subscription
            $stmt = $pdo->prepare("SELECT id FROM user_subscriptions WHERE user_id = ? AND is_active = 1");
            $stmt->execute([$user_id]);
            $existing = $stmt->fetch();
            
            if ($existing) {
                // Update existing subscription
                $stmt = $pdo->prepare("UPDATE user_subscriptions SET 
                    membership_id = ?,
                    start_date = ?,
                    end_date = ?,
                    is_yearly = ?,
                    duration_days = ?,
                    amount_paid = ?,
                    is_active = 1,
                    cancelled_at = NULL,
                    admin_assigned = 1
                    WHERE id = ?");
                $stmt->execute([
                    $membership_id,
                    $start_date->format('Y-m-d H:i:s'),
                    $end_date->format('Y-m-d H:i:s'),
                    $is_yearly,
                    $duration_days,
                    $amount,
                    $existing['id']
                ]);
            } else {
                // Create new subscription
                $stmt = $pdo->prepare("INSERT INTO user_subscriptions (
                    user_id, membership_id, start_date, end_date, is_yearly, 
                    duration_days, payment_method, amount_paid, is_active, admin_assigned
                ) VALUES (?, ?, ?, ?, ?, ?, 'admin', ?, 1, 1)");
                $stmt->execute([
                    $user_id,
                    $membership_id,
                    $start_date->format('Y-m-d H:i:s'),
                    $end_date->format('Y-m-d H:i:s'),
                    $is_yearly,
                    $duration_days,
                    $amount
                ]);
            }
            
            $_SESSION['success'] = "Membership assigned successfully";
        }
    } elseif (isset($_POST['revoke_membership'])) {
        $subscription_id = (int)$_POST['subscription_id'];
        
        $stmt = $pdo->prepare("UPDATE user_subscriptions SET 
            is_active = 0,
            cancelled_at = NOW()
            WHERE id = ?");
        $stmt->execute([$subscription_id]);
        
        $_SESSION['success'] = "Membership revoked successfully";
    } elseif (isset($_POST['extend_membership'])) {
        $subscription_id = (int)$_POST['subscription_id'];
        $extension_days = (int)$_POST['extension_days'];
        
        $stmt = $pdo->prepare("UPDATE user_subscriptions SET 
            end_date = DATE_ADD(end_date, INTERVAL ? DAY)
            WHERE id = ?");
        $stmt->execute([$extension_days, $subscription_id]);
        
        $_SESSION['success'] = "Membership extended successfully";
    }
    
    header('Location: membership_admin.php');
    exit;
}

// Handle search and pagination
$search = $_GET['search'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

$query = "SELECT 
    u.id, u.username, u.email, 
    us.id as subscription_id, us.membership_id, us.start_date, us.end_date, 
    us.is_yearly, us.is_active, us.cancelled_at,
    ml.name as membership_name, ml.promo_price, ml.yearly_discount
FROM users u
LEFT JOIN user_subscriptions us ON us.user_id = u.id AND us.is_active = 1
LEFT JOIN membership_levels ml ON ml.id = us.membership_id";

$count_query = "SELECT COUNT(*) FROM users u";
$params = [];
$where = [];

if (!empty($search)) {
    $where[] = "(u.username LIKE ? OR u.email LIKE ?)";
    $params = array_merge($params, ["%$search%", "%$search%"]);
}

if (!empty($where)) {
    $query .= " WHERE " . implode(" AND ", $where);
    $count_query .= " WHERE " . implode(" AND ", $where);
}

$query .= " ORDER BY u.id DESC LIMIT $per_page OFFSET $offset";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$users = $stmt->fetchAll();

$stmt = $pdo->prepare($count_query);
$stmt->execute($params);
$total_users = $stmt->fetchColumn();
$total_pages = ceil($total_users / $per_page);

// Get all membership levels for dropdown
$stmt = $pdo->query("SELECT * FROM membership_levels ORDER BY name");
$membership_levels = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Membership Management | Admin Panel</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Feather Icons -->
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    
    <style>
        /* Reuse the same styles from users.php */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
        }
        
        .badge-active {
            background-color: var(--success);
        }
        .badge-expired {
            background-color: var(--danger);
        }
        .badge-pending {
            background-color: var(--warning);
        }
        .membership-details {
            font-size: 0.9rem;
        }
        .days-remaining {
            font-weight: bold;
        }
        .text-expiring {
            color: var(--warning);
        }
        .text-expired {
            color: var(--danger);
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <div class="container-fluid">
            <div class="row">
                <!-- Admin Sidebar (same as users.php) -->
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block admin-sidebar">
                    <!-- ... same sidebar content as users.php ... -->
                </nav>
                
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content-area">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Membership Management</h1>
                        <div>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#assignMembershipModal">
                                <i class="bi bi-plus-lg"></i> Assign Membership
                            </button>
                        </div>
                    </div>
                    
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= $_SESSION['success'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    
                    <div class="card mb-4">
                        <div class="card-body">
                            <form method="GET" class="mb-4">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="search" 
                                            value="<?= htmlspecialchars($search) ?>" 
                                            placeholder="Search by username or email">
                                    <button class="btn btn-primary" type="submit">Search</button>
                                </div>
                            </form>
                            
                            <div class="table-container">
                                <table class="table table-striped table-hover align-middle">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>User</th>
                                            <th>Email</th>
                                            <th>Membership</th>
                                            <th>Status</th>
                                            <th>Expires In</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($users as $user): ?>
                                        <tr>
                                            <td><?= $user['id'] ?></td>
                                            <td><?= htmlspecialchars($user['username']) ?></td>
                                            <td><?= htmlspecialchars($user['email']) ?></td>
                                            <td>
                                                <?php if ($user['subscription_id']): ?>
                                                    <strong><?= htmlspecialchars($user['membership_name']) ?></strong>
                                                    <div class="membership-details">
                                                        <?= $user['is_yearly'] ? 'Yearly' : 'Monthly' ?> - 
                                                        $<?= number_format($user['promo_price'], 2) ?>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-muted">No membership</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($user['subscription_id']): ?>
                                                    <?php if ($user['is_active']): ?>
                                                        <span class="badge badge-active">Active</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-expired">Revoked</span>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">None</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($user['subscription_id'] && $user['is_active']): ?>
                                                    <?php
                                                    $end_date = new DateTime($user['end_date']);
                                                    $today = new DateTime();
                                                    $interval = $today->diff($end_date);
                                                    $days = $interval->format('%r%a');
                                                    
                                                    if ($days > 0) {
                                                        $class = $days <= 7 ? 'text-expiring' : '';
                                                        echo "<span class='days-remaining $class'>{$days} days</span>";
                                                    } else {
                                                        echo "<span class='days-remaining text-expired'>Expired</span>";
                                                    }
                                                    ?>
                                                <?php elseif ($user['subscription_id'] && !$user['is_active']): ?>
                                                    <span class="text-muted">Revoked on <?= date('M j, Y', strtotime($user['cancelled_at'])) ?></span>
                                                <?php else: ?>
                                                    <span class="text-muted">N/A</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="action-btns">
                                                <?php if ($user['subscription_id'] && $user['is_active']): ?>
                                                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" 
                                                            data-bs-target="#extendModal" 
                                                            data-subscription_id="<?= $user['subscription_id'] ?>"
                                                            data-username="<?= htmlspecialchars($user['username']) ?>">
                                                        <i class="bi bi-calendar-plus"></i> Extend
                                                    </button>
                                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" 
                                                            data-bs-target="#revokeModal" 
                                                            data-subscription_id="<?= $user['subscription_id'] ?>"
                                                            data-username="<?= htmlspecialchars($user['username']) ?>">
                                                        <i class="bi bi-x-circle"></i> Revoke
                                                    </button>
                                                <?php elseif ($user['subscription_id'] && !$user['is_active']): ?>
                                                    <button class="btn btn-sm btn-success" data-bs-toggle="modal" 
                                                            data-bs-target="#reactivateModal" 
                                                            data-subscription_id="<?= $user['subscription_id'] ?>"
                                                            data-username="<?= htmlspecialchars($user['username']) ?>">
                                                        <i class="bi bi-arrow-clockwise"></i> Reactivate
                                                    </button>
                                                <?php else: ?>
                                                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" 
                                                            data-bs-target="#assignModal" 
                                                            data-user_id="<?= $user['id'] ?>"
                                                            data-username="<?= htmlspecialchars($user['username']) ?>">
                                                        <i class="bi bi-plus-circle"></i> Assign
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <nav aria-label="Page navigation">
                                <ul class="pagination justify-content-center">
                                    <?php if ($page > 1): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?= $page-1 ?>&search=<?= urlencode($search) ?>">Previous</a>
                                        </li>
                                    <?php endif; ?>
                                    
                                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                            <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                                        </li>
                                    <?php endfor; ?>
                                    
                                    <?php if ($page < $total_pages): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?= $page+1 ?>&search=<?= urlencode($search) ?>">Next</a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <!-- Assign Membership Modal -->
    <div class="modal fade" id="assignMembershipModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Assign New Membership</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="assign_user_id" class="form-label">User</label>
                            <select class="form-select" id="assign_user_id" name="user_id" required>
                                <option value="">Select User</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?= $user['id'] ?>">
                                        <?= htmlspecialchars($user['username']) ?> (<?= htmlspecialchars($user['email']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="assign_membership_id" class="form-label">Membership Level</label>
                            <select class="form-select" id="assign_membership_id" name="membership_id" required>
                                <option value="">Select Membership Level</option>
                                <?php foreach ($membership_levels as $level): ?>
                                    <option value="<?= $level['id'] ?>">
                                        <?= htmlspecialchars($level['name']) ?> - 
                                        $<?= number_format($level['promo_price'], 2) ?>/mo
                                        (<?= $level['yearly_discount'] ?>% yearly discount)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="assign_is_yearly" name="is_yearly">
                            <label class="form-check-label" for="assign_is_yearly">Yearly Subscription</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="assign_membership" class="btn btn-primary">Assign</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Assign Modal (for specific user) -->
    <div class="modal fade" id="assignModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="user_id" id="assign_user_id_specific">
                    <div class="modal-header">
                        <h5 class="modal-title">Assign Membership to <span id="assign_username"></span></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="assign_membership_id_specific" class="form-label">Membership Level</label>
                            <select class="form-select" id="assign_membership_id_specific" name="membership_id" required>
                                <option value="">Select Membership Level</option>
                                <?php foreach ($membership_levels as $level): ?>
                                    <option value="<?= $level['id'] ?>">
                                        <?= htmlspecialchars($level['name']) ?> - 
                                        $<?= number_format($level['promo_price'], 2) ?>/mo
                                        (<?= $level['yearly_discount'] ?>% yearly discount)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="assign_is_yearly_specific" name="is_yearly">
                            <label class="form-check-label" for="assign_is_yearly_specific">Yearly Subscription</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="assign_membership" class="btn btn-primary">Assign</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Revoke Modal -->
    <div class="modal fade" id="revokeModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="subscription_id" id="revoke_subscription_id">
                    <div class="modal-header">
                        <h5 class="modal-title">Revoke Membership</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Are you sure you want to revoke membership for <strong id="revoke_username"></strong>?</p>
                        <div class="alert alert-warning">
                            <strong>Note:</strong> This will immediately cancel their access to premium features.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="revoke_membership" class="btn btn-danger">Revoke</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Extend Modal -->
    <div class="modal fade" id="extendModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="subscription_id" id="extend_subscription_id">
                    <div class="modal-header">
                        <h5 class="modal-title">Extend Membership</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Extend membership for <strong id="extend_username"></strong></p>
                        <div class="mb-3">
                            <label for="extension_days" class="form-label">Number of Days to Extend</label>
                            <input type="number" class="form-control" id="extension_days" name="extension_days" min="1" value="30" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="extend_membership" class="btn btn-primary">Extend</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Reactivate Modal -->
    <div class="modal fade" id="reactivateModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="subscription_id" id="reactivate_subscription_id">
                    <div class="modal-header">
                        <h5 class="modal-title">Reactivate Membership</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Reactivate membership for <strong id="reactivate_username"></strong>?</p>
                        <div class="alert alert-info">
                            <strong>Note:</strong> This will restore their access to premium features.
                        </div>
                        <div class="mb-3">
                            <label for="reactivate_days" class="form-label">Duration (days)</label>
                            <input type="number" class="form-control" id="reactivate_days" name="extension_days" min="1" value="30" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="extend_membership" class="btn btn-success">Reactivate</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize Feather Icons
        feather.replace();

        // Handle assign modal data
        const assignModal = document.getElementById('assignModal');
        if (assignModal) {
            assignModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                document.getElementById('assign_user_id_specific').value = button.getAttribute('data-user_id');
                document.getElementById('assign_username').textContent = button.getAttribute('data-username');
            });
        }

        // Handle revoke modal data
        const revokeModal = document.getElementById('revokeModal');
        if (revokeModal) {
            revokeModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                document.getElementById('revoke_subscription_id').value = button.getAttribute('data-subscription_id');
                document.getElementById('revoke_username').textContent = button.getAttribute('data-username');
            });
        }

        // Handle extend modal data
        const extendModal = document.getElementById('extendModal');
        if (extendModal) {
            extendModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                document.getElementById('extend_subscription_id').value = button.getAttribute('data-subscription_id');
                document.getElementById('extend_username').textContent = button.getAttribute('data-username');
            });
        }

        // Handle reactivate modal data
        const reactivateModal = document.getElementById('reactivateModal');
        if (reactivateModal) {
            reactivateModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                document.getElementById('reactivate_subscription_id').value = button.getAttribute('data-subscription_id');
                document.getElementById('reactivate_username').textContent = button.getAttribute('data-username');
            });
        }
    </script>
</body>
</html>