<?php
// admin/helpdesk.php
require_once '../includes/db.php';

// Admin verification
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_response'])) {
        // Add response to ticket
        $ticket_id = (int)$_POST['ticket_id'];
        $response = trim($_POST['response']);
        $status = $_POST['status'];
        
        // Insert response
        $stmt = $pdo->prepare("INSERT INTO helpdesk_responses (ticket_id, user_id, response) VALUES (?, ?, ?)");
        $stmt->execute([$ticket_id, $_SESSION['user_id'], $response]);
        
        // Update ticket status
        $stmt = $pdo->prepare("UPDATE helpdesk_tickets SET status = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$status, $ticket_id]);
        
        // Send notification to user
        $notification_title = "New Response on Your Ticket";
        $notification_message = "An admin has responded to your support ticket";
        $related_url = "../helpdesk.php?ticket_id=" . $ticket_id;
        
        $stmt = $pdo->prepare("SELECT user_id FROM helpdesk_tickets WHERE id = ?");
        $stmt->execute([$ticket_id]);
        $ticket = $stmt->fetch();
        
        if ($ticket) {
            $stmt = $pdo->prepare("INSERT INTO notifications 
                                  (user_id, title, message, type, related_id, related_url) 
                                  VALUES (?, ?, ?, 'helpdesk', ?, ?)");
            $stmt->execute([$ticket['user_id'], $notification_title, $notification_message, $ticket_id, $related_url]);
        }
        
        $_SESSION['success'] = "Response added successfully";
    } 
    elseif (isset($_POST['update_status'])) {
        // Update ticket status only
        $ticket_id = (int)$_POST['ticket_id'];
        $status = $_POST['status'];
        
        $stmt = $pdo->prepare("UPDATE helpdesk_tickets SET status = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$status, $ticket_id]);
        
        // Send notification if status changed to resolved/closed
        if (in_array($status, ['resolved', 'closed'])) {
            $notification_title = "Ticket Status Updated";
            $notification_message = "Your ticket status has been updated to: " . ucfirst($status);
            $related_url = "../helpdesk.php?ticket_id=" . $ticket_id;
            
            $stmt = $pdo->prepare("SELECT user_id FROM helpdesk_tickets WHERE id = ?");
            $stmt->execute([$ticket_id]);
            $ticket = $stmt->fetch();
            
            if ($ticket) {
                $stmt = $pdo->prepare("INSERT INTO notifications 
                                      (user_id, title, message, type, related_id, related_url) 
                                      VALUES (?, ?, ?, 'helpdesk', ?, ?)");
                $stmt->execute([$ticket['user_id'], $notification_title, $notification_message, $ticket_id, $related_url]);
            }
        }
        
        $_SESSION['success'] = "Ticket status updated";
    }
    elseif (isset($_POST['request_review'])) {
        // Request review from user
        $ticket_id = (int)$_POST['ticket_id'];
        
        // Verify ticket is resolved/closed
        $stmt = $pdo->prepare("SELECT user_id, status, reviewed, review_requested FROM helpdesk_tickets WHERE id = ?");
        $stmt->execute([$ticket_id]);
        $ticket = $stmt->fetch();
        
        if ($ticket && in_array($ticket['status'], ['resolved', 'closed']) && !$ticket['reviewed'] && !$ticket['review_requested']) {
            // Mark as review requested
            $stmt = $pdo->prepare("UPDATE helpdesk_tickets SET review_requested = 1 WHERE id = ?");
            $stmt->execute([$ticket_id]);
            
            // Send notification to user
            $notification_title = "Please Rate Your Support Experience";
            $notification_message = "We'd appreciate your feedback on your recent support ticket";
            $related_url = "../helpdesk.php?ticket_id=" . $ticket_id;
            
            $stmt = $pdo->prepare("INSERT INTO notifications 
                                  (user_id, title, message, type, related_id, related_url) 
                                  VALUES (?, ?, ?, 'helpdesk', ?, ?)");
            $stmt->execute([$ticket['user_id'], $notification_title, $notification_message, $ticket_id, $related_url]);
            
            $_SESSION['success'] = "Review request sent to user";
        } else {
            $_SESSION['error'] = "You can only request reviews for resolved or closed tickets that haven't been reviewed or had a review requested already.";
        }
    }
    
    header('Location: helpdesk.php' . (isset($_GET['ticket_id']) ? '?ticket_id=' . $_GET['ticket_id'] : '')); // Redirect back to current ticket if open
    exit;
}

// Get all tickets with user info and response count
$stmt = $pdo->query("
    SELECT t.*, u.username, u.email, 
           (SELECT COUNT(*) FROM helpdesk_responses WHERE ticket_id = t.id) as response_count,
           (SELECT COUNT(*) FROM ticket_reviews WHERE ticket_id = t.id) as has_review
    FROM helpdesk_tickets t
    JOIN users u ON t.user_id = u.id
    ORDER BY 
        CASE WHEN t.status = 'open' THEN 0 ELSE 1 END,
        CASE t.priority 
            WHEN 'high' THEN 0 
            WHEN 'medium' THEN 1 
            WHEN 'low' THEN 2 
            ELSE 3 
        END,
        t.created_at DESC
");
$tickets = $stmt->fetchAll();

// Get responses for selected ticket
$responses = [];
$selected_ticket = null;
$ticket_review = null;
if (isset($_GET['ticket_id'])) {
    $ticket_id = (int)$_GET['ticket_id'];
    
    // Get ticket details
    $stmt = $pdo->prepare("
        SELECT t.*, u.username, u.email, s.name as stream_name
        FROM helpdesk_tickets t
        JOIN users u ON t.user_id = u.id
        LEFT JOIN streams s ON t.stream_id = s.id
        WHERE t.id = ?
    ");
    $stmt->execute([$ticket_id]);
    $selected_ticket = $stmt->fetch();
    
    if ($selected_ticket) {
        // Get all responses
        $stmt = $pdo->prepare("
            SELECT r.*, u.username, u.email, u.is_admin
            FROM helpdesk_responses r
            JOIN users u ON r.user_id = u.id
            WHERE r.ticket_id = ?
            ORDER BY r.created_at ASC
        ");
        $stmt->execute([$ticket_id]);
        $responses = $stmt->fetchAll();
        
        // Get review if exists
        $stmt = $pdo->prepare("SELECT * FROM ticket_reviews WHERE ticket_id = ?");
        $stmt->execute([$ticket_id]);
        $ticket_review = $stmt->fetch();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Helpdesk Management | Admin Panel</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Font Awesome for consistent icons across pages -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
            xintegrity="sha512-1ycn6IcaQQ40ZefMdHjAcUwaGDvPwdOaUcsU5XrU+pL87B7fC3J0P2Kqj1Z5M5YqD65B2L52B7y42j5P5c+A=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Feather Icons for new tab icons -->
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>

    <style>
        /* Define your color variables */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
            --light-green: #90EE90; /* Light green color */
        }

        /* Body and main layout styling */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--gray-100);
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer if added */
        }
        .site-wrapper { /* New wrapper for sticky footer logic */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container-fluid {
            padding: 0; /* Remove padding to make sidebar stick to edge */
            flex-grow: 1; /* Allow container-fluid to take up remaining height */
        }
        .row {
            margin: 0; /* Remove row margins to prevent unwanted space */
            flex-grow: 1;
        }
        /* Main content area */
        main {
            padding: 20px !important; /* Important to override Bootstrap default */
            background-color: var(--gray-100); /* Content area background */
            flex-grow: 1;
        }
        .d-flex.justify-content-between.flex-wrap.flex-md-nowrap.align-items-center {
            padding-top: 1.5rem !important; /* Bootstrap pt-3 */
            padding-bottom: 1rem !important; /* Bootstrap pb-2 */
            margin-bottom: 1.5rem !important; /* Bootstrap mb-3 */
        }

        /* Admin Sidebar basic styling */
        .admin-sidebar {
            background-color: var(--dark);
            color: var(--white);
            padding: 20px;
            /* Fixed position for desktop view */
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: 250px; /* Fixed width for the sidebar */
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .admin-sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary);
            font-size: 1.8rem;
            font-weight: 700;
        }
        .admin-sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .admin-sidebar ul li {
            margin-bottom: 10px;
        }
        .admin-sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--gray-300);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        .admin-sidebar ul li a:hover,
        .admin-sidebar ul li a.active {
            background-color: var(--gray-700);
            color: var(--white);
        }
        .admin-sidebar ul li a i {
            width: 20px;
            height: 20px;
        }

        /* Specific styles for helpdesk.php content */
        .card {
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05); /* Soft shadow */
        }
        .card-header {
            background-color: var(--white); /* Ensure headers are white */
            border-bottom: 1px solid var(--gray-200);
            padding: 1rem 1.25rem;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }
        .card-body {
            padding: 25px;
        }
        .list-group-item {
            border-left: 4px solid transparent;
            transition: all 0.2s ease;
        }
        .list-group-item.active {
            background-color: var(--primary);
            border-color: var(--primary);
            color: var(--white);
        }
        .list-group-item.active .badge, .list-group-item.active small {
            color: var(--white) !important;
        }
        .list-group-item.priority-high { border-left-color: var(--danger); }
        .list-group-item.priority-medium { border-left-color: var(--warning); }
        .list-group-item.priority-low { border-left-color: var(--success); }

        .status-badge {
            display: inline-block;
            padding: 0.35em 0.65em;
            font-size: 0.75em;
            font-weight: 700;
            line-height: 1;
            color: #fff;
            text-align: center;
            white-space: nowrap;
            vertical-align: baseline;
            border-radius: 0.375rem;
        }
        .status-open { background-color: var(--info); }
        .status-pending { background-color: var(--warning); color: #000; }
        .status-resolved { background-color: var(--success); }
        .status-closed { background-color: var(--gray-500); }

        .ticket-container {
            max-height: 500px;
            overflow-y: auto;
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            padding: 15px;
            background-color: var(--white);
        }
        .response {
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
        }
        .user-response {
            background-color: var(--gray-100);
            border-color: var(--gray-200);
            text-align: left;
        }
        .admin-response {
            background-color: #e6fffa; /* Light teal/green for admin */
            border-color: #81e6d9; /* Darker teal/green */
            text-align: right;
        }
        .admin-response strong {
            color: var(--primary);
        }
        .admin-response p {
            text-align: left; /* Keep text direction normal */
        }
        
        .review-star {
            font-size: 1.5rem;
            color: var(--gray-300);
        }
        .review-star.active {
            color: gold;
        }
        .request-review-btn {
            background-color: var(--secondary);
            border-color: var(--secondary);
        }
        .request-review-btn:hover {
            background-color: #3182ce;
            border-color: #3182ce;
        }
        .form-select.w-auto {
            width: auto !important;
        }

        /* Responsive adjustments: Sidebar becomes standard column on mobile */
        @media (max-width: 767.98px) {
            .admin-sidebar {
                position: relative; /* Remove fixed positioning on small screens */
                width: 100%; /* Take full width on small screens */
                height: auto; /* Adjust height based on content */
                box-shadow: none; /* Remove shadow to blend better */
            }
            main {
                margin-left: 0 !important; /* Remove desktop margin on small screens */
            }
            .navbar-mobile-toggle { /* Ensure this is hidden as it's not needed now */
                display: none !important;
            }
        }

        @media (min-width: 768px) { /* Applies to md and larger screens */
            .main-content-area {
                margin-left: 250px; /* Offset for the fixed sidebar */
            }
            /* Hide the mobile toggle navbar on desktop */
            .navbar-mobile-toggle {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <!-- Mobile Navbar/Toggle is not included as per instruction to ignore mobile changes. -->
        <!-- The layout will now simply stack on small screens. -->

        <div class="container-fluid">
            <div class="row">
                <!-- Admin Sidebar -->
                <!-- The d-md-block class makes it a block element from md breakpoint up, making it visible -->
                <!-- The 'collapse' class is removed to ensure it's always visible on desktop -->
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block admin-sidebar">
                    <div class="position-sticky pt-3">
                        <h2>Admin Panel</h2>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i data-feather="users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_levels.php">
                                    <i data-feather="award"></i> Membership Levels
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="payment_settings.php">
                                    <i data-feather="dollar-sign"></i> Payment Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="transactions.php">
                                    <i data-feather="credit-card"></i> Transactions
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="affiliates.php">
                                    <i data-feather="link"></i> Affiliates
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="helpdesk.php">
                                    <i data-feather="life-buoy"></i> Helpdesk
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="gift_management.php">
                                    <i data-feather="gift"></i> Gift Management
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="thresholds.php">
                                    <i data-feather="sliders"></i> Thresholds
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_admin.php">
                                    <i data-feather="user-check"></i> Membership+
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="teams.php">
                                    <i data-feather="users"></i> Teams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="streams_management.php">
                                    <i data-feather="video"></i> Streams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="cashouts.php" style="color: var(--light-green);">
                                    <i data-feather="dollar-sign"></i> Cashouts
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="email_settings.php">
                                    <i data-feather="mail"></i> Email Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="notifications.php">
                                    <i data-feather="bell"></i> Notifications
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="ai_settings.php">
                                    <i data-feather="cpu"></i> AI Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="niches.php">
                                    <i data-feather="grid"></i> Niches
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../dashboard.php">
                                    <i data-feather="home"></i> Back to Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">
                                    <i data-feather="log-out"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- End Admin Sidebar -->
                
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content-area">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Helpdesk Management</h1>
                    </div>
                    
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= $_SESSION['success'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?= $_SESSION['error'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['error']); ?>
                    <?php endif; ?>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header bg-white">
                                    <h5 class="mb-0">Open Tickets</h5>
                                </div>
                                <div class="card-body p-0">
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($tickets as $ticket): ?>
                                            <a href="?ticket_id=<?= $ticket['id'] ?>" 
                                               class="list-group-item list-group-item-action <?= $selected_ticket && $selected_ticket['id'] == $ticket['id'] ? 'active' : '' ?> 
                                               priority-<?= $ticket['priority'] ?>">
                                                <div class="d-flex justify-content-between">
                                                    <strong><?= htmlspecialchars($ticket['title']) ?></strong>
                                                    <span class="badge bg-secondary"><?= $ticket['response_count'] ?></span>
                                                </div>
                                                <div class="d-flex justify-content-between small">
                                                    <span><?= htmlspecialchars($ticket['username']) ?></span>
                                                    <span><?= date('M j, H:i', strtotime($ticket['created_at'])) ?></span>
                                                </div>
                                                <div class="d-flex justify-content-between mt-1">
                                                    <span class="status-badge status-<?= $ticket['status'] ?>">
                                                        <?= ucfirst($ticket['status']) ?>
                                                    </span>
                                                    <span class="badge bg-<?= $ticket['priority'] == 'high' ? 'danger' : ($ticket['priority'] == 'medium' ? 'warning' : 'success') ?>">
                                                        <?= ucfirst($ticket['priority']) ?>
                                                    </span>
                                                </div>
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-8">
                            <?php if ($selected_ticket): ?>
                                <div class="card">
                                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                                        <h5 class="mb-0">Ticket #<?= $selected_ticket['id'] ?>: <?= htmlspecialchars($selected_ticket['title']) ?></h5>
                                        <div>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="ticket_id" value="<?= $selected_ticket['id'] ?>">
                                                <select name="status" class="form-select form-select-sm d-inline w-auto" onchange="this.form.submit()">
                                                    <option value="open" <?= $selected_ticket['status'] == 'open' ? 'selected' : '' ?>>Open</option>
                                                    <option value="pending" <?= $selected_ticket['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                                                    <option value="resolved" <?= $selected_ticket['status'] == 'resolved' ? 'selected' : '' ?>>Resolved</option>
                                                    <option value="closed" <?= $selected_ticket['status'] == 'closed' ? 'selected' : '' ?>>Closed</option>
                                                </select>
                                                <input type="hidden" name="update_status">
                                            </form>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="ticket-meta mb-4">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <p><strong>Created by:</strong> <?= htmlspecialchars($selected_ticket['username']) ?> (<?= htmlspecialchars($selected_ticket['email']) ?>)</p>
                                                    <p><strong>Priority:</strong> 
                                                        <span class="badge bg-<?= $selected_ticket['priority'] == 'high' ? 'danger' : ($selected_ticket['priority'] == 'medium' ? 'warning' : 'success') ?>">
                                                            <?= ucfirst($selected_ticket['priority']) ?>
                                                        </span>
                                                    </p>
                                                </div>
                                                <div class="col-md-6">
                                                    <p><strong>Created:</strong> <?= date('M j, Y H:i', strtotime($selected_ticket['created_at'])) ?></p>
                                                    <?php if ($selected_ticket['stream_name']): ?>
                                                        <p><strong>Stream:</strong> <?= htmlspecialchars($selected_ticket['stream_name']) ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="ticket-description mb-4 p-3 bg-light rounded">
                                            <h6>Description:</h6>
                                            <p><?= nl2br(htmlspecialchars($selected_ticket['description'])) ?></p>
                                        </div>
                                        
                                        <?php if ($ticket_review): ?>
                                            <div class="ticket-review mb-4">
                                                <h5>User Review</h5>
                                                <div class="review-stars mb-2">
                                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                                        <span class="review-star <?= $i <= $ticket_review['rating'] ? 'active' : '' ?>">★</span>
                                                    <?php endfor; ?>
                                                </div>
                                                <?php if ($ticket_review['review']): ?>
                                                    <div class="review-comment p-3 bg-light rounded">
                                                        <p><?= nl2br(htmlspecialchars($ticket_review['review'])) ?></p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php elseif (in_array($selected_ticket['status'], ['resolved', 'closed']) && !$selected_ticket['has_review'] && !$selected_ticket['review_requested']): // Check for has_review property if available or add logic to verify no review exists?>
                                            <form method="POST" class="mb-4">
                                                <input type="hidden" name="ticket_id" value="<?= $selected_ticket['id'] ?>">
                                                <button type="submit" name="request_review" class="btn btn-primary request-review-btn">
                                                    Request Review from User
                                                </button>
                                            </form>
                                        <?php elseif ($selected_ticket['review_requested'] && !$selected_ticket['has_review']): // Check for has_review property if available?>
                                            <div class="alert alert-info mb-4">
                                                Review request sent to user - pending response
                                            </div>
                                        <?php endif; ?>
                                        
                                        <h5 class="mb-3">Responses (<?= count($responses) ?>)</h5>
                                        <div class="ticket-container mb-4">
                                            <?php if (empty($responses)): ?>
                                                <div class="alert alert-info">No responses yet</div>
                                            <?php else: ?>
                                                <?php foreach ($responses as $response): ?>
                                                    <div class="response p-3 mb-3 rounded <?= $response['is_admin'] ? 'admin-response' : 'user-response' ?>">
                                                        <div class="d-flex justify-content-between mb-2">
                                                            <strong><?= htmlspecialchars($response['username']) ?></strong>
                                                            <small class="text-muted"><?= date('M j, Y H:i', strtotime($response['created_at'])) ?></small>
                                                        </div>
                                                        <p><?= nl2br(htmlspecialchars($response['response'])) ?></p>
                                                    </div>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <form method="POST">
                                            <input type="hidden" name="ticket_id" value="<?= $selected_ticket['id'] ?>">
                                            <div class="mb-3">
                                                <label for="response" class="form-label">Add Response</label>
                                                <textarea class="form-control" id="response" name="response" rows="3" required></textarea>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <select name="status" class="form-select w-auto">
                                                    <option value="open" <?= $selected_ticket['status'] == 'open' ? 'selected' : '' ?>>Keep as Open</option>
                                                    <option value="pending" <?= $selected_ticket['status'] == 'pending' ? 'selected' : '' ?>>Mark as Pending</option>
                                                    <option value="resolved" <?= $selected_ticket['status'] == 'resolved' ? 'selected' : '' ?>>Mark as Resolved</option>
                                                    <option value="closed" <?= $selected_ticket['status'] == 'closed' ? 'selected' : '' ?>>Mark as Closed</option>
                                                </select>
                                                <button type="submit" name="add_response" class="btn btn-primary">Submit Response</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="card">
                                    <div class="card-body text-center py-5">
                                        <i class="bi bi-chat-square-text fs-1 text-muted"></i>
                                        <h5 class="mt-3">Select a ticket to view details</h5>
                                        <p class="text-muted">Choose a ticket from the list to view its details and respond</p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize Feather Icons
        feather.replace();

        // Auto-scroll to bottom of responses
        const ticketContainer = document.querySelector('.ticket-container');
        if (ticketContainer) {
            ticketContainer.scrollTop = ticketContainer.scrollHeight;
        }
    </script>
</body>
</html>
