<?php
// admin/notifications.php
require_once '../includes/db.php';

// Admin verification
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit;
}

// Handle search
$search = '';
$notifications = [];
$selected_user = null;

if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
    
    if (!empty($search)) {
        // Search for users
        $stmt = $pdo->prepare("SELECT id, username, email FROM users 
                               WHERE username LIKE ? OR email LIKE ? 
                               ORDER BY username LIMIT 20");
        $stmt->execute(["%$search%", "%$search%"]);
        $users = $stmt->fetchAll();
        
        if (count($users) === 1) {
            // If only one user found, show their notifications
            $selected_user = $users[0];
            $stmt = $pdo->prepare("SELECT * FROM notifications 
                                  WHERE user_id = ? 
                                  ORDER BY created_at DESC");
            $stmt->execute([$selected_user['id']]);
            $notifications = $stmt->fetchAll();
        }
    }
}

// Handle notification actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['mark_read'])) {
        $notification_id = (int)$_POST['notification_id'];
        $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1, read_at = NOW() WHERE id = ?");
        $stmt->execute([$notification_id]);
        $_SESSION['success'] = "Notification marked as read";
    } elseif (isset($_POST['delete_notification'])) {
        $notification_id = (int)$_POST['notification_id'];
        $stmt = $pdo->prepare("DELETE FROM notifications WHERE id = ?");
        $stmt->execute([$notification_id]);
        $_SESSION['success'] = "Notification deleted";
    }
    
    // Redirect back to maintain search state
    $redirect_url = "notifications.php";
    if (!empty($search)) {
        $redirect_url .= "?search=" . urlencode($search);
    }
    header("Location: $redirect_url");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications | Admin Panel</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Font Awesome for consistent icons across pages -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
            xintegrity="sha512-1ycn6IcaQQ40ZefMdHjAcUwaGDvPwdOaUcsU5XrU+pL87B7fC3J0P2Kqj1Z5M5YqD65B2L52B7y42j5P5c+A=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Feather Icons for new tab icons -->
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>

    <style>
        /* Define your color variables */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
            --light-green: #90EE90; /* Light green color */
        }

        /* Body and main layout styling */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--gray-100);
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer if added */
        }
        .site-wrapper { /* New wrapper for sticky footer logic */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container-fluid {
            padding: 0; /* Remove padding to make sidebar stick to edge */
            flex-grow: 1; /* Allow container-fluid to take up remaining height */
        }
        .row {
            margin: 0; /* Remove row margins to prevent unwanted space */
            flex-grow: 1;
        }
        /* Main content area */
        main {
            padding: 20px !important; /* Important to override Bootstrap default */
            background-color: var(--gray-100); /* Content area background */
            flex-grow: 1;
        }
        .d-flex.justify-content-between.flex-wrap.flex-md-nowrap.align-items-center {
            padding-top: 1.5rem !important; /* Bootstrap pt-3 */
            padding-bottom: 1rem !important; /* Bootstrap pb-2 */
            margin-bottom: 1.5rem !important; /* Bootstrap mb-3 */
        }

        /* Admin Sidebar basic styling */
        .admin-sidebar {
            background-color: var(--dark);
            color: var(--white);
            padding: 20px;
            /* Fixed position for desktop view */
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: 250px; /* Fixed width for the sidebar */
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .admin-sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary);
            font-size: 1.8rem;
            font-weight: 700;
        }
        .admin-sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .admin-sidebar ul li {
            margin-bottom: 10px;
        }
        .admin-sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--gray-300);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        .admin-sidebar ul li a:hover,
        .admin-sidebar ul li a.active {
            background-color: var(--gray-700);
            color: var(--white);
        }
        .admin-sidebar ul li a i {
            width: 20px;
            height: 20px;
        }

        /* Specific styles for notifications.php content */
        .notification-card {
            border-left: 4px solid var(--primary); /* Using primary color for consistency */
        }
        .notification-card.unread {
            border-left-color: var(--danger); /* Using danger color for unread */
            background-color: var(--gray-100); /* Use gray-100 for unread background */
        }
        .notification-type {
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .search-results {
            max-height: 300px;
            overflow-y: auto;
            border: 1px solid var(--gray-200); /* Added border for clarity */
            border-radius: 8px;
            padding: 15px;
        }
        /* Card styles */
        .card {
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05); /* Soft shadow */
        }
        .card-body {
            padding: 25px;
        }
        .form-control, .form-select {
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            padding: 10px 15px;
            color: var(--gray-800);
            background-color: var(--white);
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(58, 195, 184, 0.25);
        }
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: background-color 0.2s, border-color 0.2s;
        }
        .btn-primary:hover {
            background-color: #2da89e;
            border-color: #2da89e;
        }
        .alert {
            border-radius: 8px;
            font-weight: 500;
        }

        /* Responsive adjustments: Sidebar becomes standard column on mobile */
        @media (max-width: 767.98px) {
            .admin-sidebar {
                position: relative; /* Remove fixed positioning on small screens */
                width: 100%; /* Take full width on small screens */
                height: auto; /* Adjust height based on content */
                box-shadow: none; /* Remove shadow to blend better */
            }
            main {
                margin-left: 0 !important; /* Remove desktop margin on small screens */
            }
            .navbar-mobile-toggle { /* Ensure this is hidden as it's not needed now */
                display: none !important;
            }
        }

        @media (min-width: 768px) { /* Applies to md and larger screens */
            .main-content-area {
                margin-left: 250px; /* Offset for the fixed sidebar */
            }
            /* Hide the mobile toggle navbar on desktop */
            .navbar-mobile-toggle {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <!-- Mobile Navbar/Toggle is not included as per instruction to ignore mobile changes. -->
        <!-- The layout will now simply stack on small screens. -->

        <div class="container-fluid">
            <div class="row">
                <!-- Admin Sidebar -->
                <!-- The d-md-block class makes it a block element from md breakpoint up, making it visible -->
                <!-- The 'collapse' class is removed to ensure it's always visible on desktop -->
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block admin-sidebar">
                    <div class="position-sticky pt-3">
                        <h2>Admin Panel</h2>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">
                                    <i data-feather="users"></i> Users
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_levels.php">
                                    <i data-feather="award"></i> Membership Levels
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="payment_settings.php">
                                    <i data-feather="dollar-sign"></i> Payment Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="transactions.php">
                                    <i data-feather="credit-card"></i> Transactions
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="affiliates.php">
                                    <i data-feather="link"></i> Affiliates
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="helpdesk.php">
                                    <i data-feather="life-buoy"></i> Helpdesk
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="gift_management.php">
                                    <i data-feather="gift"></i> Gift Management
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="thresholds.php">
                                    <i data-feather="sliders"></i> Thresholds
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="membership_admin.php">
                                    <i data-feather="user-check"></i> Membership+
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="teams.php">
                                    <i data-feather="users"></i> Teams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="streams_management.php">
                                    <i data-feather="video"></i> Streams
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="cashouts.php" style="color: var(--light-green);">
                                    <i data-feather="dollar-sign"></i> Cashouts
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="notifications.php">
                                    <i data-feather="bell"></i> Notifications
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="ai_settings.php">
                                    <i data-feather="cpu"></i> AI Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="niches.php">
                                    <i data-feather="grid"></i> Niches
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../dashboard.php">
                                    <i data-feather="home"></i> Back to Dashboard
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../auth/logout.php">
                                    <i data-feather="log-out"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- End Admin Sidebar -->
                
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content-area">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">User Notifications</h1>
                    </div>
                    
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= $_SESSION['success'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    
                    <div class="card mb-4">
                        <div class="card-body">
                            <form method="GET" class="mb-4">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="search" 
                                            value="<?= htmlspecialchars($search) ?>" 
                                            placeholder="Search by username or email">
                                    <button class="btn btn-primary" type="submit">Search</button>
                                </div>
                            </form>
                            
                            <?php if (!empty($search) && !$selected_user && !empty($users)): ?>
                                <div class="search-results mb-4">
                                    <h5 class="mb-3">Search Results</h5>
                                    <div class="list-group">
                                        <?php foreach ($users as $user_row): // Renamed to user_row to avoid conflict with $user from admin verification ?>
                                            <a href="notifications.php?search=<?= urlencode($user_row['username']) ?>" 
                                               class="list-group-item list-group-item-action">
                                                <strong><?= htmlspecialchars($user_row['username']) ?></strong>
                                                <small class="text-muted d-block"><?= htmlspecialchars($user_row['email']) ?></small>
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php elseif ($selected_user): ?>
                                <div class="d-flex justify-content-between align-items-center mb-4">
                                    <h5>
                                        Notifications for 
                                        <strong><?= htmlspecialchars($selected_user['username']) ?></strong>
                                        <small class="text-muted"><?= htmlspecialchars($selected_user['email']) ?></small>
                                    </h5>
                                    <a href="notifications.php" class="btn btn-sm btn-outline-secondary">Clear</a>
                                </div>
                                
                                <?php if (empty($notifications)): ?>
                                    <div class="alert alert-info">No notifications found for this user.</div>
                                <?php else: ?>
                                    <div class="list-group">
                                        <?php foreach ($notifications as $notification): ?>
                                            <div class="list-group-item notification-card <?= !$notification['is_read'] ? 'unread' : '' ?>">
                                                <div class="d-flex justify-content-between align-items-start">
                                                    <div class="me-3">
                                                        <span class="badge bg-secondary notification-type mb-1">
                                                            <?= htmlspecialchars($notification['type']) ?>
                                                        </span>
                                                        <h6 class="mb-1"><?= htmlspecialchars($notification['title']) ?></h6>
                                                        <p class="mb-1"><?= htmlspecialchars($notification['message']) ?></p>
                                                        <small class="text-muted">
                                                            <?= date('M j, Y g:i a', strtotime($notification['created_at'])) ?>
                                                            <?php if ($notification['is_read']): ?>
                                                                &middot; Read on <?= date('M j, Y', strtotime($notification['read_at'])) ?>
                                                            <?php endif; ?>
                                                        </small>
                                                    </div>
                                                    <div class="btn-group btn-group-sm">
                                                        <form method="POST" class="d-inline">
                                                            <input type="hidden" name="notification_id" value="<?= $notification['id'] ?>">
                                                            <button type="submit" name="mark_read" class="btn btn-sm btn-outline-success" 
                                                                    <?= $notification['is_read'] ? 'disabled' : '' ?>>
                                                                <i data-feather="check-square"></i>
                                                            </button>
                                                        </form>
                                                        <form method="POST" class="d-inline">
                                                            <input type="hidden" name="notification_id" value="<?= $notification['id'] ?>">
                                                            <button type="submit" name="delete_notification" class="btn btn-sm btn-outline-danger">
                                                                <i data-feather="trash"></i>
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            <?php elseif (!empty($search) && empty($users)): ?>
                                <div class="alert alert-warning">No users found matching your search.</div>
                            <?php else: ?>
                                <div class="alert alert-info">Search for a user to view their notifications.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize Feather Icons
        feather.replace();
    </script>
</body>
</html>
