<?php
// admin/dashboard.php
require_once '../includes/db.php';

// Admin verification
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit;
}

// Determine which page to load
$allowed_pages = [
    'dashboard' => 'Dashboard',
    'users' => 'Users',
    'membership_levels' => 'Membership Levels',
    'transactions' => 'Transactions',
    'payment_settings' => 'Payment Settings',
    'email_settings' => 'Email Settings',
    'ai_settings' => 'AI Settings',
    'affiliates' => 'Affiliates',
    'cashouts' => 'Cashouts',
    'niches' => 'Niches',
    'notifications' => 'Notifications'
];

$page = $_GET['page'] ?? 'dashboard';
if (!array_key_exists($page, $allowed_pages)) {
    $page = 'dashboard';
}

// Get stats for dashboard
if ($page === 'dashboard') {
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $total_users = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(*) FROM transactions WHERE status = 'completed'");
    $total_transactions = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT SUM(amount) FROM transactions WHERE status = 'completed'");
    $total_revenue = $stmt->fetchColumn() ?? 0;
    
    $stmt = $pdo->query("SELECT COUNT(*) FROM affiliate_cashouts WHERE status = 'pending'");
    $pending_cashouts = $stmt->fetchColumn();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Admin Board</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 48px 0 0;
            box-shadow: inset -1px 0 0 rgba(0, 0, 0, .1);
            background-color: #212529;
        }
        
        .sidebar-sticky {
            position: relative;
            top: 0;
            height: calc(100vh - 48px);
            padding-top: .5rem;
            overflow-x: hidden;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            color: #adb5bd;
            padding: 0.5rem 1rem;
        }
        
        .sidebar .nav-link.active {
            color: #fff;
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .sidebar .nav-link:hover {
            color: #fff;
            background-color: rgba(255, 255, 255, 0.05);
        }
        
        .sidebar .nav-link .bi {
            margin-right: 4px;
            color: #6c757d;
        }
        
        .sidebar .nav-link.active .bi,
        .sidebar .nav-link:hover .bi {
            color: #0d6efd;
        }
        
        .main-content {
            padding: 20px;
            margin-left: 220px;
            margin-top: 40px !important;
        }
        
        .stat-card {
            border-left: 4px solid #0d6efd;
        }
        
        .navbar-brand {
            padding-top: .75rem;
            padding-bottom: .75rem;
            background-color: rgba(0, 0, 0, .25);
            box-shadow: inset -1px 0 0 rgba(0, 0, 0, .25);
        }
        
        .navbar .navbar-toggler {
            top: .25rem;
            right: 1rem;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark fixed-top navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="../dashboard.php">
                            <i class="bi bi-speedometer2"></i> Main Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../auth/logout.php">
                            <i class="bi bi-box-arrow-right"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 d-none d-md-block sidebar">
                <div class="sidebar-sticky">
                    <ul class="nav flex-column">
                        <?php foreach ($allowed_pages as $key => $name): ?>
                            <li class="nav-item">
                                <a class="nav-link <?= $page === $key ? 'active' : '' ?>" 
                                   href="dashboard.php?page=<?= $key ?>">
                                    <i class="bi bi-<?= getIconForPage($key) ?>"></i>
                                    <?= $name ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </nav>
            
            <main role="main" class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
                <?php if ($page === 'dashboard'): ?>
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">Admin Dashboard</h1>
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-md-3">
                            <div class="card stat-card h-100">
                                <div class="card-body">
                                    <h6 class="card-title">Total Users</h6>
                                    <p class="card-text h2"><?= number_format($total_users) ?></p>
                                    <a href="dashboard.php?page=users" class="btn btn-sm btn-outline-primary">View Users</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card stat-card h-100">
                                <div class="card-body">
                                    <h6 class="card-title">Total Revenue</h6>
                                    <p class="card-text h2">$<?= number_format($total_revenue, 2) ?></p>
                                    <a href="dashboard.php?page=transactions" class="btn btn-sm btn-outline-primary">View Transactions</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card stat-card h-100">
                                <div class="card-body">
                                    <h6 class="card-title">Completed Transactions</h6>
                                    <p class="card-text h2"><?= number_format($total_transactions) ?></p>
                                    <a href="dashboard.php?page=transactions" class="btn btn-sm btn-outline-primary">View Transactions</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card stat-card h-100">
                                <div class="card-body">
                                    <h6 class="card-title">Pending Cashouts</h6>
                                    <p class="card-text h2"><?= number_format($pending_cashouts) ?></p>
                                    <a href="dashboard.php?page=cashouts" class="btn btn-sm btn-outline-primary">View Cashouts</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Quick Actions</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <a href="dashboard.php?page=users" class="btn btn-primary w-100">
                                        <i class="bi bi-people-fill"></i> Manage Users
                                    </a>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <a href="dashboard.php?page=membership_levels" class="btn btn-success w-100">
                                        <i class="bi bi-card-list"></i> Membership Levels
                                    </a>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <a href="dashboard.php?page=payment_settings" class="btn btn-info w-100">
                                        <i class="bi bi-credit-card"></i> Payment Settings
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <?php include_once "{$page}.php"; ?>
                <?php endif; ?>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
function getIconForPage($page) {
    $icons = [
        'dashboard' => 'speedometer2',
        'users' => 'people-fill',
        'membership_levels' => 'card-list',
        'transactions' => 'credit-card',
        'payment_settings' => 'credit-card-2-back',
        'email_settings' => 'envelope',
        'ai_settings' => 'robot',
        'affiliates' => 'person-plus',
        'cashouts' => 'cash-coin',
        'niches' => 'tags',
        'notifications' => 'bell'
    ];
    return $icons[$page] ?? 'gear';
}
?>