<?php
require_once 'includes/header.php';
require_once 'includes/db.php';

$campaign_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

// Get campaign details
$stmt = $pdo->prepare("SELECT * FROM winback_campaigns WHERE id = ? AND user_id = ?");
$stmt->execute([$campaign_id, $user_id]);
$campaign = $stmt->fetch();

if (!$campaign) {
    header('Location: automations.php');
    exit;
}

// Get campaign execution logs
$stmt = $pdo->prepare("SELECT * FROM campaign_logs WHERE campaign_id = ? ORDER BY executed_at DESC LIMIT 50");
$stmt->execute([$campaign_id]);
$logs = $stmt->fetchAll();

// Get campaign stats
$stmt = $pdo->prepare("SELECT 
    COUNT(*) as total_executions,
    SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as successful,
    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
    FROM campaign_logs WHERE campaign_id = ?");
$stmt->execute([$campaign_id]);
$stats = $stmt->fetch();
?>

<div class="campaign-details">
    <h1><?= htmlspecialchars($campaign['name']) ?></h1>
    
    <div class="stats-grid">
        <div class="stat-card">
            <h3>Total Executions</h3>
            <p><?= $stats['total_executions'] ?></p>
        </div>
        <div class="stat-card">
            <h3>Successful</h3>
            <p><?= $stats['successful'] ?></p>
        </div>
        <div class="stat-card">
            <h3>Failed</h3>
            <p><?= $stats['failed'] ?></p>
        </div>
    </div>
    
    <div class="execution-logs">
        <h2>Recent Executions</h2>
        <table>
            <!-- Logs table similar to automations list -->
        </table>
    </div>
</div>