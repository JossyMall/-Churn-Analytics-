// assets/js/retention.js
document.addEventListener('DOMContentLoaded', function() {
    // Chart colors - defined globally or imported from a config
    const colors = {
        primary: '#3ac3b8', // Example color
        secondary: '#4a90e2', // Example color
        background: '#f8f9fa',
        text: '#333',
        grid: '#e0e0e0',
        highRisk: '#ef4444', // red-500
        mediumRisk: '#f59e0b', // amber-500
        lowRisk: '#22c55e' // green-500
    };

    // DOM Elements
    const dateRangeSelect = document.getElementById('dateRange');
    const cohortSelect = document.getElementById('cohortFilter');
    const streamSelect = document.getElementById('streamFilter');
    const loadingIndicator = document.getElementById('loadingIndicator');
    
    // Summary Metrics
    const retentionRateValue = document.getElementById('retentionRateValue');
    const churnRateValue = document.getElementById('churnRateValue');
    const resurrectionRateValue = document.getElementById('resurrectionRateValue');
    const retentionChange = document.getElementById('retentionChange'); // Placeholder for future
    const churnChange = document.getElementById('churnChange');       // Placeholder for future
    const resurrectionChange = document.getElementById('resurrectionChange'); // Placeholder for future

    // Chart Canvas Elements & Contexts
    const retentionChartCanvas = document.getElementById('retentionChart');
    const churnChartCanvas = document.getElementById('churnChart');
    const heatmapContainer = document.getElementById('heatmapContainer');
    
    const retentionChartCtx = retentionChartCanvas ? retentionChartCanvas.getContext('2d') : null;
    const churnChartCtx = churnChartCanvas ? churnChartCanvas.getContext('2d') : null;

    // Tooltip for heatmap (if not already in HTML)
    let heatmapTooltip = document.getElementById('heatmapTooltip');
    if (!heatmapTooltip) { // Create if it doesn't exist
        heatmapTooltip = document.createElement('div');
        heatmapTooltip.id = 'heatmapTooltip';
        heatmapTooltip.className = 'heatmap-tooltip'; // Add a class for specific styling
        document.body.appendChild(heatmapTooltip);
    }
    
    // Initialize Chart.js instances
    let retentionLineChart, churnBarChart;

    // --- Demo Data for Charts (defined once, globally accessible within DOMContentLoaded) ---
    const generateDemoMonthlyData = (baseValue, labelPrefix = '') => {
        const demoLabels = [];
        const demoData = [];
        const today = new Date();
        for (let i = 11; i >= 0; i--) {
            const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
            demoLabels.push(d.toLocaleString('en-us', { month: 'short', year: 'numeric' }));
            demoData.push(parseFloat((baseValue + Math.random() * (baseValue * 0.2) - (baseValue * 0.1)).toFixed(1)));
        }
        return { labels: demoLabels, data: demoData };
    };

    const demoAcquisitionData = generateDemoMonthlyData(100);
    const demoChurnRateData = generateDemoMonthlyData(15); // Average churn score
    const demoChurnDistributionDataValues = [30, 40, 30]; // High, Medium, Low risk percentages
    const demoChurnDistributionDataLabels = ['Low Risk', 'Medium Risk', 'High Risk']; // Labels for distribution

    const demoHeatmapData = {
        cohorts: [{ id: 1, name: 'Q1 2024 Signups' }, { id: 2, name: 'Trial Users' }],
        months: ['Month 0', 'Month 1', 'Month 2', 'Month 3'],
        data: [
            [100, 85, 70, 60], // Q1 2024 retention
            [100, 70, 50, 30]  // Trial Users retention
        ]
    };


    function getChartOptions(title, displayLegend = false) {
        return {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: displayLegend
                },
                title: {
                    display: false, // Title usually in HTML, not in Chart.js itself
                    text: title
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: 'rgba(0,0,0,0.8)',
                    titleFont: { size: 12, weight: 'bold' },
                    bodyFont: { size: 12 },
                    padding: 10,
                    callbacks: {
                        label: function(context) {
                            // Ensure the value is a number for % display
                            const value = typeof context.parsed.y === 'number' ? context.parsed.y : context.parsed.r; // Use r for Doughnut chart
                            return `${context.dataset.label}: ${value.toFixed(1)}%`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: { display: false, drawBorder: false },
                    ticks: { color: colors.text }
                },
                y: {
                    beginAtZero: true,
                    max: 100, // Max for percentage charts
                    grid: { color: colors.grid, drawBorder: false },
                    ticks: {
                        color: colors.text,
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
            }
        };
    }

    function hexToRgba(hex, alpha) {
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }

    // Function to initialize Chart.js instances (called once on DOMContentLoaded)
    function initCharts() {
        if (retentionChartCtx) {
            retentionLineChart = new Chart(retentionChartCtx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Retention Rate', // This label might change based on data received (e.g., Churn Score)
                        data: [],
                        borderColor: colors.primary,
                        backgroundColor: hexToRgba(colors.primary, 0.1), // Gradient fill
                        fill: 'origin', // Fill from origin (bottom)
                        borderWidth: 2,
                        tension: 0.4,
                        pointRadius: 3,
                        pointHoverRadius: 5
                    }]
                },
                options: getChartOptions('Churn Trends Over Time')
            });
        }

        if (churnChartCtx) {
            churnBarChart = new Chart(churnChartCtx, {
                type: 'bar', // Assuming bar for distribution
                data: {
                    labels: demoChurnDistributionDataLabels, // Fixed labels for distribution
                    datasets: [{
                        label: 'Percentage of Contacts',
                        data: [],
                        backgroundColor: [colors.lowRisk, colors.mediumRisk, colors.highRisk],
                        borderColor: [colors.lowRisk, colors.mediumRisk, colors.highRisk],
                        borderWidth: 1
                    }]
                },
                options: getChartOptions('Churn Risk Distribution', true) // Display legend for bar chart
            });
        }
    }


    // --- Heatmap Drawing Function ---
    function renderHeatmap(data) {
        if (!heatmapContainer) return;

        // Clear previous content and hide loading
        heatmapContainer.innerHTML = '';
        if (loadingIndicator) loadingIndicator.style.display = 'none';

        if (!data || !data.cohorts || !data.periods || !data.data || data.cohorts.length === 0 || data.periods.length === 0) {
            heatmapContainer.innerHTML = `
                <div class="empty-state">
                    <h3>No Cohort Retention Data</h3>
                    <p>Insufficient data to generate the cohort retention heatmap. Ensure you have cohorts, contacts within them, and sufficient historical data.</p>
                </div>
            `;
            return;
        }

        const table = document.createElement('table');
        table.className = 'w-full border-collapse text-sm bg-white shadow-sm rounded-lg overflow-hidden'; // Tailwind classes

        // Table Header (Months/Periods)
        const thead = table.createTHead();
        let headerRow = thead.insertRow();
        let emptyTh = document.createElement('th');
        emptyTh.className = 'p-3 text-left border-b border-gray-300 bg-gray-100 font-semibold sticky left-0 z-10'; // Sticky for cohort labels
        headerRow.appendChild(emptyTh); // Empty cell for cohort labels

        data.periods.forEach(period => {
            let th = document.createElement('th');
            th.className = 'p-3 text-center border-b border-gray-300 bg-gray-100 font-semibold';
            th.textContent = period;
            headerRow.appendChild(th);
        });

        // Table Body (Cohorts and Retention Data)
        const tbody = table.createTBody();
        data.cohorts.forEach((cohort, cohortIndex) => {
            let tr = tbody.insertRow();
            let thCohort = document.createElement('th');
            thCohort.className = 'p-3 text-left border-b border-gray-200 bg-gray-50 font-medium sticky left-0 z-10';
            thCohort.textContent = cohort.name;
            tr.appendChild(thCohort);

            // Ensure data.data[cohortIndex] exists and is an array before iterating
            const cohortRetentionData = data.data[cohortIndex] || []; 
            
            cohortRetentionData.forEach((percentage, monthIndex) => {
                let td = tr.insertCell();
                td.className = 'p-3 text-center border-b border-gray-200';
                
                if (percentage !== null && typeof percentage === 'number') {
                    // Determine color based on percentage
                    let bgColor = 'bg-red-50'; // Default for low retention (below 20%)
                    if (percentage >= 80) bgColor = 'bg-green-200';
                    else if (percentage >= 60) bgColor = 'bg-green-100';
                    else if (percentage >= 40) bgColor = 'bg-yellow-100';
                    else if (percentage >= 20) bgColor = 'bg-orange-100';
                    
                    td.className += ` ${bgColor} font-semibold text-gray-800`;
                    td.textContent = `${percentage}%`;
                } else {
                    td.textContent = '-'; // For months before acquisition or no data
                    td.className += ' text-gray-400';
                }
            });
        });

        heatmapContainer.appendChild(table);
    }

    // --- Show/Hide Loading Indicator ---
    function showLoading() {
        if (loadingIndicator) loadingIndicator.style.display = 'flex';
    }

    function hideLoading() {
        if (loadingIndicator) loadingIndicator.style.display = 'none';
    }

    // --- Main Fetch and Render Function ---
    async function fetchRetentionData() {
        showLoading();
        
        try {
            const params = new URLSearchParams({
                dateRange: dateRangeSelect.value,
                cohort: cohortSelect.value,
                stream: streamSelect.value
            });
            
            const response = await fetch(`api2/retention.php?${params}`);
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Network response was not ok (${response.status}): ${errorText}`);
            }
            
            const data = await response.json();
            
            if (data.error) {
                console.error('API Error:', data.error);
                // Fallback to demo data on API error
                renderAllChartsWithFallback(data.error);
                return;
            }

            // Update Summary Metrics
            retentionRateValue.textContent = `${data.summary.retentionRate ?? 0}%`;
            churnRateValue.textContent = `${data.summary.churnRate ?? 0}%`;
            resurrectionRateValue.textContent = `${data.summary.resurrectionRate ?? 0}%`;
            // Placeholder for changes vs previous period (currently always 0%)
            retentionChange.textContent = `0%`; 
            churnChange.textContent = `0%`;     
            resurrectionChange.textContent = `0%`; 
            
            // Update and Draw Chart.js Charts
            // Monthly Churn Score Trend Chart (retentionChart in HTML)
            if (retentionLineChart && data.trends.labels && data.trends.labels.length > 0 && data.trends.retention && data.trends.retention.length > 0) {
                retentionLineChart.data.labels = data.trends.labels;
                retentionLineChart.data.datasets[0].data = data.trends.retention;
                retentionLineChart.data.datasets[0].label = 'Avg Churn Score'; // Adjust label for data
                retentionLineChart.update();
            } else {
                 if (retentionLineChart) {
                    retentionLineChart.destroy(); // Destroy existing chart if no data
                    // Re-initialize with empty data to display empty state
                    retentionLineChart = new Chart(retentionChartCtx, {
                        type: 'line',
                        data: { labels: [], datasets: [] },
                        options: getChartOptions('Churn Trends Over Time')
                    });
                    retentionChartCtx.clearRect(0, 0, retentionChartCtx.canvas.width, retentionChartCtx.canvas.height);
                    retentionChartCtx.font = "16px Inter";
                    retentionChartCtx.textAlign = "center";
                    retentionChartCtx.fillStyle = colors.text;
                    retentionChartCtx.fillText("No data for Monthly Churn Trends.", retentionChartCtx.canvas.width / 2, retentionChartCtx.canvas.height / 2);
                 }
            }

            // Churn Distribution Chart (churnChart in HTML)
            if (churnBarChart && data.churnDistribution.values && data.churnDistribution.values.length === 3) {
                churnBarChart.data.labels = data.churnDistribution.labels; // Ensure labels are correctly set from API if they change
                churnBarChart.data.datasets[0].data = data.churnDistribution.values;
                churnBarChart.update();
            } else {
                 if (churnBarChart) {
                    churnBarChart.destroy(); // Destroy existing chart if no data
                    // Re-initialize with empty data to display empty state
                    churnBarChart = new Chart(churnChartCtx, {
                        type: 'bar',
                        data: { labels: demoChurnDistributionDataLabels, datasets: [] },
                        options: getChartOptions('Churn Risk Distribution', true)
                    });
                    churnChartCtx.clearRect(0, 0, churnChartCtx.canvas.width, churnChartCtx.canvas.height);
                    churnChartCtx.font = "16px Inter";
                    churnChartCtx.textAlign = "center";
                    churnChartCtx.fillStyle = colors.text;
                    churnChartCtx.fillText("No data for Churn Distribution.", churnChartCtx.canvas.width / 2, churnChartCtx.canvas.height / 2);
                 }
            }
            
            // Render Heatmap
            renderHeatmap(data.cohortAnalysis);
            
        } catch (error) {
            console.error('Error fetching retention data:', error);
            renderAllChartsWithFallback(error.message);
        } finally {
            hideLoading();
        }
    }

    // --- Fallback to Demo Data Function ---
    function renderAllChartsWithFallback(errorMessage = 'An unexpected error occurred or no data found.') {
        // Update Summary Metrics to reflect demo/empty data
        retentionRateValue.textContent = `Demo%`;
        churnRateValue.textContent = `Demo%`;
        resurrectionRateValue.textContent = `Demo%`;
        retentionChange.textContent = `0%`;
        churnChange.textContent = `0%`;
        resurrectionChange.textContent = `0%`;

        // Draw demo charts using Chart.js update method
        if (retentionLineChart) {
            retentionLineChart.data.labels = demoChurnRateData.labels; // Use demo churn rate labels/data for consistency
            retentionLineChart.data.datasets[0].label = 'Demo Avg Churn Score';
            retentionLineChart.data.datasets[0].data = demoChurnRateData.data;
            retentionLineChart.update();
        } else {
             if (retentionChartCanvas) { // Fallback if somehow retentionLineChart wasn't initialized
                const tempCtx = retentionChartCanvas.getContext('2d');
                if (tempCtx) {
                    tempCtx.clearRect(0, 0, retentionChartCanvas.width, retentionChartCanvas.height);
                    tempCtx.font = "16px Inter";
                    tempCtx.textAlign = "center";
                    tempCtx.fillStyle = colors.text;
                    tempCtx.fillText("Demo Chart (No Real Data)", retentionChartCanvas.width / 2, retentionChartCanvas.height / 2);
                }
             }
        }
        
        if (churnBarChart) {
            churnBarChart.data.labels = demoChurnDistributionDataLabels;
            churnBarChart.data.datasets[0].data = demoChurnDistributionDataValues;
            churnBarChart.update();
        } else {
            if (churnChartCanvas) { // Fallback if somehow churnBarChart wasn't initialized
                const tempCtx = churnChartCanvas.getContext('2d');
                if (tempCtx) {
                    tempCtx.clearRect(0, 0, churnChartCanvas.width, churnChartCanvas.height);
                    tempCtx.font = "16px Inter";
                    tempCtx.textAlign = "center";
                    tempCtx.fillStyle = colors.text;
                    tempCtx.fillText("Demo Chart (No Real Data)", churnChartCanvas.width / 2, churnChartCanvas.height / 2);
                }
            }
        }
        
        renderHeatmap(demoHeatmapData); // Pass demo heatmap data
    }


    // --- Event Listeners for Filters ---
    dateRangeSelect.addEventListener('change', fetchRetentionData);
    streamSelect.addEventListener('change', fetchRetentionData);
    cohortSelect.addEventListener('change', fetchRetentionData);

    // Initial setup and data fetch
    initCharts(); // Initialize Chart.js objects first
    fetchRetentionData(); // Then fetch data

    // Heatmap tooltip handling (your existing code)
    // IMPORTANT: Ensure 'heatmapTooltip' element is created in HTML or dynamically via JS.
    // My previous code dynamically created it if not present, which is good.
    // Add specific CSS for .heatmap-tooltip in your CSS file if not already present.
    document.addEventListener('mouseover', function(e) {
        // Ensure tooltip element is properly positioned and visible
        if (e.target.classList.contains('heatmap-cell') && e.target.dataset.tooltip) {
            const cell = e.target;
            const rect = cell.getBoundingClientRect();
            
            heatmapTooltip.textContent = cell.dataset.tooltip; // No need for replace(/\n/g, '\n') as pre-wrap handles it
            heatmapTooltip.style.left = `${rect.left + window.scrollX}px`;
            heatmapTooltip.style.top = `${rect.top + window.scrollY - 40}px`; // Adjust 40px as needed for vertical offset
            heatmapTooltip.style.opacity = '1';
            heatmapTooltip.style.visibility = 'visible'; // Ensure visibility
        }
    });

    document.addEventListener('mouseout', function(e) {
        if (e.target.classList.contains('heatmap-cell')) {
            heatmapTooltip.style.opacity = '0';
            heatmapTooltip.style.visibility = 'hidden'; // Hide tooltip
        }
    });
});