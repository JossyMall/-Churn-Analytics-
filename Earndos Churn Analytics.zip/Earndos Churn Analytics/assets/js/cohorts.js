// Handle modals
document.addEventListener('DOMContentLoaded', function() {
    // New cohort modal
    const newCohortBtn = document.getElementById('new-cohort-btn') || 
                         document.getElementById('new-cohort-btn-main');
    const newCohortModal = document.getElementById('new-cohort-modal');
    
    if (newCohortBtn) {
        newCohortBtn.addEventListener('click', () => {
            newCohortModal.classList.add('active');
        });
    }

    // Edit cohort modal
    const editCohortBtn = document.getElementById('edit-cohort-btn');
    const editCohortModal = document.getElementById('edit-cohort-modal');
    
    if (editCohortBtn) {
        editCohortBtn.addEventListener('click', () => {
            editCohortModal.classList.add('active');
        });
    }

    // Add members modal
    const addMembersBtn = document.getElementById('add-members-btn');
    const addMembersModal = document.getElementById('add-members-modal');
    
    if (addMembersBtn) {
        addMembersBtn.addEventListener('click', () => {
            addMembersModal.classList.add('active');
        });
    }

    // Close modals
    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', function() {
            this.closest('.modal').classList.remove('active');
        });
    });

    // Close modals when clicking outside
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('active');
            }
        });
    });

    // Select all members checkbox
    const selectAll = document.getElementById('select-all-members');
    if (selectAll) {
        selectAll.addEventListener('change', function() {
            document.querySelectorAll('input[name="member_ids[]"]').forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });
    }

    // Bulk actions
    const bulkActions = document.getElementById('bulk-actions');
    if (bulkActions) {
        document.querySelectorAll('input[name="member_ids[]"]').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const checked = document.querySelectorAll('input[name="member_ids[]"]:checked').length;
                bulkActions.style.display = checked > 0 ? 'block' : 'none';
            });
        });
    }
});