document.addEventListener('DOMContentLoaded', function() {
    // Star rating functionality
    document.querySelectorAll('.review-star').forEach(star => {
        star.addEventListener('click', function() {
            const rating = this.getAttribute('data-rating');
            const stars = this.parentElement.querySelectorAll('.review-star');
            
            stars.forEach((s, index) => {
                if (index < rating) {
                    s.classList.add('active');
                } else {
                    s.classList.remove('active');
                }
            });
            
            this.closest('form').querySelector('input[name="rating"]').value = rating;
        });
    });

    // Modal handling
    const modals = {
        'new-ticket-btn': 'new-ticket-modal',
        'open-review-modal': 'reviewModal'
    };

    Object.entries(modals).forEach(([btnClass, modalId]) => {
        document.getElementById(modalId)?.querySelector('.modal-close').addEventListener('click', () => {
            document.getElementById(modalId).style.display = 'none';
        });

        document.querySelectorAll(`.${btnClass}`).forEach(btn => {
            btn.addEventListener('click', function() {
                const modal = document.getElementById(modalId);
                if (modalId === 'reviewModal') {
                    modal.querySelector('input[name="ticket_id"]').value = this.getAttribute('data-ticket-id');
                }
                modal.style.display = 'block';
            });
        });
    });

    // Close modals when clicking outside
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    });

    // Auto-scroll responses
    const ticketContainer = document.querySelector('.ticket-responses');
    if (ticketContainer) {
        ticketContainer.scrollTop = ticketContainer.scrollHeight;
    }
});