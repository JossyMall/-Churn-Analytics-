<?php
/**
 * Churn Analytics PHP SDK
 * 
 * Official PHP client library for the Churn Analytics API
 * Version: 1.0.0
 * 
 * @package ChurnAnalytics
 * @license MIT
 * @author Churn Analytics Team
 * @docs https://docs.churnanalytics.com/api/php-sdk
 */

class ChurnAnalyticsClient {
    private $apiKey;
    private $baseUrl;
    private $timeout = 30;
    private $verifySSL = true;
    private $debug = false;
    private $userAgent = 'ChurnAnalytics-PHP-SDK/1.0';

    /**
     * Initialize the SDK client
     * 
     * @param string $apiKey Your API key from Churn Analytics dashboard
     * @param string $baseUrl (Optional) Custom API base URL
     * @throws InvalidArgumentException If API key is empty
     */
    public function __construct($apiKey, $baseUrl = 'https://api.churnanalytics.com/v1') {
        if (empty($apiKey)) {
            throw new InvalidArgumentException('API key cannot be empty');
        }
        
        $this->apiKey = $apiKey;
        $this->baseUrl = rtrim($baseUrl, '/');
    }

    // ====================
    // CLIENT CONFIGURATION
    // ====================

    /**
     * Set connection timeout
     * @param int $seconds Timeout in seconds (default: 30)
     * @return self
     */
    public function setTimeout($seconds) {
        $this->timeout = (int)$seconds;
        return $this;
    }

    /**
     * Enable/disable SSL verification
     * @param bool $verify Enable SSL verification (default: true)
     * @return self
     */
    public function setVerifySSL($verify) {
        $this->verifySSL = (bool)$verify;
        return $this;
    }

    /**
     * Enable debug mode
     * @param bool $enable Enable debug output (default: false)
     * @return self
     */
    public function setDebug($enable) {
        $this->debug = (bool)$enable;
        return $this;
    }

    // ====================
    // CORE REQUEST HANDLER
    // ====================

    /**
     * Make authenticated API request
     * 
     * @param string $method HTTP method (GET|POST|PUT|DELETE)
     * @param string $endpoint API endpoint
     * @param array $data Request payload
     * @return array Decoded JSON response
     * @throws RuntimeException On API errors
     */
    private function request($method, $endpoint, $data = []) {
        $url = $this->baseUrl . '/' . ltrim($endpoint, '/');
        
        $headers = [
            'Authorization: Bearer ' . $this->apiKey,
            'Content-Type: application/json',
            'Accept: application/json',
            'User-Agent: ' . $this->userAgent
        ];

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_SSL_VERIFYPEER => $this->verifySSL,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_HEADER => $this->debug
        ]);

        $method = strtoupper($method);
        switch ($method) {
            case 'POST':
                curl_setopt($ch, CURLOPT_POST, true);
                break;
            case 'PUT':
            case 'DELETE':
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
                break;
        }

        if ($method !== 'GET' && !empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } elseif ($method === 'GET' && !empty($data)) {
            $url .= '?' . http_build_query($data);
            curl_setopt($ch, CURLOPT_URL, $url);
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if ($this->debug) {
            echo "Request: $method $url\n";
            if ($method !== 'GET') {
                echo "Payload: " . json_encode($data, JSON_PRETTY_PRINT) . "\n";
            }
            echo "Response ($httpCode): $response\n";
        }

        if (curl_errno($ch)) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new RuntimeException("cURL error: $error");
        }
        
        curl_close($ch);
        
        $result = json_decode($response, true) ?? [];
        if ($httpCode >= 400) {
            $error = $result['error'] ?? ['message' => 'Unknown error occurred'];
            throw new RuntimeException(
                "API request failed ($httpCode): " . $error['message'],
                $httpCode
            );
        }

        return $result;
    }

    // ====================
    // STREAMS API METHODS
    // ====================

    /**
     * Create a new tracking stream
     * 
     * @param array $data {
     *     @var string $name        Stream name (required)
     *     @var string $website_url Website URL (optional)
     *     @var bool   $is_app      Whether this is a mobile app (default: false)
     *     @var string $description Stream description (optional)
     *     @var string $color_code  Hex color code (optional)
     *     @var int    $niche_id    Niche ID (optional)
     * }
     * @return array Created stream data
     */
    public function createStream(array $data) {
        return $this->request('POST', 'streams', $data);
    }

    /**
     * Get stream details
     * @param int $streamId
     * @return array Stream data
     */
    public function getStream($streamId) {
        return $this->request('GET', "streams/$streamId");
    }

    /**
     * List all streams
     * @param array $params {
     *     @var int $page     Page number (default: 1)
     *     @var int $per_page Items per page (default: 20)
     * }
     * @return array List of streams
     */
    public function listStreams(array $params = []) {
        return $this->request('GET', 'streams', $params);
    }

    // ====================
    // CONTACTS API METHODS
    // ====================

    /**
     * Add a contact to a stream
     * 
     * @param int $streamId
     * @param array $data {
     *     @var string      $external_id  External system ID (optional)
     *     @var string      $username     Username (optional)
     *     @var string      $email        Email address (required)
     *     @var array       $custom_data  Key-value pairs of custom data
     *     @var string|null $cohort_id    Cohort ID to assign (optional)
     * }
     * @return array Created contact data
     */
    public function addContact($streamId, array $data) {
        return $this->request('POST', "streams/$streamId/contacts", $data);
    }

    /**
     * Bulk import contacts via CSV
     * 
     * @param int $streamId
     * @param string $csvFile Path to CSV file
     * @param array $options {
     *     @var bool $has_headers   Whether CSV has headers (default: true)
     *     @var string $delimiter   CSV delimiter (default: ",")
     * }
     * @return array Import result
     */
    public function importContacts($streamId, $csvFile, array $options = []) {
        $payload = [
            'file' => new CURLFile($csvFile),
            'options' => json_encode($options)
        ];
        return $this->request('POST', "streams/$streamId/contacts/import", $payload);
    }

    // ====================
    // METRICS API METHODS
    // ====================

    /**
     * Record standard metric for a contact
     * 
     * @param int $contactId
     * @param string $metricName One of: login_frequency, last_login_date, 
     *                           feature_usage, session_duration, etc.
     * @param mixed $value Metric value
     * @return array Operation result
     */
    public function recordMetric($contactId, $metricName, $value) {
        return $this->request('POST', "contacts/$contactId/metrics", [
            'metric' => $metricName,
            'value' => $value
        ]);
    }

    /**
     * Record custom metric for a contact
     * 
     * @param int $contactId
     * @param string $metricName Your custom metric name
     * @param mixed $value Metric value
     * @return array Operation result
     */
    public function recordCustomMetric($contactId, $metricName, $value) {
        return $this->request('POST', "contacts/$contactId/metrics/custom", [
            'metric' => $metricName,
            'value' => $value
        ]);
    }

    // ====================
    // CHURN API METHODS
    // ====================

    /**
     * Get churn prediction for a contact
     * 
     * @param int $contactId
     * @return array {
     *     @var float  $score    Churn probability (0-100)
     *     @var string $report   Detailed analysis report
     *     @var array  $suggestions Winback suggestions
     * }
     */
    public function getChurnPrediction($contactId) {
        return $this->request('GET', "contacts/$contactId/churn");
    }

    /**
     * Mark contact as churned
     * 
     * @param int $contactId
     * @param string|null $reason Optional churn reason
     * @return array Operation result
     */
    public function markAsChurned($contactId, $reason = null) {
        return $this->request('POST', "contacts/$contactId/churn", [
            'reason' => $reason
        ]);
    }

    // ====================
    // COHORTS API METHODS
    // ====================

    /**
     * Create a new cohort
     * 
     * @param int $streamId
     * @param array $data {
     *     @var string $name            Cohort name
     *     @var string $description     Cohort description
     *     @var float  $cost_per_user   Customer acquisition cost
     *     @var float  $revenue_per_user Average revenue per user
     * }
     * @return array Created cohort data
     */
    public function createCohort($streamId, array $data) {
        return $this->request('POST', "streams/$streamId/cohorts", $data);
    }

    /**
     * Add contact to cohort
     * 
     * @param int $contactId
     * @param int $cohortId
     * @return array Operation result
     */
    public function addToCohort($contactId, $cohortId) {
        return $this->request('POST', "contacts/$contactId/cohorts", [
            'cohort_id' => $cohortId
        ]);
    }
}

// ====================
// USAGE EXAMPLES
// ====================

/*
// Initialize client
$client = new ChurnAnalyticsClient('your_api_key_here');

// Example 1: Creating a stream and adding contacts
$stream = $client->createStream([
    'name' => 'My SaaS Customers',
    'website_url' => 'https://mysaas.com'
]);

$contact = $client->addContact($stream['id'], [
    'email' => 'user@example.com',
    'username' => 'johndoe',
    'custom_data' => [
        'plan_type' => 'premium',
        'signup_source' => 'organic'
    ]
]);

// Example 2: Recording metrics
$client->recordMetric($contact['id'], 'login_frequency', 5);
$client->recordMetric($contact['id'], 'last_login_date', date('Y-m-d H:i:s'));
$client->recordCustomMetric($contact['id'], 'feature_x_usage', 42);

// Example 3: Getting churn prediction
$prediction = $client->getChurnPrediction($contact['id']);
if ($prediction['score'] > 70) {
    $client->markAsChurned($contact['id'], 'High churn probability');
}
*/