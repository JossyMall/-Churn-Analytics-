<?php
/**
 * Churn Analytics PHP SDK
 * Version: 1.0
 * Author: Churn Analytics Team
 */

class ChurnAnalyticsClient {
    private $apiKey;
    private $baseUrl;
    private $timeout = 30;
    private $verifySSL = true;
    private $debug = false;

    /**
     * Initialize the SDK client
     * @param string $apiKey Your API key
     * @param string $baseUrl Base URL of the API (optional)
     */
    public function __construct($apiKey, $baseUrl = 'https://api.churnanalytics.com/v1') {
        $this->apiKey = $apiKey;
        $this->baseUrl = rtrim($baseUrl, '/');
    }

    /**
     * Set connection timeout
     * @param int $seconds Timeout in seconds
     */
    public function setTimeout($seconds) {
        $this->timeout = (int)$seconds;
    }

    /**
     * Enable/disable SSL verification
     * @param bool $verify
     */
    public function setVerifySSL($verify) {
        $this->verifySSL = (bool)$verify;
    }

    /**
     * Enable debug mode
     * @param bool $enable
     */
    public function setDebug($enable) {
        $this->debug = (bool)$enable;
    }

    // ==================== CORE METHODS ====================

    /**
     * Make API request
     * @param string $method HTTP method
     * @param string $endpoint API endpoint
     * @param array $data Request data
     * @return array API response
     * @throws Exception
     */
    private function request($method, $endpoint, $data = []) {
        $url = $this->baseUrl . '/' . ltrim($endpoint, '/');
        $headers = [
            'Authorization: Bearer ' . $this->apiKey,
            'Content-Type: application/json',
            'Accept: application/json'
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $this->verifySSL);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        if ($this->debug) {
            curl_setopt($ch, CURLOPT_VERBOSE, true);
        }

        switch (strtoupper($method)) {
            case 'POST':
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                break;
            case 'PUT':
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                break;
            case 'DELETE':
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
            default: // GET
                if (!empty($data)) {
                    $url .= '?' . http_build_query($data);
                    curl_setopt($ch, CURLOPT_URL, $url);
                }
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            throw new Exception("cURL error: " . $error);
        }

        $result = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Invalid JSON response: " . $response);
        }

        if ($httpCode >= 400) {
            $errorMsg = $result['message'] ?? 'Unknown error occurred';
            throw new Exception("API error ($httpCode): $errorMsg", $httpCode);
        }

        return $result;
    }

    // ==================== STREAMS ====================

    /**
     * Create a new stream
     * @param array $data Stream data
     * @return array Created stream
     */
    public function createStream($data) {
        return $this->request('POST', 'streams', $data);
    }

    /**
     * Get stream by ID
     * @param int $streamId
     * @return array Stream data
     */
    public function getStream($streamId) {
        return $this->request('GET', "streams/$streamId");
    }

    // ... (more stream methods to be added)

    // ==================== CONTACTS ====================

    /**
     * Add a new contact
     * @param int $streamId
     * @param array $data Contact data
     * @return array Created contact
     */
    public function addContact($streamId, $data) {
        return $this->request('POST', "streams/$streamId/contacts", $data);
    }

    /**
     * Update a contact
     * @param int $contactId
     * @param array $data Contact data
     * @return array Updated contact
     */
    public function updateContact($contactId, $data) {
        return $this->request('PUT', "contacts/$contactId", $data);
    }

    // ... (more contact methods to be added)

    // ==================== METRICS ====================

    /**
     * Record metric for a contact
     * @param int $contactId
     * @param string $metricName
     * @param mixed $value
     * @return array Result
     */
    public function recordMetric($contactId, $metricName, $value) {
        return $this->request('POST', "contacts/$contactId/metrics", [
            'metric' => $metricName,
            'value' => $value
        ]);
    }

    // ... (more metric methods to be added)

    // ==================== CHURN ====================

    /**
     * Get churn score for a contact
     * @param int $contactId
     * @return array Churn data
     */
    public function getChurnScore($contactId) {
        return $this->request('GET', "contacts/$contactId/churn");
    }

    // ... (more churn methods to be added)

    // ==================== COHORTS ====================

    /**
     * Add contact to cohort
     * @param int $contactId
     * @param int $cohortId
     * @return array Result
     */
    public function addToCohort($contactId, $cohortId) {
        return $this->request('POST', "contacts/$contactId/cohorts", [
            'cohort_id' => $cohortId
        ]);
    }

    // ... (more cohort methods to be added)
}