<?php
// Ensure NO WHITESPACE/BOM BEFORE THIS PHP TAG
ini_set('display_errors', 1); // Display errors directly in output (for debugging)
ini_set('display_startup_errors', 1); // Display startup errors
error_reporting(E_ALL); // Report all types of errors

// Configure error logging to a specific file (ensure this file is writable by the web server)
ini_set('log_errors', '1');
// Use __DIR__ to ensure path is relative to the current script's directory
// So, if api2/ is sibling to project root, and log is in project root: __DIR__ . '/../php_api_errors.log'
ini_set('error_log', __DIR__ . '/../php_api_errors.log'); 

session_start(); // Start session

header('Content-Type: application/json'); // Set header first thing

// Authenticate user
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Not authenticated.']);
    exit;
}

// Correct path to db.php based on your confirmed structure: api2/ and includes/ are siblings
require_once __DIR__ . '/../includes/db.php'; 

$user_id = $_SESSION['user_id'];

// Get filter parameters, ensure default to null or appropriate type
$date_range_days = isset($_GET['dateRange']) ? (int)$_GET['dateRange'] : 30; 
$selected_stream_id = isset($_GET['stream']) && $_GET['stream'] !== '' ? (int)$_GET['stream'] : null;
$selected_cohort_id = isset($_GET['cohort']) && $_GET['cohort'] !== '' ? (int)$_GET['cohort'] : null;

// Determine start and end dates based on dateRange
$end_date_obj = new DateTime('now');
$start_date_obj = new DateTime('now');

// Handle date range
if ($date_range_days === 0) { 
    $start_date_obj->modify('-12 months'); // Default for 'custom' date range if not properly implemented
} else {
    $start_date_obj->modify("-{$date_range_days} days");
}

$start_date_str = $start_date_obj->format('Y-m-d 00:00:00');
$end_date_str = $end_date_obj->format('Y-m-d 23:59:59');

$response_data = [
    'summary' => [
        'retentionRate' => 0,
        'churnRate' => 0,
        'resurrectionRate' => 0,
        'retentionChange' => 0, 
        'churnChange' => 0,     
        'resurrectionChange' => 0 
    ],
    'trends' => [ 
        'labels' => [],
        'retention' => [] 
    ],
    'churnDistribution' => [ 
        'labels' => ['Low Risk', 'Medium Risk', 'High Risk'],
        'values' => [0, 0, 0] 
    ],
    'cohortAnalysis' => [ 
        'cohorts' => [], 
        'periods' => [], 
        'data' => [] 
    ],
    'error' => null
];

try {
    // 1. Determine relevant stream IDs for the current user and selected filters
    $relevant_stream_ids = [];
    $stmt_relevant_streams_query = "";
    $stmt_relevant_streams_params = [];

    if ($selected_stream_id !== null) {
        // Only consider the explicitly selected stream, but ensure user has access
        $stmt_relevant_streams_query = "
            SELECT s.id FROM streams s
            LEFT JOIN team_streams ts ON s.id = ts.stream_id
            LEFT JOIN team_members tm ON ts.team_id = tm.team_id
            WHERE s.id = ? AND (s.user_id = ? OR tm.user_id = ?)
        ";
        $stmt_relevant_streams_params = [
            $selected_stream_id,
            $user_id,
            $user_id
        ];
    } else {
        // Fetch all streams the user has access to (owned or shared via teams)
        $stmt_relevant_streams_query = "
            SELECT s.id
            FROM streams s
            WHERE s.user_id = ?
            UNION
            SELECT s.id
            FROM team_streams ts
            JOIN streams s ON ts.stream_id = s.id
            JOIN team_members tm ON ts.team_id = tm.team_id
            WHERE tm.user_id = ?
        ";
        $stmt_relevant_streams_params = [$user_id, $user_id];
    }

    $stmt_all_accessible_streams = $pdo->prepare($stmt_relevant_streams_query);
    $stmt_all_accessible_streams->execute($stmt_relevant_streams_params);
    $relevant_stream_ids = array_column($stmt_all_accessible_streams->fetchAll(PDO::FETCH_ASSOC), 'id');
    
    // If no relevant streams found, exit early with empty data
    if (empty($relevant_stream_ids)) {
        echo json_encode($response_data); 
        exit;
    }

    // Build base contact filter SQL and parameters for all subsequent queries
    // Initialize contact_filter_sql_conditions as an empty array here.
    $contact_filter_sql_conditions = []; // CRITICAL FIX: Initialize as empty array
    $stream_ids_placeholders = implode(',', array_fill(0, count($relevant_stream_ids), '?'));
    $contact_filter_params_base = $relevant_stream_ids; 
    
    // Add the stream filter condition
    $contact_filter_sql_conditions[] = "c.stream_id IN ({$stream_ids_placeholders})"; 

    if ($selected_cohort_id !== null) {
        $contact_filter_conditions[] = "c.id IN (SELECT contact_id FROM contact_cohorts WHERE cohort_id = ?)";
        $contact_filter_params_base[] = $selected_cohort_id;
    }

    $contact_filter_sql_where_clause = implode(' AND ', $contact_filter_sql_conditions); // Line 127 in your error report, if not, adjust


    // --- CALCULATE SUMMARY METRICS (for `summary` object in JS) --- 
    // Total contacts that fall under the current filters (created up to end date)
    $query_total_contacts = "
        SELECT COUNT(id) FROM contacts c
        WHERE {$contact_filter_sql_where_clause}
        AND c.created_at <= ? 
    ";
    $stmt_total_contacts_at_end = $pdo->prepare($query_total_contacts);
    $stmt_total_contacts_at_end->execute(array_merge($contact_filter_params_base, [$end_date_str]));
    $total_contacts_at_end_of_period = $stmt_total_contacts_at_end->fetchColumn();

    $query_churned_in_period = "
        SELECT COUNT(DISTINCT cu.contact_id) FROM churned_users cu
        JOIN contacts c ON cu.contact_id = c.id
        WHERE {$contact_filter_sql_where_clause} AND cu.churned_at BETWEEN ? AND ?
    ";
    $stmt_churned_in_period = $pdo->prepare($query_churned_in_period);
    $stmt_churned_in_period->execute(array_merge($contact_filter_params_base, [$start_date_str, $end_date_str]));
    $churned_in_period = $stmt_churned_in_period->fetchColumn();

    $query_resurrected_in_period = "
        SELECT COUNT(DISTINCT ru.contact_id) FROM resurrected_users ru
        JOIN contacts c ON ru.contact_id = c.id
        WHERE {$contact_filter_sql_where_clause} AND ru.resurrected_at BETWEEN ? AND ?
    ";
    $stmt_resurrected_in_period = $pdo->prepare($query_resurrected_in_period);
    $stmt_resurrected_in_period->execute(array_merge($contact_filter_params_base, [$start_date_str, $end_date_str]));
    $resurrected_in_period = $stmt_resurrected_in_period->fetchColumn();
    
    $active_base_for_churn = $total_contacts_at_end_of_period; 
    if ($active_base_for_churn === 0) { 
        $response_data['summary']['churnRate'] = 0;
    } else {
        $response_data['summary']['churnRate'] = round(($churned_in_period / $active_base_for_churn) * 100, 2);
    }
    
    $response_data['summary']['retentionRate'] = round(100 - $response_data['summary']['churnRate'], 2);
    $response_data['summary']['resurrectionRate'] = ($churned_in_period > 0) ? round(($resurrected_in_period / $churned_in_period) * 100, 2) : 0;


    // --- CHURN DISTRIBUTION (for `churnDistribution` chart in JS) --- 
    $query_latest_scores_dist = "
        SELECT cs.score
        FROM churn_scores cs
        JOIN contacts c ON cs.contact_id = c.id
        WHERE {$contact_filter_sql_where_clause}
        AND cs.scored_at BETWEEN ? AND ?
        AND (cs.contact_id, cs.scored_at) IN (
            SELECT contact_id, MAX(scored_at) FROM churn_scores GROUP BY contact_id
        )
    ";
    $stmt_latest_scores_dist = $pdo->prepare($query_latest_scores_dist);
    $stmt_latest_scores_dist->execute(array_merge($contact_filter_params_base, [$start_date_str, $end_date_str]));
    $latest_scores_dist = $stmt_latest_scores_dist->fetchAll(PDO::FETCH_ASSOC);

    $high_risk = 0;
    $medium_risk = 0;
    $low_risk = 0;
    foreach ($latest_scores_dist as $score_data) {
        $score = $score_data['score'];
        if ($score > 70) { 
            $high_risk++;
        } elseif ($score > 40) { 
            $medium_risk++;
        } else { 
            $low_risk++;
        }
    }
    $total_scored_contacts_dist = $high_risk + $medium_risk + $low_risk;
    if ($total_scored_contacts_dist > 0) {
        $response_data['churnDistribution']['values'][0] = round(($low_risk / $total_scored_contacts_dist) * 100, 1);
        $response_data['churnDistribution']['values'][1] = round(($medium_risk / $total_scored_contacts_dist) * 100, 1);
        $response_data['churnDistribution']['values'][2] = 100 - ($response_data['churnDistribution']['values'][0] + $response_data['churnDistribution']['values'][1]); 
    }


    // --- MONTHLY CHURN SCORE TREND (for `trends.retention` chart in JS) --- 
    $num_months_trend = 12; 
    $monthly_trend_labels = [];
    $monthly_churn_scores_data = [];
    
    $date_cursor = (new DateTime('now'))->modify("-{$num_months_trend} months")->modify('first day of this month');
    $current_month_start = (new DateTime('now'))->modify('first day of this month');

    while ($date_cursor <= $current_month_start) {
        $month_key = $date_cursor->format('Y-m');
        $monthly_trend_labels[] = $date_cursor->format('M Y');
        
        $month_start_date_sql = $date_cursor->format('Y-m-01 00:00:00');
        $month_end_date_sql = $date_cursor->format('Y-m-t 23:59:59');

        $query_avg_score_trend = "
            SELECT AVG(cs.score)
            FROM churn_scores cs
            JOIN contacts c ON cs.contact_id = c.id
            WHERE {$contact_filter_sql_where_clause}
            AND cs.scored_at BETWEEN ? AND ?
            AND (cs.contact_id, cs.scored_at) IN (SELECT contact_id, MAX(scored_at) FROM churn_scores GROUP BY contact_id)
        ";
        $stmt_avg_score_trend = $pdo->prepare($query_avg_score_trend);
        $stmt_avg_score_trend->execute(array_merge($contact_filter_params_base, [$month_start_date_sql, $month_end_date_sql]));
        $avg_score = $stmt_avg_score_trend->fetchColumn();
        $monthly_churn_scores_data[] = round($avg_score ?? 0, 1); 

        $date_cursor->modify('+1 month');
    }

    $response_data['trends']['labels'] = $monthly_trend_labels;
    $response_data['trends']['retention'] = $monthly_churn_scores_data;


    // --- COHORT RETENTION HEATMAP (for `cohortAnalysis` chart in JS) --- 
    $cohorts_for_heatmap = [];
    $query_cohorts_heatmap = "
        SELECT DISTINCT c.id, c.name FROM cohorts c
        WHERE c.created_by = ? OR c.id IN (
            SELECT cc.cohort_id FROM contact_cohorts cc
            JOIN contacts co ON cc.contact_id = co.id
            WHERE co.stream_id IN (" . implode(',', array_fill(0, count($relevant_stream_ids), '?')) . ")
        )
        ORDER BY c.name
    ";
    $stmt_cohorts_heatmap = $pdo->prepare($query_cohorts_heatmap);
    $stmt_cohorts_heatmap->execute(array_merge([$user_id], $relevant_stream_ids));
    $all_relevant_cohorts_heatmap = $stmt_cohorts_heatmap->fetchAll(PDO::FETCH_ASSOC);

    foreach ($all_relevant_cohorts_heatmap as $cohort_row) {
        $response_data['cohortAnalysis']['cohorts'][] = ['id' => $cohort_row['id'], 'name' => $cohort_row['name']];
    }

    if (!empty($all_relevant_cohorts_heatmap)) {
        $max_retention_periods = 6; 
        for ($i = 0; $i <= $max_retention_periods; $i++) {
            $response_data['cohortAnalysis']['periods'][] = "Month " . $i;
        }

        foreach ($all_relevant_cohorts_heatmap as $cohort_row) {
            $cohort_id = $cohort_row['id'];
            $retention_row_data = array_fill(0, $max_retention_periods + 1, null); 

            // Get acquisition months for contacts within this cohort and relevant streams
            // Create a unique placeholder string for this specific query's stream IDs.
            $stream_ids_placeholders_acq = implode(',', array_fill(0, count($relevant_stream_ids), '?'));
            $query_acq_months_heatmap = "
                SELECT DISTINCT DATE_FORMAT(c.created_at, '%Y-%m') AS acquisition_month
                FROM contacts c
                JOIN contact_cohorts cc ON c.id = cc.contact_id
                WHERE cc.cohort_id = ? AND c.stream_id IN ({$stream_ids_placeholders_acq})
                AND c.created_at BETWEEN ? AND ?
                ORDER BY acquisition_month ASC
            ";
            $stmt_acq_months_heatmap = $pdo->prepare($query_acq_months_heatmap);
            $acq_months_params = array_merge([$cohort_id], $relevant_stream_ids, [
                $start_date_obj->format('Y-m-01 00:00:00'),
                $end_date_obj->format('Y-m-t 23:59:59')
            ]);
            $stmt_acq_months_heatmap->execute($acq_months_params);
            $acquisition_months_for_cohort_heatmap = $stmt_acq_months_heatmap->fetchAll(PDO::FETCH_COLUMN);

            if (empty($acquisition_months_for_cohort_heatmap)) {
                 $response_data['cohortAnalysis']['data'][] = $retention_row_data; 
                 continue;
            }

            foreach ($acquisition_months_for_cohort_heatmap as $acq_month_str) {
                $acq_date = new DateTime($acq_month_str . '-01');

                $stream_ids_placeholders_init = implode(',', array_fill(0, count($relevant_stream_ids), '?'));
                $query_initial_size_heatmap = "
                    SELECT COUNT(c.id) FROM contacts c
                    JOIN contact_cohorts cc ON c.id = cc.contact_id
                    WHERE cc.cohort_id = ? AND c.stream_id IN ({$stream_ids_placeholders_init})
                    AND DATE_FORMAT(c.created_at, '%Y-%m') = ?
                ";
                $stmt_initial_size_heatmap = $pdo->prepare($query_initial_size_heatmap);
                $initial_size_params = array_merge([$cohort_id], $relevant_stream_ids, [$acq_month_str]);
                $stmt_initial_size_heatmap->execute($initial_size_params);
                $initial_size = $stmt_initial_size_heatmap->fetchColumn();

                if ($initial_size === 0) continue;

                for ($offset = 0; $offset <= $max_retention_periods; $offset++) {
                    $period_date = (clone $acq_date)->modify("+$offset months");
                    $period_month_str = $period_date->format('Y-m');

                    // Make sure we don't go beyond current date for retention
                    if ($period_date > new DateTime('now')) {
                        $retention_percentage = null; 
                    } else {
                        $stream_ids_placeholders_retained = implode(',', array_fill(0, count($relevant_stream_ids), '?'));
                        $query_retained_heatmap = "
                            SELECT COUNT(DISTINCT c.id) FROM contacts c
                            JOIN contact_cohorts cc ON c.id = cc.contact_id
                            WHERE cc.cohort_id = ? AND c.stream_id IN ({$stream_ids_placeholders_retained})
                            AND DATE_FORMAT(c.created_at, '%Y-%m') = ? 
                            AND NOT EXISTS (
                                SELECT 1 FROM churned_users cu
                                WHERE cu.contact_id = c.id
                                AND DATE_FORMAT(cu.churned_at, '%Y-%m') <= ? 
                            )
                            AND c.created_at <= ? 
                        ";
                        $stmt_retained_heatmap = $pdo->prepare($query_retained_heatmap);
                        $retained_params = array_merge([$cohort_id], $relevant_stream_ids, [
                            $acq_month_str,
                            $period_month_str,
                            $period_date->format('Y-m-t 23:59:59')
                        ]);
                        $stmt_retained_heatmap->execute($retained_params);
                        $retained_count = $stmt_retained_heatmap->fetchColumn();

                        $retention_percentage = round(($retained_count / $initial_size) * 100, 1);
                        $retention_percentage = max(0, min(100, $retention_percentage)); 
                    }
                    $retention_row_data[$offset] = $retention_percentage;
                }
            }
            // Add this row's data to the main response for the heatmap
            // The $cohort_id_to_index map helps with this.
            if (isset($cohort_id_to_index[$cohort_id])) {
                $response_data['cohortAnalysis']['data'][$cohort_id_to_index[$cohort_id]] = $retention_row_data;
            } else {
                error_log("API Error: Cohort ID {$cohort_id} processed for heatmap data but not found in cohort_id_to_index map.");
            }
        }
    }


} catch (PDOException $e) {
    $response_data['error'] = 'Database error: ' . $e->getMessage() . " - SQLSTATE: " . $e->getCode();
    error_log("API Error (api/retention.php) PDOException: " . $e->getMessage() . " - SQL: " . ($e->getPrevious() ? $e->getPrevious()->getMessage() : 'N/A') . " -- File: " . $e->getFile() . " -- Line: " . $e->getLine());
} catch (Exception $e) {
    $response_data['error'] = 'General error: ' . $e->getMessage();
    error_log("API Error (api/retention.php) General Exception: " . $e->getMessage() . " -- File: " . $e->getFile() . " -- Line: " . $e->getLine());
}

echo json_encode($response_data);