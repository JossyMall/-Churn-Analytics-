<?php
require_once __DIR__ . '/../includes/db.php';

error_log("[CleanupLogs] Cron job started at " . date('Y-m-d H:i:s'));

try {
    $pdo->beginTransaction();

    $tables = [
        'automation_queue' => 'created_at',
        'action_queue' => 'created_at', 
        'automation_logs' => 'executed_at'
    ];

    foreach ($tables as $table => $dateField) {
        $deleted = $pdo->exec("
            DELETE FROM {$table} 
            WHERE {$dateField} < DATE_SUB(NOW(), INTERVAL 30 DAY)
        ");
        error_log("[CleanupLogs] Deleted {$deleted} old records from {$table}");
    }

    $pdo->commit();
    error_log("[CleanupLogs] Cleanup completed successfully");
} catch (Exception $e) {
    $pdo->rollBack();
    error_log("[CleanupLogs] ERROR: " . $e->getMessage());
    exit(1);
}

exit(0);