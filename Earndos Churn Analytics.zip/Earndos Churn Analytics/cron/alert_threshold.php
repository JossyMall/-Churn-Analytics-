<?php
// cron/alert_threshold.php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/email_functions.php';

// 1. System Enable Check
$system_enabled = $pdo->query("SELECT value FROM config WHERE setting = 'enable_threshold_alerts'")
                     ->fetchColumn();
if (!$system_enabled) {
    file_put_contents(__DIR__ . '/../logs/threshold_cron.log', 
        date('Y-m-d H:i:s') . " - System alerts disabled\n", FILE_APPEND);
    exit(0);
}

// 2. Get all active thresholds with user preferences
$thresholds = $pdo->query("
    SELECT 
        t.id as threshold_id,
        t.user_id,
        t.stream_id,
        t.threshold,
        t.alert_methods,
        u.username as user_name,
        u.email,
        up.phone_number,
        up.webhook_url,
        up.webhook_type,
        s.name as stream_name,
        up.alert_is_email,
        up.alert_is_sms,
        up.alert_is_push
    FROM user_alert_thresholds t
    JOIN users u ON t.user_id = u.id AND u.is_active = 1
    LEFT JOIN user_profiles up ON u.id = up.user_id
    LEFT JOIN streams s ON t.stream_id = s.id
")->fetchAll();

foreach ($thresholds as $threshold) {
    try {
        // 3. Find high-risk contacts (last 24 hours)
        $stmt = $pdo->prepare("
            SELECT c.id, c.username, c.email, cs.score, cs.scored_at
            FROM contacts c
            JOIN churn_scores cs ON c.id = cs.contact_id
            WHERE (c.stream_id = :stream_id OR :stream_id IS NULL)
            AND cs.score >= :threshold
            AND cs.scored_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ORDER BY cs.score DESC
            LIMIT 25
        ");
        $stmt->execute([
            'stream_id' => $threshold['stream_id'],
            'threshold' => $threshold['threshold']
        ]);
        $risky_contacts = $stmt->fetchAll();

        if (empty($risky_contacts)) continue;

        // 4. Prepare notification data
        $top_contact = $risky_contacts[0];
        $alert_methods = explode(',', $threshold['alert_methods']);
        $stream_ref = $threshold['stream_name'] ?: 'All Streams';
        
        $notification_data = [
            'user_id' => $threshold['user_id'],
            'title' => "Churn Alert: {$top_contact['username']}",
            'message' => "Exceeded {$threshold['threshold']}% risk ({$top_contact['score']}%) in {$stream_ref}",
            'type' => 'threshold_alert',
            'related_id' => $top_contact['id'],
            'related_url' => "/contacts/view.php?id={$top_contact['id']}",
            'details' => json_encode([
                'threshold' => $threshold['threshold'],
                'actual_score' => $top_contact['score'],
                'stream' => $stream_ref,
                'contact_count' => count($risky_contacts),
                'top_contacts' => array_slice(array_map(function($c) {
                    return ['id' => $c['id'], 'username' => $c['username'], 'score' => $c['score']];
                }, $risky_contacts), 0, 5)
            ])
        ];

        // 5. Create notification record
        $pdo->prepare("
            INSERT INTO notifications 
            (user_id, title, message, type, related_id, related_url, details, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ")->execute(array_values($notification_data));

        $notification_id = $pdo->lastInsertId();
        
        // 6. Send through all enabled channels
        foreach ($alert_methods as $method) {
            $method = trim(strtolower($method));
            
            // Email
            if ($method === 'email' && $threshold['alert_is_email']) {
                $email_content = render_email_template('threshold_alert', [
                    'user' => $threshold,
                    'contacts' => $risky_contacts,
                    'threshold' => $threshold['threshold'],
                    'notification_id' => $notification_id
                ]);
                send_email($threshold['email'], $notification_data['title'], $email_content);
            }
            
            // SMS
            if ($method === 'sms' && $threshold['alert_is_sms']) {
                send_sms($threshold['phone_number'], 
                    "{$notification_data['title']}: {$notification_data['message']}");
            }
            
            // Webhook
            if ($method === 'webhook' && $threshold['webhook_url']) {
                send_webhook($threshold['webhook_url'], [
                    'event' => 'churn_threshold_alert',
                    'notification_id' => $notification_id,
                    'data' => $notification_data
                ], $threshold['webhook_type']);
            }
        }

        // 7. Log successful processing
        file_put_contents(__DIR__ . '/../logs/threshold_cron.log', 
            date('Y-m-d H:i:s') . " - Sent alert for threshold {$threshold['threshold_id']}\n", 
            FILE_APPEND);

    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/../logs/threshold_errors.log', 
            date('Y-m-d H:i:s') . " - Threshold {$threshold['threshold_id']} error: " . 
            $e->getMessage() . "\n", FILE_APPEND);
        continue;
    }
}