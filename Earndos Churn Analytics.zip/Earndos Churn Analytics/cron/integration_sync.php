<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/external_apis/IntegrationManager.php';

error_log("[IntegrationSync] Cron job started at " . date('Y-m-d H:i:s'));

try {
    $pdo->beginTransaction();
    $integrationManager = new IntegrationManager($pdo);

    $integrations = $pdo->query("
        SELECT id, service_name, auth_config 
        FROM external_integrations 
        WHERE is_active = 1
    ")->fetchAll(PDO::FETCH_ASSOC);

    foreach ($integrations as $integration) {
        try {
            switch ($integration['service_name']) {
                case 'zendesk':
                    $integrationManager->syncZendeskTickets($integration['id']);
                    break;
                case 'freshdesk':
                    $integrationManager->syncFreshdeskTickets($integration['id']);
                    break;
                case 'stripe':
                    $integrationManager->syncStripeSubscriptions($integration['id']);
                    break;
            }
            $pdo->prepare("UPDATE external_integrations SET last_sync_at = NOW() WHERE id = ?")
                ->execute([$integration['id']]);
        } catch (Exception $e) {
            error_log("[IntegrationSync] Failed sync for integration {$integration['id']}: " . $e->getMessage());
        }
    }

    $pdo->commit();
    error_log("[IntegrationSync] Completed sync for " . count($integrations) . " integrations");
} catch (Exception $e) {
    $pdo->rollBack();
    error_log("[IntegrationSync] ERROR: " . $e->getMessage());
    exit(1);
}

exit(0);