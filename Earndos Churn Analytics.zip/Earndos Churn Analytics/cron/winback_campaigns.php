<?php
// cron/winback_campaigns.php
// This script is designed to be executed as a server-side cron job.
// It processes active automations, evaluates their conditions, and performs actions.

// Set up error reporting for cron execution
ini_set('display_errors', 0); // Do not display errors to output in cron context
ini_set('log_errors', 1);     // Log errors to PHP error log
error_reporting(E_ALL);

// Define a log file path for cron-specific logging (optional, but good practice)
define('CRON_LOG_FILE', __DIR__ . '/../logs/cron_winback.log');

// Include database connection
require_once __DIR__ . '/../includes/db.php';

// Include necessary helper functions (e.g., for email, SMS, webhooks)
// These functions are assumed to exist in your includes/ directory.
// For this script, we'll include placeholders/stubs for them.
require_once __DIR__ . '/../includes/functions.php'; // For logging, general helpers
require_once __DIR__ . '/../includes/email_functions.php'; // For send_email_notification
require_once __DIR__ . '/../includes/sms_functions.php';   // For send_sms_notification
require_once __DIR__ . '/../includes/webhook_functions.php'; // For send_webhook_notification

// Function to write messages to the cron log file
function cron_log($message) {
    file_put_contents(CRON_LOG_FILE, date('[Y-m-d H:i:s]') . " " . $message . PHP_EOL, FILE_APPEND);
}

cron_log("Cron job 'winback_campaigns.php' started.");

try {
    // 1. Fetch all active automations
    $stmt = $pdo->prepare("SELECT
                               id, user_id, name, description,
                               source_type, source_config_json,
                               condition_type, condition_config_json,
                               action_type, action_config_json
                           FROM automation_workflows
                           WHERE is_active = 1");
    $stmt->execute();
    $automations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    cron_log("Found " . count($automations) . " active automations to process.");

    foreach ($automations as $automation) {
        cron_log("Processing automation: ID " . $automation['id'] . " - " . $automation['name']);

        $automation_id = $automation['id'];
        $automation_user_id = $automation['user_id'];
        $source_type = $automation['source_type'];
        $source_config = json_decode($automation['source_config_json'], true);
        $condition_type = $automation['condition_type'];
        $condition_config = json_decode($automation['condition_config_json'], true);
        $action_type = $automation['action_type'];
        $action_config = json_decode($automation['action_config_json'], true);

        // Fetch user profile for SMS/Webhook details
        $user_profile_stmt = $pdo->prepare("SELECT * FROM user_profiles WHERE user_id = ?");
        $user_profile_stmt->execute([$automation_user_id]);
        $user_profile = $user_profile_stmt->fetch(PDO::FETCH_ASSOC);

        // --- Step 1: Identify Target Contacts (Source Stage) ---
        $contacts_to_evaluate = [];
        $source_sql = '';
        $source_params = [];

        if ($source_type === 'stream') {
            $stream_id = $source_config['stream_id'];
            $source_sql = "SELECT c.*, s.name as stream_name FROM contacts c JOIN streams s ON c.stream_id = s.id WHERE c.stream_id = ? AND s.user_id = ?";
            $source_params = [$stream_id, $automation_user_id];
        } elseif ($source_type === 'cohort') {
            $cohort_id = $source_config['cohort_id'];
            $source_sql = "SELECT c.*, s.name as stream_name FROM contacts c JOIN contact_cohorts cc ON c.id = cc.contact_id JOIN streams s ON c.stream_id = s.id WHERE cc.cohort_id = ? AND s.user_id = ?";
            $source_params = [$cohort_id, $automation_user_id];
        } elseif ($source_type === 'contact') {
            $contact_ids = $source_config['contact_id']; // This is an array
            if (!empty($contact_ids)) {
                $placeholders = implode(',', array_fill(0, count($contact_ids), '?'));
                $source_sql = "SELECT c.*, s.name as stream_name FROM contacts c JOIN streams s ON c.stream_id = s.id WHERE c.id IN ($placeholders) AND s.user_id = ?";
                $source_params = array_merge($contact_ids, [$automation_user_id]);
            }
        }

        if (!empty($source_sql)) {
            $contacts_stmt = $pdo->prepare($source_sql);
            $contacts_stmt->execute($source_params);
            $contacts_to_evaluate = $contacts_stmt->fetchAll(PDO::FETCH_ASSOC);
            cron_log("Found " . count($contacts_to_evaluate) . " contacts for source type: {$source_type} (Automation ID: {$automation_id})");
        } else {
            cron_log("No source contacts identified for automation ID: {$automation_id}. Skipping.");
            continue; // Skip to next automation
        }

        // --- Step 2: Evaluate Condition for Each Contact ---
        foreach ($contacts_to_evaluate as $contact) {
            $contact_id = $contact['id'];
            $condition_met = false;
            $condition_details = "N/A"; // To store details about why condition was met/not met

            // Prevent re-processing if already succeeded for this automation within a recent period
            // This is a simple debouncing mechanism. Adjust as needed.
            $last_log_stmt = $pdo->prepare("SELECT executed_at, status FROM automation_logs WHERE workflow_id = ? AND contact_id = ? ORDER BY executed_at DESC LIMIT 1");
            $last_log_stmt->execute([$automation_id, $contact_id]);
            $last_log = $last_log_stmt->fetch(PDO::FETCH_ASSOC);

            // If an automation already successfully ran for this contact very recently (e.g., last 24 hours), skip.
            // Or if it failed repeatedly, you might implement a back-off.
            if ($last_log && $last_log['status'] === 'success' && (time() - strtotime($last_log['executed_at'])) < (24 * 3600)) { // 24 hours
                cron_log("Skipping contact {$contact_id} for automation {$automation_id}: already successfully processed recently.");
                continue;
            }

            switch ($condition_type) {
                case 'churn_probability':
                    $operator = $condition_config['operator'];
                    $value = $condition_config['value'];
                    $score_stmt = $pdo->prepare("SELECT score FROM churn_scores WHERE contact_id = ? ORDER BY scored_at DESC LIMIT 1");
                    $score_stmt->execute([$contact_id]);
                    $latest_score = $score_stmt->fetchColumn();

                    if ($latest_score !== false) {
                        $eval = false;
                        switch ($operator) {
                            case '>': $eval = ($latest_score > $value); break;
                            case '<': $eval = ($latest_score < $value); break;
                            case '=': $eval = ($latest_score == $value); break;
                            case '>=': $eval = ($latest_score >= $value); break;
                            case '<=': $eval = ($latest_score <= $value); break;
                        }
                        if ($eval) {
                            $condition_met = true;
                            $condition_details = "Churn probability {$latest_score}% {$operator} {$value}%";
                        } else {
                            $condition_details = "Churn probability {$latest_score}% not {$operator} {$value}%";
                        }
                    } else {
                        $condition_details = "No churn score found.";
                    }
                    break;

                case 'competitor_visit':
                    $competitor_id = $condition_config['competitor_id'];
                    $timeframe_days = $condition_config['timeframe_days'];
                    $threshold_date = date('Y-m-d H:i:s', strtotime("-{$timeframe_days} days"));

                    $visit_stmt = $pdo->prepare("SELECT COUNT(*) FROM metric_data md
                                                 JOIN churn_metrics cm ON md.metric_id = cm.id
                                                 WHERE md.contact_id = ?
                                                 AND cm.name = 'competitor_visit'
                                                 AND JSON_EXTRACT(md.value, '$.competitor_id') = ?
                                                 AND md.recorded_at >= ?"); // Assuming value stores competitor_id in JSON
                    $visit_stmt->execute([$contact_id, $competitor_id, $threshold_date]);
                    $visit_count = $visit_stmt->fetchColumn();

                    if ($visit_count > 0) {
                        $condition_met = true;
                        $competitor_name = ""; // Try to get competitor name for log
                        $comp_name_stmt = $pdo->prepare("SELECT name FROM competitors WHERE id = ?");
                        $comp_name_stmt->execute([$competitor_id]);
                        $comp_name = $comp_name_stmt->fetchColumn();
                        $competitor_name = $comp_name ?: "ID:".$competitor_id;
                        $condition_details = "Visited competitor '{$competitor_name}' {$visit_count} time(s) in last {$timeframe_days} days.";
                    } else {
                         $condition_details = "Did not visit competitor in last {$timeframe_days} days.";
                    }
                    break;

                case 'feature_usage':
                    $feature_name = $condition_config['feature_name'];
                    $min_usage_count = $condition_config['min_usage_count'];
                    $usage_stmt = $pdo->prepare("SELECT COUNT(*) FROM metric_data md
                                                 JOIN churn_metrics cm ON md.metric_id = cm.id
                                                 WHERE md.contact_id = ?
                                                 AND cm.name = 'feature_usage'
                                                 AND JSON_EXTRACT(md.value, '$.feature_name') = ?"); // Assuming value stores feature_name in JSON
                    $usage_stmt->execute([$contact_id, $feature_name]);
                    $current_usage = $usage_stmt->fetchColumn();

                    if ($current_usage >= $min_usage_count) {
                        $condition_met = true;
                        $condition_details = "Feature '{$feature_name}' used {$current_usage} time(s) (>= {$min_usage_count}).";
                    } else {
                         $condition_details = "Feature '{$feature_name}' used {$current_usage} time(s) (< {$min_usage_count}).";
                    }
                    break;

                case 'last_login':
                    $days_since_login = $condition_config['days_since_login'];
                    $login_metric_id_stmt = $pdo->prepare("SELECT id FROM churn_metrics WHERE name = 'last_login_date'");
                    $login_metric_id_stmt->execute();
                    $login_metric_id = $login_metric_id_stmt->fetchColumn();

                    if ($login_metric_id) {
                        $last_login_stmt = $pdo->prepare("SELECT value FROM metric_data WHERE contact_id = ? AND metric_id = ? ORDER BY recorded_at DESC LIMIT 1");
                        $last_login_stmt->execute([$contact_id, $login_metric_id]);
                        $last_login_date = $last_login_stmt->fetchColumn();

                        if ($last_login_date) {
                            $diff_in_days = (new DateTime())->diff(new DateTime($last_login_date))->days;
                            if ($diff_in_days >= $days_since_login) {
                                $condition_met = true;
                                $condition_details = "Last login {$diff_in_days} days ago (>= {$days_since_login} days).";
                            } else {
                                $condition_details = "Last login {$diff_in_days} days ago (< {$days_since_login} days).";
                            }
                        } else {
                            // If no last login date recorded, and condition is for days_since_login, it's considered met
                            $condition_met = true; // No login ever, means it's been more than X days
                            $condition_details = "No last login date recorded. Considered met (no login in history).";
                        }
                    } else {
                        $condition_details = "Last login date metric not found in churn_metrics.";
                    }
                    break;
            }

            // --- Step 3: Execute Action if Condition Met ---
            if ($condition_met) {
                $action_status = 'failed'; // Default to failed
                $action_details = "Action '{$action_type}' for contact {$contact['email']}. Condition met: {$condition_details}. ";

                try {
                    switch ($action_type) {
                        case 'email':
                            $template_id = $action_config['template_id'];
                            $email_template_stmt = $pdo->prepare("SELECT subject, content, sender_name FROM email_templates WHERE id = ? AND user_id = ?");
                            $email_template_stmt->execute([$template_id, $automation_user_id]);
                            $email_template = $email_template_stmt->fetch(PDO::FETCH_ASSOC);

                            if ($email_template) {
                                // Replace placeholders in email subject and content
                                $subject = replace_placeholders($email_template['subject'], $contact);
                                $body = replace_placeholders($email_template['content'], $contact);
                                $sender_name = $email_template['sender_name'];

                                // Check user's notification preferences from user_profiles
                                if ($user_profile && $user_profile['alert_is_email']) {
                                    send_email_notification($contact['email'], $subject, $body, $sender_name);
                                    $action_status = 'success';
                                    $action_details .= "Email sent to {$contact['email']} using template ID {$template_id}.";
                                } else {
                                    $action_details .= "Email not sent: User disabled email alerts.";
                                }
                            } else {
                                $action_details .= "Email template ID {$template_id} not found or unauthorized.";
                            }
                            break;

                        case 'sms':
                            $phone_field = $action_config['phone_field'];
                            $sms_message_template = $action_config['sms_message'];

                            // Attempt to get phone number from contact's custom data
                            $contact_custom_data = json_decode($contact['custom_data'] ?? '{}', true);
                            $phone_number = $contact_custom_data[$phone_field] ?? null;

                            if ($phone_number) {
                                $sms_message = replace_placeholders($sms_message_template, $contact);
                                // Check user's notification preferences
                                if ($user_profile && $user_profile['alert_is_sms'] && !empty($user_profile['phone_number'])) {
                                    send_sms_notification($phone_number, $sms_message); // Placeholder call
                                    $action_status = 'success';
                                    $action_details .= "SMS sent to {$phone_number}.";
                                } else {
                                    $action_details .= "SMS not sent: User disabled SMS alerts or no primary phone number.";
                                }
                            } else {
                                $action_details .= "SMS not sent: Phone number field '{$phone_field}' not found for contact.";
                            }
                            break;

                        case 'change_cohort':
                            $new_cohort_id = $action_config['cohort_id'];
                            // Remove from existing cohorts first (if multi-cohort is desired, modify this logic)
                            $pdo->prepare("DELETE FROM contact_cohorts WHERE contact_id = ?")->execute([$contact_id]);
                            // Add to new cohort
                            $cohort_add_stmt = $pdo->prepare("INSERT INTO contact_cohorts (contact_id, cohort_id) VALUES (?, ?) ON DUPLICATE KEY UPDATE cohort_id = VALUES(cohort_id)");
                            $cohort_add_stmt->execute([$contact_id, $new_cohort_id]);
                            $action_status = 'success';
                            $action_details .= "Contact moved to cohort ID {$new_cohort_id}.";
                            break;

                        case 'notification':
                            $notification_message_template = $action_config['notification_message'];
                            $notification_message = replace_placeholders($notification_message_template, $contact);

                            $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type, related_id) VALUES (?, ?, ?, ?, ?)");
                            $notif_stmt->execute([$automation_user_id, "Automation Alert: " . $automation['name'], $notification_message, 'churn', $contact_id]);
                            $action_status = 'success';
                            $action_details .= "Notification sent to automation owner.";
                            break;

                        case 'external': // Zapier webhook
                            $service_name = $action_config['service_name'];
                            if ($service_name === 'zapier') {
                                $zapier_event_name = $action_config['zapier_event_name'];
                                $zapier_payload_template = $action_config['zapier_payload_template'];

                                $webhook_url = $user_profile['zapier_webhook'] ?? null;

                                if ($webhook_url) {
                                    $processed_payload = replace_placeholders($zapier_payload_template, $contact);
                                    // Add specific automation and event name to payload
                                    $payload_data = json_decode($processed_payload, true) ?: [];
                                    $payload_data['automation_id'] = $automation_id;
                                    $payload_data['automation_name'] = $automation['name'];
                                    $payload_data['event_name'] = $zapier_event_name;
                                    $final_payload = json_encode($payload_data);

                                    // Placeholder for sending webhook
                                    send_webhook_notification($webhook_url, $final_payload);
                                    $action_status = 'success';
                                    $action_details .= "Zapier webhook triggered for event '{$zapier_event_name}'.";
                                } else {
                                    $action_details .= "Zapier webhook not sent: Webhook URL not configured for user.";
                                }
                            } else {
                                $action_details .= "External service '{$service_name}' not supported or configured.";
                            }
                            break;
                    }
                } catch (Exception $e) {
                    $action_status = 'failed';
                    $action_details .= "Action execution failed: " . $e->getMessage();
                    cron_log("ERROR: Automation ID {$automation_id}, Contact ID {$contact_id} - Action failed: " . $e->getMessage());
                }

                // Log the action result regardless of success or failure
                $log_stmt = $pdo->prepare("INSERT INTO automation_logs (workflow_id, contact_id, status, details) VALUES (?, ?, ?, ?)");
                $log_stmt->execute([$automation_id, $contact_id, $action_status, $action_details]);
                cron_log("Automation ID {$automation_id}, Contact ID {$contact_id} - Action Logged: {$action_status} - {$action_details}");

            } else {
                cron_log("Automation ID {$automation_id}, Contact ID {$contact_id} - Condition NOT met: {$condition_details}. Skipping action.");
            }
        }
    }

    cron_log("Cron job 'winback_campaigns.php' finished successfully.");

} catch (PDOException $e) {
    cron_log("DATABASE ERROR in cron job 'winback_campaigns.php': " . $e->getMessage());
} catch (Exception $e) {
    cron_log("GENERAL ERROR in cron job 'winback_campaigns.php': " . $e->getMessage());
}

// --- Placeholder functions (replace with your actual implementations) ---
// These should ideally be in separate files like includes/email_functions.php, etc.

/**
 * Replace placeholders in a string with actual contact data.
 * @param string $template_string
 * @param array $contact_data
 * @return string
 */
function replace_placeholders($template_string, $contact_data) {
    $replacements = [
        '{contact_username}' => htmlspecialchars($contact_data['username'] ?? 'N/A'),
        '{contact_email}' => htmlspecialchars($contact_data['email'] ?? 'N/A'),
        '{contact_id}' => htmlspecialchars($contact_data['id'] ?? 'N/A'),
        '{stream_name}' => htmlspecialchars($contact_data['stream_name'] ?? 'N/A'),
        '{current_date}' => date('Y-m-d'),
        '{current_timestamp}' => date('Y-m-d H:i:s'),
        // Add more placeholders as needed based on your action configs (e.g., churn_score, competitor_name)
    ];

    // For churn_score, if available
    global $pdo;
    if (strpos($template_string, '{churn_score}') !== false) {
        $score_stmt = $pdo->prepare("SELECT score FROM churn_scores WHERE contact_id = ? ORDER BY scored_at DESC LIMIT 1");
        $score_stmt->execute([$contact_data['id']]);
        $latest_score = $score_stmt->fetchColumn();
        $replacements['{churn_score}'] = $latest_score !== false ? htmlspecialchars(round($latest_score, 2)) : 'N/A';
    }

    // For competitor_name, if competitor_id is available in contact_data (e.g., from a metric)
    // This is more complex as it depends on context of a metric, usually passed explicitly
    // For simplicity, let's assume if it's needed, it's specifically pulled.
    // If the condition was competitor_visit, the competitor_name would be known.
    // This placeholder logic might need refinement if used outside a direct competitor context.
    // For now, it will look up if a 'competitor_id' exists in the contact_data or if it was the triggering condition.
    if (strpos($template_string, '{competitor_name}') !== false) {
        // This is a simplistic lookup, might need to be more context-aware
        // e.g., if the automation was triggered specifically by a competitor visit.
        // For a cron, we might not always have this context per contact easily.
        // A more robust solution might pass the specific competitor_name during action execution.
        $replacements['{competitor_name}'] = 'N/A'; // Default
        // Example: if the original action config had a competitor_id
        if (isset($contact_data['competitor_id'])) {
             $comp_name_stmt = $GLOBALS['pdo']->prepare("SELECT name FROM competitors WHERE id = ?");
             $comp_name_stmt->execute([$contact_data['competitor_id']]);
             $comp_name = $comp_name_stmt->fetchColumn();
             $replacements['{competitor_name}'] = htmlspecialchars($comp_name ?: 'N/A');
        }
    }

    // Placeholder for feature_name if needed
    if (strpos($template_string, '{feature_name}') !== false) {
        $replacements['{feature_name}'] = 'N/A'; // Depends on context
    }

    // Placeholder for login_days_since_last if needed
    if (strpos($template_string, '{login_days_since_last}') !== false) {
        $replacements['{login_days_since_last}'] = 'N/A'; // Depends on context
    }

    foreach ($replacements as $placeholder => $value) {
        $template_string = str_replace($placeholder, $value, $template_string);
    }
    return $template_string;
}

/**
 * Placeholder for sending email notifications.
 * In a real application, this would use a robust mailer library (e.g., PHPMailer).
 * It should respect global email settings (PHP Mail vs. SMTP).
 * @param string $to_email
 * @param string $subject
 * @param string $body
 * @param string $sender_name
 * @return bool
 */
function send_email_notification($to_email, $subject, $body, $sender_name) {
    // Implement actual email sending logic here
    // For example:
    /*
    global $pdo;
    $config_stmt = $pdo->query("SELECT setting, value FROM config WHERE setting IN ('email_method', 'smtp_host', 'smtp_port', 'smtp_username', 'smtp_password', 'smtp_encryption')");
    $config = $config_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    if (($config['email_method'] ?? 'phpmail') === 'smtp') {
        // Use PHPMailer or similar with SMTP details
        // Example (simplified):
        // $mail = new PHPMailer(true);
        // $mail->isSMTP();
        // $mail->Host = $config['smtp_host'];
        // $mail->Port = $config['smtp_port'];
        // $mail->SMTPAuth = true;
        // $mail->Username = $config['smtp_username'];
        // $mail->Password = $config['smtp_password'];
        // $mail->SMTPSecure = $config['smtp_encryption'];
        // $mail->setFrom($config['smtp_username'], $sender_name);
        // $mail->addAddress($to_email);
        // $mail->isHTML(true);
        // $mail->Subject = $subject;
        // $mail->Body = $body;
        // $mail->send();
        cron_log("SIMULATED: Sent SMTP email to {$to_email} with subject '{$subject}' from '{$sender_name}'.");
    } else {
        // Use PHP's mail() function
        $headers = "From: {$sender_name} <no-reply@" . parse_url(BASE_URL, PHP_URL_HOST) . ">\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        // mail($to_email, $subject, $body, $headers);
        cron_log("SIMULATED: Sent PHP Mail to {$to_email} with subject '{$subject}' from '{$sender_name}'.");
    }
    */
    cron_log("SIMULATED: Sent email to {$to_email} with subject '{$subject}' from '{$sender_name}'.");
    return true; // Assume success for simulation
}

/**
 * Placeholder for sending SMS notifications.
 * In a real application, this would integrate with an SMS gateway API (e.g., Twilio, Nexmo).
 * @param string $phone_number
 * @param string $message
 * @return bool
 */
function send_sms_notification($phone_number, $message) {
    // Implement actual SMS sending logic here
    // Requires an SMS gateway API key and account balance
    cron_log("SIMULATED: Sent SMS to {$phone_number}: '{$message}'.");
    return true; // Assume success for simulation
}

/**
 * Placeholder for sending webhook notifications (e.g., to Zapier).
 * @param string $webhook_url
 * @param string $payload_json
 * @return bool
 */
function send_webhook_notification($webhook_url, $payload_json) {
    $ch = curl_init($webhook_url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload_json);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($payload_json)
    ]);
    $result = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($http_code >= 200 && $http_code < 300) {
        cron_log("Webhook sent to {$webhook_url} with payload '{$payload_json}'. Response: {$result}");
        return true;
    } else {
        cron_log("WEBHOOK ERROR: Failed to send to {$webhook_url}. HTTP Code: {$http_code}, Error: {$curl_error}, Response: {$result}");
        return false;
    }
}

// You might also need to define base_url if not defined by db.php for placeholder functions
if (!defined('BASE_URL')) {
    define('BASE_URL', 'http://localhost'); // Fallback for cron if not set via web request
}

?>
