<?php
// cron/automation_processor.php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Log execution start
error_log("[AutomationProcessor] Cron job started at " . date('Y-m-d H:i:s'));

try {
    $pdo->beginTransaction();

    // Get all active automations
    $stmt = $pdo->query("
        SELECT id, flow_data 
        FROM automation_workflows 
        WHERE is_active = 1
    ");
    $automations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($automations)) {
        error_log("[AutomationProcessor] No active automations found.");
        exit(0);
    }

    foreach ($automations as $automation) {
        $flow_data = json_decode($automation['flow_data'], true);
        if (json_last_error() !== JSON_ERROR_NONE || !isset($flow_data['nodes'])) {
            error_log("[AutomationProcessor] Invalid flow_data for workflow ID: " . $automation['id']);
            continue;
        }

        // Find all source nodes
        foreach ($flow_data['nodes'] as $node) {
            if ($node['type'] !== 'source') continue;

            $source_type = $node['config']['sourceType'] ?? '';
            $source_id = $node['config']['sourceId'] ?? null;

            if (empty($source_type) || empty($source_id)) {
                error_log("[AutomationProcessor] Invalid source config in workflow ID: " . $automation['id']);
                continue;
            }

            // Get contacts for this source
            $contacts = get_contacts_for_source($pdo, $source_type, $source_id);
            if (empty($contacts)) {
                error_log("[AutomationProcessor] No contacts found for source in workflow ID: " . $automation['id']);
                continue;
            }

            // Queue contacts for evaluation
            $queue_stmt = $pdo->prepare("
                INSERT INTO automation_queue 
                (workflow_id, contact_id, node_id, status) 
                VALUES (?, ?, ?, 'pending')
                ON DUPLICATE KEY UPDATE status = 'pending'
            ");

            foreach ($contacts as $contact_id) {
                $queue_stmt->execute([$automation['id'], $contact_id, $node['id']]);
            }
        }
    }

    $pdo->commit();
    error_log("[AutomationProcessor] Successfully processed " . count($automations) . " automations.");
} catch (Exception $e) {
    $pdo->rollBack();
    error_log("[AutomationProcessor] ERROR: " . $e->getMessage());
    exit(1); // Fail cron job
}

exit(0); // Success