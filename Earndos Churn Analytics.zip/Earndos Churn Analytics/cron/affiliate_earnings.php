<?php
require_once __DIR__.'/../includes/db.php';

// Log cron job execution
file_put_contents(__DIR__.'/affiliate_earnings.log', "[" . date('Y-m-d H:i:s') . "] Cron job started\n", FILE_APPEND);

try {
    // Find completed transactions with unconverted referrals
    $stmt = $pdo->query("
        SELECT t.user_id as referred_id, t.amount, t.membership_id, 
               r.referrer_id, ar.percentage
        FROM transactions t
        JOIN affiliate_referrals r ON t.user_id = r.referred_id
        LEFT JOIN affiliate_rewards ar ON t.membership_id = ar.membership_id
        WHERE t.status = 'completed'
        AND r.has_converted = 0
        AND t.completed_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
    ");

    $processed = 0;
    $errors = 0;

    while ($transaction = $stmt->fetch()) {
        try {
            $pdo->beginTransaction();

            // Calculate commission (default to 10% if not set)
            $percentage = $transaction['percentage'] ?? 0.10;
            $commission = $transaction['amount'] * $percentage;

            // Record affiliate earnings
            $pdo->prepare("
                INSERT INTO affiliate_earnings 
                (user_id, amount, source, source_id, earned_date)
                VALUES (?, ?, 'membership', ?, NOW())
            ")->execute([
                $transaction['referrer_id'],
                $commission,
                $transaction['membership_id']
            ]);

            // Mark referral as converted
            $pdo->prepare("
                UPDATE affiliate_referrals 
                SET has_converted = 1 
                WHERE referrer_id = ? AND referred_id = ?
            ")->execute([
                $transaction['referrer_id'],
                $transaction['referred_id']
            ]);

            // Get username for notification
            $username = $pdo->prepare("
                SELECT username FROM users WHERE id = ?
            ")->execute([$transaction['referred_id']])->fetchColumn();

            // Create notification
            $message = "You earned $" . number_format($commission, 2) . 
                      " from " . ($username ?: "a user") . "'s membership purchase";
            $pdo->prepare("
                INSERT INTO notifications 
                (user_id, title, message, type, related_id, created_at)
                VALUES (?, 'New Affiliate Earnings', ?, 'affiliate', ?, NOW())
            ")->execute([
                $transaction['referrer_id'],
                $message,
                $transaction['referred_id']
            ]);

            $pdo->commit();
            $processed++;
            
            file_put_contents(__DIR__.'/affiliate_earnings.log', 
                "[" . date('Y-m-d H:i:s') . "] Processed referral: " . 
                "Referrer {$transaction['referrer_id']}, " .
                "Referred {$transaction['referred_id']}, " .
                "Amount $" . number_format($commission, 2) . "\n", 
                FILE_APPEND);
                
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors++;
            
            file_put_contents(__DIR__.'/affiliate_earnings.log', 
                "[" . date('Y-m-d H:i:s') . "] ERROR processing transaction: " . 
                $e->getMessage() . "\n", 
                FILE_APPEND);
        }
    }

    // Log results
    file_put_contents(__DIR__.'/affiliate_earnings.log', 
        "[" . date('Y-m-d H:i:s') . "] Cron job completed. " .
        "Processed: $processed, Errors: $errors\n", 
        FILE_APPEND);

} catch (Exception $e) {
    file_put_contents(__DIR__.'/affiliate_earnings.log', 
        "[" . date('Y-m-d H:i:s') . "] FATAL ERROR: " . 
        $e->getMessage() . "\n", 
        FILE_APPEND);
}