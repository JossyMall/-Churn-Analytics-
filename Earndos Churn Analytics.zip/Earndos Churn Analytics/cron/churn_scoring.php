<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Get AI configuration from database
$config = $pdo->query("SELECT * FROM config WHERE setting IN ('ai_model', 'openai_key', 'deepseek_key')")->fetchAll(PDO::FETCH_KEY_PAIR);
$ai_model = $config['ai_model'] ?? 'deepseek';
$api_key = $ai_model === 'deepseek' ? ($config['deepseek_key'] ?? '') : ($config['openai_key'] ?? '');

if (empty($api_key)) {
    log_error("No API key configured for selected AI model ($ai_model)");
    exit;
}

// Get all active users with subscriptions
$users = $pdo->query("
    SELECT u.id, u.username, u.email 
    FROM users u
    JOIN user_subscriptions s ON u.id = s.user_id
    WHERE s.is_active = 1 AND s.end_date > NOW()
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($users as $user) {
    try {
        // Get contacts that need scoring (either never scored or have new metrics since last score)
        $contacts = $pdo->prepare("
            SELECT c.id, c.username, c.email, c.last_activity, 
                   GROUP_CONCAT(DISTINCT m.name SEPARATOR ', ') as metrics,
                   cs.score as last_score
            FROM contacts c
            JOIN streams st ON c.stream_id = st.id
            LEFT JOIN metric_data md ON md.contact_id = c.id
            LEFT JOIN churn_metrics m ON md.metric_id = m.id
            LEFT JOIN (
                SELECT contact_id, MAX(scored_at) as last_score_date 
                FROM churn_scores 
                GROUP BY contact_id
            ) latest ON latest.contact_id = c.id
            LEFT JOIN churn_scores cs ON cs.contact_id = c.id AND cs.scored_at = latest.last_score_date
            WHERE st.user_id = ? AND (
                latest.last_score_date IS NULL OR 
                EXISTS (
                    SELECT 1 FROM metric_data 
                    WHERE contact_id = c.id AND recorded_at > latest.last_score_date
                )
            )
            GROUP BY c.id
            LIMIT 20
        ");
        $contacts->execute([$user['id']]);
        $contacts = $contacts->fetchAll(PDO::FETCH_ASSOC);

        if (empty($contacts)) {
            continue;
        }

        foreach ($contacts as $contact) {
            // Prepare data for AI analysis
            $analysis_data = [
                'contact_id' => $contact['id'],
                'username' => $contact['username'],
                'email' => $contact['email'],
                'last_activity' => $contact['last_activity'],
                'metrics_available' => $contact['metrics'],
                'previous_score' => $contact['last_score'] ?? null
            ];

            // Get detailed metrics for analysis
            $metrics = $pdo->prepare("
                SELECT m.name, md.value, md.recorded_at
                FROM metric_data md
                JOIN churn_metrics m ON md.metric_id = m.id
                WHERE md.contact_id = ?
                ORDER BY md.recorded_at DESC
                LIMIT 50
            ");
            $metrics->execute([$contact['id']]);
            $analysis_data['metrics'] = $metrics->fetchAll(PDO::FETCH_ASSOC);

            // Get custom metrics if any
            $custom_metrics = $pdo->prepare("
                SELECT cm.name, md.value, md.recorded_at
                FROM metric_data md
                JOIN custom_metrics cm ON md.custom_metric_id = cm.id
                WHERE md.contact_id = ?
                ORDER BY md.recorded_at DESC
                LIMIT 20
            ");
            $custom_metrics->execute([$contact['id']]);
            $analysis_data['custom_metrics'] = $custom_metrics->fetchAll(PDO::FETCH_ASSOC);

            // Prepare prompt for AI
            $prompt = create_ai_prompt($analysis_data);
            
            // Call AI API
            $response = call_ai_api($ai_model, $api_key, $prompt);
            
            if ($response && $response['success']) {
                $score = (float)$response['score'];
                $report = $response['report'];
                $suggestions = $response['suggestions'];
                
                // Store the score in database
                $stmt = $pdo->prepare("
                    INSERT INTO churn_scores 
                    (contact_id, score, report, model_used) 
                    VALUES (?, ?, ?, ?)
                ");
                $stmt->execute([
                    $contact['id'],
                    $score,
                    $report,
                    $ai_model
                ]);
                
                // Store winback suggestions
                foreach ($suggestions as $suggestion) {
                    $stmt = $pdo->prepare("
                        INSERT INTO winback_suggestions 
                        (contact_id, suggestion) 
                        VALUES (?, ?)
                    ");
                    $stmt->execute([$contact['id'], $suggestion]);
                }
                
                // Check if we need to send alerts
                check_churn_alerts($user['id'], $contact['id'], $score);
                
                log_message("Scored contact {$contact['id']} for user {$user['id']}: $score");
            } else {
                log_error("AI scoring failed for contact {$contact['id']}: " . ($response['error'] ?? 'Unknown error'));
            }
            
            // Be kind to the API - sleep between requests
            sleep(2);
        }
    } catch (Exception $e) {
        log_error("Error processing user {$user['id']}: " . $e->getMessage());
        continue;
    }
}

/**
 * Creates the AI prompt for churn analysis
 */
function create_ai_prompt(array $data): string {
    $prompt = "Analyze this customer's churn risk based on the following data:\n\n";
    $prompt .= "Customer: {$data['username']} ({$data['email']})\n";
    $prompt .= "Last Activity: {$data['last_activity']}\n\n";
    $prompt .= "Available Metrics:\n{$data['metrics']}\n\n";
    
    if (!empty($data['metrics'])) {
        $prompt .= "Metric Details:\n";
        foreach ($data['metrics'] as $metric) {
            $prompt .= "- {$metric['name']}: {$metric['value']} (at {$metric['recorded_at']})\n";
        }
    }
    
    if (!empty($data['custom_metrics'])) {
        $prompt .= "\nCustom Metrics:\n";
        foreach ($data['custom_metrics'] as $metric) {
            $prompt .= "- {$metric['name']}: {$metric['value']} (at {$metric['recorded_at']})\n";
        }
    }
    
    $prompt .= "\nProvide:\n1. Churn probability score (0-100)\n";
    $prompt .= "2. Detailed analysis report\n";
    $prompt .= "3. 3-5 specific winback suggestions\n";
    $prompt .= "Format response as JSON with: score, report, suggestions[]";
    
    return $prompt;
}

/**
 * Calls the appropriate AI API
 */
function call_ai_api(string $model, string $api_key, string $prompt): array {
    if ($model === 'deepseek') {
        return call_deepseek_api($api_key, $prompt);
    } else {
        return call_openai_api($api_key, $prompt);
    }
}

/**
 * Calls DeepSeek API for churn analysis
 */
function call_deepseek_api(string $api_key, string $prompt): array {
    $url = 'https://api.deepseek.com/v1/chat/completions';
    
    $data = [
        'model' => 'deepseek-churn',
        'messages' => [
            ['role' => 'system', 'content' => 'You are a customer churn analysis assistant.'],
            ['role' => 'user', 'content' => $prompt]
        ],
        'temperature' => 0.7,
        'max_tokens' => 1000
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $api_key
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if ($http_code !== 200) {
        return ['success' => false, 'error' => "API request failed with code $http_code"];
    }
    
    $result = json_decode($response, true);
    $content = $result['choices'][0]['message']['content'] ?? '';
    
    try {
        $analysis = json_decode($content, true);
        return [
            'success' => true,
            'score' => $analysis['score'] ?? 0,
            'report' => $analysis['report'] ?? '',
            'suggestions' => $analysis['suggestions'] ?? []
        ];
    } catch (Exception $e) {
        return ['success' => false, 'error' => 'Invalid API response format'];
    }
}

/**
 * Checks if alerts need to be sent based on churn score
 */
function check_churn_alerts(int $user_id, int $contact_id, float $score): void {
    global $pdo;
    
    // Get user's alert thresholds
    $thresholds = $pdo->prepare("
        SELECT threshold, alert_methods 
        FROM user_alert_thresholds 
        WHERE user_id = ? AND (stream_id IS NULL OR stream_id IN (
            SELECT stream_id FROM contacts WHERE id = ?
        ))
        ORDER BY stream_id IS NULL
        LIMIT 1
    ");
    $thresholds->execute([$user_id, $contact_id]);
    $threshold = $thresholds->fetch(PDO::FETCH_ASSOC);
    
    if (!$threshold || $score < $threshold['threshold']) {
        return;
    }
    
    // Get contact details
    $contact = $pdo->prepare("
        SELECT c.username, c.email, s.name as stream_name
        FROM contacts c
        JOIN streams s ON c.stream_id = s.id
        WHERE c.id = ?
    ");
    $contact->execute([$contact_id]);
    $contact = $contact->fetch(PDO::FETCH_ASSOC);
    
    // Create notification
    $message = "High churn risk detected for {$contact['username']} ({$contact['email']}) in {$contact['stream_name']}. ";
    $message .= "Churn probability: " . round($score, 1) . "%";
    
    $pdo->prepare("
        INSERT INTO notifications 
        (user_id, title, message, type, related_id) 
        VALUES (?, 'High Churn Risk', ?, 'churn', ?)
    ")->execute([$user_id, $message, $contact_id]);
    
    // Send alerts based on user's preferences
    $methods = explode(',', $threshold['alert_methods']);
    
    if (in_array('email', $methods)) {
        send_churn_alert_email($user_id, $contact, $score);
    }
    
    if (in_array('webhook', $methods)) {
        send_churn_alert_webhook($user_id, $contact, $score);
    }
    
    // Note: SMS would be handled similarly
}

/**
 * Sends churn alert email
 */
function send_churn_alert_email(int $user_id, array $contact, float $score): void {
    global $pdo;
    
    // Get user's email preferences
    $user = $pdo->prepare("
        SELECT u.email, p.alert_is_email, p.full_name
        FROM users u
        JOIN user_profiles p ON u.id = p.user_id
        WHERE u.id = ?
    ")->execute([$user_id])->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || !$user['alert_is_email']) {
        return;
    }
    
    $to = $user['email'];
    $subject = "Churn Alert: {$contact['username']} has high churn risk";
    
    $message = "
        <html>
        <body>
            <h2>Churn Alert</h2>
            <p>Hello {$user['full_name']},</p>
            <p>We've detected a high churn risk for one of your customers:</p>
            
            <table>
                <tr><td><strong>Customer:</strong></td><td>{$contact['username']}</td></tr>
                <tr><td><strong>Email:</strong></td><td>{$contact['email']}</td></tr>
                <tr><td><strong>Stream:</strong></td><td>{$contact['stream_name']}</td></tr>
                <tr><td><strong>Churn Probability:</strong></td><td>" . round($score, 1) . "%</td></tr>
            </table>
            
            <p>Please review this customer in your dashboard and consider taking winback actions.</p>
            
            <p><a href='" . BASE_URL . "/dashboard'>View in Dashboard</a></p>
            
            <p>Best regards,<br>Churn Analytics Team</p>
        </body>
        </html>
    ";
    
    // Use your existing email sending function
    send_email($to, $subject, $message);
}

/**
 * Sends churn alert to webhook (Slack/MS Teams/Discord)
 */
function send_churn_alert_webhook(int $user_id, array $contact, float $score): void {
    global $pdo;
    
    $webhook = $pdo->prepare("
        SELECT webhook_type, webhook_url 
        FROM user_profiles 
        WHERE user_id = ? AND webhook_url IS NOT NULL
    ")->execute([$user_id])->fetch(PDO::FETCH_ASSOC);
    
    if (!$webhook) {
        return;
    }
    
    $payload = [
        'text' => "🚨 High churn risk alert",
        'attachments' => [[
            'color' => '#FF0000',
            'fields' => [
                ['title' => 'Customer', 'value' => $contact['username'], 'short' => true],
                ['title' => 'Email', 'value' => $contact['email'], 'short' => true],
                ['title' => 'Stream', 'value' => $contact['stream_name'], 'short' => true],
                ['title' => 'Churn Probability', 'value' => round($score, 1) . '%', 'short' => true],
                ['title' => 'View Details', 'value' => BASE_URL . "/dashboard?contact={$contact['id']}"]
            ]
        ]]
    ];
    
    $ch = curl_init($webhook['webhook_url']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_exec($ch);
    curl_close($ch);
}