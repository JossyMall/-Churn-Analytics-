<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/email_functions.php';
require_once __DIR__ . '/../includes/external_apis/IntegrationManager.php';

error_log("[ActionDispatcher] Cron job started at " . date('Y-m-d H:i:s'));

try {
    $pdo->beginTransaction();
    $integrationManager = new IntegrationManager($pdo);

    $stmt = $pdo->query("
        SELECT aq.id, aq.workflow_id, aq.contact_id, aq.node_id, aq.action_data, 
               c.email, c.username, c.external_id, c.custom_data
        FROM action_queue aq
        JOIN contacts c ON aq.contact_id = c.id
        WHERE aq.status = 'pending'
        LIMIT 100
        FOR UPDATE SKIP LOCKED
    ");
    $actions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($actions)) {
        error_log("[ActionDispatcher] No pending actions.");
        exit(0);
    }

    foreach ($actions as $action) {
        $config = json_decode($action['action_data'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $pdo->prepare("UPDATE action_queue SET status = 'failed', error = 'Invalid JSON config' WHERE id = ?")
                ->execute([$action['id']]);
            continue;
        }

        try {
            switch ($config['actionType']) {
                case 'email':
                    $template = $pdo->prepare("SELECT subject, content FROM email_templates WHERE id = ?")
                        ->execute([$config['templateId']])
                        ->fetch(PDO::FETCH_ASSOC);
                    if ($template) {
                        send_email(
                            $action['email'],
                            $template['subject'],
                            replace_placeholders($template['content'], $action)
                        );
                    }
                    break;

                case 'sms':
                    $phone = json_decode($action['custom_data'], true)[$config['phoneField']] ?? '';
                    if ($phone) {
                        send_sms($phone, replace_placeholders($config['message'], $action));
                    }
                    break;

                case 'external':
                    $integrationManager->executeAction(
                        $config['integrationId'],
                        $action['contact_id'],
                        $config['actionConfig']
                    );
                    break;
            }

            $pdo->prepare("UPDATE action_queue SET status = 'completed', completed_at = NOW() WHERE id = ?")
                ->execute([$action['id']]);
        } catch (Exception $e) {
            $pdo->prepare("UPDATE action_queue SET status = 'failed', error = ? WHERE id = ?")
                ->execute([substr($e->getMessage(), 0, 255), $action['id']]);
        }
    }

    $pdo->commit();
    error_log("[ActionDispatcher] Processed " . count($actions) . " actions.");
} catch (Exception $e) {
    $pdo->rollBack();
    error_log("[ActionDispatcher] ERROR: " . $e->getMessage());
    exit(1);
}

exit(0);