<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Check for expired subscriptions
$expired_subscriptions = $pdo->query("
    SELECT s.id, s.user_id, u.email, u.username, m.name as membership_name
    FROM user_subscriptions s
    JOIN users u ON s.user_id = u.id
    JOIN membership_levels m ON s.membership_id = m.id
    WHERE s.is_active = 1 AND s.end_date <= NOW()
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($expired_subscriptions as $sub) {
    try {
        // Deactivate subscription
        $pdo->prepare("UPDATE user_subscriptions SET is_active = 0 WHERE id = ?")->execute([$sub['id']]);
        
        // Downgrade user to free tier
        $pdo->prepare("UPDATE users SET is_admin = 0 WHERE id = ?")->execute([$sub['user_id']]);
        
        // Create notification
        $message = "Your {$sub['membership_name']} subscription has expired. You've been downgraded to the free plan.";
        $pdo->prepare("
            INSERT INTO notifications 
            (user_id, title, message, type) 
            VALUES (?, 'Subscription Expired', ?, 'payment')
        ")->execute([$sub['user_id'], $message]);
        
        // Send expiration email
        send_subscription_email(
            $sub['email'],
            'Subscription Expired',
            "expired_subscription",
            [
                'username' => $sub['username'],
                'membership_name' => $sub['membership_name'],
                'renew_link' => BASE_URL . '/membership'
            ]
        );
        
        log_message("Expired subscription for user {$sub['user_id']}");
        
    } catch (Exception $e) {
        log_error("Error processing subscription {$sub['id']}: " . $e->getMessage());
    }
}

// Check for subscriptions expiring soon (7 days)
$expiring_soon = $pdo->query("
    SELECT s.id, s.user_id, u.email, u.username, m.name as membership_name, 
           DATEDIFF(s.end_date, CURDATE()) as days_left
    FROM user_subscriptions s
    JOIN users u ON s.user_id = u.id
    JOIN membership_levels m ON s.membership_id = m.id
    WHERE s.is_active = 1 
    AND s.end_date > NOW() 
    AND DATEDIFF(s.end_date, CURDATE()) <= 7
    AND NOT EXISTS (
        SELECT 1 FROM notifications 
        WHERE user_id = s.user_id 
        AND type = 'payment' 
        AND title = 'Subscription Expiring Soon'
        AND created_at >= DATE_SUB(NOW(), INTERVAL 3 DAY)
    )
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($expiring_soon as $sub) {
    try {
        // Create notification
        $message = "Your {$sub['membership_name']} subscription expires in {$sub['days_left']} days. Renew now to avoid service interruption.";
        $pdo->prepare("
            INSERT INTO notifications 
            (user_id, title, message, type) 
            VALUES (?, 'Subscription Expiring Soon', ?, 'payment')
        ")->execute([$sub['user_id'], $message]);
        
        // Send reminder email
        send_subscription_email(
            $sub['email'],
            'Subscription Expiring Soon',
            "expiring_soon",
            [
                'username' => $sub['username'],
                'membership_name' => $sub['membership_name'],
                'days_left' => $sub['days_left'],
                'renew_link' => BASE_URL . '/membership'
            ]
        );
        
        log_message("Sent renewal reminder for user {$sub['user_id']}");
        
    } catch (Exception $e) {
        log_error("Error sending renewal reminder for subscription {$sub['id']}: " . $e->getMessage());
    }
}

// Check for gift eligibility
$eligible_gifts = $pdo->query("
    SELECT g.id as gift_id, u.id as user_id, u.email, u.username, g.name as gift_name,
           g.duration_months, m.name as membership_name
    FROM user_subscriptions s
    JOIN users u ON s.user_id = u.id
    JOIN membership_levels m ON s.membership_id = m.id
    JOIN membership_gifts g ON (g.membership_id = m.id OR g.is_global = 1)
    WHERE s.is_active = 1
    AND DATEDIFF(NOW(), s.start_date) >= (g.duration_months * 30)
    AND NOT EXISTS (
        SELECT 1 FROM user_gifts 
        WHERE user_id = u.id AND gift_id = g.id
    )
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($eligible_gifts as $gift) {
    try {
        // Award gift
        $pdo->prepare("
            INSERT INTO user_gifts 
            (user_id, gift_id) 
            VALUES (?, ?)
        ")->execute([$gift['user_id'], $gift['gift_id']]);
        
        // Create notification
        $message = "Congratulations! You've earned the {$gift['gift_name']} gift for maintaining your {$gift['membership_name']} membership for {$gift['duration_months']} months.";
        $pdo->prepare("
            INSERT INTO notifications 
            (user_id, title, message, type) 
            VALUES (?, 'Gift Earned', ?, 'system')
        ")->execute([$gift['user_id'], $message]);
        
        // Send gift email
        send_subscription_email(
            $gift['email'],
            'You Earned a Gift!',
            "gift_earned",
            [
                'username' => $gift['username'],
                'gift_name' => $gift['gift_name'],
                'membership_name' => $gift['membership_name'],
                'duration_months' => $gift['duration_months']
            ]
        );
        
        log_message("Awarded gift {$gift['gift_id']} to user {$gift['user_id']}");
        
    } catch (Exception $e) {
        log_error("Error awarding gift {$gift['gift_id']} to user {$gift['user_id']}: " . $e->getMessage());
    }
}

// Helper function for subscription emails
function send_subscription_email($to, $subject, $template, $data) {
    $template_path = __DIR__ . "/../templates/emails/{$template}.html";
    
    if (!file_exists($template_path)) {
        log_error("Email template not found: {$template}");
        return false;
    }
    
    $content = file_get_contents($template_path);
    
    foreach ($data as $key => $value) {
        $content = str_replace("{{{$key}}}", $value, $content);
    }
    
    return send_email($to, $subject, $content);
}