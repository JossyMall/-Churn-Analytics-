<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

error_log("[ConditionEvaluator] Cron job started at " . date('Y-m-d H:i:s'));

try {
    $pdo->beginTransaction();

    $stmt = $pdo->query("
        SELECT aq.id, aq.workflow_id, aq.contact_id, aq.node_id, aw.flow_data
        FROM automation_queue aq
        JOIN automation_workflows aw ON aq.workflow_id = aw.id
        WHERE aq.status = 'pending'
        LIMIT 1000
    ");
    $evaluations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($evaluations)) {
        error_log("[ConditionEvaluator] No pending evaluations.");
        exit(0);
    }

    $action_queue_stmt = $pdo->prepare("
        INSERT INTO action_queue 
        (workflow_id, contact_id, node_id, action_data, status) 
        VALUES (?, ?, ?, ?, 'pending')
    ");

    foreach ($evaluations as $eval) {
        $flow_data = json_decode($eval['flow_data'], true);
        if (json_last_error() !== JSON_ERROR_NONE) continue;

        foreach ($flow_data['connections'] as $conn) {
            if ($conn['source'] !== $eval['node_id']) continue;

            $target_node = null;
            foreach ($flow_data['nodes'] as $node) {
                if ($node['id'] === $conn['target']) {
                    $target_node = $node;
                    break;
                }
            }
            if (!$target_node || $target_node['type'] !== 'condition') continue;

            $condition_met = false;
            switch ($target_node['config']['conditionType']) {
                case 'churn_probability':
                    $stmt = $pdo->prepare("
                        SELECT score FROM churn_scores 
                        WHERE contact_id = ? 
                        ORDER BY scored_at DESC LIMIT 1
                    ");
                    $stmt->execute([$eval['contact_id']]);
                    $score = $stmt->fetchColumn();
                    if ($score !== false) {
                        $operator = $target_node['config']['operator'] ?? '>';
                        $threshold = (float)($target_node['config']['value'] ?? 0);
                        $condition_met = ($operator === '>' && $score > $threshold) || 
                                         ($operator === '<' && $score < $threshold);
                    }
                    break;

                case 'last_login':
                    $stmt = $pdo->prepare("
                        SELECT DATEDIFF(NOW(), MAX(recorded_at)) 
                        FROM metric_data 
                        WHERE contact_id = ? AND metric_id = 2
                    ");
                    $stmt->execute([$eval['contact_id']]);
                    $days = $stmt->fetchColumn();
                    if ($days !== false) {
                        $threshold = (int)($target_node['config']['value'] ?? 0);
                        $condition_met = $days >= $threshold;
                    }
                    break;
            }

            if ($condition_met) {
                foreach ($flow_data['connections'] as $action_conn) {
                    if ($action_conn['source'] !== $target_node['id']) continue;

                    $action_node = null;
                    foreach ($flow_data['nodes'] as $node) {
                        if ($node['id'] === $action_conn['target']) {
                            $action_node = $node;
                            break;
                        }
                    }
                    if (!$action_node || $action_node['type'] !== 'action') continue;

                    $action_queue_stmt->execute([
                        $eval['workflow_id'],
                        $eval['contact_id'],
                        $action_node['id'],
                        json_encode($action_node['config'])
                    ]);
                }
            }
        }

        $stmt = $pdo->prepare("UPDATE automation_queue SET status = 'processed' WHERE id = ?");
        $stmt->execute([$eval['id']]);
    }

    $pdo->commit();
    error_log("[ConditionEvaluator] Processed " . count($evaluations) . " evaluations.");
} catch (Exception $e) {
    $pdo->rollBack();
    error_log("[ConditionEvaluator] ERROR: " . $e->getMessage());
    exit(1);
}

exit(0);