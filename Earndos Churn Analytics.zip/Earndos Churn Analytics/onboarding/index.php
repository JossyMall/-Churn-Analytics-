
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Onboarding! - Setup Checklist</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            color: #333;
            padding: 20px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
            width: 100%;
            max-width: 800px;
        }
        
        h1 {
            color: #2c3e50;
            margin-bottom: 10px;
            font-size: 32px;
        }
        
        .subheader {
            color: #7f8c8d;
            margin-bottom: 20px;
            font-size: 16px;
        }
        
        .checklist-container {
            width: 100%;
            max-width: 800px;
            padding: 20px;
            overflow-y: auto;
            max-height: 80vh;
        }
        
        .task-box {
            background-color: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            display: flex;
            position: relative;
            transition: all 0.3s ease;
        }
        
        .task-box:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }
        
        .task-status {
            flex-shrink: 0;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            margin-right: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }
        
        .completed .task-status {
            background-color: #3ac3b8;
            color: white;
        }
        
        .pending .task-status {
            background-color: #95a5a6;
            color: #ecf0f1;
        }
        
        .task-content {
            flex-grow: 1;
        }
        
        .task-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .task-description {
            color: #7f8c8d;
            font-size: 14px;
            line-height: 1.5;
        }
        
        .pending {
            filter: grayscale(0.8);
            opacity: 0.8;
        }
        
        .completed {
            border-left: 5px solid #3ac3b8;
        }
        
        .pending {
            border-left: 5px solid #95a5a6;
        }
        
        .progress-container {
            width: 100%;
            max-width: 800px;
            margin-bottom: 30px;
            padding: 0 20px;
        }
        
        .progress-track {
            height: 12px;
            background-color: #ecf0f1;
            border-radius: 10px;
            overflow: visible;
            margin-top: 25px;
            margin-bottom: 35px;
            position: relative;
        }
        
        .progress-fill {
            height: 100%;
            background-color: #3ac3b8;
            width: 33%; /* Assuming 2 out of 6 tasks completed */
            border-radius: 10px;
            transition: width 0.5s ease;
        }
        
        .waypoint {
            position: absolute;
            width: 20px;
            height: 20px;
            background-color: #ecf0f1;
            border: 3px solid #bdc3c7;
            border-radius: 50%;
            top: -4px;
            transform: translateX(-50%);
            z-index: 2;
            transition: background-color 0.3s ease;
        }
        
        .waypoint[data-step="1"] { left: 0%; }
        .waypoint[data-step="2"] { left: 20%; }
        .waypoint[data-step="3"] { left: 40%; }
        .waypoint[data-step="4"] { left: 60%; }
        .waypoint[data-step="5"] { left: 80%; }
        .waypoint[data-step="6"] { left: 100%; }
        
        .waypoint.completed {
            background-color: #3ac3b8;
            border-color: #000000;
        }
        
        .progress-car {
            position: absolute;
            left: 33%; /* Aligns with 2 completed tasks out of 6 */
            top: -15px;
            transform: translateX(-50%);
            z-index: 3;
            transition: left 0.8s ease;
        }
        
        #progress-car {
            width: 40px;
            height: auto;
        }
        
        .waypoint:after {
            content: attr(title);
            position: absolute;
            top: 25px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 10px;
            color: #7f8c8d;
            white-space: nowrap;
            text-align: center;
        }
        
        .progress-text {
            display: flex;
            justify-content: space-between;
            font-size: 14px;
            color: #7f8c8d;
            margin-top: 5px;
        }
        
        @media (max-width: 600px) {
            .task-box {
                flex-direction: column;
                padding: 20px;
            }
            
            .task-status {
                margin-bottom: 15px;
                margin-right: 0;
                align-self: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Setup Checklist</h1>
        <p class="subheader">Complete these tasks to fully configure your churn tracking system</p>
    </div>
    
    <div class="progress-container">
        <div class="progress-track">
            <div class="waypoint" data-step="1" title="Setup API Key"></div>
            <div class="waypoint" data-step="2" title="Complete Profile"></div>
            <div class="waypoint" data-step="3" title="Create Stream"></div>
            <div class="waypoint" data-step="4" title="Setup Cohorts"></div>
            <div class="waypoint" data-step="5" title="Configure Competitors"></div>
            <div class="waypoint" data-step="6" title="Set up Win-back Automation"></div>
            <div class="progress-car">
                <img src="car.png" alt="Progress Car" id="progress-car">
            </div>
            <div class="progress-fill"></div>
        </div>
        <div class="progress-text">
            <span>2 of 6 tasks completed</span>
            <span>33% complete</span>
        </div>
    </div>
    
    <div class="checklist-container">
        <!-- Completed tasks -->
        <div class="task-box completed">
            <div class="task-status">✓</div>
            <div class="task-content">
                <h3 class="task-title">1. Setup API Key</h3>
                <p class="task-description">Generate and securely store your API key to allow secure communication between your platforms and our churn tracking system.</p>
            </div>
        </div>
        
        <div class="task-box completed">
            <div class="task-status">✓</div>
            <div class="task-content">
                <h3 class="task-title">2. Complete Profile and Upload a Picture</h3>
                <p class="task-description">Update your account information and add a profile picture for better team collaboration and account management.</p>
            </div>
        </div>
        
        <!-- Pending tasks -->
        <div class="task-box pending">
            <div class="task-status">✗</div>
            <div class="task-content">
                <h3 class="task-title">3. Create a Stream</h3>
                <p class="task-description">Set up a new project stream (app or website) to define the specific platform where you want to track and prevent customer churn.</p>
            </div>
        </div>
        
        <div class="task-box pending">
            <div class="task-status">✗</div>
            <div class="task-content">
                <h3 class="task-title">4. Setup Cohorts for Your Stream</h3>
                <p class="task-description">Define user segments and groups to analyze churn patterns across different customer demographics and behaviors.</p>
            </div>
        </div>
        
        <div class="task-box pending">
            <div class="task-status">✗</div>
            <div class="task-content">
                <h3 class="task-title">5. Configure Competitors</h3>
                <p class="task-description">Identify your main competitors to enable comparative churn analysis and gain insights into market positioning.</p>
            </div>
        </div>
        
        <div class="task-box pending">
            <div class="task-status">✗</div>
            <div class="task-content">
                <h3 class="task-title">6. Set up Win-back Automation</h3>
                <p class="task-description">Configure automated workflows that trigger when contacts in a stream or cohort are detected to have high churn risk or have already churned, helping you recover lost customers.</p>
            </div>
        </div>
    </div>

    <script>
        // This script handles the checklist functionality and progress tracking
        document.addEventListener('DOMContentLoaded', function() {
            // Initial setup
            updateWaypoints();
            
            // Make task boxes clickable to toggle status
            const taskBoxes = document.querySelectorAll('.task-box');
            
            taskBoxes.forEach((box, index) => {
                box.addEventListener('click', function() {
                    // Toggle completed/pending status
                    if (this.classList.contains('completed')) {
                        this.classList.remove('completed');
                        this.classList.add('pending');
                        this.querySelector('.task-status').textContent = '✗';
                    } else {
                        this.classList.remove('pending');
                        this.classList.add('completed');
                        this.querySelector('.task-status').textContent = '✓';
                    }
                    
                    // Update progress visualization
                    updateProgress();
                });
            });
            
            function updateProgress() {
                const total = taskBoxes.length;
                const completed = document.querySelectorAll('.task-box.completed').length;
                const percentage = Math.round((completed / total) * 100);
                const progressPercentage = completed === 0 ? 0 : (completed / total) * 100;
                
                // Update progress bar fill
                document.querySelector('.progress-fill').style.width = progressPercentage + '%';
                
                // Update text
                document.querySelector('.progress-text span:first-child').textContent = 
                    `${completed} of ${total} tasks completed`;
                document.querySelector('.progress-text span:last-child').textContent = 
                    `${percentage}% complete`;
                
                // Update car position (align with the last completed waypoint or start if none)
                const carPosition = completed === 0 ? 0 : (completed / total) * 100;
                document.querySelector('.progress-car').style.left = carPosition + '%';
                
                // Update waypoints
                updateWaypoints();
            }
            
            function updateWaypoints() {
                const waypoints = document.querySelectorAll('.waypoint');
                const completedTasks = document.querySelectorAll('.task-box.completed').length;
                
                waypoints.forEach((waypoint, index) => {
                    // Mark waypoints as completed based on task completion
                    if (index < completedTasks) {
                        waypoint.classList.add('completed');
                    } else {
                        waypoint.classList.remove('completed');
                    }
                });
            }
        });
    </script>
</body>
</html>