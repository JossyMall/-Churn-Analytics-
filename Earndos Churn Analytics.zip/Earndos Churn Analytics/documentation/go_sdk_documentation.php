<?php
// documentations/go_sdk_documentation.php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

require_once '../includes/db.php'; // Path from documentations/ to includes/db.php
require_once '../includes/header.php'; // Includes global HTML head, meta, and possibly global CSS/JS.

$current_user_id = $_SESSION['user_id'];
$base_api_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . "/api/index.php"; // Adjust if your API is under a different path like /api/v1/

// --- Fetch User's API Key ---
$user_api_key = null;
$stmt_api_key = $pdo->prepare("SELECT api_key FROM user_api_keys WHERE user_id = :user_id ORDER BY created_at DESC LIMIT 1");
$stmt_api_key->bindValue(':user_id', $current_user_id, PDO::PARAM_INT);
$stmt_api_key->execute();
$api_key_data = $stmt_api_key->fetch(PDO::FETCH_ASSOC);

if ($api_key_data) {
    $user_api_key = $api_key_data['api_key'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Go SDK Documentation</title>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <!-- Include Font Awesome for the eye icon if not already in header.php -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"
            xintegrity="sha512-Tn2m0TIpgVyTzzvmxLNuqbSJH3JP8jm+Cy3hvHrW7ndTDcJ1w5mBiksqDBb8GpE2ksktFvDB/ykZ0mDpsZj20w=="
            crossorigin="anonymous"
            referrerpolicy="no-referrer"></script>
    <style>
        /* Base styles consistent with dashboard/explore/profile */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
        }

        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer */
        }

        .site-wrapper { /* Main flex container for sticky footer */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .doc-container {
            max-width: 900px;
            margin: 40px auto;
            padding: 20px;
            box-sizing: border-box;
            flex-grow: 1; /* Allows content area to expand and push footer down */
            border-radius: 12px;
            border: 1px solid var(--gray-200);
        }

        h1, h2, h3, h4 {
            color: var(--dark);
            margin-top: 1.5em;
            margin-bottom: 0.8em;
        }

        h1 { font-size: 2.5em; text-align: center; margin-bottom: 1em; }
        h2 { font-size: 2em; border-bottom: 2px solid var(--gray-200); padding-bottom: 0.5em; margin-top: 2em; }
        h3 { font-size: 1.5em; color: var(--primary); }
        h4 { font-size: 1.2em; color: var(--gray-800); }

        p {
            margin-bottom: 1em;
        }

        ul {
            list-style-type: disc;
            margin-left: 20px;
            margin-bottom: 1em;
        }

        strong {
            color: var(--gray-800);
        }

        a {
            color: var(--info);
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }

        .api-key-header {
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #000000;
            margin-bottom: 30px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
            text-align: center;
        }
        .api-key-header h2 {
            margin: 0;
            padding-bottom: 0;
            border-bottom: none;
            font-size: 1.8em;
        }
        .api-key-display {
            font-family: 'Courier New', Courier, monospace;
            padding: 10px 15px;
            border-radius: 8px;
            font-size: 0.9em;
            color: var(--gray-800);
            display: flex;
            align-items: center;
            gap: 10px;
            max-width: 100%;
            overflow-x: auto;
        }
        .api-key-display span {
            white-space: nowrap; /* Prevent key from wrapping */
        }
        .btn-api-action {
            background-color: var(--primary);
            color: var(--white);
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: background-color 0.2s;
            font-size: 0.9em;
        }
        .btn-api-action:hover {
            background-color: #2da89e;
        }
        .btn-api-action i {
            width: 16px;
            height: 16px;
        }
        .no-key-message {
            color: var(--danger);
            font-weight: 500;
        }
        .no-key-message a {
            color: var(--danger);
            text-decoration: underline;
        }


        code {
            background-color: #10ff00;
            padding: 2px 4px;
            border-radius: 4px;
            font-family: 'Courier New', Courier, monospace;
            font-size: 0.9em;
            font-weight: 900;
            color: var(--dark);
        }

        pre {
            background-color: var(--gray-800);
            color: var(--white);
            padding: 15px;
            border-radius: 8px;
            overflow-x: auto;
            font-family: 'Courier New', Courier, monospace;
            font-size: 0.9em;
            line-height: 1.4;
            margin-bottom: 1.5em;
            position: relative;
        }
        pre button.copy-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: var(--gray-600);
            color: var(--white);
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.8em;
            transition: background-color 0.2s;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        pre button.copy-btn:hover {
            background-color: var(--gray-500);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 1.5em;
        }
        table th, table td {
            border: 1px solid var(--gray-300);
            padding: 8px 12px;
            text-align: left;
        }
        table th {
            background-color: var(--gray-200);
            font-weight: 600;
            color: var(--gray-800);
        }
        table tr:nth-child(even) {
            background-color: var(--gray-100);
        }

        .api-endpoint-box {
            background-color: var(--gray-50);
            border-left: 5px solid var(--primary);
            padding: 15px;
            margin-bottom: 1.5em;
            border-radius: 8px;
        }
        .api-endpoint-box h4 {
            margin-top: 0;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .api-endpoint-box .method {
            background-color: var(--dark);
            color: var(--white);
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.8em;
            font-weight: bold;
            text-transform: uppercase;
        }
        .api-endpoint-box .path {
            font-family: 'Courier New', Courier, monospace;
            font-weight: bold;
            color: var(--dark);
        }

        /* Footer styles (from includes/footer.php, adjusted for new layout) */
        .footer {
            padding: 15px 0;
            margin-top: auto; /* Pushes the footer to the bottom */
            border-top: 1px solid var(--gray-200);
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 15px;
            color: var(--gray-600);
        }
        
        .copyright {
            color: var(--gray-600);
            font-size: 0.9rem;
        }
        
        .logout-link {
            color: var(--danger);
            text-decoration: none;
            transition: color 0.3s;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .logout-link:hover {
            color: #c82333;
        }
        .logout-link strong {
            font-weight: 600;
        }
        .logout-link i {
            font-size: 1em;
        }
        /* End Footer styles */

        @media (max-width: 768px) {
            .doc-container {
                margin: 20px auto;
                padding: 15px;
            }
            h1 { font-size: 2em; }
            h2 { font-size: 1.5em; }
            h3 { font-size: 1.2em; }
            .api-key-display {
                flex-direction: column;
                align-items: flex-start;
            }
            .api-key-display button {
                width: 100%;
                justify-content: center;
            }
             pre {
                font-size: 0.8em;
            }
            pre button.copy-btn {
                position: relative;
                top: auto;
                right: auto;
                width: 100%;
                margin-top: 10px;
            }
            .footer-content {
                flex-direction: column;
                gap: 10px;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <div class="doc-container">
            <h1>Go SDK Documentation</h1>
            <p>This documentation provides a comprehensive guide to integrating with the Earndos Business Intelligence API using the Go programming language. It covers all available endpoints, required parameters, and provides Go-specific code examples to help you get started quickly.</p>

            <div class="api-key-header">
                <h2>Your API Key</h2>
                <?php if ($user_api_key): ?>
                    <div class="api-key-display">
                        <span id="apiKeySpan" data-full-key="<?= htmlspecialchars($user_api_key) ?>">********</span>
                        <button class="btn-api-action" id="toggleApiKey">
                            <i class="fas fa-eye"></i> Show Key
                        </button>
                        <button class="btn-api-action" id="copyApiKey">
                            <i class="fas fa-copy"></i> Copy Key
                        </button>
                    </div>
                <?php else: ?>
                    <p class="no-key-message">You don't have an API key yet. <a href="../settings.php" target="_blank">Create one on your settings page</a> to get started!</p>
                <?php endif; ?>
            </div>

            <h2>API Base URL & Authentication</h2>
            <p>The base URL for all API requests is: <code><?= htmlspecialchars($base_api_url) ?></code></p>

            <h3>Authentication</h3>
            <p>All API requests (except client-side tracking events) require authentication using your unique API Key.</p>
            <p>Include your API Key in the <code>X-API-KEY</code> header for every request.</p>
            <p>Go HTTP clients can set this header easily:</p>
            <pre><code>import (
	"net/http"
)

// ...

req, err := http.NewRequest("GET", "<?= htmlspecialchars($base_api_url) ?>/streams", nil)
if err != nil {
    // handle error
}
req.Header.Set("X-API-KEY", "YOUR_API_KEY_HERE")

// ...
</code></pre>

            <h3>Tracking Code Authentication</h3>
            <p>For client-side tracking events (e.g., from a website JavaScript snippet), use the specific <code>tracking_code</code> associated with your Stream. This code is passed as a query parameter.</p>
            <p>Example: <code><?= htmlspecialchars($base_api_url) ?>/track?code=YOUR_TRACKING_CODE&event=page_view&contact_id=123</code></p>

            <h2>Error Responses</h2>
            <p>The API will return standard HTTP status codes and a JSON object with an <code>error</code> key and optionally <code>details</code>. You should always check the HTTP status code before attempting to parse the response body.</p>
            <table>
                <thead>
                    <tr>
                        <th>HTTP Status Code</th>
                        <th>Meaning</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>200 OK</code></td>
                        <td>Success</td>
                        <td>The request was successful.</td>
                    </tr>
                    <tr>
                        <td><code>201 Created</code></td>
                        <td>Created</td>
                        <td>A new resource was successfully created.</td>
                    </tr>
                    <tr>
                        <td><code>400 Bad Request</code></td>
                        <td>Client Error</td>
                        <td>The request was malformed or missing required parameters.</td>
                    </tr>
                    <tr>
                        <td><code>401 Unauthorized</code></td>
                        <td>Authentication Failed</td>
                        <td>No API Key provided or invalid API Key.</td>
                    </tr>
                    <tr>
                        <td><code>403 Forbidden</code></td>
                        <td>Authorization Failed</td>
                        <td>The API Key is valid, but the user is not authorized to access this resource or perform this action (e.g., trying to access another user's data). Invalid tracking code.</td>
                    </tr>
                    <tr>
                        <td><code>402 Payment Required</code></td>
                        <td>Membership Limit</td>
                        <td>The action cannot be completed due to your membership level limits (e.g., max streams, max contacts).</td>
                    </tr>
                    <tr>
                        <td><code>404 Not Found</code></td>
                        <td>Not Found</td>
                        <td>The requested endpoint or resource does not exist.</td>
                    </tr>
                    <tr>
                        <td><code>405 Method Not Allowed</code></td>
                        <td>Method Not Allowed</td>
                        <td>The HTTP method used is not supported for this endpoint.</td>
                    </tr>
                    <tr>
                        <td><code>409 Conflict</code></td>
                        <td>Conflict</td>
                        <td>The request could not be completed due to a conflict with the current state of the resource (e.g., email already exists).</td>
                    </tr>
                    <tr>
                        <td><code>500 Internal Server Error</code></td>
                        <td>Server Error</td>
                        <td>An unexpected error occurred on the server.</td>
                    </tr>
                </tbody>
            </table>

            <h2>Helper Functions & Structs (Go)</h2>
            <p>It's good practice to define Go structs that match the JSON structure of your API requests and responses. This helps with type safety and makes JSON marshaling/unmarshaling straightforward.</p>
            <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
)

const (
	apiKey = "<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>" // Replace with your actual API Key
	baseURL = "<?= htmlspecialchars($base_api_url) ?>"
)

// APIError represents the structure of an API error response
type APIError struct {
	Error   string `json:"error"`
	Details string `json:"details,omitempty"`
}

// makeRequest is a generic helper function to make API calls
func makeRequest(method, endpoint string, body interface{}, response interface{}) error {
	client := &http.Client{}
	var reqBody bytes.Buffer
	if body != nil {
		if err := json.NewEncoder(&reqBody).Encode(body); err != nil {
			return fmt.Errorf("failed to encode request body: %w", err)
		}
	}

	req, err := http.NewRequest(method, fmt.Sprintf("%s%s", baseURL, endpoint), &reqBody)
	if err != nil {
		return fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("X-API-KEY", apiKey)
	req.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to execute request: %w", err)
	}
	defer resp.Body.Close()

	respBody, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("failed to read response body: %w", err)
	}

	if resp.StatusCode >= 400 {
		var apiErr APIError
		if err := json.Unmarshal(respBody, &apiErr); err != nil {
			return fmt.Errorf("API error (Status: %d): %s", resp.StatusCode, string(respBody))
		}
		return fmt.Errorf("API error (Status: %d): %s - %s", resp.StatusCode, apiErr.Error, apiErr.Details)
	}

	if response != nil {
		if err := json.Unmarshal(respBody, response); err != nil {
			return fmt.Errorf("failed to decode response body: %w", err)
		}
	}
	return nil
}

// TrackingEvent is a generic helper function for the /api/track endpoint (client-side data)
func trackEvent(trackingCode string, eventName string, contactID int, value interface{}, metadata map[string]interface{}) error {
	client := &http.Client{}
	
	// Create query parameters
	q := make(map[string]string)
	q["code"] = trackingCode
	q["event"] = eventName
	
	// Encode data into JSON body
	data := make(map[string]interface{})
	data["contact_id"] = contactID
	data["value"] = value
	if metadata != nil {
		data["metadata"] = metadata
	}

	jsonBody, err := json.Marshal(data)
	if err != nil {
		return fmt.Errorf("failed to marshal tracking data: %w", err)
	}

	req, err := http.NewRequest("POST", fmt.Sprintf("%s/track?code=%s", baseURL, trackingCode), bytes.NewBuffer(jsonBody))
	if err != nil {
		return fmt.Errorf("failed to create track request: %w", err)
	}
	req.Header.Set("Content-Type", "application/json") // No X-API-KEY for track endpoint

	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to execute track request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		respBody, _ := ioutil.ReadAll(resp.Body)
		return fmt.Errorf("track API error (Status: %d): %s", resp.StatusCode, string(respBody))
	}
	return nil
}

// Define structs for common API responses/requests
type SuccessResponse struct {
	Success bool   `json:"success"`
	Message string `json:"message,omitempty"`
}
</code></pre>

            <h2>API Endpoints</h2>

            <h3>1. Streams</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/streams</span></h4>
                <p>Retrieves a list of all streams belonging to the authenticated user.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type Stream struct {
	ID                 int     `json:"id"`
	Name               string  `json:"name"`
	WebsiteURL         string  `json:"website_url"`
	IsApp              bool    `json:"is_app"`
	Description        string  `json:"description"`
	ColorCode          string  `json:"color_code"`
	NicheID            *int    `json:"niche_id"` // Use pointer for nullable fields
	TrackingCode       string  `json:"tracking_code"`
	AcquisitionCost    float64 `json:"acquisition_cost"`
	CoverImage         string  `json:"cover_image"`
	MarketingChannel   string  `json:"marketing_channel"`
	RevenuePerUser     float64 `json:"revenue_per_user"`
	Currency           string  `json:"currency"`
}

func getStreams() ([]Stream, error) {
	var streams []Stream
	err := makeRequest("GET", "/streams", nil, &streams)
	return streams, err
}

func main() {
	streams, err := getStreams()
	if err != nil {
		fmt.Printf("Error getting streams: %v\n", err)
		return
	}

	fmt.Println("Streams:")
	for _, s := range streams {
		fmt.Printf(" - ID: %d, Name: %s, URL: %s, Tracking Code: %s\n", s.ID, s.Name, s.WebsiteURL, s.TrackingCode)
	}
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/streams</span></h4>
                <p>Creates a new stream for the authenticated user.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type CreateStreamRequest struct {
	Name             string  `json:"name"`
	Description      string  `json:"description"`
	ColorCode        string  `json:"color_code"`
	IsApp            bool    `json:"is_app"`
	WebsiteURL       string  `json:"website_url,omitempty"`
	NicheID          *int    `json:"niche_id,omitempty"`
	AcquisitionCost  float64 `json:"acquisition_cost,omitempty"`
	CoverImage       string  `json:"cover_image,omitempty"`
	MarketingChannel string  `json:"marketing_channel,omitempty"`
	RevenuePerUser   float64 `json:"revenue_per_user,omitempty"`
	Currency         string  `json:"currency,omitempty"`
}

type CreateStreamResponse struct {
	Success      bool   `json:"success"`
	StreamID     int    `json:"stream_id"`
	TrackingCode string `json:"tracking_code"`
}

func createStream(reqData CreateStreamRequest) (*CreateStreamResponse, error) {
	var response CreateStreamResponse
	err := makeRequest("POST", "/streams", reqData, &response)
	return &response, err
}

func main() {
	nicheID := 1 // Example niche ID
	newStream := CreateStreamRequest{
		Name:            "Go Lang Project",
		Description:     "Tracking Go application users.",
		ColorCode:       "#ff5733",
		IsApp:           false,
		WebsiteURL:      "https://goapp.example.com",
		NicheID:         &nicheID,
		AcquisitionCost: 20.00,
	}

	res, err := createStream(newStream)
	if err != nil {
		fmt.Printf("Error creating stream: %v\n", err)
		return
	}
	fmt.Printf("Stream created successfully! ID: %d, Tracking Code: %s\n", res.StreamID, res.TrackingCode)
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">DELETE</span> <span class="path">/api/streams/{id}</span></h4>
                <p>Deletes a stream and all its associated data (contacts, features, competitors, cohorts tied to stream). <strong>This action is irreversible.</strong></p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
	"strconv"
)

func deleteStream(streamID int) error {
	endpoint := fmt.Sprintf("/streams/%s", strconv.Itoa(streamID))
	err := makeRequest("DELETE", endpoint, nil, nil)
	return err
}

func main() {
	streamIDToDelete := 123 // Replace with the actual Stream ID you want to delete
	err := deleteStream(streamIDToDelete)
	if err != nil {
		fmt.Printf("Error deleting stream: %v\n", err)
		return
	}
	fmt.Printf("Stream %d deleted successfully.\n", streamIDToDelete)
}
</code></pre>
            </div>

            <h3>2. Cohorts</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/cohorts</span></h4>
                <p>Retrieves all cohorts belonging to the authenticated user.</p>
                <p>Optional query parameter: <code>stream_id</code> to filter cohorts by a specific stream.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
	"net/url"
	"strconv"
)

type Cohort struct {
	ID            int     `json:"id"`
	StreamID      int     `json:"stream_id"`
	Name          string  `json:"name"`
	Description   string  `json:"description"`
	CostPerUser   float64 `json:"cost_per_user"`
	RevenuePerUser float64 `json:"revenue_per_user"`
}

func getCohorts(streamID *int) ([]Cohort, error) {
	endpoint := "/cohorts"
	if streamID != nil {
		params := url.Values{}
		params.Add("stream_id", strconv.Itoa(*streamID))
		endpoint = fmt.Sprintf("%s?%s", endpoint, params.Encode())
	}

	var cohorts []Cohort
	err := makeRequest("GET", endpoint, nil, &cohorts)
	return cohorts, err
}

func main() {
	// Get all cohorts
	cohorts, err := getCohorts(nil)
	if err != nil {
		fmt.Printf("Error getting all cohorts: %v\n", err)
		return
	}
	fmt.Println("All Cohorts:")
	for _, c := range cohorts {
		fmt.Printf(" - ID: %d, Name: %s, StreamID: %d\n", c.ID, c.Name, c.StreamID)
	}

	// Get cohorts filtered by stream
	streamIDFilter := 456 // Replace with your stream ID
	filteredCohorts, err := getCohorts(&streamIDFilter)
	if err != nil {
		fmt.Printf("Error getting filtered cohorts: %v\n", err)
		return
	}
	fmt.Printf("\nCohorts for Stream %d:\n", streamIDFilter)
	for _, c := range filteredCohorts {
		fmt.Printf(" - ID: %d, Name: %s\n", c.ID, c.Name)
	}
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/cohorts</span></h4>
                <p>Creates a new cohort under one of your streams.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type CreateCohortRequest struct {
	StreamID      int     `json:"stream_id"`
	Name          string  `json:"name"`
	Description   string  `json:"description,omitempty"`
	CostPerUser   float64 `json:"cost_per_user,omitempty"`
	RevenuePerUser float64 `json:"revenue_per_user,omitempty"`
}

type CreateCohortResponse struct {
	Success  bool `json:"success"`
	CohortID int  `json:"cohort_id"`
}

func createCohort(reqData CreateCohortRequest) (*CreateCohortResponse, error) {
	var response CreateCohortResponse
	err := makeRequest("POST", "/cohorts", reqData, &response)
	return &response, err
}

func main() {
	newCohort := CreateCohortRequest{
		StreamID:      456, // Replace with your stream ID
		Name:          "Go Users Segment",
		Description:   "Users who signed up via Go application.",
		CostPerUser:   10.50,
		RevenuePerUser: 50.00,
	}

	res, err := createCohort(newCohort)
	if err != nil {
		fmt.Printf("Error creating cohort: %v\n", err)
		return
	}
	fmt.Printf("Cohort created successfully! ID: %d\n", res.CohortID)
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">DELETE</span> <span class="path">/api/cohorts/{id}</span></h4>
                <p>Deletes a cohort and removes all contacts from it. Contacts themselves are NOT deleted.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
	"strconv"
)

func deleteCohort(cohortID int) error {
	endpoint := fmt.Sprintf("/cohorts/%s", strconv.Itoa(cohortID))
	err := makeRequest("DELETE", endpoint, nil, nil)
	return err
}

func main() {
	cohortIDToDelete := 789 // Replace with the actual Cohort ID
	err := deleteCohort(cohortIDToDelete)
	if err != nil {
		fmt.Printf("Error deleting cohort: %v\n", err)
		return
	}
	fmt.Printf("Cohort %d deleted successfully.\n", cohortIDToDelete)
}
</code></pre>
            </div>

            <h3>3. Features</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/features</span></h4>
                <p>Retrieves features associated with a specific stream owned by the authenticated user.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
	"net/url"
	"strconv"
)

type Feature struct {
	ID       int    `json:"id"`
	Name     string `json:"name"`
	URL      string `json:"url"`
	Tags     string `json:"tags"`
	StreamID int    `json:"stream_id"`
}

func getFeatures(streamID int) ([]Feature, error) {
	params := url.Values{}
	params.Add("stream_id", strconv.Itoa(streamID))
	endpoint := fmt.Sprintf("/features?%s", params.Encode())

	var features []Feature
	err := makeRequest("GET", endpoint, nil, &features)
	return features, err
}

func main() {
	streamID := 456 // Replace with your stream ID
	features, err := getFeatures(streamID)
	if err != nil {
		fmt.Printf("Error getting features: %v\n", err)
		return
	}

	fmt.Printf("Features for Stream %d:\n", streamID)
	for _, f := range features {
		fmt.Printf(" - ID: %d, Name: %s, URL: %s, Tags: %s\n", f.ID, f.Name, f.URL, f.Tags)
	}
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/features</span></h4>
                <p>Creates a new feature for a specific stream.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type CreateFeatureRequest struct {
	StreamID int    `json:"stream_id"`
	Name     string `json:"name"`
	URL      string `json:"url,omitempty"`
	Tags     string `json:"tags,omitempty"`
}

type CreateFeatureResponse struct {
	Success   bool `json:"success"`
	FeatureID int  `json:"feature_id"`
}

func createFeature(reqData CreateFeatureRequest) (*CreateFeatureResponse, error) {
	var response CreateFeatureResponse
	err := makeRequest("POST", "/features", reqData, &response)
	return &response, err
}

func main() {
	newFeature := CreateFeatureRequest{
		StreamID: 456, // Replace with your stream ID
		Name:     "Go Dashboard Access",
		URL:      "https://goapp.example.com/dashboard",
		Tags:     "dashboard, access, UI",
	}

	res, err := createFeature(newFeature)
	if err != nil {
		fmt.Printf("Error creating feature: %v\n", err)
		return
	}
	fmt.Printf("Feature created successfully! ID: %d\n", res.FeatureID)
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">DELETE</span> <span class="path">/api/features/{id}</span></h4>
                <p>Deletes a feature.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
	"strconv"
)

func deleteFeature(featureID int) error {
	endpoint := fmt.Sprintf("/features/%s", strconv.Itoa(featureID))
	err := makeRequest("DELETE", endpoint, nil, nil)
	return err
}

func main() {
	featureIDToDelete := 101 // Replace with the actual Feature ID
	err := deleteFeature(featureIDToDelete)
	if err != nil {
		fmt.Printf("Error deleting feature: %v\n", err)
		return
	}
	fmt.Printf("Feature %d deleted successfully.\n", featureIDToDelete)
}
</code></pre>
            </div>

            <h3>4. Competitors</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/competitors</span></h4>
                <p>Retrieves competitors associated with a specific stream owned by the authenticated user.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
	"net/url"
	"strconv"
)

type Competitor struct {
	ID        int    `json:"id"`
	Name      string `json:"name"`
	URL       string `json:"url"`
	IsPricing bool   `json:"is_pricing"`
	StreamID  int    `json:"stream_id"`
}

func getCompetitors(streamID int) ([]Competitor, error) {
	params := url.Values{}
	params.Add("stream_id", strconv.Itoa(streamID))
	endpoint := fmt.Sprintf("/competitors?%s", params.Encode())

	var competitors []Competitor
	err := makeRequest("GET", endpoint, nil, &competitors)
	return competitors, err
}

func main() {
	streamID := 456 // Replace with your stream ID
	competitors, err := getCompetitors(streamID)
	if err != nil {
		fmt.Printf("Error getting competitors: %v\n", err)
		return
	}

	fmt.Printf("Competitors for Stream %d:\n", streamID)
	for _, comp := range competitors {
		fmt.Printf(" - ID: %d, Name: %s, URL: %s, IsPricing: %t\n", comp.ID, comp.Name, comp.URL, comp.IsPricing)
	}
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/competitors</span></h4>
                <p>Creates a new competitor entry for a specific stream.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type CreateCompetitorRequest struct {
	StreamID  int    `json:"stream_id"`
	Name      string `json:"name"`
	URL       string `json:"url"`
	IsPricing bool   `json:"is_pricing,omitempty"`
}

type CreateCompetitorResponse struct {
	Success      bool `json:"success"`
	CompetitorID int  `json:"competitor_id"`
}

func createCompetitor(reqData CreateCompetitorRequest) (*CreateCompetitorResponse, error) {
	var response CreateCompetitorResponse
	err := makeRequest("POST", "/competitors", reqData, &response)
	return &response, err
}

func main() {
	newCompetitor := CreateCompetitorRequest{
		StreamID:  456, // Replace with your stream ID
		Name:      "Another Go App",
		URL:       "https://anothergoapp.com/pricing",
		IsPricing: true,
	}

	res, err := createCompetitor(newCompetitor)
	if err != nil {
		fmt.Printf("Error creating competitor: %v\n", err)
		return
	}
	fmt.Printf("Competitor created successfully! ID: %d\n", res.CompetitorID)
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">DELETE</span> <span class="path">/api/competitors/{id}</span></h4>
                <p>Deletes a competitor.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
	"strconv"
)

func deleteCompetitor(competitorID int) error {
	endpoint := fmt.Sprintf("/competitors/%s", strconv.Itoa(competitorID))
	err := makeRequest("DELETE", endpoint, nil, nil)
	return err
}

func main() {
	competitorIDToDelete := 202 // Replace with the actual Competitor ID
	err := deleteCompetitor(competitorIDToDelete)
	if err != nil {
		fmt.Printf("Error deleting competitor: %v\n", err)
		return
	}
	fmt.Printf("Competitor %d deleted successfully.\n", competitorIDToDelete)
}
</code></pre>
            </div>

            <h3>5. Contacts</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/contacts</span></h4>
                <p>Retrieves contacts for the authenticated user, with optional filters and pagination.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
	"net/url"
	"strconv"
)

type Contact struct {
	ID          int                `json:"id"`
	Username    string             `json:"username"`
	Email       string             `json:"email"`
	ExternalID  string             `json:"external_id"`
	LastActivity string            `json:"last_activity"`
	CustomData  map[string]interface{} `json:"custom_data"` // Or a more specific struct if schema is known
	StreamName  string             `json:"stream_name"`
}

func getContacts(streamID, cohortID *int, search *string, limit, offset *int) ([]Contact, error) {
	params := url.Values{}
	if streamID != nil {
		params.Add("stream_id", strconv.Itoa(*streamID))
	}
	if cohortID != nil {
		params.Add("cohort_id", strconv.Itoa(*cohortID))
	}
	if search != nil {
		params.Add("search", *search)
	}
	if limit != nil {
		params.Add("limit", strconv.Itoa(*limit))
	}
	if offset != nil {
		params.Add("offset", strconv.Itoa(*offset))
	}

	endpoint := "/contacts"
	if len(params) > 0 {
		endpoint = fmt.Sprintf("%s?%s", endpoint, params.Encode())
	}

	var contacts []Contact
	err := makeRequest("GET", endpoint, nil, &contacts)
	return contacts, err
}

func main() {
	// Example: Get contacts for a specific stream, with search and pagination
	streamID := 456
	searchQuery := "test"
	limit := 5
	offset := 0

	contacts, err := getContacts(&streamID, nil, &searchQuery, &limit, &offset)
	if err != nil {
		fmt.Printf("Error getting contacts: %v\n", err)
		return
	}

	fmt.Println("Contacts:")
	for _, c := range contacts {
		fmt.Printf(" - ID: %d, Email: %s, Stream: %s, LastActivity: %s\n", c.ID, c.Email, c.StreamName, c.LastActivity)
	}
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/contacts</span></h4>
                <p>Creates a new contact for a specified stream. Can optionally assign to cohorts and include custom data.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type CreateContactRequest struct {
	StreamID   int                    `json:"stream_id"`
	Email      string                 `json:"email"`
	Username   string                 `json:"username,omitempty"`
	ExternalID string                 `json:"external_id,omitempty"`
	CustomData map[string]interface{} `json:"custom_data,omitempty"`
	CohortIDs  []int                  `json:"cohort_ids,omitempty"`
}

type CreateContactResponse struct {
	Success   bool `json:"success"`
	ContactID int  `json:"contact_id"`
}

func createContact(reqData CreateContactRequest) (*CreateContactResponse, error) {
	var response CreateContactResponse
	err := makeRequest("POST", "/contacts", reqData, &response)
	return &response, err
}

func main() {
	newContact := CreateContactRequest{
		StreamID:   456, // Replace with your stream ID
		Email:      "go.user@example.com",
		Username:   "go_user_1",
		ExternalID: "GO_USER_XYZ",
		CustomData: map[string]interface{}{
			"go_version": "1.22",
			"preferred_plan": "Enterprise",
		},
		CohortIDs: []int{789}, // Replace with actual cohort IDs if any
	}

	res, err := createContact(newContact)
	if err != nil {
		fmt.Printf("Error creating contact: %v\n", err)
		return
	}
	fmt.Printf("Contact created successfully! ID: %d\n", res.ContactID)
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">PUT</span> <span class="path">/api/contacts/{id}</span></h4>
                <p>Updates an existing contact's details or cohort assignments.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
	"strconv"
)

type UpdateContactRequest struct {
	Username          string                 `json:"username,omitempty"`
	Email             string                 `json:"email,omitempty"`
	ExternalID        string                 `json:"external_id,omitempty"`
	CustomData        map[string]interface{} `json:"custom_data,omitempty"` // Replaces existing custom_data
	UpdateCustomFields map[string]interface{} `json:"update_custom_fields,omitempty"` // Updates specific custom fields
	DeleteCustomFields []string               `json:"delete_custom_fields,omitempty"` // Deletes specific custom fields
	AddToLists        []int                  `json:"add_to_cohorts,omitempty"` // Corrected field name based on API
	RemoveFromLists   []int                  `json:"remove_from_cohorts,omitempty"` // Corrected field name based on API
}

func updateContact(contactID int, reqData UpdateContactRequest) error {
	endpoint := fmt.Sprintf("/contacts/%s", strconv.Itoa(contactID))
	err := makeRequest("PUT", endpoint, reqData, nil)
	return err
}

func main() {
	contactIDToUpdate := 321 // Replace with the actual Contact ID
	
	updateData := UpdateContactRequest{
		Username: "go_user_updated",
		UpdateCustomFields: map[string]interface{}{
			"last_login_client": "Go Client",
			"user_tier":         "Premium",
		},
		AddToLists: []int{987}, // Add to cohort ID 987
		RemoveFromLists: []int{789}, // Remove from cohort ID 789
	}

	err := updateContact(contactIDToUpdate, updateData)
	if err != nil {
		fmt.Printf("Error updating contact: %v\n", err)
		return
	}
	fmt.Printf("Contact %d updated successfully.\n", contactIDToUpdate)
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">DELETE</span> <span class="path">/api/contacts/{id}</span></h4>
                <p>Deletes a contact and all its associated data (metric data, churn scores, cohort associations, churn/resurrection records). <strong>This action is irreversible.</strong></p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
	"strconv"
)

func deleteContact(contactID int) error {
	endpoint := fmt.Sprintf("/contacts/%s", strconv.Itoa(contactID))
	err := makeRequest("DELETE", endpoint, nil, nil)
	return err
}

func main() {
	contactIDToDelete := 321 // Replace with the actual Contact ID
	err := deleteContact(contactIDToDelete)
	if err != nil {
		fmt.Printf("Error deleting contact: %v\n", err)
		return
	}
	fmt.Printf("Contact %d and all related data deleted successfully.\n", contactIDToDelete)
}
</code></pre>
            </div>

            <h3>6. Metrics & Churn Data</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/metrics</span></h4>
                <p>Submits a new data point for a predefined or custom metric for a specific contact.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type SubmitMetricRequest struct {
	ContactID  int         `json:"contact_id"`
	MetricName string      `json:"metric_name"`
	Value      interface{} `json:"value"` // Can be string, number, bool
}

func submitMetric(reqData SubmitMetricRequest) error {
	err := makeRequest("POST", "/metrics", reqData, nil)
	return err
}

func main() {
	// Example: Submit a predefined metric (payment_status)
	err := submitMetric(SubmitMetricRequest{
		ContactID:  321, // Replace with contact ID
		MetricName: "payment_status",
		Value:      "completed",
	})
	if err != nil {
		fmt.Printf("Error submitting payment_status metric: %v\n", err)
	} else {
		fmt.Println("Payment status metric submitted successfully.")
	}

	// Example: Submit a custom metric
	err = submitMetric(SubmitMetricRequest{
		ContactID:  321, // Replace with contact ID
		MetricName: "go_feature_usage_count",
		Value:      15, // Example value
	})
	if err != nil {
		fmt.Printf("Error submitting custom metric: %v\n", err)
	} else {
		fmt.Println("Custom metric 'go_feature_usage_count' submitted successfully.")
	}
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/metrics</span></h4>
                <p>Retrieves all metric data points for a specific contact. This fetches both predefined and custom metrics.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
	"net/url"
	"strconv"
)

type MetricData struct {
	MetricName  string      `json:"metric_name"`
	Value       interface{} `json:"value"`
	RecordedAt  string      `json:"recorded_at"`
	Source      string      `json:"source"`
	Type        string      `json:"type"` // 'predefined' or 'custom'
}

func getContactMetrics(contactID int) ([]MetricData, error) {
	params := url.Values{}
	params.Add("contact_id", strconv.Itoa(contactID))
	endpoint := fmt.Sprintf("/metrics?%s", params.Encode())

	var metrics []MetricData
	err := makeRequest("GET", endpoint, nil, &metrics)
	return metrics, err
}

func main() {
	contactID := 321 // Replace with contact ID
	metrics, err := getContactMetrics(contactID)
	if err != nil {
		fmt.Printf("Error getting contact metrics: %v\n", err)
		return
	}

	fmt.Printf("Metrics for Contact %d:\n", contactID)
	for _, m := range metrics {
		fmt.Printf(" - Name: %s, Value: %v, Recorded: %s, Type: %s\n", m.MetricName, m.Value, m.RecordedAt, m.Type)
	}
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/mark-churned</span></h4>
                <p>Marks a contact as churned and records a reason.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type MarkChurnedRequest struct {
	ContactID int    `json:"contact_id"`
	Reason    string `json:"reason,omitempty"`
}

func markChurned(reqData MarkChurnedRequest) error {
	err := makeRequest("POST", "/mark-churned", reqData, nil)
	return err
}

func main() {
	err := markChurned(MarkChurnedRequest{
		ContactID: 321, // Replace with contact ID
		Reason:    "Reduced engagement over time",
	})
	if err != nil {
		fmt.Printf("Error marking contact churned: %v\n", err)
		return
	}
	fmt.Printf("Contact %d marked as churned successfully.\n", 321)
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/mark-resurrected</span></h4>
                <p>Marks a contact as resurrected (if they were previously churned) and removes them from the churned list.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type MarkResurrectedRequest struct {
	ContactID int `json:"contact_id"`
}

func markResurrected(reqData MarkResurrectedRequest) error {
	err := makeRequest("POST", "/mark-resurrected", reqData, nil)
	return err
}

func main() {
	err := markResurrected(MarkResurrectedRequest{
		ContactID: 321, // Replace with contact ID
	})
	if err != nil {
		fmt.Printf("Error marking contact resurrected: %v\n", err)
		return
	}
	fmt.Printf("Contact %d marked as resurrected successfully.\n", 321)
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/churn-scores</span></h4>
                <p>Retrieves churn scores for contacts. Requires either a <code>stream_id</code> or a <code>contact_id</code>.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
	"net/url"
	"strconv"
)

type ChurnScore struct {
	ContactID int     `json:"contact_id"`
	Username  string  `json:"username"`
	Email     string  `json:"email"`
	Score     float64 `json:"score"`
	ScoredAt  string  `json:"scored_at"`
	Report    string  `json:"report"` // JSON string of the report
}

func getChurnScores(streamID, contactID *int) ([]ChurnScore, error) {
	params := url.Values{}
	if streamID != nil {
		params.Add("stream_id", strconv.Itoa(*streamID))
	} else if contactID != nil {
		params.Add("contact_id", strconv.Itoa(*contactID))
	} else {
		return nil, fmt.Errorf("either streamID or contactID must be provided")
	}

	endpoint := fmt.Sprintf("/churn-scores?%s", params.Encode())

	var scores []ChurnScore
	err := makeRequest("GET", endpoint, nil, &scores)
	return scores, err
}

func main() {
	// Get score for a specific contact
	contactID := 321
	scores, err := getChurnScores(nil, &contactID)
	if err != nil {
		fmt.Printf("Error getting churn scores for contact %d: %v\n", contactID, err)
		return
	}
	for _, s := range scores {
		fmt.Printf("Contact %d Churn Score: %.2f%% (as of %s)\n", s.ContactID, s.Score, s.ScoredAt)
	}

	// Get scores for a specific stream
	streamID := 456
	scoresByStream, err := getChurnScores(&streamID, nil)
	if err != nil {
		fmt.Printf("Error getting churn scores for stream %d: %v\n", streamID, err)
		return
	}
	fmt.Printf("\nChurn Scores for Stream %d:\n", streamID)
	for _, s := range scoresByStream {
		fmt.Printf(" - Contact ID: %d, Score: %.2f%%\n", s.ContactID, s.Score)
	}
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/churn-calculate</span></h4>
                <p>Triggers the AI churn score calculation for a single contact. This can be used for on-demand scoring.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type CalculateChurnRequest struct {
	ContactID int `json:"contact_id"`
}

type CalculateChurnResponse struct {
	Success bool                   `json:"success"`
	ContactID int                  `json:"contact_id"`
	Score     float64                `json:"score"`
	Report    map[string]interface{} `json:"report"` // Decoded JSON report
	ModelUsed string                 `json:"model_used"`
}

func calculateChurnScore(reqData CalculateChurnRequest) (*CalculateChurnResponse, error) {
	var response CalculateChurnResponse
	err := makeRequest("POST", "/churn-calculate", reqData, &response)
	return &response, err
}

func main() {
	contactID := 321 // Replace with contact ID
	res, err := calculateChurnScore(CalculateChurnRequest{ContactID: contactID})
	if err != nil {
		fmt.Printf("Error calculating churn score for contact %d: %v\n", contactID, err)
		return
	}
	fmt.Printf("Churn score calculated for Contact %d: %.2f%% (Model: %s)\n", res.ContactID, res.Score, res.ModelUsed)
	fmt.Printf("Report Summary: %s\n", res.Report["summary"])
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/churn-batch-calculate</span></h4>
                <p>Triggers a batch AI churn score calculation for contacts within a specific stream that need re-scoring (e.g., new data, old score). Useful for cron jobs.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type CalculateBatchChurnRequest struct {
	StreamID int `json:"stream_id"`
}

type BatchChurnResult struct {
	ContactID int     `json:"contact_id"`
	Score     float64 `json:"score,omitempty"`
	Status    string  `json:"status"` // "success", "skipped", "failed"
	Reason    string  `json:"reason,omitempty"`
}

type CalculateBatchChurnResponse struct {
	Success          bool               `json:"success"`
	ProcessedContacts int                `json:"processed_contacts"`
	Results          []BatchChurnResult `json:"results"`
}

func calculateBatchChurnScores(reqData CalculateBatchChurnRequest) (*CalculateBatchChurnResponse, error) {
	var response CalculateBatchChurnResponse
	err := makeRequest("POST", "/churn-batch-calculate", reqData, &response)
	return &response, err
}

func main() {
	streamID := 456 // Replace with your stream ID
	res, err := calculateBatchChurnScores(CalculateBatchChurnRequest{StreamID: streamID})
	if err != nil {
		fmt.Printf("Error calculating batch churn scores for stream %d: %v\n", streamID, err)
		return
	}
	fmt.Printf("Batch churn calculation initiated for stream %d. Processed %d contacts.\n", streamID, res.ProcessedContacts)
	for _, result := range res.Results {
		fmt.Printf(" - Contact %d: Status: %s, Score: %.2f%% (Reason: %s)\n", result.ContactID, result.Status, result.Score, result.Reason)
	}
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/winback-suggestions</span></h4>
                <p>Generates and stores win-back suggestions for a specific contact based on their churn score and metrics. Uses internal logic (placeholder for AI).</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type GenerateWinbackSuggestionsRequest struct {
	ContactID int `json:"contact_id"`
}

type GenerateWinbackSuggestionsResponse struct {
	Success    bool     `json:"success"`
	Suggestions []string `json:"suggestions"`
}

func generateWinbackSuggestions(reqData GenerateWinbackSuggestionsRequest) (*GenerateWinbackSuggestionsResponse, error) {
	var response GenerateWinbackSuggestionsResponse
	err := makeRequest("POST", "/winback-suggestions", reqData, &response)
	return &response, err
}

func main() {
	contactID := 321 // Replace with contact ID
	res, err := generateWinbackSuggestions(GenerateWinbackSuggestionsRequest{ContactID: contactID})
	if err != nil {
		fmt.Printf("Error generating win-back suggestions for contact %d: %v\n", contactID, err)
		return
	}
	fmt.Printf("Win-back suggestions for Contact %d:\n", contactID)
	for i, s := range res.Suggestions {
		fmt.Printf(" %d. %s\n", i+1, s)
	}
}
</code></pre>
            </div>

            <h3>7. Notifications</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/notifications</span></h4>
                <p>Retrieves all notifications for the authenticated user, ordered by creation date (newest first).</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type Notification struct {
	ID         int    `json:"id"`
	Title      string `json:"title"`
	Message    string `json:"message"`
	IsRead     bool   `json:"is_read"`
	CreatedAt  string `json:"created_at"`
	ReadAt     string `json:"read_at"`
	Type       string `json:"type"`
	RelatedID  *int   `json:"related_id,omitempty"`
	RelatedURL string `json:"related_url,omitempty"`
}

func getNotifications() ([]Notification, error) {
	var notifications []Notification
	err := makeRequest("GET", "/notifications", nil, &notifications)
	return notifications, err
}

func main() {
	notifications, err := getNotifications()
	if err != nil {
		fmt.Printf("Error getting notifications: %v\n", err)
		return
	}

	fmt.Println("Notifications:")
	for _, n := range notifications {
		readStatus := "Unread"
		if n.IsRead {
			readStatus = "Read"
		}
		fmt.Printf(" - ID: %d, Title: %s, Type: %s, Status: %s, Created: %s\n", n.ID, n.Title, n.Type, readStatus, n.CreatedAt)
	}
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">PUT</span> <span class="path">/api/notifications/{id}/mark-read</span></h4>
                <p>Marks a specific notification as read for the authenticated user.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
	"strconv"
)

func markNotificationAsRead(notificationID int) error {
	endpoint := fmt.Sprintf("/notifications/%s/mark-read", strconv.Itoa(notificationID))
	err := makeRequest("PUT", endpoint, nil, nil)
	return err
}

func main() {
	notificationIDToMarkRead := 55 // Replace with actual notification ID
	err := markNotificationAsRead(notificationIDToMarkRead)
	if err != nil {
		fmt.Printf("Error marking notification %d as read: %v\n", notificationIDToMarkRead, err)
		return
	}
	fmt.Printf("Notification %d marked as read successfully.\n", notificationIDToMarkRead)
}
</code></pre>
            </div>

            <h3>8. User Profile & Settings</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/profile</span></h4>
                <p>Retrieves the authenticated user's full profile details (company info, personal info, notification preferences, integration keys).</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type UserProfile struct {
	Username          string `json:"username"`
	Email             string `json:"email"`
	ProfilePic        string `json:"profile_pic,omitempty"`
	CompanyName       string `json:"company_name,omitempty"`
	Industry          string `json:"industry,omitempty"`
	CompanySize       string `json:"company_size,omitempty"`
	CompanyInfo       string `json:"company_info,omitempty"`
	FullName          string `json:"full_name,omitempty"`
	AlertIsEmail      bool   `json:"alert_is_email"`
	AlertIsSMS        bool   `json:"alert_is_sms"`
	PhoneNumber       string `json:"phone_number,omitempty"`
	WebhookType       string `json:"webhook_type,omitempty"`
	WebhookURL        string `json:"webhook_url,omitempty"`
	StripeKey         string `json:"stripe_key,omitempty"`
	ChargebeeKey      string `json:"chargebee_key,omitempty"`
	SegmentKey        string `json:"segment_key,omitempty"`
	ZendeskKey        string `json:"zendesk_key,omitempty"`
	FreshdeskKey      string `json:"freshdesk_key,omitempty"`
	ZapierWebhook     string `json:"zapier_webhook,omitempty"`
	WebhookSlack      string `json:"webhook_slack,omitempty"`
	WebhookTeams      string `json:"webhook_teams,omitempty"`
	WebhookDiscord    string `json:"webhook_discord,omitempty"`
}

func getUserProfile() (*UserProfile, error) {
	var profile UserProfile
	err := makeRequest("GET", "/profile", nil, &profile)
	return &profile, err
}

func main() {
	profile, err := getUserProfile()
	if err != nil {
		fmt.Printf("Error getting user profile: %v\n", err)
		return
	}

	fmt.Println("User Profile:")
	fmt.Printf(" - Username: %s\n", profile.Username)
	fmt.Printf(" - Email: %s\n", profile.Email)
	fmt.Printf(" - Company: %s (%s)\n", profile.CompanyName, profile.Industry)
	fmt.Printf(" - Email Alerts: %t, SMS Alerts: %t\n", profile.AlertIsEmail, profile.AlertIsSMS)
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">PUT</span> <span class="path">/api/profile</span></h4>
                <p>Updates the authenticated user's profile details. Only include the fields you wish to update.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

// UpdateUserProfileRequest includes fields that can be updated.
// Omit fields not being updated.
type UpdateUserProfileRequest struct {
	CompanyName    string `json:"company_name,omitempty"`
	Industry       string `json:"industry,omitempty"`
	FullName       string `json:"full_name,omitempty"`
	PhoneNumber    string `json:"phone_number,omitempty"`
	AlertIsEmail   *bool  `json:"alert_is_email,omitempty"` // Use pointer to differentiate between false and unset
	AlertIsSMS     *bool  `json:"alert_is_sms,omitempty"`   // Use pointer
	WebhookSlack   string `json:"webhook_slack,omitempty"`
	StripeKey      string `json:"stripe_key,omitempty"`
	// Add other fields from user_profiles as needed
}

func updateUserProfile(reqData UpdateUserProfileRequest) error {
	err := makeRequest("PUT", "/profile", reqData, nil)
	return err
}

func main() {
	// Example: Update company name and enable SMS alerts
	enableSMS := true
	updateData := UpdateUserProfileRequest{
		CompanyName: "Go Solutions Inc.",
		Industry:    "Technology",
		AlertIsSMS:  &enableSMS,
	}

	err := updateUserProfile(updateData)
	if err != nil {
		fmt.Printf("Error updating user profile: %v\n", err)
		return
	}
	fmt.Println("User profile updated successfully.")
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/settings</span></h4>
                <p>Retrieves the authenticated user's general settings, including API keys, tracking method, and payment method details.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type APIKey struct {
	ID           int    `json:"id"`
	APIKey       string `json:"api_key"`
	CreatedAt    string `json:"created_at"`
	LastUsed     string `json:"last_used"`
	TrackingMethod string `json:"tracking_method"`
}

type PaymentMethod struct {
	Method        string `json:"method"`
	PaypalEmail   string `json:"paypal_email"`
	BankName      string `json:"bank_name"`
	AccountName   string `json:"account_name"`
	AccountNumber string `json:"account_number"`
	RoutingNumber string `json:"routing_number"`
	UsdtWallet    string `json:"usdt_wallet"`
}

type UserSettings struct {
	APIKeys        []APIKey      `json:"api_keys"`
	PaymentMethods *PaymentMethod `json:"payment_methods"` // Use pointer for nullable object
}

func getUserSettings() (*UserSettings, error) {
	var settings UserSettings
	err := makeRequest("GET", "/settings", nil, &settings)
	return &settings, err
}

func main() {
	settings, err := getUserSettings()
	if err != nil {
		fmt.Printf("Error getting user settings: %v\n", err)
		return
	}

	fmt.Println("User Settings:")
	if len(settings.APIKeys) > 0 {
		fmt.Println(" - API Keys:")
		for _, key := range settings.APIKeys {
			fmt.Printf("   - ID: %d, Key: %s, Tracking: %s\n", key.ID, key.APIKey, key.TrackingMethod)
		}
	}
	if settings.PaymentMethods != nil {
		fmt.Printf(" - Payment Method: %s\n", settings.PaymentMethods.Method)
		// Print details based on method type
	}
}
</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">PUT</span> <span class="path">/api/settings</span></h4>
                <p>Updates the authenticated user's general settings. Only include the fields you wish to update.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

type UpdateSettingsRequest struct {
	TrackingMethod string         `json:"tracking_method,omitempty"`
	PaymentMethod  *PaymentMethod `json:"payment_method,omitempty"` // Use pointer for optional struct
}

// PaymentMethod struct as defined in GET /api/settings example

func updateUserSettings(reqData UpdateSettingsRequest) error {
	err := makeRequest("PUT", "/settings", reqData, nil)
	return err
}

func main() {
	// Example 1: Update Tracking Method
	err := updateUserSettings(UpdateSettingsRequest{
		TrackingMethod: "non_gdpr",
	})
	if err != nil {
		fmt.Printf("Error updating tracking method: %v\n", err)
	} else {
		fmt.Println("Tracking method updated successfully.")
	}

	// Example 2: Update Payment Method (PayPal)
	paypalMethod := PaymentMethod{
		Method: "paypal",
		PaypalEmail: "go.dev@example.com",
	}
	err = updateUserSettings(UpdateSettingsRequest{
		PaymentMethod: &paypalMethod,
	})
	if err != nil {
		fmt.Printf("Error updating PayPal method: %v\n", err)
	} else {
		fmt.Println("PayPal method updated successfully.")
	}
}
</code></pre>
            </div>

            <h3>9. Tracking Endpoint (Client-side / JavaScript)</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/track?code=YOUR_TRACKING_CODE</span></h4>
                <p>Submit various tracking events (e.g., page views, feature usage, competitor visits, custom events). Authentication for this endpoint uses the Stream's unique <code>tracking_code</code> passed as a query parameter.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>package main

import (
	"fmt"
)

// trackEvent function is already defined in the Helper Functions & Structs section.
// This is an example of how to call it directly.

func main() {
	trackingCode := "YOUR_STREAM_TRACKING_CODE" // Replace with your stream's tracking code
	contactID := 321                             // Replace with contact ID in your system
	
	// Example 1: Track a feature usage event
	err := trackEvent(
		trackingCode,
		"dashboard_viewed",
		contactID,
		"true", // Value for boolean-like events
		map[string]interface{}{"screen_resolution": "1920x1080"},
	)
	if err != nil {
		fmt.Printf("Error tracking dashboard_viewed: %v\n", err)
	} else {
		fmt.Println("Dashboard view tracking event sent.")
	}

	// Example 2: Track a custom metric event (e.g., 'items_added_to_cart')
	err = trackEvent(
		trackingCode,
		"items_added_to_cart", // This will be created as a custom metric if not exists
		contactID,
		5, // Value for numeric events
		nil,
	)
	if err != nil {
		fmt.Printf("Error tracking items_added_to_cart: %v\n", err)
	} else {
		fmt.Println("Items added to cart tracking event sent.")
	}
}
</code></pre>
            </div>

            <h2>Important Notes:</h2>
            <ul>
                <li>Replace <code>YOUR_API_KEY</code> and <code>YOUR_STREAM_TRACKING_CODE</code> with your actual keys.</li>
                <li>All <code>{id}</code> in paths are placeholders for actual numerical IDs.</li>
                <li>Ensure you handle network errors and API error responses gracefully in your Go application.</li>
                <li>For production, consider using a dedicated Go HTTP client library (e.g., `gorilla/mux` for routing if building a server, or just standard `net/http` for client-side) and error handling strategies suitable for your application.</li>
                <li>Go requires explicit type conversion where mixed types are involved. Pay attention to `strconv.Itoa` for int-to-string conversion in URLs and `json.Marshal`/`json.Unmarshal` for JSON handling.</li>
                <li>Fields marked with `,omitempty` in Go structs will be omitted from the JSON payload if their value is the zero value for their type (e.g., `false` for bool, `""` for string, `0` for int/float, or `nil` for pointers). Use pointers (`*bool`, `*int`) for optional boolean/integer fields if `false`/`0` is a meaningful value that you *do* want to send.</li>
            </ul>

        </div>
        <?php require_once '../includes/footer.php'; ?>
    </div>

    <script>
        // Initialize Feather Icons
        feather.replace();

        // API Key Visibility Toggle
        const apiKeySpan = document.getElementById('apiKeySpan');
        const toggleApiKeyBtn = document.getElementById('toggleApiKey');
        const copyApiKeyBtn = document.getElementById('copyApiKey');

        if (apiKeySpan && toggleApiKeyBtn && copyApiKeyBtn) {
            let isKeyVisible = false;
            const fullKey = apiKeySpan.dataset.fullKey;

            toggleApiKeyBtn.addEventListener('click', function() {
                isKeyVisible = !isKeyVisible;
                if (isKeyVisible) {
                    apiKeySpan.textContent = fullKey;
                    toggleApiKeyBtn.innerHTML = '<i class="fas fa-eye-slash"></i> Hide Key';
                } else {
                    apiKeySpan.textContent = '********';
                    toggleApiKeyBtn.innerHTML = '<i class="fas fa-eye"></i> Show Key';
                }
            });

            copyApiKeyBtn.addEventListener('click', function() {
                // Temporarily unmask key to copy, then re-mask
                const originalText = apiKeySpan.textContent;
                apiKeySpan.textContent = fullKey; // Show full key for copying

                navigator.clipboard.writeText(fullKey).then(() => {
                    copyApiKeyBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
                    setTimeout(() => {
                        copyApiKeyBtn.innerHTML = '<i class="fas fa-copy"></i> Copy Key';
                        // Revert visibility if it was hidden
                        if (!isKeyVisible) {
                            apiKeySpan.textContent = originalText; // Restore masked state
                        }
                    }, 1500);
                }).catch(err => {
                    console.error('Failed to copy API key: ', err);
                    alert('Failed to copy API key. Please copy it manually.');
                });
            });
        }

        // Copy button functionality for all <pre> blocks
        document.querySelectorAll('pre button.copy-btn').forEach(button => {
            button.addEventListener('click', function() {
                const codeBlock = this.nextElementSibling; // The <code> tag
                if (codeBlock && codeBlock.tagName === 'CODE') {
                    const textToCopy = codeBlock.textContent;
                    navigator.clipboard.writeText(textToCopy).then(() => {
                        this.innerHTML = '<i class="fas fa-check"></i> Copied!';
                        setTimeout(() => {
                            this.innerHTML = '<i class="fas fa-copy"></i> Copy';
                        }, 1500);
                    }).catch(err => {
                        console.error('Failed to copy Go code: ', err);
                        alert('Failed to copy code. Please copy it manually.');
                    });
                }
            });
        });
    </script>
</body>
</html>
