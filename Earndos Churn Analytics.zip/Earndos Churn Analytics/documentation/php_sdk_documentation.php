<?php
// documentations/php_sdk_documentation.php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

require_once '../includes/db.php'; // Path from documentations/ to includes/db.php
require_once '../includes/header.php'; // Includes global HTML head, meta, and possibly global CSS/JS.

$current_user_id = $_SESSION['user_id'];
$base_api_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . "/api/index.php"; // Adjust if your API is under a different path like /api/v1/

// --- Fetch User's API Key ---
$user_api_key = null;
$stmt_api_key = $pdo->prepare("SELECT api_key FROM user_api_keys WHERE user_id = :user_id ORDER BY created_at DESC LIMIT 1");
$stmt_api_key->bindValue(':user_id', $current_user_id, PDO::PARAM_INT);
$stmt_api_key->execute();
$api_key_data = $stmt_api_key->fetch(PDO::FETCH_ASSOC);

if ($api_key_data) {
    $user_api_key = $api_key_data['api_key'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP SDK Documentation</title>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <!-- Include Font Awesome for the eye icon if not already in header.php -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"
            xintegrity="sha512-Tn2m0TIpgVyTzzvmxLNuqbSJH3JP8jm+Cy3hvHrW7ndTDcJ1w5mBiksqDBb8GpE2ksktFvDB/ykZ0mDpsZj20w=="
            crossorigin="anonymous"
            referrerpolicy="no-referrer"></script>
    <style>
        /* Base styles consistent with dashboard/explore/profile */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
        }

        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer */
        }

        .site-wrapper { /* Main flex container for sticky footer */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .doc-container {
            max-width: 900px;
            margin: 40px auto;
            padding: 20px;
            box-sizing: border-box;
            flex-grow: 1; /* Allows content area to expand and push footer down */
            border-radius: 12px;
        }

        h1, h2, h3, h4 {
            color: var(--dark);
            margin-top: 1.5em;
            margin-bottom: 0.8em;
        }

        h1 { font-size: 2.5em; text-align: center; margin-bottom: 1em; }
        h2 { font-size: 2em; border-bottom: 2px solid var(--gray-200); padding-bottom: 0.5em; margin-top: 2em; }
        h3 { font-size: 1.5em; color: var(--primary); }
        h4 { font-size: 1.2em; color: var(--gray-800); }

        p {
            margin-bottom: 1em;
        }

        ul {
            list-style-type: disc;
            margin-left: 20px;
            margin-bottom: 1em;
        }

        strong {
            color: var(--gray-800);
        }

        a {
            color: var(--info);
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }

        .api-key-header {
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #000000;
            margin-bottom: 30px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
            text-align: center;
        }
        .api-key-header h2 {
            margin: 0;
            padding-bottom: 0;
            border-bottom: none;
            font-size: 1.8em;
        }
        .api-key-display {
            font-family: 'Courier New', Courier, monospace;
            padding: 10px 15px;
            border-radius: 8px;
            font-size: 0.9em;
            color: var(--gray-800);
            display: flex;
            align-items: center;
            gap: 10px;
            max-width: 100%;
            overflow-x: auto;
        }
        .api-key-display span {
            white-space: nowrap; /* Prevent key from wrapping */
        }
        .btn-api-action {
            background-color: var(--primary);
            color: var(--white);
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: background-color 0.2s;
            font-size: 0.9em;
        }
        .btn-api-action:hover {
            background-color: #2da89e;
        }
        .btn-api-action i {
            width: 16px;
            height: 16px;
        }
        .no-key-message {
            color: var(--danger);
            font-weight: 500;
        }
        .no-key-message a {
            color: var(--danger);
            text-decoration: underline;
        }


        code {
            background-color: #68d391;
            padding: 2px 4px;
            border-radius: 4px;
            font-family: 'Courier New', Courier, monospace;
            font-size: 0.9em;
            font-weight: 900;
            color: var(--dark);
        }

        pre {
            background-color: var(--gray-800);
            color: var(--white);
            padding: 15px;
            border-radius: 8px;
            overflow-x: auto;
            font-family: 'Courier New', Courier, monospace;
            font-size: 0.9em;
            line-height: 1.4;
            margin-bottom: 1.5em;
            position: relative;
        }
        pre button.copy-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: var(--gray-600);
            color: var(--white);
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.8em;
            transition: background-color 0.2s;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        pre button.copy-btn:hover {
            background-color: var(--gray-500);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 1.5em;
        }
        table th, table td {
            border: 1px solid var(--gray-300);
            padding: 8px 12px;
            text-align: left;
        }
        table th {
            background-color: var(--gray-200);
            font-weight: 600;
            color: var(--gray-800);
        }
        table tr:nth-child(even) {
            background-color: var(--gray-100);
        }

        .api-endpoint-box {
            background-color: var(--gray-50);
            border-left: 5px solid var(--primary);
            padding: 15px;
            margin-bottom: 1.5em;
            border-radius: 8px;
        }
        .api-endpoint-box h4 {
            margin-top: 0;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .api-endpoint-box .method {
            background-color: var(--dark);
            color: var(--white);
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.8em;
            font-weight: bold;
            text-transform: uppercase;
        }
        .api-endpoint-box .path {
            font-family: 'Courier New', Courier, monospace;
            font-weight: bold;
            color: var(--dark);
        }

        /* Footer styles (from includes/footer.php, adjusted for new layout) */
        .footer {
            padding: 15px 0;
            margin-top: auto; /* Pushes the footer to the bottom */
            border-top: 1px solid var(--gray-200);
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 15px;
            color: var(--gray-600);
        }
        
        .copyright {
            color: var(--gray-600);
            font-size: 0.9rem;
        }
        
        .logout-link {
            color: var(--danger);
            text-decoration: none;
            transition: color 0.3s;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .logout-link:hover {
            color: #c82333;
        }
        .logout-link strong {
            font-weight: 600;
        }
        .logout-link i {
            font-size: 1em;
        }
        /* End Footer styles */

        @media (max-width: 768px) {
            .doc-container {
                margin: 20px auto;
                padding: 15px;
            }
            h1 { font-size: 2em; }
            h2 { font-size: 1.5em; }
            h3 { font-size: 1.2em; }
            .api-key-display {
                flex-direction: column;
                align-items: flex-start;
            }
            .api-key-display button {
                width: 100%;
                justify-content: center;
            }
             pre {
                font-size: 0.8em;
            }
            pre button.copy-btn {
                position: relative;
                top: auto;
                right: auto;
                width: 100%;
                margin-top: 10px;
            }
            .footer-content {
                flex-direction: column;
                gap: 10px;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <div class="doc-container">
            <h1>PHP SDK Documentation</h1>
            <p>This documentation provides a comprehensive guide to integrating with the Earndos Business Intelligence API using PHP. It covers all available endpoints, required parameters, and provides code examples to help you get started quickly.</p>

            <div class="api-key-header">
                <h2>Your API Key</h2>
                <?php if ($user_api_key): ?>
                    <div class="api-key-display">
                        <span id="apiKeySpan" data-full-key="<?= htmlspecialchars($user_api_key) ?>">********</span>
                        <button class="btn-api-action" id="toggleApiKey">
                            <i class="fas fa-eye"></i> Show Key
                        </button>
                        <button class="btn-api-action" id="copyApiKey">
                            <i class="fas fa-copy"></i> Copy Key
                        </button>
                    </div>
                <?php else: ?>
                    <p class="no-key-message">You don't have an API key yet. <a href="../settings.php" target="_blank">Create one on your settings page</a> to get started!</p>
                <?php endif; ?>
            </div>

            <h2>API Base URL & Authentication</h2>
            <p>The base URL for all API requests is: <code><?= htmlspecialchars($base_api_url) ?></code></p>

            <h3>Authentication</h3>
            <p>All API requests (except client-side tracking events) require authentication using your unique API Key.</p>
            <p>Include your API Key in the <code>X-API-KEY</code> header for every request:</p>
            <pre><code>curl -X GET \
  '<?= htmlspecialchars($base_api_url) ?>/streams' \
  -H 'X-API-KEY: YOUR_API_KEY_HERE'</code></pre>

            <h3>Tracking Code Authentication</h3>
            <p>For client-side tracking events (e.g., from a website JavaScript snippet), use the specific <code>tracking_code</code> associated with your Stream. This code is passed as a GET parameter.</p>
            <p>Example: <code><?= htmlspecialchars($base_api_url) ?>/track?code=YOUR_TRACKING_CODE&event=page_view&contact_id=123</code></p>

            <h2>Error Responses</h2>
            <p>The API will return standard HTTP status codes and a JSON object with an <code>error</code> key and optionally <code>details</code>.</p>
            <table>
                <thead>
                    <tr>
                        <th>HTTP Status Code</th>
                        <th>Meaning</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>200 OK</code></td>
                        <td>Success</td>
                        <td>The request was successful.</td>
                    </tr>
                    <tr>
                        <td><code>201 Created</code></td>
                        <td>Created</td>
                        <td>A new resource was successfully created.</td>
                    </tr>
                    <tr>
                        <td><code>400 Bad Request</code></td>
                        <td>Client Error</td>
                        <td>The request was malformed or missing required parameters.</td>
                    </tr>
                    <tr>
                        <td><code>401 Unauthorized</code></td>
                        <td>Authentication Failed</td>
                        <td>No API Key provided or invalid API Key.</td>
                    </tr>
                    <tr>
                        <td><code>403 Forbidden</code></td>
                        <td>Authorization Failed</td>
                        <td>The API Key is valid, but the user is not authorized to access this resource or perform this action (e.g., trying to access another user's data). Invalid tracking code.</td>
                    </tr>
                    <tr>
                        <td><code>402 Payment Required</code></td>
                        <td>Membership Limit</td>
                        <td>The action cannot be completed due to your membership level limits (e.g., max streams, max contacts).</td>
                    </tr>
                    <tr>
                        <td><code>404 Not Found</code></td>
                        <td>Not Found</td>
                        <td>The requested endpoint or resource does not exist.</td>
                    </tr>
                    <tr>
                        <td><code>405 Method Not Allowed</code></td>
                        <td>Method Not Allowed</td>
                        <td>The HTTP method used is not supported for this endpoint.</td>
                    </tr>
                    <tr>
                        <td><code>409 Conflict</code></td>
                        <td>Conflict</td>
                        <td>The request could not be completed due to a conflict with the current state of the resource (e.g., email already exists).</td>
                    </tr>
                    <tr>
                        <td><code>500 Internal Server Error</code></td>
                        <td>Server Error</td>
                        <td>An unexpected error occurred on the server.</td>
                    </tr>
                </tbody>
            </table>

            <h2>API Endpoints</h2>

            <h3>1. Streams</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/streams</span></h4>
                <p>Retrieves a list of all streams belonging to the authenticated user.</p>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/streams';

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";

if ($httpCode === 200) {
    $data = json_decode($response, true);
    print_r($data);
} else {
    // Handle error
    echo "Error fetching streams.\n";
}
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/streams</span></h4>
                <p>Creates a new stream for the authenticated user.</p>
                <h5>Request Body Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>name</code></td><td>string</td><td>Yes</td><td>Name of the stream.</td></tr>
                        <tr><td><code>description</code></td><td>string</td><td>Yes</td><td>Description of the stream.</td></tr>
                        <tr><td><code>color_code</code></td><td>string</td><td>Yes</td><td>Hex color code for the stream (e.g., <code>#3ac3b8</code>).</td></tr>
                        <tr><td><code>is_app</code></td><td>boolean</td><td>No</td><td>Set to <code>1</code> if it's a mobile app, <code>0</code> otherwise. Default <code>0</code>.</td></tr>
                        <tr><td><code>website_url</code></td><td>string</td><td>Cond.</td><td>Required if <code>is_app</code> is <code>0</code>. URL of the website.</td></tr>
                        <tr><td><code>niche_id</code></td><td>integer</td><td>No</td><td>ID of the niche the stream belongs to.</td></tr>
                        <tr><td><code>acquisition_cost</code></td><td>decimal</td><td>No</td><td>Estimated cost to acquire a user. Default <code>0.00</code>.</td></tr>
                        <tr><td><code>cover_image</code></td><td>string</td><td>No</td><td>URL or path to a cover image for the stream.</td></tr>
                        <tr><td><code>marketing_channel</code></td><td>string</td><td>No</td><td>Primary marketing channel for this stream.</td></tr>
                        <tr><td><code>revenue_per_user</code></td><td>decimal</td><td>No</td><td>Estimated revenue per user for this stream. Default <code>0.00</code>.</td></tr>
                        <tr><td><code>currency</code></td><td>string</td><td>No</td><td>Currency code (e.g., <code>USD</code>, <code>EUR</code>). Default <code>USD</code>.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/streams';

$data = [
    'name' => 'My New Web App',
    'description' => 'Tracking churn for my awesome web application.',
    'color_code' => '#007bff',
    'is_app' => 0,
    'website_url' => 'https://mynewwebapp.com',
    'niche_id' => 1, // Example niche ID, replace with actual
    'acquisition_cost' => 15.50,
    'marketing_channel' => 'Organic Search',
    'revenue_per_user' => 9.99,
    'currency' => 'USD'
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">DELETE</span> <span class="path">/api/streams/{id}</span></h4>
                <p>Deletes a stream and all its associated data (contacts, features, competitors, cohorts tied to stream). <strong>This action is irreversible.</strong></p>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$streamIdToDelete = 123; // Replace with the actual Stream ID
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/streams/' . $streamIdToDelete;

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <h3>2. Cohorts</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/cohorts</span></h4>
                <p>Retrieves all cohorts belonging to the authenticated user.</p>
                <p>Optional query parameter: <code>stream_id</code> to filter cohorts by a specific stream.</p>
                <h5>Example Request (All Cohorts):</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/cohorts';

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
                <h5>Example Request (Filtered by Stream):</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$streamId = 456; // Replace with your stream ID
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/cohorts?stream_id=' . $streamId;

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/cohorts</span></h4>
                <p>Creates a new cohort under one of your streams.</p>
                <h5>Request Body Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>stream_id</code></td><td>integer</td><td>Yes</td><td>The ID of the stream this cohort belongs to.</td></tr>
                        <tr><td><code>name</code></td><td>string</td><td>Yes</td><td>Name of the cohort (e.g., "High-Value Users").</td></tr>
                        <tr><td><code>description</code></td><td>string</td><td>No</td><td>Description of the cohort.</td></tr>
                        <tr><td><code>cost_per_user</code></td><td>decimal</td><td>No</td><td>Estimated acquisition cost per user in this cohort. Default <code>0.00</code>.</td></tr>
                        <tr><td><code>revenue_per_user</code></td><td>decimal</td><td>No</td><td>Estimated revenue per user in this cohort. Default <code>0.00</code>.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/cohorts';

$data = [
    'stream_id' => 456, // Replace with your stream ID
    'name' => 'Free Trial Enders',
    'description' => 'Users who completed their free trial recently.',
    'cost_per_user' => 5.25,
    'revenue_per_user' => 0.00 // Assuming they haven't converted yet
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">DELETE</span> <span class="path">/api/cohorts/{id}</span></h4>
                <p>Deletes a cohort and removes all contacts from it. Contacts themselves are NOT deleted.</p>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$cohortIdToDelete = 789; // Replace with the actual Cohort ID
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/cohorts/' . $cohortIdToDelete;

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <h3>3. Features</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/features</span></h4>
                <p>Retrieves features associated with a specific stream owned by the authenticated user.</p>
                <h5>Query Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>stream_id</code></td><td>integer</td><td>Yes</td><td>The ID of the stream for which to retrieve features.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$streamId = 456; // Replace with your stream ID
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/features?stream_id=' . $streamId;

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/features</span></h4>
                <p>Creates a new feature for a specific stream.</p>
                <h5>Request Body Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>stream_id</code></td><td>integer</td><td>Yes</td><td>The ID of the stream this feature belongs to.</td></tr>
                        <tr><td><code>name</code></td><td>string</td><td>Yes</td><td>Name of the feature (e.g., "Interactive Map").</td></tr>
                        <tr><td><code>url</code></td><td>string</td><td>No</td><td>Optional URL associated with the feature (for web projects).</td></tr>
                        <tr><td><code>tags</code></td><td>string</td><td>No</td><td>Comma-separated tags describing the feature (e.g., "analytics, visualization").</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/features';

$data = [
    'stream_id' => 456, // Replace with your stream ID
    'name' => 'Advanced Reporting',
    'url' => 'https://yourplatform.com/reports/advanced',
    'tags' => 'reporting, charts, data, analytics'
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">DELETE</span> <span class="path">/api/features/{id}</span></h4>
                <p>Deletes a feature.</p>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$featureIdToDelete = 101; // Replace with the actual Feature ID
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/features/' . $featureIdToDelete;

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <h3>4. Competitors</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/competitors</span></h4>
                <p>Retrieves competitors associated with a specific stream owned by the authenticated user.</p>
                <h5>Query Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>stream_id</code></td><td>integer</td><td>Yes</td><td>The ID of the stream for which to retrieve competitors.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$streamId = 456; // Replace with your stream ID
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/competitors?stream_id=' . $streamId;

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/competitors</span></h4>
                <p>Creates a new competitor entry for a specific stream.</p>
                <h5>Request Body Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>stream_id</code></td><td>integer</td><td>Yes</td><td>The ID of the stream this competitor belongs to.</td></tr>
                        <tr><td><code>name</code></td><td>string</td><td>Yes</td><td>Name of the competitor (e.g., "Competitor X").</td></tr>
                        <tr><td><code>url</code></td><td>string</td><td>Yes</td><td>URL of the competitor's website or specific page.</td></tr>
                        <tr><td><code>is_pricing</code></td><td>boolean</td><td>No</td><td>Set to <code>1</code> if this is a pricing page URL, <code>0</code> otherwise. Default <code>0</code>.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/competitors';

$data = [
    'stream_id' => 456, // Replace with your stream ID
    'name' => 'Rival Analytics Co.',
    'url' => 'https://rivalanalytics.com/pricing',
    'is_pricing' => 1
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">DELETE</span> <span class="path">/api/competitors/{id}</span></h4>
                <p>Deletes a competitor.</p>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$competitorIdToDelete = 202; // Replace with the actual Competitor ID
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/competitors/' . $competitorIdToDelete;

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <h3>5. Contacts</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/contacts</span></h4>
                <p>Retrieves contacts for the authenticated user, with optional filters and pagination.</p>
                <h5>Query Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>stream_id</code></td><td>integer</td><td>No</td><td>Filter contacts by a specific stream ID.</td></tr>
                        <tr><td><code>cohort_id</code></td><td>integer</td><td>No</td><td>Filter contacts by a specific cohort ID.</td></tr>
                        <tr><td><code>search</code></td><td>string</td><td>No</td><td>Search contacts by username or email.</td></tr>
                        <tr><td><code>limit</code></td><td>integer</td><td>No</td><td>Maximum number of contacts to return (default: 20, max: 100).</td></tr>
                        <tr><td><code>offset</code></td><td>integer</td><td>No</td><td>Offset for pagination (default: 0).</td></tr>
                    </tbody>
                </table>
                <h5>Example Request (Filtered & Paginated):</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/contacts';

$queryParams = [
    'stream_id' => 456, // Example stream ID
    'search' => 'john.doe',
    'limit' => 10,
    'offset' => 0
];
$fullUrl = $apiUrl . '?' . http_build_query($queryParams);

$ch = curl_init($fullUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/contacts</span></h4>
                <p>Creates a new contact for a specified stream. Can optionally assign to cohorts and include custom data.</p>
                <h5>Request Body Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>stream_id</code></td><td>integer</td><td>Yes</td><td>The ID of the stream this contact belongs to.</td></tr>
                        <tr><td><code>email</code></td><td>string</td><td>Yes</td><td>Email address of the contact.</td></tr>
                        <tr><td><code>username</code></td><td>string</td><td>No</td><td>Username of the contact.</td></tr>
                        <tr><td><code>external_id</code></td><td>string</td><td>No</td><td>An ID from your own system for this contact.</td></tr>
                        <tr><td><code>custom_data</code></td><td>object</td><td>No</td><td>JSON object of additional key-value pairs for this contact.</td></tr>
                        <tr><td><code>cohort_ids</code></td><td>array of integers</td><td>No</td><td>Array of cohort IDs to assign this contact to upon creation.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/contacts';

$data = [
    'stream_id' => 456, // Replace with your stream ID
    'email' => 'jane.doe@example.com',
    'username' => 'janedoe',
    'external_id' => 'USER_ABC_123',
    'custom_data' => [
        'plan_type' => 'Pro',
        'signup_source' => 'Facebook Ad'
    ],
    'cohort_ids' => [789, 987] // Replace with actual cohort IDs
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">PUT</span> <span class="path">/api/contacts/{id}</span></h4>
                <p>Updates an existing contact's details or cohort assignments.</p>
                <h5>Path Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>id</code></td><td>integer</td><td>The ID of the contact to update.</td></tr>
                    </tbody>
                </table>
                <h5>Request Body Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>username</code></td><td>string</td><td>No</td><td>New username for the contact.</td></tr>
                        <tr><td><code>email</code></td><td>string</td><td>No</td><td>New email address for the contact. Must be unique within the stream.</td></tr>
                        <tr><td><code>external_id</code></td><td>string</td><td>No</td><td>New external ID for the contact.</td></tr>
                        <tr><td><code>custom_data</code></td><td>object</td><td>No</td><td>Full JSON object to replace the existing <code>custom_data</code>.</td></tr>
                        <tr><td><code>update_custom_fields</code></td><td>object</td><td>No</td><td>Key-value pairs to update specific individual custom fields (creates if not exists, updates if exists).</td></tr>
                        <tr><td><code>delete_custom_fields</code></td><td>array of strings</td><td>No</td><td>Array of custom field names to delete.</td></tr>
                        <tr><td><code>add_to_cohorts</code></td><td>array of integers</td><td>No</td><td>Array of cohort IDs to add the contact to.</td></tr>
                        <tr><td><code>remove_from_cohorts</code></td><td>array of integers</td><td>No</td><td>Array of cohort IDs to remove the contact from.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$contactIdToUpdate = 321; // Replace with the actual Contact ID
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/contacts/' . $contactIdToUpdate;

$data = [
    'username' => 'jane_new_name',
    'email' => 'jane.newemail@example.com',
    'update_custom_fields' => [
        'plan_type' => 'Enterprise',
        'last_survey_date' => '2024-05-15'
    ],
    'add_to_cohorts' => [987], // Add to cohort 987
    'remove_from_cohorts' => [789] // Remove from cohort 789
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">DELETE</span> <span class="path">/api/contacts/{id}</span></h4>
                <p>Deletes a contact and all its associated data (metric data, churn scores, cohort associations, churn/resurrection records). <strong>This action is irreversible.</strong></p>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$contactIdToDelete = 321; // Replace with the actual Contact ID
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/contacts/' . $contactIdToDelete;

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <h3>6. Metrics & Churn Data</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/metrics</span></h4>
                <p>Submits a new data point for a predefined or custom metric for a specific contact.</p>
                <h5>Request Body Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>contact_id</code></td><td>integer</td><td>Yes</td><td>The ID of the contact to record the metric for.</td></tr>
                        <tr><td><code>metric_name</code></td><td>string</td><td>Yes</td><td>The name of the metric (e.g., <code>login_frequency</code>, <code>payment_status</code>, or your custom metric name).</td></tr>
                        <tr><td><code>value</code></td><td>mixed</td><td>Yes</td><td>The value of the metric. Can be string, number, boolean.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request (Predefined Metric):</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/metrics';

$data = [
    'contact_id' => 321, // Replace with contact ID
    'metric_name' => 'payment_status',
    'value' => 'completed'
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
                <h5>Example Request (Custom Metric):</h5>
                <p>If <code>my_custom_metric</code> does not exist, it will be automatically created for your user.</p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/metrics';

$data = [
    'contact_id' => 321, // Replace with contact ID
    'metric_name' => 'my_custom_metric',
    'value' => 75.3 // Example value
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/metrics</span></h4>
                <p>Retrieves all metric data points for a specific contact. This fetches both predefined and custom metrics.</p>
                <h5>Query Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>contact_id</code></td><td>integer</td><td>Yes</td><td>The ID of the contact whose metrics to retrieve.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$contactId = 321; // Replace with contact ID
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/metrics?contact_id=' . $contactId;

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/mark-churned</span></h4>
                <p>Marks a contact as churned and records a reason.</p>
                <h5>Request Body Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>contact_id</code></td><td>integer</td><td>Yes</td><td>The ID of the contact to mark as churned.</td></tr>
                        <tr><td><code>reason</code></td><td>string</td><td>No</td><td>Optional reason for churn (e.g., "Inactive for 60 days", "Subscription cancelled").</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/mark-churned';

$data = [
    'contact_id' => 321, // Replace with contact ID
    'reason' => 'User stopped logging in'
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/mark-resurrected</span></h4>
                <p>Marks a contact as resurrected (if they were previously churned) and removes them from the churned list.</p>
                <h5>Request Body Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>contact_id</code></td><td>integer</td><td>Yes</td><td>The ID of the contact to mark as resurrected.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/mark-resurrected';

$data = [
    'contact_id' => 321 // Replace with contact ID
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/churn-scores</span></h4>
                <p>Retrieves churn scores for contacts. Requires either a <code>stream_id</code> or a <code>contact_id</code>.</p>
                <h5>Query Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>stream_id</code></td><td>integer</td><td>Cond.</td><td>Retrieve scores for all contacts in this stream.</td></tr>
                        <tr><td><code>contact_id</code></td><td>integer</td><td>Cond.</td><td>Retrieve scores for a single contact.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request (by Contact ID):</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$contactId = 321; // Replace with contact ID
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/churn-scores?contact_id=' . $contactId;

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/churn-calculate</span></h4>
                <p>Triggers the AI churn score calculation for a single contact. This can be used for on-demand scoring.</p>
                <h5>Request Body Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>contact_id</code></td><td>integer</td><td>Yes</td><td>The ID of the contact to calculate churn score for.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/churn-calculate';

$data = [
    'contact_id' => 321 // Replace with contact ID
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/churn-batch-calculate</span></h4>
                <p>Triggers a batch AI churn score calculation for contacts within a specific stream that need re-scoring (e.g., new data, old score). Useful for cron jobs.</p>
                <h5>Request Body Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>stream_id</code></td><td>integer</td><td>Yes</td><td>The ID of the stream for which to calculate churn scores.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/churn-batch-calculate';

$data = [
    'stream_id' => 456 // Replace with stream ID
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/winback-suggestions</span></h4>
                <p>Generates and stores win-back suggestions for a specific contact based on their churn score and metrics. Uses internal logic (placeholder for AI).</p>
                <h5>Request Body Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>contact_id</code></td><td>integer</td><td>Yes</td><td>The ID of the contact to generate suggestions for.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/winback-suggestions';

$data = [
    'contact_id' => 321 // Replace with contact ID
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <h3>7. Notifications</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/notifications</span></h4>
                <p>Retrieves all notifications for the authenticated user, ordered by creation date (newest first).</p>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/notifications';

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">PUT</span> <span class="path">/api/notifications/{id}/mark-read</span></h4>
                <p>Marks a specific notification as read for the authenticated user.</p>
                <h5>Path Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>id</code></td><td>integer</td><td>The ID of the notification to mark as read.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$notificationIdToMarkRead = 55; // Replace with actual notification ID
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/notifications/' . $notificationIdToMarkRead . '/mark-read';

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);
// No request body needed for this specific action

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <h3>8. User Profile & Settings</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/profile</span></h4>
                <p>Retrieves the authenticated user's full profile details (company info, personal info, notification preferences, integration keys).</p>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/profile';

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">PUT</span> <span class="path">/api/profile</span></h4>
                <p>Updates the authenticated user's profile details. Only include the fields you wish to update.</p>
                <h5>Request Body Parameters (Partial list, see `user_profiles` table for all fields):</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>company_name</code></td><td>string</td><td>No</td><td>Company name.</td></tr>
                        <tr><td><code>industry</code></td><td>string</td><td>No</td><td>Industry (e.g., "Technology").</td></tr>
                        <tr><td><code>full_name</code></td><td>string</td><td>No</td><td>Your full name.</td></tr>
                        <tr><td><code>phone_number</code></td><td>string</td><td>No</td><td>Phone number for SMS alerts (e.g., "+1234567890").</td></tr>
                        <tr><td><code>alert_is_email</code></td><td>boolean</td><td>No</td><td><code>1</code> to enable email alerts, <code>0</code> to disable.</td></tr>
                        <tr><td><code>alert_is_sms</code></td><td>boolean</td><td>No</td><td><code>1</code> to enable SMS alerts, <code>0</code> to disable.</td></tr>
                        <tr><td><code>webhook_type</code></td><td>enum</td><td>No</td><td>Primary webhook service (<code>slack</code>, <code>microsoft_teams</code>, <code>discord</code>).</td></tr>
                        <tr><td><code>webhook_url</code></td><td>string</td><td>No</td><td>General webhook URL.</td></tr>
                        <tr><td><code>stripe_key</code></td><td>string</td><td>No</td><td>Stripe API Key.</td></tr>
                        <tr><td><code>zapier_webhook</code></td><td>string</td><td>No</td><td>Dedicated Zapier webhook URL.</td></tr>
                        <!-- Add other fields from user_profiles table as needed -->
                    </tbody>
                </table>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/profile';

$data = [
    'company_name' => 'Acme Corp',
    'industry' => 'Manufacturing',
    'full_name' => 'Alice Smith',
    'alert_is_sms' => 1,
    'phone_number' => '+15551234567',
    'webhook_type' => 'slack',
    'webhook_slack' => 'https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX'
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">GET</span> <span class="path">/api/settings</span></h4>
                <p>Retrieves the authenticated user's general settings, including API keys, tracking method, and payment method details.</p>
                <h5>Example Request:</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/settings';

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <div class="api-endpoint-box">
                <h4><span class="method">PUT</span> <span class="path">/api/settings</span></h4>
                <p>Updates the authenticated user's general settings. Only include the fields you wish to update.</p>
                <h5>Request Body Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>tracking_method</code></td><td>enum</td><td>No</td><td>Your preferred tracking method (<code>gdpr</code>, <code>non_gdpr</code>, <code>hybrid</code>).</td></tr>
                        <tr><td><code>payment_method</code></td><td>object</td><td>No</td><td>Object containing payment method details.
                            <br>Example for PayPal: <code>{'method': 'paypal', 'paypal_email': 'your@paypal.com'}</code>
                            <br>Example for Bank: <code>{'method': 'bank', 'bank_name': 'My Bank', 'account_name': 'My Name', 'account_number': '1234567890'}</code>
                            <br>Example for USDT: <code>{'method': 'usdt', 'usdt_wallet': 'yourUSDTwalletaddress'}</code></td></tr>
                    </tbody>
                </table>
                <h5>Example Request (Update Tracking Method):</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/settings';

$data = [
    'tracking_method' => 'hybrid'
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
                <h5>Example Request (Update Payment Method - PayPal):</h5>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$apiKey = '<?= htmlspecialchars($user_api_key ?? 'YOUR_API_KEY') ?>';
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/settings';

$data = [
    'payment_method' => [
        'method' => 'paypal',
        'paypal_email' => 'my.email@example.com'
    ]
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-KEY: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <h3>9. Tracking Endpoint (Client-side / JavaScript)</h3>
            <div class="api-endpoint-box">
                <h4><span class="method">POST</span> <span class="path">/api/track?code=YOUR_TRACKING_CODE</span></h4>
                <p>Submit various tracking events (e.g., page views, feature usage, competitor visits, custom events) usually from client-side JavaScript or server-side when API Key authentication is not suitable.</p>
                <p>Authentication for this endpoint uses the Stream's unique <code>tracking_code</code> passed as a GET parameter.</p>
                <h5>Request Body Parameters:</h5>
                <table>
                    <thead>
                        <tr><th>Parameter</th><th>Type</th><th>Required</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>event</code></td><td>string</td><td>Yes</td><td>The event name (e.g., <code>page_view</code>, <code>feature_usage</code>, <code>competitor_visit</code>, or a <code>custom_metric</code> name).</td></tr>
                        <tr><td><code>contact_id</code></td><td>integer</td><td>Yes</td><td>The ID of the contact performing the action.</td></tr>
                        <tr><td><code>value</code></td><td>mixed</td><td>Yes</td><td>The value associated with the event (e.g., URL for <code>page_view</code>, feature name for <code>feature_usage</code>, <code>true</code> for simple events).</td></tr>
                        <tr><td><code>metadata</code></td><td>object</td><td>No</td><td>Optional JSON object for additional event details.</td></tr>
                    </tbody>
                </table>
                <h5>Example Request (Feature Usage from Server-side PHP with tracking code):</h5>
                <p>
                    <strong>Note:</strong> While this uses a tracking code, this PHP example demonstrates how you'd send data to it from your own server-side, perhaps from a backend process that observes user actions. For actual client-side usage, you'd embed a JavaScript snippet on your website.
                </p>
                <pre><button class="copy-btn"><i class="fas fa-copy"></i> Copy</button><code>&lt;?php
$trackingCode = 'YOUR_STREAM_TRACKING_CODE'; // Replace with your stream's tracking code
$apiUrl = '<?= htmlspecialchars($base_api_url) ?>/track?code=' . $trackingCode;

$data = [
    'event' => 'feature_usage',
    'contact_id' => 321, // ID of the contact in your system (from your API contacts)
    'value' => 'DashboardReportViewed', // Value can be feature name or identifier
    'metadata' => [
        'page_url' => 'https://yourplatform.com/dashboard/reports',
        'browser' => 'Chrome'
    ]
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?&gt;</code></pre>
            </div>

            <h2>Important Notes:</h2>
            <ul>
                <li>Replace <code>YOUR_API_KEY_HERE</code> and <code>YOUR_STREAM_TRACKING_CODE</code> with your actual keys.</li>
                <li>All <code>{id}</code> in paths are placeholders for actual numerical IDs.</li>
                <li>Ensure your server's cURL extension is enabled for the PHP examples to work.</li>
                <li>For production, always handle API responses, including error codes, robustly.</li>
            </ul>

        </div>
        <?php require_once '../includes/footer.php'; ?>
    </div>

    <script>
        // Initialize Feather Icons
        feather.replace();

        // API Key Visibility Toggle
        const apiKeySpan = document.getElementById('apiKeySpan');
        const toggleApiKeyBtn = document.getElementById('toggleApiKey');
        const copyApiKeyBtn = document.getElementById('copyApiKey');

        if (apiKeySpan && toggleApiKeyBtn && copyApiKeyBtn) {
            let isKeyVisible = false;
            const fullKey = apiKeySpan.dataset.fullKey;

            toggleApiKeyBtn.addEventListener('click', function() {
                isKeyVisible = !isKeyVisible;
                if (isKeyVisible) {
                    apiKeySpan.textContent = fullKey;
                    toggleApiKeyBtn.innerHTML = '<i class="fas fa-eye-slash"></i> Hide Key';
                } else {
                    apiKeySpan.textContent = '********';
                    toggleApiKeyBtn.innerHTML = '<i class="fas fa-eye"></i> Show Key';
                }
            });

            copyApiKeyBtn.addEventListener('click', function() {
                // Temporarily unmask key to copy, then re-mask
                const originalText = apiKeySpan.textContent;
                apiKeySpan.textContent = fullKey; // Show full key for copying

                navigator.clipboard.writeText(fullKey).then(() => {
                    copyApiKeyBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
                    setTimeout(() => {
                        copyApiKeyBtn.innerHTML = '<i class="fas fa-copy"></i> Copy Key';
                        // Revert visibility if it was hidden
                        if (!isKeyVisible) {
                            apiKeySpan.textContent = originalText; // Restore masked state
                        }
                    }, 1500);
                }).catch(err => {
                    console.error('Failed to copy API key: ', err);
                    alert('Failed to copy API key. Please copy it manually.');
                });
            });
        }
    </script>
</body>
</html>
