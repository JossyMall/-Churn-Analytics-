<?php
// documentations/index.php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

require_once '../includes/db.php'; // Path from documentations/ to includes/db.php
require_once '../includes/header.php'; // Includes global HTML head, meta, and possibly global CSS/JS.

// The API base URL, adjusted for this location
$base_api_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . "/api/index.php";

// Fetch user's API key to display (same logic as other docs)
$user_api_key = null;
try {
    $stmt_api_key = $pdo->prepare("SELECT api_key FROM user_api_keys WHERE user_id = :user_id ORDER BY created_at DESC LIMIT 1");
    $stmt_api_key->bindValue(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt_api_key->execute();
    $api_key_data = $stmt_api_key->fetch(PDO::FETCH_ASSOC);

    if ($api_key_data) {
        $user_api_key = $api_key_data['api_key'];
    }
} catch (PDOException $e) {
    error_log("Error fetching API key for documentation: " . $e->getMessage());
    // Gracefully handle: $user_api_key remains null
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Documentation Home</title>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"
            xintegrity="sha512-Tn2m0TIpgVyTzzvmxLNuqbSJH3JP8jm+Cy3hvHrW7ndTDcJ1w5mBiksqDBb8GpE2ksktFvDB/ykZ0mDpsZj20w=="
            crossorigin="anonymous"
            referrerpolicy="no-referrer"></script>
    <style>
        /* Base styles consistent with other project pages */
        :root {
            --primary: #3ac3b8;
            --secondary: #4299e1;
            --danger: #e53e3e;
            --warning: #f6ad55;
            --success: #68d391;
            --info: #4299e1;
            --dark: #1a202c;
            --light: #f7fafc;
            --white: #ffffff;
            --gray-100: #f7fafc;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e0;
            --gray-400: #a0aec0;
            --gray-500: #718096;
            --gray-600: #4a5568;
            --gray-700: #2d3748;
            --gray-800: #1a202c;
            --gray-900: #171923;
        }

        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            color: var(--gray-700);
            line-height: 1.6;
            display: flex;
            flex-direction: column; /* For sticky footer */
        }

        .site-wrapper { /* Main flex container for sticky footer */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-color: transparent; /* Explicitly no background */
        }

        .doc-container {
            max-width: 900px;
            margin: 40px auto;
            padding: 30px; /* Increased padding for content box */
            box-sizing: border-box;
            flex-grow: 1; /* Allows content area to expand and push footer down */
            border-radius: 12px;
        }

        h1, h2, h3 {
            color: var(--dark);
            margin-top: 1.5em;
            margin-bottom: 0.8em;
        }

        h1 { font-size: 2.5em; text-align: center; margin-bottom: 1em; }
        h2 { font-size: 2em; border-bottom: 2px solid var(--gray-200); padding-bottom: 0.5em; margin-top: 2em; }
        h3 { font-size: 1.5em; color: var(--primary); }

        p {
            margin-bottom: 1em;
        }

        ul {
            list-style-type: disc;
            margin-left: 20px;
            margin-bottom: 1em;
        }

        strong {
            color: var(--gray-800);
        }

        a {
            color: var(--info);
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }

        .api-key-header {
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
            text-align: center;
        }
        .api-key-header h2 {
            margin: 0;
            padding-bottom: 0;
            border-bottom: none;
            font-size: 1.8em;
        }
        .api-key-display {
            font-family: 'Courier New', Courier, monospace;
            background-color: var(--gray-200);
            padding: 10px 15px;
            border-radius: 8px;
            font-size: 1.1em;
            color: var(--gray-800);
            display: flex;
            align-items: center;
            gap: 10px;
            max-width: 100%;
            overflow-x: auto;
        }
        .api-key-display span {
            white-space: nowrap;
        }
        .btn-api-action {
            background-color: var(--primary);
            color: var(--white);
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: background-color 0.2s;
            font-size: 0.9em;
        }
        .btn-api-action:hover {
            background-color: #2da89e;
        }
        .btn-api-action i {
            width: 16px;
            height: 16px;
        }
        .no-key-message {
            color: var(--danger);
            font-weight: 500;
        }
        .no-key-message a {
            color: var(--danger);
            text-decoration: underline;
        }

        .sdk-links {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-top: 30px;
            align-items: center; /* Center the links */
        }
        .sdk-link-card {
            background-color: var(--gray-100);
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            width: 80%; /* Adjust width as needed */
            max-width: 400px;
            transition: transform 0.2s, box-shadow 0.2s;
            text-decoration: none; /* Remove underline from card link */
            color: var(--dark); /* Ensure text color is readable */
        }
        .sdk-link-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.1);
        }
        .sdk-link-card h3 {
            margin-top: 0;
            margin-bottom: 10px;
            color: var(--primary);
        }
        .sdk-link-card p {
            font-size: 0.9em;
            color: var(--gray-600);
        }

        /* Footer styles (from includes/footer.php) */
        .footer {
            padding: 15px 0;
            margin-top: auto; /* Pushes the footer to the bottom */
            border-top: 1px solid var(--gray-200);
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 15px;
            color: var(--gray-600);
        }
        
        .copyright {
            color: var(--gray-600);
            font-size: 0.9rem;
        }
        
        .logout-link {
            color: var(--danger);
            text-decoration: none;
            transition: color 0.3s;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .logout-link:hover {
            color: #c82333;
        }
        .logout-link strong {
            font-weight: 600;
        }
        .logout-link i {
            font-size: 1em;
        }
        /* End Footer styles */

        @media (max-width: 768px) {
            .doc-container {
                margin: 20px auto;
                padding: 15px;
            }
            h1 { font-size: 2em; }
            h2 { font-size: 1.5em; }
            h3 { font-size: 1.2em; }
            .api-key-display {
                flex-direction: column;
                align-items: flex-start;
            }
            .api-key-display button {
                width: 100%;
                justify-content: center;
            }
            .sdk-link-card {
                width: 100%; /* Full width on small screens */
            }
            .footer-content {
                flex-direction: column;
                gap: 10px;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="site-wrapper">
        <div class="doc-container">
            <h1>Earndos BI API Documentation</h1>
            <p>Welcome to the Earndos Business Intelligence API documentation. This API allows you to programmatically interact with your churn analytics data, manage streams, contacts, and integrate your applications with our powerful prediction and win-back features.</p>
            <p>Our API is built on a RESTful architecture, utilizing standard HTTP methods (GET, POST, PUT, DELETE) and JSON payloads for data exchange. Authenticate your requests using your unique API Key to ensure secure and authorized access.</p>

            <div class="api-key-header">
                <h2>Your API Key</h2>
                <?php if ($user_api_key): ?>
                    <div class="api-key-display">
                        <span id="apiKeySpan" data-full-key="<?= htmlspecialchars($user_api_key) ?>">********</span>
                        <button class="btn-api-action" id="toggleApiKey">
                            <i class="fas fa-eye"></i> Show Key
                        </button>
                        <button class="btn-api-action" id="copyApiKey">
                            <i class="fas fa-copy"></i> Copy Key
                        </button>
                    </div>
                <?php else: ?>
                    <p class="no-key-message">You don't have an API key yet. <a href="../settings.php" target="_blank">Create one on your settings page</a> to get started!</p>
                <?php endif; ?>
            </div>

            <h2>How it Works</h2>
            <p>The API provides endpoints for all major functionalities within the Earndos BI platform. You can:</p>
            <ul>
                <li><strong>Manage Streams:</strong> Create, retrieve, and delete your data "streams" (e.g., your applications, websites).</li>
                <li><strong>Manage Contacts:</strong> Add, update, and delete individual contacts (your users) within your streams, including custom fields.</li>
                <li><strong>Track Metrics:</strong> Submit a wide range of predefined and custom churn metrics for your contacts.</li>
                <li><strong>Manage Cohorts:</strong> Organize your contacts into custom segments.</li>
                <li><strong>Manage Features & Competitors:</strong> Define and track usage of specific features and monitor competitor website visits.</li>
                <li><strong>Access Churn Data:</strong> Retrieve churn scores, identify high-risk users, and track churned/resurrected contacts.</li>
                <li><strong>Receive Notifications:</strong> Fetch your notifications directly via the API.</li>
                <li><strong>Update Profile & Settings:</strong> Programmatically manage your user profile and general account settings.</li>
            </ul>
            <p>For detailed information on each endpoint, refer to our language-specific SDK documentation:</p>

            <div class="sdk-links">
                <a href="php_sdk_documentation.php" class="sdk-link-card">
                    <h3>PHP SDK Documentation</h3>
                    <p>Learn how to integrate with our API using PHP, including code examples for all endpoints.</p>
                </a>
                <a href="go_sdk_documentation.php" class="sdk-link-card">
                    <h3>Go SDK Documentation</h3>
                    <p>Explore our API integration with Go, complete with Go-specific code snippets and best practices.</p>
                </a>
            </div>

        </div>
        <?php require_once '../includes/footer.php'; ?>
    </div>

    <script>
        // Initialize Feather Icons
        feather.replace();

        // API Key Visibility Toggle
        const apiKeySpan = document.getElementById('apiKeySpan');
        const toggleApiKeyBtn = document.getElementById('toggleApiKey');
        const copyApiKeyBtn = document.getElementById('copyApiKey');

        if (apiKeySpan && toggleApiKeyBtn && copyApiKeyBtn) {
            let isKeyVisible = false;
            // Use dataset.fullKey which is correctly camelCased by JavaScript
            const fullKey = apiKeySpan.dataset.fullKey; 

            toggleApiKeyBtn.addEventListener('click', function() {
                isKeyVisible = !isKeyVisible;
                if (isKeyVisible) {
                    apiKeySpan.textContent = fullKey;
                    toggleApiKeyBtn.innerHTML = '<i class="fas fa-eye-slash"></i> Hide Key';
                } else {
                    apiKeySpan.textContent = '********';
                    toggleApiKeyBtn.innerHTML = '<i class="fas fa-eye"></i> Show Key';
                }
            });

            copyApiKeyBtn.addEventListener('click', function() {
                // Temporarily unmask key to copy, then re-mask
                const originalText = apiKeySpan.textContent;
                apiKeySpan.textContent = fullKey; // Show full key for copying

                navigator.clipboard.writeText(fullKey).then(() => {
                    copyApiKeyBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
                    setTimeout(() => {
                        copyApiKeyBtn.innerHTML = '<i class="fas fa-copy"></i> Copy Key';
                        // Revert visibility if it was hidden
                        if (!isKeyVisible) {
                            apiKeySpan.textContent = originalText; // Restore masked state
                        }
                    }, 1500);
                }).catch(err => {
                    console.error('Failed to copy API key: ', err);
                    alert('Failed to copy API key. Please copy it manually.');
                });
            });
        }
    </script>
</body>
</html>
