<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

require_once '../includes/db.php';
require_once '../includes/header.php'; // Global header (likely contains <head> and initial <body> structure)

$current_user_id = $_SESSION['user_id'];

// !!! IMPORTANT DEBUGGING LINES - KEEP AT VERY TOP !!!
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1'); // Shows parse errors at startup
ini_set('log_errors', '1'); // Ensures errors are logged
ini_set('error_log', '/var/www/www-root/data/www/earndos.com/io/php_app_errors.log'); // DIRECTS ERRORS HERE

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_experiment'])) {
        $name = trim($_POST['experiment_name']);
        $description = trim($_POST['experiment_description']);
        $channel = $_POST['acquisition_channel'];
        $sourceType = $_POST['source_type'];
        $sourceId = $_POST['source_id'];
        $specificValue = trim($_POST['specific_value']);

        if (!empty($name) && !empty($channel) && !empty($sourceType) && !empty($sourceId)) {
            try {
                $pdo->beginTransaction();

                // Insert experiment
                $stmt = $pdo->prepare("INSERT INTO experiments (user_id, name, description) VALUES (?, ?, ?)");
                $stmt->execute([$current_user_id, $name, $description]);
                $experimentId = $pdo->lastInsertId();

                // Insert experiment source
                $stmt = $pdo->prepare("INSERT INTO experiment_sources (experiment_id, channel_type, source_type, source_id, specific_value) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$experimentId, $channel, $sourceType, $sourceId, $specificValue]);

                $pdo->commit();
                $_SESSION['success'] = "Experiment created successfully";
                header('Location: index.php');
                exit();
            } catch (PDOException $e) {
                $pdo->rollBack();
                $_SESSION['error'] = "Error creating experiment: " . $e->getMessage();
                header('Location: index.php');
                exit();
            }
        } else {
            $_SESSION['error'] = "Please fill all required fields";
            header('Location: index.php');
            exit();
        }
    }
}

// Date range handling
$dateRange = isset($_GET['date_range']) ? intval($_GET['date_range']) : 10;
$endDate = date('Y-m-d');
$startDate = date('Y-m-d', strtotime("-$dateRange weeks"));

// Selected experiments for comparison
$selectedExperimentIds = isset($_GET['compare']) ? $_GET['compare'] : [];
if (!is_array($selectedExperimentIds)) {
    $selectedExperimentIds = [$selectedExperimentIds];
}
$selectedExperimentIds = array_filter($selectedExperimentIds, 'is_numeric');

// Fetch all available experiments
$experiments = [];
$stmt = $pdo->prepare("SELECT e.* FROM experiments e WHERE e.user_id = ? ORDER BY e.created_at DESC");
$stmt->execute([$current_user_id]);
$experiments = $stmt->fetchAll();

// If no experiments selected but we have some, select the first one
if (empty($selectedExperimentIds) && !empty($experiments)) {
    $selectedExperimentIds = [$experiments[0]['id']];
}

// Initialize data arrays
$chartData = [];
$tableData = [];
$metricsData = [];
$sources = [];
$competitorData = [];

if (!empty($selectedExperimentIds)) {
    // Fetch all selected experiment sources
    $placeholders = implode(',', array_fill(0, count($selectedExperimentIds), '?'));
    $stmt = $pdo->prepare("
        SELECT es.*, e.name AS experiment_name
        FROM experiment_sources es
        JOIN experiments e ON es.experiment_id = e.id
        WHERE es.experiment_id IN ($placeholders)
        ORDER BY e.created_at DESC
    ");
    $stmt->execute($selectedExperimentIds);
    $sources = $stmt->fetchAll();

    // Generate real data for each source
    foreach ($sources as $source) {
        $sourceId = $source['id'];
        $channel = $source['channel_type'];
        $sourceType = $source['source_type'];
        $sourceEntityId = $source['source_id'];

        // Get contacts for this source
        $contacts = [];
        if ($sourceType === 'stream') {
            $stmt = $pdo->prepare("SELECT id FROM contacts WHERE stream_id = ?");
            $stmt->execute([$sourceEntityId]);
            $contacts = $stmt->fetchAll(PDO::FETCH_COLUMN);
        } elseif ($sourceType === 'cohort') {
            $stmt = $pdo->prepare("SELECT contact_id FROM contact_cohorts WHERE cohort_id = ?");
            $stmt->execute([$sourceEntityId]);
            $contacts = $stmt->fetchAll(PDO::FETCH_COLUMN);
        } else {
            $contacts = [$sourceEntityId]; // Single contact
        }

        if (empty($contacts)) continue;

        // Get churn data for these contacts
        $stmt = $pdo->prepare("
            SELECT DATE_FORMAT(cs.scored_at, '%Y-%m-%d') AS week, AVG(cs.score) AS avg_score
            FROM churn_scores cs
            WHERE cs.contact_id IN (".implode(',', $contacts).")
            AND cs.scored_at BETWEEN ? AND ?
            GROUP BY week
            ORDER BY week
            LIMIT 10
        ");
        $stmt->execute([$startDate, $endDate]);
        $churnData = $stmt->fetchAll();

        // Get competitor visits for these contacts
        $stmt = $pdo->prepare("
            SELECT COUNT(*) AS visit_count
            FROM metric_data md
            JOIN churn_metrics cm ON md.metric_id = cm.id
            WHERE md.contact_id IN (".implode(',', $contacts).")
            AND cm.name = 'competitor_visit'
            AND md.recorded_at BETWEEN ? AND ?
        ");
        $stmt->execute([$startDate, $endDate]);
        $competitorVisits = $stmt->fetchColumn();

        // Get total contacts for percentage calculation
        $totalContacts = count($contacts);
        $competitorVisitPercent = $totalContacts > 0 ? ($competitorVisits / $totalContacts) * 100 : 0;

        // Prepare chart data
        $labels = [];
        $values = [];
        foreach ($churnData as $row) {
            $labels[] = date('M j', strtotime($row['week']));
            $values[] = $row['avg_score'];
        }

        // Create unique identifier for this source
        $sourceKey = $source['experiment_id'].'-'.$source['id'];

        // Calculate confidence level (explanation below)
        $confidenceLevel = calculateConfidenceLevel($contacts, $current_user_id);

        $chartData[$sourceKey] = [
            'label' => $source['experiment_name'].' - '.ucfirst($channel),
            'data' => $values,
            'borderColor' => getExperimentColor($source['experiment_id']),
            'backgroundColor' => getExperimentColor($source['experiment_id']) . '20',
            'labels' => $labels
        ];

        // Calculate metrics
        $currentChurn = !empty($values) ? end($values) : 0;
        $previousChurn = count($values) > 1 ? $values[count($values)-2] : $currentChurn;
        $change = $currentChurn - $previousChurn;

        // Get session duration
        $stmt = $pdo->prepare("
            SELECT AVG(CAST(value AS DECIMAL(10,2))) AS avg_duration
            FROM metric_data
            WHERE contact_id IN (".implode(',', $contacts).")
            AND metric_id = (SELECT id FROM churn_metrics WHERE name = 'session_duration')
        ");
        $stmt->execute();
        $avgDuration = $stmt->fetchColumn();

        // Get feature adoption
        $stmt = $pdo->prepare("
            SELECT COUNT(DISTINCT contact_id) * 100.0 / COUNT(*) AS adoption_rate
            FROM metric_data
            WHERE contact_id IN (".implode(',', $contacts).")
            AND metric_id = (SELECT id FROM churn_metrics WHERE name = 'feature_usage')
        ");
        $stmt->execute();
        $featureAdoption = $stmt->fetchColumn();

        $metricsData[$sourceKey] = [
            'current' => $currentChurn,
            'change' => $change,
            'trend' => $values,
            'duration' => $avgDuration,
            'feature_adoption' => $featureAdoption,
            'competitor_visits' => $competitorVisits,
            'competitor_visit_percent' => $competitorVisitPercent,
            'total_contacts' => $totalContacts,
            'experiment_name' => $source['experiment_name'],
            'channel' => $channel,
            'specific_value' => $source['specific_value'],
            'confidence_level' => $confidenceLevel,
            'experiment_id' => $source['experiment_id']
        ];
    }

    // Find best performer (lowest churn rate)
    if (!empty($metricsData)) {
        $bestPerformer = null;
        $bestChurnRate = 100; // Start with worst possible

        foreach ($metricsData as $sourceKey => $data) {
            if ($data['current'] < $bestChurnRate) {
                $bestChurnRate = $data['current'];
                $bestPerformer = $data;
                $bestPerformer['source_key'] = $sourceKey;
            }
        }
    }
}

/**
 * Calculate confidence level for experiment results
 * Confidence is based on:
 * 1. Sample size (number of contacts) - 40% weight
 * 2. Data consistency (variance in churn scores) - 30% weight
 * 3. Duration of experiment - 20% weight
 * 4. Completeness of data - 10% weight
 */
function calculateConfidenceLevel($contactIds, $userId) {
    global $pdo;

    if (empty($contactIds)) return 0;

    $totalContacts = count($contactIds);

    // Get data consistency (variance in churn scores)
    $stmt = $pdo->prepare("
        SELECT STDDEV(score) as std_dev, AVG(score) as avg_score
        FROM churn_scores
        WHERE contact_id IN (".implode(',', $contactIds).")
    ");
    $stmt->execute();
    $consistencyData = $stmt->fetch();
    $stdDev = $consistencyData['std_dev'] ?? 0;
    $avgScore = $consistencyData['avg_score'] ?? 0;

    // Calculate consistency score (lower std dev = higher consistency)
    $consistencyScore = $avgScore > 0 ? max(0, 100 - (($stdDev / $avgScore)) * 100) : 100;

    // Get duration of experiment (days since first data point)
    $stmt = $pdo->prepare("
        SELECT DATEDIFF(NOW(), MIN(scored_at)) as days_running
        FROM churn_scores
        WHERE contact_id IN (".implode(',', $contactIds).")
    ");
    $stmt->execute();
    $daysRunning = $stmt->fetchColumn();
    $durationScore = min(100, $daysRunning); // Cap at 100

    // Get completeness of data (% of contacts with recent scores)
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT contact_id) as recent_contacts
        FROM churn_scores
        WHERE contact_id IN (".implode(',', $contactIds).")
        AND scored_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ");
    $stmt->execute();
    $recentContacts = $stmt->fetchColumn();
    $completenessScore = ($recentContacts / $totalContacts) * 100;

    // Calculate weighted confidence score
    $sampleSizeScore = min(100, ($totalContacts / 1000) * 100); // Cap at 1000 contacts
    $confidenceScore = (
        ($sampleSizeScore * 0.4) +
        ($consistencyScore * 0.3) +
        ($durationScore * 0.2) +
        ($completenessScore * 0.1)
    );

    return min(100, max(0, $confidenceScore)); // Ensure between 0-100
}

function getExperimentColor($experimentId) {
    // Generate consistent colors based on experiment ID
    $colors = [
        '#3ac3b8', '#4299e1', '#ed64a6', '#9f7aea', '#f6ad55',
        '#68d391', '#f687b3', '#63b3ed', '#f6e05e', '#81e6d9'
    ];
    return $colors[$experimentId % count($colors)];
}

function getConfidenceBadge($confidenceLevel) {
    if ($confidenceLevel >= 80) {
        return '<span class="badge badge-high">High</span>';
    } elseif ($confidenceLevel >= 50) {
        return '<span class="badge badge-medium">Medium</span>';
    } else {
        return '<span class="badge badge-low">Low</span>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Churn Experiments</title>
    <link rel="stylesheet" href="experiment.css">
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Custom styles from the provided HTML for the chart and other elements */
        body {
            font-family: 'Inter', sans-serif;
            /* Removed background-color */
            box-sizing: border-box;
        }

        .chart-container {
            position: relative;
            /* Removed background-color */
            border: 1px solid #e0e7ff;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            max-width: 900px;
            width: 100%;
            height: 400px;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 1rem;
            margin: 20px auto; /* Center the chart container */
        }

        canvas {
            display: block;
            width: 100%;
            height: 100%;
            border-radius: 1rem;
        }

        /* Tooltip styling */
        .tooltip {
            position: absolute;
            background-color: rgba(30, 41, 59, 0.9);
            color: #ffffff;
            padding: 0.5rem 0.75rem;
            border-radius: 0.5rem;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.2s ease-in-out;
            z-index: 100;
            white-space: nowrap;
            font-size: 0.875rem;
            line-height: 1.25rem;
            transform: translate(-50%, -110%);
        }

        .tooltip.visible {
            opacity: 1;
        }

        /* Existing custom styles from your original PHP file */
        .confidence-meter {
            display: flex;
            align-items: center;
            margin-top: 8px;
        }
        .confidence-fill {
            height: 6px;
            background: linear-gradient(90deg, #f56565, #f6e05e, #68d391);
            border-radius: 3px;
            margin-right: 8px;
        }
        .confidence-value {
            font-size: 12px;
            font-weight: bold;
            color: #4a5568;
        }
        .badge-high { background-color: #68d391; }
        .badge-medium { background-color: #f6e05e; }
        .badge-low { background-color: #f56565; }
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            color: white;
        }
        .best-performer {
            border: 2px solid #68d391;
            position: relative;
        }
        .best-performer::after {
            content: '★ Best Performer';
            position: absolute;
            top: -10px;
            right: 10px;
            background: #68d391;
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 10px;
        }

        /* Basic styling for existing elements for better integration */
        .experiment-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            border-radius: 8px;
        }
        .experiment-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .experiment-header h1 {
            font-size: 2em;
            color: #333;
        }
        .experiment-header p {
            color: #666;
        }
        .alert {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
        }
        .alert.error {
            background-color: #fdd;
            color: #d00;
            border: 1px solid #d00;
        }
        .alert.success {
            background-color: #ddf;
            color: #00d;
            border: 1px solid #00d;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input[type="text"],
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .btn-primary {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn-primary:hover {
            background-color: #45a049;
        }
        .comparison-controls, .source-filters {
            margin-top: 20px;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 8px;
            border: 1px solid #eee;
        }
        .comparison-controls form {
            display: flex;
            gap: 15px;
            align-items: flex-end;
        }
        .experiment-metrics {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .metric-card {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }
        .metric-label {
            font-size: 0.9em;
            color: #777;
            margin-bottom: 5px;
        }
        .metric-value {
            font-size: 2em;
            font-weight: bold;
            color: #333;
        }
        .metric-change {
            font-size: 0.8em;
            margin-top: 5px;
        }
        .metric-change.positive { color: #28a745; }
        .metric-change.negative { color: #dc3545; }
        .sparkline-container {
            height: 50px;
            width: 100%;
            margin-top: 10px;
        }
        .sparkline {
            width: 100%;
            height: 100%;
            overflow: visible; /* Allows points to go slightly outside if needed for effect */
        }
        .sparkline path {
            fill: none;
            stroke-width: 2;
        }
        .sparkline circle {
            fill: white;
            stroke-width: 2;
        }
        .chart-section {
            margin-top: 30px;
        }
        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        .chart-title {
            font-size: 1.5em;
            color: #333;
        }
        .chart-legend {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }
        .legend-item {
            display: flex;
            align-items: center;
            font-size: 0.9em;
            color: #555;
        }
        .legend-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 5px;
        }
        .table-section {
            margin-top: 30px;
        }
        .table-title {
            font-size: 1.5em;
            color: #333;
            margin-bottom: 15px;
        }
        .experiment-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        .experiment-table th, .experiment-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        .experiment-table th {
            background-color: #f2f2f2;
            font-weight: bold;
            color: #333;
        }
        .experiment-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .experiment-table tr:hover {
            background-color: #f1f1f1;
        }
        .metric-name {
            font-weight: bold;
            color: #555;
        }
        .specific-value {
            font-size: 0.8em;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="experiment-container">
        <div class="experiment-header">
            <h1>Churn Experiments</h1>
            <p>Compare user retention across acquisition channels</p>
        </div>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert error"><?= $_SESSION['error'] ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert success"><?= $_SESSION['success'] ?></div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <div class="experiment-controls">
            <form id="experimentForm" method="POST">
                <div class="form-group">
                    <label for="experiment_name">Experiment Name</label>
                    <input type="text" id="experiment_name" name="experiment_name" required>
                </div>

                <div class="form-group">
                    <label for="experiment_description">Description</label>
                    <textarea id="experiment_description" name="experiment_description"></textarea>
                </div>

                <div class="form-group">
                    <label for="acquisition_channel">Acquisition Channel</label>
                    <select id="acquisition_channel" name="acquisition_channel" required>
                        <option value="blog">Blog Posts</option>
                        <option value="landing">Landing Pages</option>
                        <option value="social">Social Media</option>
                        <option value="email">Email Campaign</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="source_type">Source Type</label>
                    <select id="source_type" name="source_type" required>
                        <option value="stream">Stream</option>
                        <option value="cohort">Cohort</option>
                        <option value="contact">Contact</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="source_id">Select Source</label>
                    <select id="source_id" name="source_id" required>
                        <?php
                        // Initial load with streams
                        $stmt = $pdo->prepare("SELECT id, name FROM streams WHERE user_id = ?");
                        $stmt->execute([$current_user_id]);
                        while ($row = $stmt->fetch()) {
                            echo "<option value='{$row['id']}'>{$row['name']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group" id="specificValueGroup">
                    <label id="specificValueLabel">Blog Post URL</label>
                    <input type="text" id="specific_value" name="specific_value" placeholder="Enter specific value">
                </div>

                <button type="submit" name="create_experiment" class="btn-primary">Create Experiment</button>
            </form>
        </div>

        <?php if (!empty($experiments)): ?>
        <div class="comparison-controls">
            <form method="GET" class="compare-form">
                <div class="form-group">
                    <label for="compare_experiments">Compare Experiments:</label>
                    <select id="compare_experiments" name="compare[]" multiple="multiple" class="experiment-select">
                        <?php foreach ($experiments as $exp): ?>
                            <option value="<?= $exp['id'] ?>" <?= in_array($exp['id'], $selectedExperimentIds) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($exp['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="date_range">Date Range (weeks):</label>
                    <select id="date_range" name="date_range">
                        <option value="4" <?= $dateRange == 4 ? 'selected' : '' ?>>4 Weeks</option>
                        <option value="8" <?= $dateRange == 8 ? 'selected' : '' ?>>8 Weeks</option>
                        <option value="10" <?= $dateRange == 10 ? 'selected' : '' ?>>10 Weeks</option>
                        <option value="12" <?= $dateRange == 12 ? 'selected' : '' ?>>12 Weeks</option>
                    </select>
                </div>

                <button type="submit" class="btn-primary">Update Comparison</button>
            </form>
        </div>

        <?php if (!empty($sources)): ?>
        <div class="source-filters">
            <?php foreach ($sources as $source): ?>
                <button class="source-btn active" data-source="<?= $source['channel_type'] ?>">
                    <?= $source['experiment_name'] ?> - <?= ucfirst($source['channel_type']) ?>
                    <?php if (!empty($source['specific_value'])): ?>
                        <span class="specific-value">(<?= $source['specific_value'] ?>)</span>
                    <?php endif; ?>
                </button>
            <?php endforeach; ?>
        </div>

        <div class="experiment-metrics">
            <?php foreach ($metricsData as $sourceKey => $data): ?>
            <div class="metric-card <?= isset($bestPerformer) && $sourceKey === $bestPerformer['source_key'] ? 'best-performer' : '' ?>">
                <div class="metric-label"><?= $data['experiment_name'] ?> - <?= ucfirst($data['channel']) ?> Churn</div>
                <div class="metric-value"><?= number_format($data['current'], 1) ?>%</div>
                <div class="metric-change <?= $data['change'] < 0 ? 'positive' : 'negative' ?>">
                    <?= $data['change'] < 0 ? '↓' : '↑' ?> <?= number_format(abs($data['change']), 1) ?>% vs last period
                </div>
                <div class="confidence-meter">
                    <div class="confidence-fill" style="width: <?= $data['confidence_level'] ?>%"></div>
                    <div class="confidence-value"><?= round($data['confidence_level']) ?>% confidence</div>
                </div>
                <div class="sparkline-container">
                    <svg class="sparkline" id="<?= $sourceKey ?>-sparkline"></svg>
                </div>
            </div>
            <?php endforeach; ?>

            <?php if (isset($bestPerformer)): ?>
            <div class="metric-card best-performer">
                <div class="metric-label">Best Performer</div>
                <div class="metric-value"><?= number_format($bestPerformer['current'], 1) ?>%</div>
                <div class="metric-details">
                    <?= $bestPerformer['experiment_name'] ?><br>
                    <small><?= ucfirst($bestPerformer['channel']) ?></small>
                </div>
                <div class="confidence-meter">
                    <div class="confidence-fill" style="width: <?= $bestPerformer['confidence_level'] ?>%"></div>
                    <div class="confidence-value"><?= round($bestPerformer['confidence_level']) ?>% confidence</div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>

        <div class="chart-section">
            <div class="chart-header">
                <h3 class="chart-title">Churn Rate Over Time</h3>
                <div class="chart-legend" id="chartLegend">
                    <?php if (!empty($sources)): ?>
                        <?php foreach ($sources as $source): ?>
                        <div class="legend-item">
                            <div class="legend-dot" style="background-color: <?= getExperimentColor($source['experiment_id']) ?>"></div>
                            <span><?= $source['experiment_name'] ?> - <?= ucfirst($source['channel_type']) ?></span>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="chart-container">
                <canvas id="myLineChart"></canvas>
                <div id="chartTooltip" class="tooltip"></div>
                <?php if (empty($chartData)): ?>
                    <p style="position: absolute; bottom: 10px; color: #888; font-size: 0.8em; text-align: center; width: 100%;">This is a demo graph. No real experiment data available yet.</p>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!empty($experiments) && !empty($sources)): // Only show table if there's data to compare ?>
        <div class="table-section">
            <h3 class="table-title">Detailed Comparison</h3>
            <table class="experiment-table">
                <thead>
                    <tr>
                        <th>Metric</th>
                        <?php foreach ($sources as $source):
                            $sourceKey = $source['experiment_id'].'-'.$source['id'];
                        ?>
                        <th>
                            <?= $source['experiment_name'] ?><br>
                            <small><?= ucfirst($source['channel_type']) ?>
                            <?php if (!empty($source['specific_value'])): ?>
                                - <?= $source['specific_value'] ?>
                            <?php endif; ?>
                            </small>
                        </th>
                        <?php endforeach; ?>
                        <th>Confidence</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="metric-name">Current Churn Rate</td>
                        <?php foreach ($sources as $source):
                            $sourceKey = $source['experiment_id'].'-'.$source['id'];
                            $data = $metricsData[$sourceKey];
                        ?>
                        <td><?= number_format($data['current'], 1) ?>%</td>
                        <?php endforeach; ?>
                        <td><?= getConfidenceBadge($data['confidence_level']) ?></td>
                    </tr>
                    <tr>
                        <td class="metric-name">Churn Change (vs last period)</td>
                        <?php foreach ($sources as $source):
                            $sourceKey = $source['experiment_id'].'-'.$source['id'];
                            $data = $metricsData[$sourceKey];
                        ?>
                        <td class="<?= $data['change'] < 0 ? 'positive' : 'negative' ?>">
                            <?= $data['change'] < 0 ? '↓' : '↑' ?> <?= number_format(abs($data['change']), 1) ?>%
                        </td>
                        <?php endforeach; ?>
                        <td><?= getConfidenceBadge($data['confidence_level']) ?></td>
                    </tr>
                    <tr>
                        <td class="metric-name">Avg Session Duration (min)</td>
                        <?php foreach ($sources as $source):
                            $sourceKey = $source['experiment_id'].'-'.$source['id'];
                            $data = $metricsData[$sourceKey];
                        ?>
                        <td class="<?= $data['duration'] > 3 ? 'positive' : '' ?>">
                            <?= number_format($data['duration'] ?? 0, 2) ?>
                        </td>
                        <?php endforeach; ?>
                        <td><?= getConfidenceBadge($data['confidence_level']) ?></td>
                    </tr>
                    <tr>
                        <td class="metric-name">Feature Adoption Rate</td>
                        <?php foreach ($sources as $source):
                            $sourceKey = $source['experiment_id'].'-'.$source['id'];
                            $data = $metricsData[$sourceKey];
                        ?>
                        <td class="<?= $data['feature_adoption'] > 60 ? 'positive' : '' ?>">
                            <?= number_format($data['feature_adoption'] ?? 0, 1) ?>%
                        </td>
                        <?php endforeach; ?>
                        <td><?= getConfidenceBadge($data['confidence_level']) ?></td>
                    </tr>
                    <tr>
                        <td class="metric-name">Competitor Visits</td>
                        <?php foreach ($sources as $source):
                            $sourceKey = $source['experiment_id'].'-'.$source['id'];
                            $data = $metricsData[$sourceKey];
                        ?>
                        <td>
                            <?= $data['competitor_visits'] ?> visits<br>
                            <small><?= number_format($data['competitor_visit_percent'], 1) ?>% of users</small>
                        </td>
                        <?php endforeach; ?>
                        <td><?= getConfidenceBadge($data['confidence_level']) ?></td>
                    </tr>
                    <tr>
                        <td class="metric-name">Total Users</td>
                        <?php foreach ($sources as $source):
                            $sourceKey = $source['experiment_id'].'-'.$source['id'];
                            $data = $metricsData[$sourceKey];
                        ?>
                        <td><?= $data['total_contacts'] ?></td>
                        <?php endforeach; ?>
                        <td><?= getConfidenceBadge($data['confidence_level']) ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <script>
        // Initialize Select2 for experiment comparison
        $(document).ready(function() {
            $('.experiment-select').select2({
                placeholder: "Select experiments to compare",
                allowClear: true,
                width: '100%'
            });
        });

        // Form handling for dynamic source selection
        document.getElementById('source_type').addEventListener('change', function() {
            const sourceType = this.value;
            const sourceSelect = document.getElementById('source_id');

            // Show loading state
            sourceSelect.innerHTML = '<option value="">Loading...</option>';

            // Fetch data via AJAX
            const xhr = new XMLHttpRequest();
            xhr.open('GET', `../api/get_sources.php?type=${sourceType}&user_id=<?= $current_user_id ?>`, true);
            xhr.onload = function() {
                if (this.status === 200) {
                    const data = JSON.parse(this.responseText);
                    sourceSelect.innerHTML = '';
                    data.forEach(item => {
                        const option = document.createElement('option');
                        option.value = item.id;
                        option.textContent = item.name;
                        sourceSelect.appendChild(option);
                    });
                }
            };
            xhr.send();
        });

        // Dynamic label for specific value field
        document.getElementById('acquisition_channel').addEventListener('change', function() {
            const channel = this.value;
            const label = document.getElementById('specificValueLabel');
            const input = document.getElementById('specific_value');

            switch(channel) {
                case 'blog':
                    label.textContent = 'Blog Post URL';
                    input.placeholder = 'https://example.com/blog/post-title';
                    break;
                case 'landing':
                    label.textContent = 'Landing Page URL';
                    input.placeholder = 'https://example.com/landing-page';
                    break;
                case 'social':
                    label.textContent = 'Social Platform';
                    input.placeholder = 'Facebook, Twitter, Instagram, etc.';
                    break;
                case 'email':
                    label.textContent = 'Campaign Name';
                    input.placeholder = 'Newsletter #5, Welcome Series, etc.';
                    break;
            }
        });

        // Sparkline initialization
        function createSparkline(containerId, data, color = '#3ac3b8') {
            const svg = document.getElementById(containerId);
            const width = svg.clientWidth;
            const height = 40;
            const padding = 5;

            svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
            svg.innerHTML = '';

            if (data.length < 2) return;

            const min = Math.min(...data);
            const max = Math.max(...data);
            const range = max - min || 1;

            const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            let pathData = '';

            data.forEach((value, index) => {
                const x = (index / (data.length - 1)) * (width - 2 * padding) + padding;
                const y = height - padding - ((value - min) / range) * (height - 2 * padding);

                if (index === 0) {
                    pathData += `M ${x} ${y}`;
                } else {
                    pathData += ` L ${x} ${y}`;
                }
            });

            path.setAttribute('d', pathData);
            path.setAttribute('stroke', color);
            svg.appendChild(path);

            data.forEach((value, index) => {
                const x = (index / (data.length - 1)) * (width - 2 * padding) + padding;
                const y = height - padding - ((value - min) / range) * (height - 2 * padding);

                const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
                circle.setAttribute('cx', x);
                circle.setAttribute('cy', y);
                circle.setAttribute('r', 3);
                circle.setAttribute('data-value', value);
                circle.setAttribute('data-index', index);
                circle.setAttribute('fill', color); /* Match circle fill to line color */
                circle.setAttribute('stroke', 'white'); /* White border for points */
                circle.setAttribute('stroke-width', '2');
                svg.appendChild(circle);
            });
        }

        <?php if (!empty($metricsData)): ?>
        // Initialize sparklines
        <?php foreach ($metricsData as $sourceKey => $data): ?>
        createSparkline('<?= $sourceKey ?>-sparkline', <?= json_encode($data['trend']) ?>, '<?= getExperimentColor($data['experiment_id']) ?>');
        <?php endforeach; ?>
        <?php endif; ?>

        // Custom Chart Initialization
        document.addEventListener('DOMContentLoaded', function() {
            const canvas = document.getElementById('myLineChart');
            const ctx = canvas.getContext('2d');
            const tooltip = document.getElementById('chartTooltip');

            // PHP data passed to JavaScript
            const phpChartData = <?= json_encode(array_values($chartData)) ?>;
            let datasetsForChart = [];
            let chartLabels = [];

            if (phpChartData.length > 0) {
                chartLabels = phpChartData[0].labels; // Assuming all datasets have the same labels
                datasetsForChart = phpChartData.map(dataset => ({
                    label: dataset.label,
                    data: dataset.data,
                    borderColor: dataset.borderColor,
                    backgroundColor: dataset.backgroundColor, // Fill color for the area under the line
                }));
            } else {
                // Demo data if no real data
                chartLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                datasetsForChart = [{
                    label: 'Demo Churn Rate',
                    data: [10, 12, 9, 15, 13, 18, 16, 20, 17, 22, 19, 25], // Example demo values
                    borderColor: '#4f46e5', // Indigo-600
                    backgroundColor: 'rgba(79, 70, 229, 0.2)', // Indigo-600 with opacity for fill
                }];
            }


            // Configuration for the chart appearance
            const config = {
                padding: 40, // Padding around the chart content within the canvas
                pointRadius: 6, // Radius of the data points
                gridColor: '#e0e7ff', // Color of grid lines
                axisLabelColor: '#6b7280', // Gray-500 for axis labels
                // lineColor and gradient colors are now handled by datasetsForChart
            };

            // Function to draw the chart
            function drawChart() {
                const devicePixelRatio = window.devicePixelRatio || 1;
                canvas.width = canvas.offsetWidth * devicePixelRatio;
                canvas.height = canvas.offsetHeight * devicePixelRatio;
                ctx.scale(devicePixelRatio, devicePixelRatio);

                ctx.clearRect(0, 0, canvas.offsetWidth, canvas.offsetHeight);

                const width = canvas.offsetWidth;
                const height = canvas.offsetHeight;
                const { padding, pointRadius, gridColor, axisLabelColor } = config;

                const chartWidth = width - 2 * padding;
                const chartHeight = height - 2 * padding;

                let allValues = [];
                // Only add values if chartLabels has data
                if (chartLabels.length > 0) {
                    datasetsForChart.forEach(dataset => {
                        allValues = allValues.concat(dataset.data);
                    });
                } else {
                    // If no real data, ensure demo values are used for scaling
                    allValues = datasetsForChart[0].data;
                }

                const maxValue = allValues.length > 0 ? Math.max(...allValues) : 100; // Default max if no data
                const minValue = allValues.length > 0 ? Math.min(...allValues) : 0; // Default min if no data
                const effectiveMinValue = minValue > 0 ? 0 : minValue;
                const effectiveMaxValue = maxValue * 1.1;
                const effectiveValueRange = effectiveMaxValue - effectiveMinValue;

                const getX = (index) => padding + (index / (chartLabels.length - 1)) * chartWidth;
                const getY = (value) => {
                    const normalizedValue = (value - effectiveMinValue) / effectiveValueRange;
                    return height - padding - (normalizedValue * chartHeight);
                };

                // Y-axis grid lines and labels
                const numYLabels = 5;
                for (let i = 0; i <= numYLabels; i++) {
                    const value = effectiveMinValue + (effectiveValueRange / numYLabels) * i;
                    const y = getY(value);

                    ctx.beginPath();
                    ctx.moveTo(padding, y);
                    ctx.lineTo(width - padding, y);
                    ctx.strokeStyle = gridColor;
                    ctx.lineWidth = 1;
                    ctx.globalAlpha = 0.5;
                    ctx.stroke();
                    ctx.globalAlpha = 1;

                    ctx.fillStyle = axisLabelColor;
                    ctx.font = '12px Inter';
                    ctx.textAlign = 'right';
                    ctx.textBaseline = 'middle';
                    ctx.fillText(Math.round(value), padding - 10, y);
                }

                // X-axis labels
                ctx.fillStyle = axisLabelColor;
                ctx.font = '12px Inter';
                ctx.textBaseline = 'top';
                chartLabels.forEach((label, i) => {
                    const x = getX(i);
                    ctx.textAlign = (i === 0) ? 'left' : (i === chartLabels.length - 1) ? 'right' : 'center';
                    ctx.fillText(label, x, height - padding + 15);
                });

                // Draw each dataset
                datasetsForChart.forEach(dataset => {
                    const data = dataset.data;
                    const lineColor = dataset.borderColor;
                    const fillColor = dataset.backgroundColor;

                    // Draw gradient fill
                    ctx.beginPath();
                    ctx.moveTo(getX(0), getY(effectiveMinValue));
                    data.forEach((value, i) => {
                        const x = getX(i);
                        const y = getY(value);
                        if (i === 0) {
                            ctx.lineTo(x, y);
                        } else {
                            const prevX = getX(i - 1);
                            const prevY = getY(data[i - 1]);
                            const cp1x = (prevX + x) / 2;
                            const cp1y = prevY;
                            const cp2x = (prevX + x) / 2;
                            const cp2y = y;
                            ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y);
                        }
                    });
                    ctx.lineTo(getX(data.length - 1), getY(effectiveMinValue));
                    ctx.closePath();

                    const gradient = ctx.createLinearGradient(0, padding, 0, height - padding);
                    gradient.addColorStop(0, fillColor); // Use dataset's background color
                    gradient.addColorStop(1, 'rgba(255, 255, 255, 0)'); // End transparent
                    ctx.fillStyle = gradient;
                    ctx.fill();

                    // Draw the line
                    ctx.beginPath();
                    data.forEach((value, i) => {
                        const x = getX(i);
                        const y = getY(value);
                        if (i === 0) {
                            ctx.moveTo(x, y);
                        } else {
                            const prevX = getX(i - 1);
                            const prevY = getY(data[i - 1]);
                            const cp1x = (prevX + x) / 2;
                            const cp1y = prevY;
                            const cp2x = (prevX + x) / 2;
                            const cp2y = y;
                            ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y);
                        }
                    });
                    ctx.strokeStyle = lineColor;
                    ctx.lineWidth = 3;
                    ctx.stroke();

                    // Draw Data Points
                    data.forEach((value, i) => {
                        const x = getX(i);
                        const y = getY(value);

                        ctx.beginPath();
                        ctx.arc(x, y, pointRadius, 0, Math.PI * 2);
                        ctx.fillStyle = lineColor;
                        ctx.fill();
                        ctx.strokeStyle = '#ffffff';
                        ctx.lineWidth = 2;
                        ctx.stroke();
                    });
                });
            }

            // Interactive Tooltip Logic
            let animationFrameId = null;

            canvas.addEventListener('mousemove', (e) => {
                cancelAnimationFrame(animationFrameId);

                animationFrameId = requestAnimationFrame(() => {
                    const rect = canvas.getBoundingClientRect();
                    const mouseX = e.clientX - rect.left;
                    const mouseY = e.clientY - rect.top;

                    let hoveredPoint = null;
                    const tolerance = config.pointRadius * 1.5;

                    datasetsForChart.forEach(dataset => {
                        dataset.data.forEach((value, i) => {
                            const x = getX(i);
                            const y = getY(value);

                            const distance = Math.sqrt(Math.pow(mouseX - x, 2) + Math.pow(mouseY - y, 2));

                            if (distance < tolerance) {
                                hoveredPoint = {
                                    datasetLabel: dataset.label,
                                    label: chartLabels[i],
                                    value: value,
                                    x: x,
                                    y: y
                                };
                                return; // Stop searching once a point is found
                            }
                        });
                        if (hoveredPoint) return; // Stop searching datasets
                    });

                    if (hoveredPoint) {
                        tooltip.innerHTML = `<strong>${hoveredPoint.datasetLabel}</strong><br> ${hoveredPoint.label}: ${hoveredPoint.value.toFixed(1)}%`;
                        tooltip.style.left = `${hoveredPoint.x}px`;
                        tooltip.style.top = `${hoveredPoint.y}px`;
                        tooltip.classList.add('visible');
                    } else {
                        tooltip.classList.remove('visible');
                    }
                });
            });

            canvas.addEventListener('mouseleave', () => {
                cancelAnimationFrame(animationFrameId);
                tooltip.classList.remove('visible');
            });

            // Responsiveness
            let resizeTimeout;
            window.addEventListener('resize', () => {
                clearTimeout(resizeTimeout);
                resizeTimeout = setTimeout(() => {
                    drawChart();
                }, 100);
            });

            // Initial draw
            drawChart();
        });
    </script>
</body>
</html>
<?php
require_once '../includes/footer.php';
?>