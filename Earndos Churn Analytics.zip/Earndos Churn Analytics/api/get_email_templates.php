<?php
// api/get_email_templates.php

// Include database connection
// Adjust path as needed based on your file structure
// From api/ to includes/db.php would be ../includes/db.php
require_once '../includes/db.php';

// Start session to access user_id
session_start();

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['error' => 'Unauthorized access. Please log in.']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    // Fetch email templates that belong to the current user OR are global templates (user_id IS NULL)
    $stmt = $pdo->prepare("SELECT id, name, subject, content, sender_name
                           FROM email_templates
                           WHERE user_id = ? OR user_id IS NULL
                           ORDER BY name ASC");
    $stmt->execute([$user_id]);
    $templates = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Return the templates as JSON
    echo json_encode($templates);

} catch (PDOException $e) {
    // Handle database errors
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'Database error: Could not retrieve email templates.', 'details' => $e->getMessage()]);
    // Log the error for debugging on the server-side
    error_log("Error fetching email templates in api/get_email_templates.php: " . $e->getMessage());
}
?>