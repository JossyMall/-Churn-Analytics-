<?php
// api/webhooks_listener.php
// This script acts as a listener for incoming webhook events from external services.
// It does NOT use API keys or tracking codes for authentication from your users,
// but rather relies on shared secrets/signatures from the sending service.

header('Content-Type: application/json');
require_once '../includes/db.php'; // Path from api/ to includes/db.php
require_once '../includes/api_helpers.php'; // Path from api/ to includes/api_helpers.php (where event processing logic resides)

// --- PHP Error Reporting for Debugging ---
// IMPORTANT: Remove or set to 0 in production environments for security.
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// --- End PHP Error Reporting ---

// Ensure the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed. Only POST requests are accepted.']);
    exit;
}

// Get the raw POST payload
$raw_payload = file_get_contents('php://input');
$payload = json_decode($raw_payload, true);

// Get any signature header provided by the sending service
$signature = $_SERVER['HTTP_X_SIGNATURE'] ?? $_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] ?? ''; // Common headers

try {
    if (empty($payload)) {
        throw new Exception('Empty or invalid JSON payload received.');
    }
    if (empty($payload['event_type'])) {
        throw new Exception('Missing "event_type" in payload. Cannot process webhook.');
    }

    $event_type = $payload['event_type'];

    // Find active webhooks configured by your users for this event type
    // This assumes your `webhooks` table stores configurations for *incoming* webhooks as well,
    // where `event_type` matches the incoming payload's event_type.
    // In many cases, the `webhooks` table is for *outgoing* webhooks from your system.
    // If this is for *incoming* webhooks (like from Stripe or Zendesk), you'd typically look up
    // the configuration based on the webhook URL or a unique ID from the external service.
    // For simplicity, here we're checking your `webhooks` table for active entries matching the event_type.
    // The `webhook_id` in the URL (e.g., /api/webhooks_listener.php?id=123) might also be used for lookup.
    // For now, let's assume `event_type` is the primary lookup key.

    $stmt = $pdo->prepare("SELECT id, user_id, url, event_type, secret_key FROM webhooks WHERE event_type = :event_type AND is_active = 1");
    $stmt->bindValue(':event_type', $event_type);
    $stmt->execute();
    $active_webhooks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($active_webhooks)) {
        // Log this if no active webhook handlers found for the event type
        error_log("No active webhook handler found for event_type: " . $event_type);
        http_response_code(200); // Respond with 200 OK even if not processed, to prevent re-sending by external service
        echo json_encode(['status' => 'success', 'message' => 'Event received, but no active handler found.']);
        exit;
    }

    $processed_count = 0;
    foreach ($active_webhooks as $webhook_config) {
        // Signature verification (if a secret key is configured for this webhook)
        if (!empty($webhook_config['secret_key'])) {
            $expected_signature = hash_hmac('sha256', $raw_payload, $webhook_config['secret_key']);
            if (!hash_equals($expected_signature, $signature)) {
                error_log("Webhook ID {$webhook_config['id']} - Signature mismatch for event_type: {$event_type}. Skipping processing.");
                continue; // Skip processing for this specific webhook config if signature doesn't match
            }
        }

        // Dispatch to appropriate helper function based on event_type
        // These helper functions will be defined in includes/api_helpers.php
        switch ($event_type) {
            case 'churn_alert': // Example: Incoming alert from an external AI service
                // Call a helper to process this specific event type
                processWebhookChurnAlert($pdo, $webhook_config['user_id'], $payload);
                break;
            case 'feature_usage': // Example: Incoming feature usage from a product analytics tool
                processWebhookFeatureUsage($pdo, $webhook_config['user_id'], $payload);
                break;
            case 'competitor_visit': // Example: Incoming competitor visit data
                processWebhookCompetitorVisit($pdo, $webhook_config['user_id'], $payload);
                break;
            case 'payment_failed': // Example: Incoming payment failure from a payment gateway
                processWebhookPaymentFailed($pdo, $webhook_config['user_id'], $payload);
                break;
            // Add more cases for other specific incoming event types (e.g., 'user_signup', 'subscription_updated')
            case 'custom': // Generic handler for custom events
            default:
                // Handle generic custom events or log unknown types
                processWebhookCustomEvent($pdo, $webhook_config['user_id'], $payload, $event_type);
                break;
        }
        $processed_count++;
    }

    http_response_code(200);
    echo json_encode(['status' => 'success', 'message' => "Webhook processed. Handlers dispatched: {$processed_count}."]);

} catch (Exception $e) {
    http_response_code(400); // Bad Request for client-side errors, or 500 for internal errors
    error_log("Webhook Listener Error: " . $e->getMessage() . " Payload: " . $raw_payload);
    echo json_encode(['error' => $e->getMessage()]);
}

exit; // Ensure no further output
?>
