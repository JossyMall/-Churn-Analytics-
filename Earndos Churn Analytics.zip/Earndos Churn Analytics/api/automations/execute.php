<?php
require_once __DIR__.'/../../includes/db.php';
require_once __DIR__.'/../../includes/automation_engine.php';
require_once __DIR__.'/../../includes/external_apis/Mautic.php';
require_once __DIR__.'/../../includes/external_apis/Hubspot.php';
require_once __DIR__.'/../../includes/external_apis/Salesforce.php';
require_once __DIR__.'/../../includes/external_apis/Zapier.php';

header('Content-Type: application/json');

// 1. Authentication
$apiKey = $_SERVER['HTTP_X_API_KEY'] ?? '';
if (empty($apiKey)) {
    http_response_code(401);
    die(json_encode(['error' => 'API key required']));
}

// 2. Validate API Key and Get User
try {
    $stmt = $pdo->prepare("
        SELECT u.id, u.is_admin, ua.tracking_method 
        FROM user_api_keys ua
        JOIN users u ON ua.user_id = u.id
        WHERE ua.api_key = ? AND u.is_active = 1
    ");
    $stmt->execute([$apiKey]);
    $user = $stmt->fetch();
    
    if (!$user) {
        http_response_code(403);
        die(json_encode(['error' => 'Invalid API key']));
    }
} catch (PDOException $e) {
    http_response_code(500);
    die(json_encode(['error' => 'Database error']));
}

// 3. Parse Request
$input = json_decode(file_get_contents('php://input'), true);
if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    die(json_encode(['error' => 'Invalid JSON']));
}

// 4. Initialize Engine and Process Request
try {
    $engine = new AutomationEngine($pdo);
    $response = [];
    
    switch ($_SERVER['REQUEST_METHOD']) {
        case 'POST':
            if (empty($input['action'])) {
                throw new Exception('Action parameter required');
            }
            
            $response = handleAction($pdo, $engine, $user['id'], $input);
            break;
            
        case 'GET':
            $response = handleGetRequest($pdo, $user['id'], $_GET);
            break;
            
        default:
            http_response_code(405);
            die(json_encode(['error' => 'Method not allowed']));
    }
    
    echo json_encode($response);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

/**
 * Handles POST actions
 */
function handleAction($pdo, $engine, $userId, $input) {
    switch ($input['action']) {
        case 'execute_workflow':
            return executeWorkflow($pdo, $engine, $userId, $input);
            
        case 'test_connection':
            return testIntegrationConnection($pdo, $userId, $input);
            
        case 'sync_contact':
            return syncContactToExternal($pdo, $userId, $input);
            
        default:
            throw new Exception('Invalid action');
    }
}

/**
 * Executes a complete automation workflow
 */
function executeWorkflow($pdo, $engine, $userId, $data) {
    // Validate required fields
    $required = ['workflow_id', 'contact_id'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            throw new Exception("Missing required field: $field");
        }
    }
    
    // Verify user owns the workflow
    $stmt = $pdo->prepare("
        SELECT 1 FROM automation_workflows 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$data['workflow_id'], $userId]);
    if (!$stmt->fetch()) {
        throw new Exception('Workflow not found');
    }
    
    // Verify user owns the contact
    $stmt = $pdo->prepare("
        SELECT 1 FROM contacts c
        JOIN streams s ON c.stream_id = s.id
        WHERE c.id = ? AND s.user_id = ?
    ");
    $stmt->execute([$data['contact_id'], $userId]);
    if (!$stmt->fetch()) {
        throw new Exception('Contact not found');
    }
    
    // Get all workflow actions
    $actions = $pdo->prepare("
        SELECT * FROM automation_actions 
        WHERE workflow_id = ?
        ORDER BY execution_order
    ");
    $actions->execute([$data['workflow_id']]);
    $actions = $actions->fetchAll();
    
    // Execute each action
    $results = [];
    foreach ($actions as $action) {
        $actionData = json_decode($action['action_data'], true);
        $results[] = executeSingleAction(
            $pdo, 
            $engine,
            $userId,
            $action['action_type'],
            $actionData,
            $data['contact_id'],
            $data['workflow_id']
        );
    }
    
    return [
        'success' => true,
        'results' => $results,
        'contact_id' => $data['contact_id'],
        'workflow_id' => $data['workflow_id']
    ];
}

/**
 * Executes a single automation action
 */
function executeSingleAction($pdo, $engine, $userId, $actionType, $actionData, $contactId, $workflowId) {
    try {
        $contact = getContactDetails($pdo, $contactId, $userId);
        
        switch ($actionType) {
            case 'email':
                return sendAutomationEmail($pdo, $userId, $contact, $actionData);
                
            case 'sms':
                return sendAutomationSMS($pdo, $userId, $contact, $actionData);
                
            case 'change_cohort':
                return changeContactCohort($pdo, $userId, $contactId, $actionData);
                
            case 'notification':
                return createNotification($pdo, $userId, $contact, $actionData);
                
            case 'external':
                return executeExternalAction($pdo, $userId, $contact, $actionData);
                
            default:
                throw new Exception("Unknown action type: $actionType");
        }
    } catch (Exception $e) {
        logActionError($pdo, $workflowId, $contactId, $actionType, $e->getMessage());
        return [
            'success' => false,
            'error' => $e->getMessage(),
            'action_type' => $actionType
        ];
    }
}

/**
 * Handles external service actions
 */
function executeExternalAction($pdo, $userId, $contact, $actionData) {
    if (empty($actionData['integration_id'])) {
        throw new Exception('Integration ID required');
    }
    
    // Get integration config
    $stmt = $pdo->prepare("
        SELECT * FROM external_integrations 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$actionData['integration_id'], $userId]);
    $integration = $stmt->fetch();
    
    if (!$integration) {
        throw new Exception('Integration not found');
    }
    
    $authConfig = json_decode($integration['auth_config'], true);
    $service = $integration['service_name'];
    
    // Initialize appropriate client
    switch ($service) {
        case 'mautic':
            $client = new MauticClient($authConfig);
            break;
            
        case 'hubspot':
            $client = new HubspotClient($authConfig);
            break;
            
        case 'salesforce':
            $client = new SalesforceClient($authConfig);
            break;
            
        case 'zapier':
            $client = new ZapierClient($authConfig);
            break;
            
        default:
            throw new Exception("Unsupported service: $service");
    }
    
    // Execute the action
    switch ($actionData['action_name']) {
        case 'add_to_segment':
            if (empty($actionData['segment_id'])) {
                throw new Exception('Segment ID required');
            }
            return $client->addToSegment($contact['id'], $actionData['segment_id']);
            
        case 'update_contact':
            return $client->createOrUpdateContact($actionData['contact_data']);
            
        case 'custom_webhook':
            return $client->triggerWebhook($actionData['payload']);
            
        default:
            throw new Exception("Unsupported action: {$actionData['action_name']}");
    }
}

/**
 * Tests an external integration connection
 */
function testIntegrationConnection($pdo, $userId, $data) {
    if (empty($data['integration_id'])) {
        throw new Exception('Integration ID required');
    }
    
    $stmt = $pdo->prepare("
        SELECT * FROM external_integrations 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$data['integration_id'], $userId]);
    $integration = $stmt->fetch();
    
    if (!$integration) {
        throw new Exception('Integration not found');
    }
    
    $authConfig = json_decode($integration['auth_config'], true);
    $service = $integration['service_name'];
    
    switch ($service) {
        case 'mautic':
            $client = new MauticClient($authConfig);
            break;
            
        case 'hubspot':
            $client = new HubspotClient($authConfig);
            break;
            
        case 'salesforce':
            $client = new SalesforceClient($authConfig);
            break;
            
        case 'zapier':
            $client = new ZapierClient($authConfig);
            break;
            
        default:
            throw new Exception("Unsupported service: $service");
    }
    
    return [
        'success' => $client->testConnection(),
        'service' => $service
    ];
}

/**
 * Handles GET requests (list endpoints)
 */
function handleGetRequest($pdo, $userId, $queryParams) {
    if (empty($queryParams['resource'])) {
        throw new Exception('Resource parameter required');
    }
    
    switch ($queryParams['resource']) {
        case 'workflows':
            return listUserWorkflows($pdo, $userId);
            
        case 'integrations':
            return listUserIntegrations($pdo, $userId);
            
        case 'segments':
            return listIntegrationSegments($pdo, $userId, $queryParams);
            
        default:
            throw new Exception('Invalid resource');
    }
}

/**
 * Lists segments from an external integration
 */
function listIntegrationSegments($pdo, $userId, $params) {
    if (empty($params['integration_id'])) {
        throw new Exception('Integration ID required');
    }
    
    $stmt = $pdo->prepare("
        SELECT * FROM external_integrations 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$params['integration_id'], $userId]);
    $integration = $stmt->fetch();
    
    if (!$integration) {
        throw new Exception('Integration not found');
    }
    
    $authConfig = json_decode($integration['auth_config'], true);
    $service = $integration['service_name'];
    
    switch ($service) {
        case 'mautic':
            $client = new MauticClient($authConfig);
            return $client->listSegments();
            
        case 'hubspot':
            $client = new HubspotClient($authConfig);
            return $client->listSegments();
            
        case 'salesforce':
            $client = new SalesforceClient($authConfig);
            return $client->listCampaigns();
            
        default:
            throw new Exception("Segments not supported for $service");
    }
}

// Helper functions (implement these based on your existing code)
function getContactDetails($pdo, $contactId, $userId) { /* ... */ }
function sendAutomationEmail($pdo, $userId, $contact, $actionData) { /* ... */ }
function sendAutomationSMS($pdo, $userId, $contact, $actionData) { /* ... */ }
function changeContactCohort($pdo, $userId, $contactId, $actionData) { /* ... */ }
function createNotification($pdo, $userId, $contact, $actionData) { /* ... */ }
function logActionError($pdo, $workflowId, $contactId, $actionType, $error) { /* ... */ }
function listUserWorkflows($pdo, $userId) { /* ... */ }
function listUserIntegrations($pdo, $userId) { /* ... */ }