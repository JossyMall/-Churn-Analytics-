<?php
// api/index.php
header('Content-Type: application/json');

// Start session at the very beginning if it's not already started by db.php/header.php.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../includes/db.php';
require_once '../includes/functions.php'; // Assuming general utility functions exist here
require_once '../includes/api_helpers.php'; // Contains all new and existing API helper functions

// IMPORTANT: Remove or set to 0 in production environments for security.
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
ini_set('log_errors', '1'); // Ensure logging is on
ini_set('error_log', '/var/www/www-root/data/www/earndos.com/io/php_app_errors.log'); // Custom log file


$user_id = null;
$stream_id_from_tracking = null;
$is_tracking_request = false;
// $user_membership variable initialization and assignment happens later after user_id is determined.

$api_key = $_SERVER['HTTP_X_API_KEY'] ?? '';
$tracking_code = $_GET['code'] ?? '';

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path_segments = explode('/', trim($path, '/'));
$endpoint = $path_segments[1] ?? '';
$sub_endpoint = $path_segments[2] ?? ''; // Used for /oauth/authorize, /oauth/token, /contacts/{id} etc.
$resource_id = $path_segments[2] ?? null; // For /contacts/{id}, /notifications/{id}/mark-read etc.
$action_param = $path_segments[3] ?? null; // For /notifications/{id}/mark-read


// Endpoints that use tracking_code for authentication
$tracking_code_auth_endpoints = ['track']; // Keep 'track' if client-side tracking is still used

if (in_array($endpoint, $tracking_code_auth_endpoints)) {
    $is_tracking_request = true;
    if (empty($tracking_code)) {
        http_response_code(401);
        die(json_encode(['error' => 'Tracking code required for this endpoint']));
    }

    $stmt = $pdo->prepare("SELECT id, user_id FROM streams WHERE tracking_code = :tracking_code");
    $stmt->bindValue(':tracking_code', $tracking_code);
    $stmt->execute();
    $stream_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$stream_data) {
        http_response_code(403);
        die(json_encode(['error' => 'Invalid tracking code']));
    }

    $stream_id_from_tracking = $stream_data['id'];
    $user_id = $stream_data['user_id'];
} else {
    // All other endpoints require API Key authentication
    if (empty($api_key)) {
        http_response_code(401);
        die(json_encode(['error' => 'API key required']));
    }

    $stmt = $pdo->prepare("SELECT user_id, tracking_method FROM user_api_keys WHERE api_key = :api_key");
    $stmt->bindValue(':api_key', $api_key);
    $stmt->execute();
    $api_key_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$api_key_data) {
        http_response_code(403);
        die(json_encode(['error' => 'Invalid API key']));
    }

    $user_id = $api_key_data['user_id'];

    // Update last_used for the API key
    $stmt = $pdo->prepare("UPDATE user_api_keys SET last_used = NOW() WHERE api_key = :api_key");
    $stmt->bindValue(':api_key', $api_key);
    $stmt->execute();
}

// Fetch user membership details after user_id is determined
$user_membership = []; // Initialize to an empty array
if ($user_id) {
    $user_membership = getUserMembershipDetails($pdo, $user_id);
}


try {
    $input_data = [];
    if (in_array($_SERVER['REQUEST_METHOD'], ['POST', 'PUT', 'DELETE'])) {
        $raw_input = file_get_contents('php://input');
        if (!empty($raw_input)) {
            $input_data = json_decode($raw_input, true);
            if ($input_data === null && json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('Invalid JSON payload: ' . json_last_error_msg());
            }
        }
    }

    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            handleGetRequest($endpoint, $resource_id, $user_id, $is_tracking_request, $stream_id_from_tracking, $user_membership, $pdo);
            break;
        case 'POST':
            handlePostRequest($endpoint, $sub_endpoint, $user_id, $is_tracking_request, $stream_id_from_tracking, $user_membership, $input_data, $pdo);
            break;
        case 'PUT':
            handlePutRequest($endpoint, $resource_id, $action_param, $user_id, $is_tracking_request, $stream_id_from_tracking, $user_membership, $input_data, $pdo);
            break;
        case 'DELETE':
            handleDeleteRequest($endpoint, $resource_id, $user_id, $is_tracking_request, $stream_id_from_tracking, $user_membership, $pdo);
            break;
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    error_log("API PDO Error ({$_SERVER['REQUEST_URI']}): " . $e->getMessage());
    echo json_encode(['error' => 'Database error', 'details' => 'An internal database error occurred.']);
} catch (Exception $e) {
    http_response_code(400); // Most application-level errors are Bad Request
    error_log("API Error ({$_SERVER['REQUEST_URI']}): " . $e->getMessage());
    echo json_encode(['error' => $e->getMessage()]);
}

/**
 * Handles GET requests.
 */
function handleGetRequest($endpoint, $resource_id, $user_id, $is_tracking_request, $tracking_stream_id, $user_membership, $pdo) {
    switch ($endpoint) {
        case 'streams':
            echo json_encode(getStreams($pdo, $user_id));
            break;
        case 'cohorts':
            $stream_id = $_GET['stream_id'] ?? null;
            echo json_encode(getCohorts($pdo, $user_id, $stream_id));
            break;
        case 'features':
            $target_stream_id = $is_tracking_request ? $tracking_stream_id : ($_GET['stream_id'] ?? null);
            echo json_encode(getFeatures($pdo, $user_id, $target_stream_id, $is_tracking_request));
            break;
        case 'competitors':
            $target_stream_id = $is_tracking_request ? $tracking_stream_id : ($_GET['stream_id'] ?? null);
            echo json_encode(getCompetitors($pdo, $user_id, $target_stream_id, $is_tracking_request));
            break;
        case 'contacts':
            // This endpoint handles fetching internal contacts.
            if ($resource_id) {
                if ($resource_id === 'metrics') { // legacy: api/contacts/metrics?contact_id=X
                    $contact_id = $_GET['contact_id'] ?? ($path_segments[3] ?? null);
                    if (!$contact_id) {
                        throw new Exception('contact_id parameter is required for /contacts/metrics endpoint.');
                    }
                    echo json_encode(getContactMetrics($pdo, $user_id, (int)$contact_id));
                } else {
                    // Placeholder for fetching a single contact by ID: /api/contacts/{contact_id}
                    // If you implement getContactDetails in api_helpers, uncomment below
                    // echo json_encode(getContactDetails($pdo, $user_id, (int)$resource_id));
                    http_response_code(404);
                    echo json_encode(['error' => 'GET Contact by ID not implemented, use /contacts?stream_id=X or /metrics?contact_id=X.']);
                }
            } else {
                $stream_id = $_GET['stream_id'] ?? null;
                $cohort_id = $_GET['cohort_id'] ?? null;
                $search = $_GET['search'] ?? null;
                $limit = $_GET['limit'] ?? 20;
                $offset = $_GET['offset'] ?? 0;
                echo json_encode(getContacts($pdo, $user_id, $stream_id, $cohort_id, $search, $limit, $offset));
            }
            break;
        case 'metrics': // Standard /api/metrics?contact_id=X
            $contact_id = $_GET['contact_id'] ?? null;
            if (!$contact_id) {
                throw new Exception('contact_id parameter is required for /metrics endpoint.');
            }
            echo json_encode(getContactMetrics($pdo, $user_id, (int)$contact_id));
            break;
        case 'churn-scores':
            $stream_id = $_GET['stream_id'] ?? null;
            $contact_id = $_GET['contact_id'] ?? null;
            echo json_encode(getChurnScores($pdo, $user_id, $stream_id, $contact_id));
            break;
        case 'high-risk':
            $threshold = $_GET['threshold'] ?? 70;
            $stream_id = $_GET['stream_id'] ?? null;
            echo json_encode(getHighRiskContacts($pdo, $user_id, $threshold, $stream_id));
            break;
        case 'churned':
            $stream_id = $_GET['stream_id'] ?? null;
            $days = $_GET['days'] ?? 0;
            echo json_encode(getChurnedUsers($pdo, $user_id, $stream_id, $days));
            break;
        case 'resurrected':
            $stream_id = $_GET['stream_id'] ?? null;
            $days = $_GET['days'] ?? 0;
            echo json_encode(getResurrectedUsers($pdo, $user_id, $stream_id, $days));
            break;
        case 'notifications':
            echo json_encode(getNotifications($pdo, $user_id));
            break;
        case 'profile':
            echo json_encode(getUserProfile($pdo, $user_id));
            break;
        case 'settings':
            echo json_encode(getUserSettings($pdo, $user_id));
            break;
        case 'available-metrics':
            echo json_encode(getAvailableMetrics($pdo, $user_id));
            break;
        case 'integrations': // Expanded to handle multiple integration functionalities
            if ($resource_id === 'contacts') { // e.g., /api/integrations/contacts?service=stripe
                $service_name = $_GET['service'] ?? null;
                if (empty($service_name)) {
                    throw new Exception('Service name is required for /integrations/contacts');
                }
                $filters = [
                    'limit' => $_GET['limit'] ?? 100,
                    'start' => $_GET['start'] ?? 0,
                    'after' => $_GET['after'] ?? null, // For cursor-based pagination (HubSpot, Salesforce)
                    'email' => $_GET['email'] ?? null, // For email search filters
                    'query' => $_GET['query'] ?? null, // For generic query (Zendesk)
                    'page' => $_GET['page'] ?? 1, // For page-based pagination (Freshdesk, Zendesk)
                    'per_page' => $_GET['per_page'] ?? 100, // For per_page (Freshdesk, Zendesk)
                ];
                echo json_encode(['success' => true, 'contacts' => fetchExternalServiceContactsAPI($pdo, $user_id, $service_name, $filters)]);
            } else if ($resource_id === 'options') { // e.g., /api/integrations/options?service=mautic
                $service_name = $_GET['service'] ?? null;
                if (empty($service_name)) {
                    throw new Exception('Service name is required for /integrations/options');
                }
                $integrationManager = new IntegrationManager($pdo);
                echo json_encode($integrationManager->getOptions($service_name, '', ['user_id' => $user_id]));
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'GET Integrations sub-endpoint not found or not supported. Try /integrations/contacts or /integrations/options.']);
            }
            break;
        case 'test-auth': // General test endpoint for authentication
            http_response_code(200);
            echo json_encode(['success' => true, 'message' => 'Authentication successful!', 'user_id' => $user_id]);
            break;
        default:
            http_response_code(404);
            echo json_encode(['error' => 'GET Endpoint not found']);
    }
}

/**
 * Handles POST requests.
 */
function handlePostRequest($endpoint, $sub_endpoint, $user_id, $is_tracking_request, $tracking_stream_id, $user_membership, $input_data, $pdo) {
    switch ($endpoint) {
        case 'track':
            echo json_encode(processTrackingEvent($pdo, $user_id, $is_tracking_request, $tracking_stream_id, $input_data));
            break;
        case 'streams':
            echo json_encode(createStream($pdo, $user_id, $user_membership, $input_data));
            break;
        case 'cohorts':
            echo json_encode(createCohort($pdo, $user_id, $input_data));
            break;
        case 'features':
            echo json_encode(createFeature($pdo, $user_id, $input_data));
            break;
        case 'competitors':
            echo json_encode(createCompetitor($pdo, $user_id, $input_data));
            break;
        case 'contacts':
            echo json_encode(createContact($pdo, $user_id, $user_membership, $input_data));
            break;
        case 'metrics':
            echo json_encode(submitMetricData($pdo, $user_id, $input_data));
            break;
        case 'mark-churned':
            echo json_encode(markContactChurned($pdo, $user_id, $input_data));
            break;
        case 'mark-resurrected':
            echo json_encode(markContactResurrected($pdo, $user_id, $input_data));
            break;
        case 'churn-calculate':
            echo json_encode(calculateChurnScoreAPI($pdo, $user_id, $input_data));
            break;
        case 'churn-batch-calculate':
            echo json_encode(calculateBatchChurnScoresAPI($pdo, $user_id, $input_data));
            break;
        case 'winback-suggestions':
            echo json_encode(generateWinbackSuggestionsAPI($pdo, $user_id, $input_data));
            break;
        case 'oauth': // Re-enabling OAuth endpoints for Mautic/Hubspot/Salesforce
            if ($sub_endpoint === 'authorize') {
                echo json_encode(handleOAuthAuthorizeRequest($pdo, $user_id, $input_data));
            } elseif ($sub_endpoint === 'token') {
                echo json_encode(handleOAuthTokenExchange($pdo, $user_id, $input_data));
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'OAuth Sub-endpoint not found']);
            }
            break;
        default:
            http_response_code(404);
            echo json_encode(['error' => 'POST Endpoint not found']);
    }
}

/**
 * Handles PUT requests.
 */
function handlePutRequest($endpoint, $resource_id, $action_param, $user_id, $is_tracking_request, $tracking_stream_id, $user_membership, $input_data, $pdo) {
    switch ($endpoint) {
        case 'contacts':
            $contact_id = $resource_id;
            if (empty($contact_id)) {
                throw new Exception('Contact ID is required for PUT /contacts endpoint.');
            }
            echo json_encode(updateContact($pdo, $user_id, (int)$contact_id, $input_data));
            break;
        case 'profile':
            echo json_encode(updateUserProfile($pdo, $user_id, $input_data));
            break;
        case 'settings':
            echo json_encode(updateUserSettings($pdo, $user_id, $input_data));
            break;
        case 'notifications':
            $notification_id = $resource_id;
            if (empty($notification_id)) {
                throw new Exception('Notification ID is required for PUT /notifications endpoint.');
            }
            if ($action_param === 'mark-read') {
                echo json_encode(markNotificationAsRead($pdo, $user_id, (int)$notification_id));
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'PUT Notification sub-endpoint not found']);
            }
            break;
        default:
            http_response_code(404);
            echo json_encode(['error' => 'PUT Endpoint not found']);
    }
}

/**
 * Handles DELETE requests.
 */
function handleDeleteRequest($endpoint, $resource_id, $user_id, $is_tracking_request, $stream_id_from_tracking, $user_membership, $pdo) {
    switch ($endpoint) {
        case 'contacts':
            $contact_id = $resource_id;
            if (empty($contact_id)) {
                throw new Exception('Contact ID is required for DELETE /contacts endpoint.');
            }
            echo json_encode(deleteContact($pdo, $user_id, (int)$contact_id));
            break;
        case 'streams':
            $stream_id = $resource_id;
            if (empty($stream_id)) {
                throw new Exception('Stream ID is required for DELETE /streams endpoint.');
            }
            echo json_encode(deleteStream($pdo, $user_id, (int)$stream_id));
            break;
        case 'cohorts':
            $cohort_id = $resource_id;
            if (empty($cohort_id)) {
                throw new Exception('Cohort ID is required for DELETE /cohorts endpoint.');
            }
            echo json_encode(deleteCohort($pdo, $user_id, (int)$cohort_id));
            break;
        case 'features':
            $feature_id = $resource_id;
            if (empty($feature_id)) {
                throw new Exception('Feature ID is required for DELETE /features endpoint.');
            }
            echo json_encode(deleteFeature($pdo, $user_id, (int)$feature_id));
            break;
        case 'competitors':
            $competitor_id = $resource_id;
            if (empty($competitor_id)) {
                throw new Exception('Competitor ID is required for DELETE /competitors endpoint.');
            }
            echo json_encode(deleteCompetitor($pdo, $user_id, (int)$competitor_id));
            break;
        default:
            http_response_code(404);
            echo json_encode(['error' => 'DELETE Endpoint not found']);
    }
}