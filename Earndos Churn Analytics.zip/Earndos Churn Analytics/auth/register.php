<?php
// auth/register.php
session_start();

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: ../dashboard.php');
    exit;
}

require_once '../includes/db.php';

$errors = [];
$success = false;

// Capture referral if present in URL
if (isset($_GET['ref'])) {
    $_SESSION['referrer'] = htmlspecialchars(trim($_GET['ref']));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validate inputs
    if (empty($username)) {
        $errors['username'] = 'Username is required';
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $errors['username'] = 'Username can only contain letters, numbers and underscores';
    } else {
        // Check if username exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $errors['username'] = 'Username already taken';
        }
    }
    
    if (empty($email)) {
        $errors['email'] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format';
    } else {
        // Check if email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors['email'] = 'Email already registered';
        }
    }
    
    if (empty($password)) {
        $errors['password'] = 'Password is required';
    } elseif (strlen($password) < 8) {
        $errors['password'] = 'Password must be at least 8 characters';
    }
    
    if ($password !== $confirm_password) {
        $errors['confirm_password'] = 'Passwords do not match';
    }
    
    // If no errors, create user
    if (empty($errors)) {
        $activation_token = bin2hex(random_bytes(32));
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        try {
            $pdo->beginTransaction();
            
            // Insert new user
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, activation_token) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$username, $email, $hashed_password, $activation_token])) {
                $new_user_id = $pdo->lastInsertId();
                
                // Process referral if exists
                if (isset($_SESSION['referrer'])) {
                    $referrer = $_SESSION['referrer'];
                    
                    // Find referrer's user ID (check both username and ID)
                    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR id = ?");
                    $stmt->execute([$referrer, $referrer]);
                    $referrer_id = $stmt->fetchColumn();
                    
                    if ($referrer_id && $referrer_id != $new_user_id) { // Prevent self-referral
                        $stmt = $pdo->prepare("INSERT INTO affiliate_referrals (referrer_id, referred_id) VALUES (?, ?)");
                        $stmt->execute([$referrer_id, $new_user_id]);
                    }
                    
                    unset($_SESSION['referrer']);
                }
                
                // Send activation email
                $activation_link = "https://" . $_SERVER['HTTP_HOST'] . "/auth/activate.php?token=$activation_token";
                
                require_once '../includes/email_functions.php';
                send_activation_email($email, $username, $activation_link);
                
                $pdo->commit();
                $success = true;
            } else {
                throw new Exception('Registration failed');
            }
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors['general'] = 'Registration failed. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Register | Churn Analytics</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    }

    body, html {
      height: 100%;
      margin: 0;
    }

    .container {
      display: flex;
      width: 100%;
      min-height: 100vh;
    }

    .left-panel {
      flex: 1;
      background: url('../assets/images/bg.png') no-repeat center center/cover;
      position: relative;
    }

    .left-panel::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.1);
    }

    .right-panel {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 2rem;
      background-color: #fff;
    }

    .login-box {
      width: 100%;
      max-width: 400px;
      text-align: center;
    }

    .login-box img.logo {
      width: 180px;
      margin-bottom: 1.5rem;
    }

    .login-box h2 {
      margin-bottom: 0.5rem;
      color: #333;
    }

    .login-box .subtitle {
      color: #666;
      margin-bottom: 1.5rem;
      font-size: 0.95rem;
    }

    .login-box .error-message {
      color: #e74c3c;
      background: #fdecea;
      padding: 12px;
      border-radius: 6px;
      margin-bottom: 1.5rem;
      font-size: 0.9rem;
    }

    .login-box .success-message {
      color: #2ecc71;
      background: #e8f8f0;
      padding: 12px;
      border-radius: 6px;
      margin-bottom: 1.5rem;
      font-size: 0.9rem;
    }

    .social-buttons {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      margin-bottom: 1.5rem;
    }

    .social-btn {
      width: 100%;
      padding: 0.8rem;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 500;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      transition: all 0.2s ease;
      border: 1px solid #ddd;
      background-color: white;
      color: #444;
    }

    .social-btn:hover {
      opacity: 0.9;
      transform: translateY(-1px);
    }

    .social-btn.google {
      border-color: #dd4b39;
      background-color: white;
      color: #dd4b39;
    }

    .social-btn.github {
      background-color: #ffffff;
      color: black;
      border-color: #000000;
    }

    .social-btn img {
      width: 18px;
      height: 18px;
    }

    .divider {
      display: flex;
      align-items: center;
      margin: 1.5rem 0;
      color: #999;
      font-size: 0.8rem;
    }

    .divider::before, .divider::after {
      content: "";
      flex: 1;
      border-bottom: 1px solid #eee;
    }

    .divider::before {
      margin-right: 1rem;
    }

    .divider::after {
      margin-left: 1rem;
    }

    .login-box input {
      width: 100%;
      padding: 0.8rem 1rem;
      margin-bottom: 0.5rem;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 0.9rem;
      transition: border 0.2s ease;
    }

    .login-box input.error-field {
      border-color: #e74c3c;
    }

    .login-box input:focus {
      outline: none;
      border-color: #3ac3b8;
      box-shadow: 0 0 0 2px rgba(58, 195, 184, 0.1);
    }

    .login-box button.login-btn {
      width: 100%;
      padding: 0.8rem;
      background-color: #3ac3b8;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 500;
      font-size: 1rem;
      transition: all 0.2s ease;
    }

    .login-box button.login-btn:hover {
      background-color: #2fa89e;
    }

    .login-box small {
      display: block;
      color: #e74c3c;
      margin-top: -0.5rem;
      margin-bottom: 0.5rem;
      text-align: left;
      font-size: 0.8rem;
    }

    .login-box .signup-text {
      margin-top: 1.5rem;
      color: #666;
      font-size: 0.9rem;
    }

    .login-box .signup-link {
      color: #3ac3b8;
      text-decoration: none;
      font-weight: 500;
      transition: color 0.2s ease;
    }

    .login-box .signup-link:hover {
      color: #2fa89e;
      text-decoration: underline;
    }

    @media (max-width: 768px) {
      .left-panel {
        display: none;
      }

      .right-panel {
        padding: 1.5rem;
      }

      .login-box {
        max-width: 100%;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="left-panel"></div>
    <div class="right-panel">
      <div class="login-box">
        <img src="../assets/images/logo.png" alt="Churn Analytics Logo" class="logo" />
        <h2>Create Your Account</h2>
        <p class="subtitle">Get started with your churn analytics dashboard</p>
        
        <?php if ($success): ?>
          <div class="success-message">
            Registration successful! Please check your email to activate your account.
          </div>
        <?php else: ?>
          <?php if (!empty($errors['general'])): ?>
            <div class="error-message"><?= htmlspecialchars($errors['general']) ?></div>
          <?php endif; ?>
          
          <div class="social-buttons">
            <button class="social-btn google" onclick="alert('Google sign up will be implemented soon')">
              <img src="../assets/images/google-icon.svg" alt="Google" />
              Sign up with Google
            </button>
            <button class="social-btn github" onclick="alert('GitHub sign up will be implemented soon')">
              <img src="../assets/images/github-icon.svg" alt="GitHub" />
              Sign up with GitHub
            </button>
          </div>
          
          <div class="divider">or</div>
          
          <form method="POST">
            <input type="text" name="username" placeholder="Username" 
                   value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                   class="<?= isset($errors['username']) ? 'error-field' : '' ?>" required />
            <?php if (isset($errors['username'])): ?>
              <small><?= htmlspecialchars($errors['username']) ?></small>
            <?php endif; ?>
            
            <input type="email" name="email" placeholder="Email" 
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                   class="<?= isset($errors['email']) ? 'error-field' : '' ?>" required />
            <?php if (isset($errors['email'])): ?>
              <small><?= htmlspecialchars($errors['email']) ?></small>
            <?php endif; ?>
            
            <input type="password" name="password" placeholder="Password" 
                   class="<?= isset($errors['password']) ? 'error-field' : '' ?>" required />
            <?php if (isset($errors['password'])): ?>
              <small><?= htmlspecialchars($errors['password']) ?></small>
            <?php endif; ?>
            
            <input type="password" name="confirm_password" placeholder="Confirm Password" 
                   class="<?= isset($errors['confirm_password']) ? 'error-field' : '' ?>" required />
            <?php if (isset($errors['confirm_password'])): ?>
              <small><?= htmlspecialchars($errors['confirm_password']) ?></small>
            <?php endif; ?>
            
            <button type="submit" class="login-btn">Create Account</button>
          </form>
          
          <p class="signup-text">Already have an account? <a href="login.php" class="signup-link">Log in</a></p>
        <?php endif; ?>
      </div>
    </div>
  </div>
  
  <script>
    // Client-side validation
    document.querySelector('form')?.addEventListener('submit', function(e) {
      const password = this.querySelector('input[name="password"]');
      const confirm = this.querySelector('input[name="confirm_password"]');
      
      if (password.value.length < 8) {
        e.preventDefault();
        alert('Password must be at least 8 characters');
        password.focus();
        return;
      }
      
      if (password.value !== confirm.value) {
        e.preventDefault();
        alert('Passwords do not match');
        confirm.focus();
      }
    });

    // Highlight error fields
    document.addEventListener('DOMContentLoaded', function() {
      const errorFields = document.querySelectorAll('.error-field');
      errorFields.forEach(field => {
        field.addEventListener('focus', function() {
          this.classList.remove('error-field');
          const errorMessage = this.nextElementSibling;
          if (errorMessage && errorMessage.tagName === 'SMALL') {
            errorMessage.remove();
          }
        });
      });
    });
  </script>
</body>
</html>