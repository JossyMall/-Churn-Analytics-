<?php
// auth/forgot_password.php
session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: ../dashboard.php');
    exit;
}

require_once '../includes/db.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    
    if (empty($email)) {
        $error = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user) {
            $reset_token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + 3600); // 1 hour expiration
            
            $stmt = $pdo->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE id = ?");
            $stmt->execute([$reset_token, $expires, $user['id']]);
            
            $reset_link = "http://" . $_SERVER['HTTP_HOST'] . "/auth/reset_password.php?token=$reset_token";
            
            require_once '../includes/email_functions.php';
            send_password_reset_email($email, $reset_link);
            
            $message = 'Password reset link sent to your email';
        } else {
            $error = 'Email not found';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Forgot Password | Churn Analytics</title>
  <style>
    /* Same CSS as login page */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    }
    body, html {
      height: 100%;
      margin: 0;
    }
    .container {
      display: flex;
      width: 100%;
      min-height: 100vh;
    }
    .left-panel {
      flex: 1;
      background: url('../assets/images/bg.png') no-repeat center center/cover;
      position: relative;
    }
    .left-panel::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.1);
    }
    .right-panel {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 2rem;
      background-color: #fff;
    }
    .login-box {
      width: 100%;
      max-width: 400px;
      text-align: center;
    }
    .login-box img.logo {
      width: 80px;
      margin-bottom: 1.5rem;
    }
    .login-box h2 {
      margin-bottom: 1rem;
      color: #333;
      font-weight: 600;
    }
    .login-box p.subtitle {
      color: #666;
      margin-bottom: 2rem;
      font-size: 0.95rem;
    }
    .login-box input {
      width: 100%;
      padding: 0.8rem 1rem;
      margin-bottom: 1rem;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 0.9rem;
      transition: border 0.2s ease;
    }
    .login-box input:focus {
      outline: none;
      border-color: #3ac3b8;
      box-shadow: 0 0 0 2px rgba(58, 195, 184, 0.1);
    }
    .login-box button.login-btn {
      width: 100%;
      padding: 0.8rem;
      background-color: #3ac3b8;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 500;
      font-size: 1rem;
      transition: all 0.2s ease;
    }
    .login-box button.login-btn:hover {
      background-color: #2fa89e;
    }
    .login-box .signup-text {
      margin-top: 1.5rem;
      color: #666;
      font-size: 0.9rem;
    }
    .login-box .signup-link {
      color: #3ac3b8;
      text-decoration: none;
      font-weight: 500;
      transition: color 0.2s ease;
    }
    .login-box .signup-link:hover {
      color: #2fa89e;
      text-decoration: underline;
    }
    @media (max-width: 768px) {
      .left-panel {
        display: none;
      }
      .right-panel {
        padding: 1.5rem;
      }
      .login-box {
        max-width: 100%;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="left-panel"></div>
    <div class="right-panel">
      <div class="login-box">
        <img src="../assets/images/logo.png" alt="Logo" class="logo" />
        <h2>Reset Password</h2>
        <p class="subtitle">Enter your email to receive a reset link</p>
        
        <?php if ($message): ?>
          <div style="color: green; margin-bottom: 1rem;"><?= htmlspecialchars($message) ?></div>
        <?php elseif ($error): ?>
          <div style="color: red; margin-bottom: 1rem;"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <form method="POST">
          <input type="email" name="email" placeholder="Email" required />
          <button type="submit" class="login-btn">Send Reset Link</button>
        </form>
        
        <p class="signup-text">Remember your password? <a href="login.php" class="signup-link">Login</a></p>
      </div>
    </div>
  </div>
</body>
</html>