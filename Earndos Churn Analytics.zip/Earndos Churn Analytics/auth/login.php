<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// auth/login.php
session_start();

// Make sure BASE_URL is defined. It's usually defined in db.php or a central config.
// If it's not defined by db.php, you might need to define it here or ensure db.php does.
// For safety, let's include db.php here first, as it's needed for $pdo and potentially BASE_URL.
require_once '../includes/db.php'; // Assuming db.php defines BASE_URL and $pdo

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    // If user is already logged in, check for an intended URL and redirect
    if (isset($_SESSION['intended_url']) && !empty($_SESSION['intended_url'])) {
        $redirect_url = $_SESSION['intended_url'];
        unset($_SESSION['intended_url']); // Clear the session variable
        header('Location: ' . BASE_URL . $redirect_url);
        exit;
    } else {
        // If already logged in and no intended URL, redirect to default slides/
        header('Location: ' . BASE_URL . '/slides/');
        exit;
    }
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle login form submission
    
    $username_email = trim($_POST['username_email']);
    $password = $_POST['password'];
    
    // Validate credentials
    $stmt = $pdo->prepare("SELECT id, password FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username_email, $username_email]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        // Login successful
        $_SESSION['user_id'] = $user['id'];
        
        // Set persistent cookie if "remember me" is checked
        if (isset($_POST['remember_me'])) {
            $token = bin2hex(random_bytes(32));
            setcookie('remember_token', $token, time() + 60*60*24*30, '/', '', false, true); // 30 days
            
            // Store token in database
            $stmt = $pdo->prepare("UPDATE users SET remember_token = ? WHERE id = ?");
            $stmt->execute([$token, $user['id']]);
        }
        
        // --- NEW: Redirect to intended URL or default after successful login ---
        if (isset($_SESSION['intended_url']) && !empty($_SESSION['intended_url'])) {
            $redirect_url = $_SESSION['intended_url'];
            unset($_SESSION['intended_url']); // Clear the session variable after use
            header('Location: ' . BASE_URL . $redirect_url); // Redirect to intended page
            exit;
        } else {
            // Default redirect if no intended URL was stored (e.g., direct login or from index)
            header('Location: ' . BASE_URL . '/slides/'); // Your default post-login page
            exit;
        }
    } else {
        $error = 'Invalid username/email or password';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login | Churn Analytics</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    }

    body, html {
      height: 100%;
      margin: 0;
    }

    .container {
      display: flex;
      width: 100%;
      min-height: 100vh;
    }

    .left-panel {
      flex: 1;
      background: url('../assets/images/bg.png') no-repeat center center/cover;
      position: relative;
    }

    .left-panel::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.1);
    }

    .right-panel {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 2rem;
      background-color: #fff;
    }

    .login-box {
      width: 100%;
      max-width: 400px;
      text-align: center;
    }

    .login-box img.logo {
      width: 180px;
      margin-bottom: 1.5rem;
    }

    .login-box h2 {
      margin-bottom: 1rem;
      color: #333;
      font-weight: 600;
    }

    .login-box p.subtitle {
      color: #666;
      margin-bottom: 2rem;
      font-size: 0.95rem;
    }

    .login-box .error-message {
      color: #e74c3c;
      background: #fdecea;
      padding: 12px;
      border-radius: 6px;
      margin-bottom: 1.5rem;
      font-size: 0.9rem;
    }

    .social-buttons {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      margin-bottom: 1.5rem;
    }

    .social-btn {
      width: 100%;
      padding: 0.8rem;
      border-radius: 66px; /* Corrected typo for consistency */
      cursor: pointer;
      font-weight: 500;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      transition: all 0.2s ease;
      border: 1px solid #ddd;
      background-color: white;
      color: #444;
    }

    .social-btn:hover {
      opacity: 0.9;
      transform: translateY(-1px);
    }

    .social-btn.google {
      border-color: #dd4b39;
      background-color: white;
      color: #dd4b39;
    }

    .social-btn.github {
      background-color: #ffffff;
      color: black;
      border-color: #000000;
    }

    .social-btn img {
      width: 18px;
      height: 18px;
    }

    .divider {
      display: flex;
      align-items: center;
      margin: 1.5rem 0;
      color: #999;
      font-size: 0.8rem;
    }

    .divider::before, .divider::after {
      content: "";
      flex: 1;
      border-bottom: 1px solid #eee;
    }

    .divider::before {
      margin-right: 1rem;
    }

    .divider::after {
      margin-left: 1rem;
    }

    .login-box input {
      width: 100%;
      padding: 0.8rem 1rem;
      margin-bottom: 1rem;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 0.9rem;
      transition: border 0.2s ease;
    }

    .login-box input:focus {
      outline: none;
      border-color: #3ac3b8;
      box-shadow: 0 0 0 2px rgba(58, 195, 184, 0.1);
    }

    .login-box button.login-btn {
      width: 100%;
      padding: 0.8rem;
      background-color: #3ac3b8;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 500;
      font-size: 1rem;
      transition: all 0.2s ease;
    }

    .login-box button.login-btn:hover {
      background-color: #2fa89e;
    }

    .remember-me {
      display: flex;
      align-items: center;
      margin-bottom: 1rem;
    }

    .remember-me input {
      width: auto;
      margin: 0 8px 0 0;
    }

    .remember-me label {
      color: #666;
      font-size: 0.9rem;
    }

    .login-box .forgot-password {
      font-size: 0.9rem;
      color: #3ac3b8;
      text-decoration: none;
      display: block;
      margin: -0.5rem 0 1.5rem;
      text-align: right;
      transition: color 0.2s ease;
    }

    .login-box .forgot-password:hover {
      color: #2fa89e;
      text-decoration: underline;
    }

    .login-box .signup-text {
      margin-top: 1.5rem;
      color: #666;
      font-size: 0.9rem;
    }

    .login-box .signup-link {
      color: #3ac3b8;
      text-decoration: none;
      font-weight: 500;
      transition: color 0.2s ease;
    }

    .login-box .signup-link:hover {
      color: #2fa89e;
      text-decoration: underline;
    }

    @media (max-width: 768px) {
      .left-panel {
        display: none;
      }

      .right-panel {
        padding: 1.5rem;
      }

      .login-box {
        max-width: 100%;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="left-panel"></div>
    <div class="right-panel">
      <div class="login-box">
        <img src="../assets/images/logo.png" alt="Churn Analytics Logo" class="logo" />
        <h2>Welcome Back!</h2>
        <p class="subtitle">Continue with social accounts or enter your details.</p>
        
        <?php if ($error): ?>
        <div class="error-message"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <div class="social-buttons">
          <button class="social-btn google" onclick="alert('Google login will be implemented soon')">
            <img src="../assets/images/google-icon.svg" alt="Google" />
            Login with Google
          </button>
          <button class="social-btn github" onclick="alert('GitHub login will be implemented soon')">
            <img src="../assets/images/github-icon.svg" alt="GitHub" />
            Login with GitHub
          </button>
        </div>
        
        <div class="divider">or</div>
        
        <form method="POST">
          <input type="text" name="username_email" placeholder="Username or Email" required />
          <input type="password" name="password" placeholder="Password" required />
          
          <div class="remember-me">
            <input type="checkbox" id="remember_me" name="remember_me">
            <label for="remember_me">Remember me</label>
          </div>
          
          <a href="forgot_password.php" class="forgot-password">Forgot password?</a>
          <button type="submit" class="login-btn">Login</button>
        </form>
        
        <p class="signup-text">Don't have an account? <a href="register.php" class="signup-link">Sign up</a></p>
      </div>
    </div>
  </div>
  
  <script>
    // Simple client-side validation
    document.querySelector('form').addEventListener('submit', function(e) {
      const inputs = this.querySelectorAll('input[required]');
      let valid = true;
      
      inputs.forEach(input => {
        if (!input.value.trim()) {
          input.style.borderColor = '#e74c3c';
          valid = false;
        } else {
          input.style.borderColor = '#ddd';
        }
      });
      
      if (!valid) {
        e.preventDefault();
        const errorDiv = document.querySelector('.error-message') || document.createElement('div');
        if (!document.querySelector('.error-message')) {
          errorDiv.className = 'error-message';
          errorDiv.textContent = 'Please fill in all required fields';
          document.querySelector('.login-box').insertBefore(errorDiv, document.querySelector('form'));
        }
      }
    });
  </script>
</body>
</html>