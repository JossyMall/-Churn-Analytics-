<?php
// auth/activate.php
session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: ../dashboard.php');
    exit;
}

require_once '../includes/db.php';

$message = '';
$error = '';

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    
    $stmt = $pdo->prepare("SELECT id FROM users WHERE activation_token = ? AND is_active = 0");
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    
    if ($user) {
        $stmt = $pdo->prepare("UPDATE users SET is_active = 1, activation_token = NULL WHERE id = ?");
        $stmt->execute([$user['id']]);
        
        $message = 'Account activated successfully! You can now login.';
    } else {
        $error = 'Invalid or expired activation link';
    }
} else {
    $error = 'No activation token provided';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Account Activation | Churn Analytics</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    }
    body, html {
      height: 100%;
      margin: 0;
    }
    .container {
      display: flex;
      width: 100%;
      min-height: 100vh;
    }
    .left-panel {
      flex: 1;
      background: url('../assets/images/bg.png') no-repeat center center/cover;
      position: relative;
    }
    .left-panel::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.1);
    }
    .right-panel {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 2rem;
      background-color: #fff;
    }
    .login-box {
      width: 100%;
      max-width: 400px;
      text-align: center;
    }
    .login-box img.logo {
      width: 180px;
      margin-bottom: 1.5rem;
    }
    .login-box h2 {
      margin-bottom: 1rem;
      color: #333;
      font-weight: 600;
    }
    .login-box .message {
      padding: 1rem;
      border-radius: 6px;
      margin-bottom: 1.5rem;
    }
    .login-box .success {
      background-color: #e6f7ee;
      color: #28a745;
    }
    .login-box .error {
      background-color: #f8e6e6;
      color: #dc3545;
    }
    .login-box .login-btn {
      width: 100%;
      padding: 0.8rem;
      background-color: #3ac3b8;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 500;
      font-size: 1rem;
      transition: all 0.2s ease;
      text-decoration: none;
      display: inline-block;
    }
    .login-box .login-btn:hover {
      background-color: #2fa89e;
    }
    @media (max-width: 768px) {
      .left-panel {
        display: none;
      }
      .right-panel {
        padding: 1.5rem;
      }
      .login-box {
        max-width: 100%;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="left-panel"></div>
    <div class="right-panel">
      <div class="login-box">
        <img src="../assets/images/logo.png" alt="Logo" class="logo" />
        <h2>Account Activation</h2>
        
        <?php if ($message): ?>
          <div class="message success"><?= htmlspecialchars($message) ?></div>
          <a href="login.php" class="login-btn">Go to Login</a>
        <?php elseif ($error): ?>
          <div class="message error"><?= htmlspecialchars($error) ?></div>
          <a href="register.php" class="login-btn">Register New Account</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</body>
</html>