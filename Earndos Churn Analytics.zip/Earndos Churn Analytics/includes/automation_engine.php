<?php
require_once __DIR__.'/db.php';

class AutomationEngine {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    /**
     * Evaluates all triggers for a contact
     */
    public function evaluateContactTriggers($contactId, $userId) {
        $triggers = $this->getUserTriggers($userId);
        $results = [];
        
        foreach ($triggers as $trigger) {
            $results[$trigger['id']] = $this->evaluateTrigger($trigger, $contactId);
        }
        
        return $results;
    }

    /**
     * Gets all triggers for a user
     */
    private function getUserTriggers($userId) {
        $stmt = $this->pdo->prepare("
            SELECT t.* FROM automation_triggers t
            JOIN automation_workflows w ON t.workflow_id = w.id
            WHERE w.user_id = ? AND w.is_active = 1
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll();
    }

    /**
     * Evaluates a single trigger against a contact
     */
    public function evaluateTrigger($trigger, $contactId) {
        $conditions = json_decode($trigger['condition_json'], true);
        
        switch ($trigger['trigger_type']) {
            case 'churn_probability':
                return $this->evaluateChurnProbability($contactId, $conditions);
                
            case 'competitor_visit':
                return $this->evaluateCompetitorVisit($contactId, $conditions);
                
            case 'feature_usage':
                return $this->evaluateFeatureUsage($contactId, $conditions);
                
            case 'last_login':
                return $this->evaluateLastLogin($contactId, $conditions);
                
            case 'subscription_status':
                return $this->evaluateSubscriptionStatus($contactId, $conditions);
                
            default:
                throw new Exception("Unknown trigger type: {$trigger['trigger_type']}");
        }
    }

    /**
     * Churn probability evaluation
     */
    private function evaluateChurnProbability($contactId, $conditions) {
        $stmt = $this->pdo->prepare("
            SELECT score FROM churn_scores 
            WHERE contact_id = ? 
            ORDER BY scored_at DESC LIMIT 1
        ");
        $stmt->execute([$contactId]);
        $score = $stmt->fetchColumn();
        
        if ($score === false) return false;
        
        return $this->compareValues(
            $score, 
            $conditions['value'], 
            $conditions['operator'] ?? '>'
        );
    }

    /**
     * Competitor visit evaluation
     */
    private function evaluateCompetitorVisit($contactId, $conditions) {
        $stmt = $this->pdo->prepare("
            SELECT 1 FROM competitor_visits
            WHERE contact_id = ? AND competitor_id = ?
            AND visited_at > DATE_SUB(NOW(), INTERVAL ? DAY)
            LIMIT 1
        ");
        $stmt->execute([
            $contactId,
            $conditions['competitor_id'],
            $conditions['timeframe_days'] ?? 30
        ]);
        return (bool)$stmt->fetchColumn();
    }

    /**
     * Feature usage evaluation
     */
    private function evaluateFeatureUsage($contactId, $conditions) {
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) FROM metric_data
            WHERE contact_id = ? 
            AND metric_id = (SELECT id FROM churn_metrics WHERE name = 'feature_usage')
            AND value = ?
            AND recorded_at > DATE_SUB(NOW(), INTERVAL ? DAY)
        ");
        $stmt->execute([
            $contactId,
            $conditions['feature_name'],
            $conditions['timeframe_days'] ?? 30
        ]);
        $count = $stmt->fetchColumn();
        
        return $count >= ($conditions['min_usage'] ?? 1);
    }

    /**
     * Last login evaluation
     */
    private function evaluateLastLogin($contactId, $conditions) {
        $stmt = $this->pdo->prepare("
            SELECT DATEDIFF(NOW(), MAX(recorded_at)) 
            FROM metric_data 
            WHERE contact_id = ? 
            AND metric_id = (SELECT id FROM churn_metrics WHERE name = 'last_login_date')
        ");
        $stmt->execute([$contactId]);
        $days = $stmt->fetchColumn();
        
        return $this->compareValues(
            $days,
            $conditions['days'],
            $conditions['operator'] ?? '>'
        );
    }

    /**
     * Subscription status evaluation
     */
    private function evaluateSubscriptionStatus($contactId, $conditions) {
        $stmt = $this->pdo->prepare("
            SELECT status FROM user_subscriptions
            WHERE user_id = (SELECT user_id FROM contacts WHERE id = ?)
            ORDER BY end_date DESC LIMIT 1
        ");
        $stmt->execute([$contactId]);
        $status = $stmt->fetchColumn();
        
        return $status === $conditions['status'];
    }

    /**
     * Generic value comparison
     */
    private function compareValues($value, $compareTo, $operator) {
        switch ($operator) {
            case '>': return $value > $compareTo;
            case '<': return $value < $compareTo;
            case '>=': return $value >= $compareTo;
            case '<=': return $value <= $compareTo;
            case '=': return $value == $compareTo;
            case '!=': return $value != $compareTo;
            default: throw new Exception("Invalid operator: $operator");
        }
    }
}