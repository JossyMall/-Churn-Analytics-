<?php
// includes/notification_functions.php

function create_notification($user_id, $type, $message, $related_id = null) {
    global $pdo;
    
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type, related_id) 
                          VALUES (?, ?, ?, ?, ?)");
    $title = ucfirst(str_replace('_', ' ', $type));
    $stmt->execute([$user_id, $title, $message, $type, $related_id]);
    
    return $pdo->lastInsertId();
}

function send_notification_email($user_id, $subject, $message) {
    global $pdo;
    
    // Get user email and preferences
    $stmt = $pdo->prepare("SELECT u.email, up.alert_is_email 
                          FROM users u
                          LEFT JOIN user_profiles up ON u.id = up.user_id
                          WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if ($user && $user['alert_is_email']) {
        // Get email settings from config
        $stmt = $pdo->query("SELECT value FROM config WHERE setting = 'smtp_enabled'");
        $smtp_enabled = $stmt->fetchColumn();
        
        if ($smtp_enabled) {
            // Use SMTP if enabled
            $stmt = $pdo->query("SELECT value FROM config WHERE setting IN ('smtp_host', 'smtp_port', 'smtp_username', 'smtp_password', 'smtp_from_email', 'smtp_from_name')");
            $config = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
            
            // Implement SMTP email sending here
            // This is a placeholder - you'll need to implement your email sending logic
            // using PHPMailer or similar library
        } else {
            // Use basic mail() function
            $headers = "From: no-reply@yourdomain.com\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
            mail($user['email'], $subject, $message, $headers);
        }
    }
}

function mark_notification_as_read($notification_id, $user_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1, read_at = NOW() 
                          WHERE id = ? AND user_id = ?");
    return $stmt->execute([$notification_id, $user_id]);
}

function get_user_notifications($user_id, $limit = 10, $unread_only = false) {
    global $pdo;
    
    $sql = "SELECT * FROM notifications 
           WHERE user_id = ?";
    
    if ($unread_only) {
        $sql .= " AND is_read = 0";
    }
    
    $sql .= " ORDER BY created_at DESC LIMIT ?";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id, $limit]);
    return $stmt->fetchAll();
}

function delete_notification($notification_id, $user_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("DELETE FROM notifications WHERE id = ? AND user_id = ?");
    return $stmt->execute([$notification_id, $user_id]);
}