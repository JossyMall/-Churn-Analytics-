<?php
// includes/external_apis/ZendeskClient.php
require_once __DIR__.'/IntegrationBase.php';

class ZendeskClient extends IntegrationBase {
    private $apiKey; // Zendesk API Token
    private $subdomain; // Zendesk Subdomain (e.g., yourcompany.zendesk.com)
    private $baseUrl; // Constructed from subdomain

    public function __construct(array $config) {
        parent::__construct($config);
        $this->serviceName = 'zendesk';
        // We'll use 'api_key' for the Zendesk API Token
        $this->apiKey = $config['api_key'] ?? '';
        // Expecting a 'subdomain' in the config
        $this->subdomain = $config['subdomain'] ?? '';
        // Construct the base API URL from the subdomain
        if (!empty($this->subdomain)) {
            $this->baseUrl = 'https://' . rtrim($this->subdomain, '/') . '.zendesk.com/api/v2';
        } else {
            $this->baseUrl = ''; // Will cause errors if not set
        }
    }

    /**
     * Tests the connection to Zendesk by attempting to retrieve a limited number of tickets.
     * @return bool True if connection is successful, false otherwise.
     */
    public function testConnection(): bool {
        if (empty($this->apiKey)) {
            $this->lastError = 'Zendesk API Token is missing.';
            return false;
        }
        if (empty($this->subdomain)) {
            $this->lastError = 'Zendesk Subdomain is missing.';
            return false;
        }
        if (empty($this->baseUrl)) {
            $this->lastError = 'Zendesk Base URL could not be constructed. Check subdomain.';
            return false;
        }

        try {
            // Use a simple, low-privilege endpoint, e.g., list tickets with a limit of 1.
            $response = $this->makeRequest(
                '/tickets?per_page=1',
                'GET'
            );
            
            // If the request succeeds, even if data is empty, it indicates a valid connection.
            return isset($response['tickets']) && is_array($response['tickets']);
        } catch (Exception $e) {
            $this->lastError = 'Zendesk Connection Error: ' . $e->getMessage();
            return false;
        }
    }

    /**
     * Fetches users (contacts) from Zendesk.
     * Zendesk API offers various resources (users, tickets, organizations).
     * We'll focus on 'users' for contact representation.
     * @param array $filters Optional filters like 'per_page', 'page', 'query'.
     * @return array An array of contacts.
     */
    public function fetchContacts(array $filters = []): array {
         if (empty($this->apiKey) || empty($this->subdomain) || empty($this->baseUrl)) {
            throw new Exception('Zendesk API Token, Subdomain, or Base URL is missing. Cannot fetch contacts.');
        }

        $perPage = $filters['per_page'] ?? 100; // Zendesk default is 100, max 100
        $page = $filters['page'] ?? 1; // For pagination
        $query = $filters['query'] ?? null; // Search query (e.g., email)

        $endpoint = '/users?per_page=' . (int)$perPage . '&page=' . (int)$page;
        if ($query) {
            $endpoint .= '&query=' . urlencode($query);
        }

        try {
            $response = $this->makeRequest(
                $endpoint,
                'GET'
            );

            $contacts = [];
            if (isset($response['users']) && is_array($response['users'])) {
                foreach ($response['users'] as $user) {
                    $contacts[] = [
                        'id' => $user['id'],
                        'email' => $user['email'] ?? null,
                        'name' => $user['name'] ?? ($user['email'] ?? 'N/A'),
                        'custom_data' => $user // Store all Zendesk user data
                    ];
                }
            }
            return $contacts;
        } catch (Exception $e) {
            $this->lastError = 'Zendesk Fetch Contacts Error: ' . $e->getMessage();
            return [];
        }
    }

    /**
     * Zendesk API Key/Token authentication does not use OAuth.
     * This method is not applicable and will throw an exception.
     */
    public function getAuthorizationUrl(string $redirectUri, string $state): string {
        throw new Exception('Zendesk API Token authentication does not use OAuth authorization URLs.');
    }

    /**
     * Zendesk API Key/Token authentication does not use OAuth.
     * This method is not applicable and will throw an exception.
     */
    public function exchangeCodeForTokens(string $code, string $redirectUri): array {
        throw new Exception('Zendesk API Token authentication does not use OAuth token exchange.');
    }

    /**
     * Zendesk API Key/Token authentication does not use OAuth.
     * This method is not applicable and will throw an exception.
     */
    public function refreshAccessToken(string $refreshToken): array {
        throw new Exception('Zendesk API Token authentication does not use OAuth refresh tokens.');
    }

    /**
     * Makes an HTTP request to the Zendesk API.
     * Uses HTTP Basic Authentication with API Token as username and empty password.
     */
    protected function makeRequest(string $endpoint, string $method = 'GET', array $data = [], array $headers = []): ?array {
        if (empty($this->baseUrl)) {
            throw new Exception("Zendesk Base URL is not set. Check subdomain.");
        }

        $url = $this->baseUrl . $endpoint; // Append endpoint to base URL

        $ch = curl_init();
        
        // Zendesk uses Basic Auth with API Token as username and empty password
        $authHeader = base64_encode($this->apiKey . ':'); 
        $standardHeaders = [
            'Authorization: Basic ' . $authHeader,
            'Content-Type: application/json' // Zendesk usually prefers JSON
        ];
        $finalHeaders = array_merge($standardHeaders, $headers);

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $finalHeaders,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);

        if (!empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            throw new Exception("cURL Error: " . $curlError);
        }

        $decodedResponse = json_decode($response, true);

        if ($status >= 400) {
            $errorMessage = "Zendesk API Error: HTTP {$status} - " . ($decodedResponse['error']['message'] ?? $response);
            error_log("Zendesk API request failed: {$errorMessage}. URL: {$url}, Method: {$method}, Data: " . json_encode($data));
            throw new Exception($errorMessage);
        }

        return $decodedResponse;
    }
}