<?php
// includes/external_apis/IntegrationBase.php

abstract class IntegrationBase { // Changed to abstract
    protected $config;
    protected $serviceName;
    protected $lastError;

    public function __construct(array $config) {
        $this->config = $config;
    }

    /**
     * Tests the connection to the external service.
     * @return bool True if connection is successful, false otherwise.
     */
    abstract public function testConnection(): bool;

    /**
     * Fetches contacts from the external service.
     * @param array $filters Optional filters to apply to the contact retrieval.
     * @return array An array of contacts, each represented as an associative array.
     */
    abstract public function fetchContacts(array $filters = []): array;

    /**
     * Generates the OAuth authorization URL for the service.
     * This method will be implemented by services that use OAuth.
     * @param string $redirectUri The URI where the user will be redirected after authorization.
     * @param string $state An opaque value used to maintain state between the request and callback.
     * @return string The authorization URL.
     * @throws Exception If OAuth authorization is not supported or configuration is missing.
     */
    public function getAuthorizationUrl(string $redirectUri, string $state): string {
        throw new Exception('OAuth authorization not implemented for this service.');
    }

    /**
     * Exchanges an authorization code for access and refresh tokens.
     * This method will be implemented by services that use OAuth.
     * @param string $code The authorization code received from the OAuth provider.
     * @param string $redirectUri The original redirect URI used in the authorization request.
     * @return array An associative array containing 'access_token', 'refresh_token', 'expires_in', etc.
     * @throws Exception If token exchange fails.
     */
    public function exchangeCodeForTokens(string $code, string $redirectUri): array {
        throw new Exception('OAuth token exchange not implemented for this service.');
    }

    /**
     * Refreshes an expired access token using a refresh token.
     * This method will be implemented by services that use OAuth.
     * @param string $refreshToken The refresh token.
     * @return array An associative array containing new 'access_token', 'expires_in', and potentially a new 'refresh_token'.
     * @throws Exception If token refresh fails.
     */
    public function refreshAccessToken(string $refreshToken): array {
        throw new Exception('Access token refresh not implemented for this service.');
    }

    public function getLastError(): ?string {
        return $this->lastError;
    }

    public function getServiceName(): string {
        return $this->serviceName;
    }

    /**
     * Protected method to make HTTP requests. To be implemented by child classes.
     * @param string $url The full URL to request.
     * @param string $method HTTP method (GET, POST, etc.).
     * @param array $data Data to send with the request (for POST/PUT).
     * @param array $headers Additional headers for the request.
     * @return array|null Decoded JSON response or null on error.
     * @throws Exception On HTTP errors or cURL issues.
     */
    abstract protected function makeRequest(string $url, string $method = 'GET', array $data = [], array $headers = []): ?array;

    /**
     * Helper function to find service data in array
     */
    public static function findServiceData(array $services, string $serviceName): ?array {
        foreach ($services as $service) {
            if ($service['service_name'] === $serviceName) {
                return $service;
            }
        }
        return null;
    }
}