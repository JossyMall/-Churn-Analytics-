<?php
// includes/external_apis/StripeClient.php
require_once __DIR__.'/IntegrationBase.php';

class StripeClient extends IntegrationBase {
    private $apiKey; // Stripe Secret Key

    public function __construct(array $config) {
        parent::__construct($config);
        $this->serviceName = 'stripe';
        // Stripe uses a single secret API key for most server-side authentication
        $this->apiKey = $config['api_key'] ?? ''; // This will typically be sk_test_... or sk_live_...
    }

    /**
     * Tests the connection to Stripe by attempting a simple API call (e.g., list customers).
     * @return bool True if connection is successful, false otherwise.
     */
    public function testConnection(): bool {
        if (empty($this->apiKey) || !str_starts_with($this->apiKey, 'sk_')) { // Basic validation
            $this->lastError = 'Invalid Stripe API Key format. Must start with "sk_".';
            return false;
        }

        try {
            // Use a simple, low-privilege endpoint to test connection, e.g., list customers with a limit of 1.
            $response = $this->makeRequest(
                'https://api.stripe.com/v1/customers?limit=1',
                'GET',
                [],
                ['Authorization: Bearer ' . $this->apiKey] // Stripe uses Bearer token auth with the secret key
            );
            
            // If the request succeeds, even if there are no customers, it indicates a valid key.
            return isset($response['data']) && is_array($response['data']);
        } catch (Exception $e) {
            $this->lastError = 'Stripe Connection Error: ' . $e->getMessage();
            return false;
        }
    }

    /**
     * Fetches customers from Stripe.
     * @param array $filters Optional filters like 'limit', 'starting_after', 'email'.
     * @return array An array of customers.
     */
    public function fetchContacts(array $filters = []): array {
        if (empty($this->apiKey)) {
            throw new Exception('Stripe API Key is missing. Cannot fetch customers.');
        }

        $limit = $filters['limit'] ?? 100; // Stripe default limit is 10, max 100
        $startingAfter = $filters['starting_after'] ?? null; // For pagination
        $email = $filters['email'] ?? null; // Search by email

        $endpoint = 'https://api.stripe.com/v1/customers?limit=' . (int)$limit;
        if ($startingAfter) {
            $endpoint .= '&starting_after=' . urlencode($startingAfter);
        }
        if ($email) {
            $endpoint .= '&email=' . urlencode($email);
        }

        try {
            $response = $this->makeRequest(
                $endpoint,
                'GET',
                [],
                ['Authorization: Bearer ' . $this->apiKey]
            );

            $customers = [];
            if (isset($response['data']) && is_array($response['data'])) {
                foreach ($response['data'] as $stripeCustomer) {
                    $customers[] = [
                        'id' => $stripeCustomer['id'],
                        'email' => $stripeCustomer['email'] ?? null,
                        'name' => $stripeCustomer['name'] ?? ($stripeCustomer['email'] ?? 'N/A'),
                        'custom_data' => $stripeCustomer // Store all Stripe customer data
                    ];
                }
            }
            return $customers;
        } catch (Exception $e) {
            $this->lastError = 'Stripe Fetch Customers Error: ' . $e->getMessage();
            return [];
        }
    }

    /**
     * Stripe does not use standard OAuth for API key authentication.
     * This method is not applicable and will throw an exception.
     */
    public function getAuthorizationUrl(string $redirectUri, string $state): string {
        throw new Exception('Stripe API Key authentication does not use OAuth authorization URLs.');
    }

    /**
     * Stripe does not use standard OAuth for API key authentication.
     * This method is not applicable and will throw an exception.
     */
    public function exchangeCodeForTokens(string $code, string $redirectUri): array {
        throw new Exception('Stripe API Key authentication does not use OAuth token exchange.');
    }

    /**
     * Stripe does not use standard OAuth for API key authentication.
     * This method is not applicable and will throw an exception.
     */
    public function refreshAccessToken(string $refreshToken): array {
        throw new Exception('Stripe API Key authentication does not use OAuth refresh tokens.');
    }

    /**
     * Makes an HTTP request to the Stripe API.
     */
    protected function makeRequest(string $url, string $method = 'GET', array $data = [], array $headers = []): ?array {
        $ch = curl_init();
        
        // Ensure standard headers for Stripe are always included
        $standardHeaders = ['Content-Type: application/x-www-form-urlencoded']; // Stripe typically uses x-www-form-urlencoded
        $finalHeaders = array_merge($standardHeaders, $headers);

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $finalHeaders,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);

        // Stripe API authentication using the secret key (username is key, password is empty)
        curl_setopt($ch, CURLOPT_USERPWD, $this->apiKey . ':'); 

        if (!empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        }

        $response = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            throw new Exception("cURL Error: " . $curlError);
        }

        $decodedResponse = json_decode($response, true);

        if ($status >= 400) {
            $errorMessage = "Stripe API Error: HTTP {$status} - " . ($decodedResponse['error']['message'] ?? $response);
            error_log("Stripe API request failed: {$errorMessage}. URL: {$url}, Method: {$method}, Data: " . json_encode($data));
            throw new Exception($errorMessage);
        }

        return $decodedResponse;
    }
}