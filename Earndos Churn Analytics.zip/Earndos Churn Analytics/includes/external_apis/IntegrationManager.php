<?php
// includes/external_apis/IntegrationManager.php
require_once __DIR__.'/IntegrationBase.php';
// Dynamically include all specific client files for all supported integrations
require_once __DIR__.'/Zapier.php';
require_once __DIR__.'/StripeClient.php';
require_once __DIR__.'/ChargebeeClient.php';
require_once __DIR__.'/SegmentClient.php';
require_once __DIR__.'/ZendeskClient.php';
require_once __DIR__.'/FreshdeskClient.php';


class IntegrationManager {
    private $pdo;
    private $integrations = []; // Cache for instantiated client objects

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    /**
     * Instantiates and returns an IntegrationBase client for a given service.
     * Caches the client objects for reuse.
     * @param string $service The name of the service (e.g., 'stripe', 'chargebee', etc.).
     * @param int $userId The ID of the user whose integration config to retrieve.
     * @return IntegrationBase An instance of the specific service client.
     * @throws Exception If the service is not supported, the client file is missing, or configuration is not found.
     */
    private function getClient(string $service, int $userId): IntegrationBase {
        $service = strtolower($service);

        // Ensure userId is a positive integer before proceeding.
        if (!is_int($userId) || $userId <= 0) {
            error_log("[IntegrationManager] Invalid userId provided to getClient: " . var_export($userId, true));
            throw new Exception("Invalid user ID for integration client instantiation.");
        }

        if (!isset($this->integrations[$service])) {
            $className = ucfirst($service).'Client'; // e.g., 'StripeClient', 'ZapierClient'
            $filePath = __DIR__."/{$className}.php";

            // --- DEBUGGING START (Keep these for now, remove in production) ---
            error_log("[IntegrationManager] Attempting to load client: {$className} from path: {$filePath}");
            // --- DEBUGGING END ---

            if (!file_exists($filePath)) {
                // --- DEBUGGING START (Keep these for now, remove in production) ---
                error_log("[IntegrationManager] File NOT found: {$filePath} for service: {$service}");
                // --- DEBUGGING END ---
                throw new Exception("API client file not found for service: {$service}.");
            }
            // require_once already done at the top

            $config = $this->getServiceConfig($userId, $service);
            if (empty($config)) {
                throw new Exception("Configuration not found for service: {$service}. Please set it up first.");
            }
            
            $this->integrations[$service] = new $className($config);
        }
        return $this->integrations[$service];
    }

    /**
     * Retrieves the stored configuration for a specific external service for a user.
     * @param int $userId The ID of the user.
     * @param string $serviceName The name of the service.
     * @return array The service configuration from the database, or an empty array if not found.
     */
    private function getServiceConfig(int $userId, string $serviceName): array {
        $stmt = $this->pdo->prepare("SELECT * FROM external_service_auth WHERE user_id = :user_id AND service_name = :service_name");
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindValue(':service_name', $serviceName);
        $stmt->execute();
        $config = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
        
        // Decode metadata if it exists and is a string
        if (isset($config['metadata']) && is_string($config['metadata']) && !empty($config['metadata'])) {
            $metadata = json_decode($config['metadata'], true);
            if (is_array($metadata)) {
                $config = array_merge($config, $metadata);
            }
        }
        return $config;
    }

    /**
     * Updates the stored configuration for a specific external service for a user.
     * This method handles varying credentials (single API key, API key + subdomain/domain, OAuth tokens).
     * It uses `api_key`, `base_url`, `access_token`, `refresh_token`, `token_expires` for main columns
     * and `metadata` for additional parameters like `client_id`, `client_secret`, `site_name`, `subdomain`, `domain`.
     * @param int $userId The ID of the user.
     * @param string $serviceName The name of the service.
     * @param array $configData The associative array of data to update.
     * @return bool True on success, false on failure.
     */
    public function updateServiceConfig(int $userId, string $serviceName, array $configData): bool {
        $existingConfig = $this->getServiceConfig($userId, $serviceName);
        $updateFields = [];
        $params = [];

        // Determine columns to bind based on which keys are present in configData
        $columnsToUpdate = ['auth_type', 'api_key', 'access_token', 'refresh_token', 'token_expires', 'base_url'];
        foreach ($columnsToUpdate as $col) {
            if (array_key_exists($col, $configData)) {
                $updateFields[] = "`{$col}` = :{$col}";
                $params[":{$col}"] = $configData[$col];
            }
        }
        
        // Handle metadata (contains client_id, client_secret, site_name, domain, subdomain etc.)
        $currentMetadata = json_decode($existingConfig['metadata'] ?? '{}', true) ?: [];
        $newMetadata = $configData['metadata'] ?? []; // PHP 7.0+ syntax
        $mergedMetadata = json_encode(array_merge($currentMetadata, $newMetadata));
        $updateFields[] = "`metadata` = :metadata";
        $params[':metadata'] = $mergedMetadata;

        // Always update last_connected_at on save/update
        $updateFields[] = "`last_connected_at` = NOW()";

        // Check if existing record exists for this service and user
        $stmt_check = $this->pdo->prepare("SELECT id FROM external_service_auth WHERE user_id = :user_id AND service_name = :service_name");
        $stmt_check->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt_check->bindValue(':service_name', $serviceName);
        $stmt_check->execute();
        $existing_id = $stmt_check->fetchColumn();

        if ($existing_id) {
            $sql = "UPDATE external_service_auth SET " . implode(', ', $updateFields) . " WHERE id = :id";
            $params[':id'] = $existing_id; // Add ID for WHERE clause
        } else {
            // For INSERT, define all columns and their placeholders explicitly.
            // All columns should be included for consistency, with null defaults if not provided.
            $insertColumns = [
                'user_id', 'service_name', 'auth_type', 'api_key', 'access_token',
                'refresh_token', 'token_expires', 'base_url', 'metadata',
                'created_at', 'last_connected_at'
            ];
            $insertPlaceholders = [
                ':user_id', ':service_name', ':auth_type', ':api_key', ':access_token',
                ':refresh_token', ':token_expires', ':base_url', ':metadata',
                'NOW()', 'NOW()'
            ];
            
            $insertParams = [
                ':user_id' => $userId,
                ':service_name' => $serviceName,
                ':auth_type' => $configData['auth_type'] ?? null, // PHP 7.0+ syntax
                ':api_key' => $configData['api_key'] ?? null, // PHP 7.0+ syntax
                ':access_token' => $configData['access_token'] ?? null, // PHP 7.0+ syntax
                ':refresh_token' => $configData['refresh_token'] ?? null, // PHP 7.0+ syntax
                ':token_expires' => $configData['token_expires'] ?? null, // PHP 7.0+ syntax
                ':base_url' => $configData['base_url'] ?? null, // PHP 7.0+ syntax
                ':metadata' => $mergedMetadata
            ];

            $sql = "INSERT INTO external_service_auth (" . implode(', ', $insertColumns) . ") VALUES (" . implode(', ', $insertPlaceholders) . ")";
            $params = $insertParams;
        }

        // --- DEBUGGING START (Keep these for now, remove in production) ---
        error_log("[IntegrationManager] updateServiceConfig SQL Query: " . $sql);
        error_log("[IntegrationManager] updateServiceConfig Bound Params: " . print_r($params, true));
        // --- DEBUGGING END ---

        try {
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute($params);
        } catch (PDOException $e) {
            error_log("[IntegrationManager] PDO Exception in updateServiceConfig: " . $e->getMessage() . " SQL: " . $sql . " Params: " . print_r($params, true));
            throw $e; // Re-throw to be caught by higher level for user-friendly error
        }
    }

    /**
     * Tests the connection for a given external service.
     * @param string $service The name of the service.
     * @param int $userId The ID of the user.
     * @return array Associative array with 'success' (bool) and 'error' (string, if any).
     * @throws Exception If service is unsupported or test fails.
     */
    public function testConnection(string $service, int $userId): array {
        try {
            $client = $this->getClient($service, $userId); // getClient will throw for unsupported services
            $success = $client->testConnection();
            
            return [
                'success' => $success,
                'error' => $success ? null : $client->getLastError()
            ];
        } catch (Exception $e) {
            error_log("[IntegrationManager] Test Connection failed for {$service} (User ID: {$userId}): " . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Fetches contacts from a specific external service.
     * Not all services support this (e.g., Segment, Zapier).
     * @param string $service The name of the service.
     * @param int $userId The ID of the user.
     * @param array $filters Optional filters to pass to the client's fetchContacts method.
     * @return array An array of contacts.
     * @throws Exception If fetching contacts fails or is not supported by the client.
     */
    public function fetchExternalContacts(string $service, int $userId, array $filters = []): array {
        try {
            $client = $this->getClient($service, $userId); // getClient will throw for unsupported services
            return $client->fetchContacts($filters); // Client's method will throw if not supported
        } catch (Exception $e) {
            $this->lastError = $e->getMessage();
            error_log("[IntegrationManager] Failed to fetch contacts from {$service} for user {$userId}: " . $e->getMessage());
            throw new Exception("Error fetching contacts from " . ucfirst($service) . ": " . $e->getMessage());
        }
    }

    /**
     * Generates the OAuth authorization URL for a specific external service.
     * Only applicable for OAuth-based services.
     * @param string $service The name of the service.
     * @param int $userId The ID of the user.
     * @param string $redirectUri The URI where the user will be redirected after authorization.
     * @param string $state An opaque value used to maintain state.
     * @return array Associative array with 'success' and 'authorization_url'.
     * @throws Exception If service does not support OAuth.
     */
    public function getAuthorizationUrl(string $service, int $userId, string $redirectUri, string $state): array {
        try {
            $client = $this->getClient($service, $userId); // getClient will throw for unsupported services
            $url = $client->getAuthorizationUrl($redirectUri, $state); // Client's method will throw if not supported
            return ['success' => true, 'authorization_url' => $url];
        } catch (Exception $e) {
            error_log("[IntegrationManager] Get Authorization URL failed for {$service} (User ID: {$userId}): " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Exchanges an authorization code for access and refresh tokens.
     * Only applicable for OAuth-based services.
     * @param string $service The name of the service.
     * @param int $userId The ID of the user.
     * @param string $code The authorization code.
     * @param string $redirectUri The redirect URI used in the initial request.
     * @return array Associative array with 'success' and token data or 'error'.
     * @throws Exception If service does not support OAuth.
     */
    public function exchangeCodeForTokens(string $service, int $userId, string $code, string $redirectUri): array {
        try {
            $client = $this->getClient($service, $userId); // getClient will throw for unsupported services
            $tokenData = $client->exchangeCodeForTokens($code, $redirectUri); // Client's method will throw if not supported

            // Save the received tokens and expiration to the database
            $this->updateServiceConfig($userId, $service, [
                'auth_type' => 'oauth', // Auth type will be 'oauth'
                'access_token' => $tokenData['access_token'] ?? null,
                'refresh_token' => $tokenData['refresh_token'] ?? null,
                'token_expires' => $tokenData['token_expires'] ?? null,
                'base_url' => $tokenData['instance_url'] ?? $tokenData['base_url'] ?? null, // Save Salesforce instance_url or Mautic base_url
                'metadata' => $tokenData['metadata'] ?? [] // Save any additional metadata returned from token exchange
            ]);
            
            return ['success' => true, 'message' => 'Tokens exchanged and saved.', 'token_data' => $tokenData];
        } catch (Exception $e) {
            error_log("[IntegrationManager] Error exchanging tokens for {$service} (User ID: {$userId}): " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Triggers an external action (e.g., sending data to Zapier, Segment).
     * Checks if the client has a `triggerWebhook`, `sendTrackEvent`, etc. method.
     * @param string $service The name of the service.
     * @param int $userId The ID of the user.
     * @param array $payload The data to send.
     * @return array Success status and message.
     * @throws Exception If action triggering is not supported or fails.
     */
    public function triggerExternalAction(string $service, int $userId, array $payload): array {
        try {
            $client = $this->getClient($service, $userId);
            
            // Flexible check for common outbound action methods
            if (method_exists($client, 'triggerWebhook')) { // For Zapier
                $response = $client->triggerWebhook($payload);
            } elseif (method_exists($client, 'sendTrackEvent')) { // For Segment
                $response = $client->sendTrackEvent(
                    $payload['event_name'] ?? 'Generic Event',
                    $payload['user_id'] ?? ($payload['contact_id'] ?? 'anonymous'),
                    $payload['properties'] ?? $payload // Pass full payload as properties if not specified
                );
            } elseif (method_exists($client, 'sendIdentifyEvent')) { // For Segment identify
                $response = $client->sendIdentifyEvent(
                    $payload['user_id'] ?? ($payload['contact_id'] ?? 'anonymous'),
                    $payload['traits'] ?? $payload // Pass full payload as traits if not specified
                );
            } else {
                throw new Exception("Action triggering not supported for service: " . ucfirst($service));
            }
            
            return ['success' => true, 'response' => $response, 'message' => 'Action triggered successfully.'];
        } catch (Exception $e) {
            error_log("[IntegrationManager] Failed to trigger action for {$service} (User ID: {$userId}): " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Retrieves options for external actions (e.g., Mautic segments, HubSpot lists, Zapier fields).
     * @param string $service The name of the service.
     * @param string $action Optional specific action to get options for.
     * @param array $config Optional configuration (user_id is expected here).
     * @return array
     * @throws Exception If service is not supported for options.
     */
    public function getOptions(string $service, string $action = '', array $config = []): array {
        try {
            $userId = $config['user_id'] ?? null; // PHP 7.0+ syntax
            if (!is_int($userId) || $userId <= 0) {
                throw new Exception("User ID is required and must be a positive integer to get integration options.");
            }
            
            // Get client to potentially fetch dynamic options (e.g., lists, segments)
            $client = $this->getClient($service, $userId); 

            switch ($service) {
                case 'zapier':
                    return [
                        'actions' => [
                            [
                                'id' => 'trigger_zap',
                                'name' => 'Trigger Zap',
                                'description' => 'Sends data to your configured Zapier webhook URL. Customize payload in automation.',
                                'fields' => [
                                    ['name' => 'event_name', 'label' => 'Event Name (for Zapier Filter)', 'type' => 'text', 'placeholder' => 'e.g., churn_alert', 'required' => true],
                                    ['name' => 'custom_payload', 'label' => 'Custom Payload (JSON)', 'type' => 'textarea', 'placeholder' => '{"contact_email": "{contact_email}", "churn_score": "{churn_score}"}']
                                ]
                            ]
                        ]
                    ];
                case 'stripe':
                    // Stripe doesn't have "actions" in the same way (it's mostly for financial ops).
                    // This could be for creating customers, subscriptions, etc., but usually triggered from within app logic.
                    // For now, return empty actions or specific simple ones.
                    return ['actions' => []]; // Or define actions like 'create_customer', 'update_subscription' if needed
                case 'chargebee':
                    return ['actions' => []]; // Similar to Stripe, direct actions from UI are less common
                case 'segment':
                    return [
                        'actions' => [
                            [
                                'id' => 'send_track_event',
                                'name' => 'Send Track Event',
                                'description' => 'Records a custom event in Segment for a user.',
                                'fields' => [
                                    ['name' => 'event_name', 'label' => 'Event Name', 'type' => 'text', 'required' => true],
                                    ['name' => 'user_id', 'label' => 'User ID (Segment)', 'type' => 'text', 'required' => true],
                                    ['name' => 'properties', 'label' => 'Properties (JSON)', 'type' => 'textarea', 'placeholder' => '{"churn_score": 75}']
                                ]
                            ],
                            [
                                'id' => 'send_identify_event',
                                'name' => 'Send Identify Event',
                                'description' => 'Updates user traits in Segment.',
                                'fields' => [
                                    ['name' => 'user_id', 'label' => 'User ID (Segment)', 'type' => 'text', 'required' => true],
                                    ['name' => 'traits', 'label' => 'Traits (JSON)', 'type' => 'textarea', 'placeholder' => '{"email": "test@example.com", "plan": "premium"}']
                                ]
                            ]
                        ]
                    ];
                case 'zendesk':
                    return [
                        'actions' => [
                            [
                                'id' => 'create_ticket',
                                'name' => 'Create Ticket',
                                'fields' => [
                                    ['name' => 'subject', 'label' => 'Subject', 'type' => 'text', 'required' => true],
                                    ['name' => 'comment', 'label' => 'Comment', 'type' => 'textarea', 'required' => true],
                                    ['name' => 'requester_email', 'label' => 'Requester Email', 'type' => 'email', 'required' => true]
                                ]
                            ]
                        ]
                    ];
                case 'freshdesk':
                    return [
                        'actions' => [
                            [
                                'id' => 'create_ticket',
                                'name' => 'Create Ticket',
                                'fields' => [
                                    ['name' => 'subject', 'label' => 'Subject', 'type' => 'text', 'required' => true],
                                    ['name' => 'description', 'label' => 'Description', 'type' => 'textarea', 'required' => true],
                                    ['name' => 'email', 'label' => 'Requester Email', 'type' => 'email', 'required' => true]
                                ]
                            ]
                        ]
                    ];
                default:
                    throw new Exception("Unsupported service for options: {$service}.");
            }
            
        } catch (Exception $e) {
            error_log("[IntegrationManager] Get Options failed for {$service} (User ID: " . ($userId ?? 'N/A') . "): " . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}