<?php
// includes/external_apis/Zapier.php
require_once __DIR__.'/IntegrationBase.php';

class ZapierClient extends IntegrationBase {
    private $webhookUrl;

    public function __construct(array $config) {
        parent::__construct($config);
        $this->serviceName = 'zapier';
        // 'base_url' from external_service_auth is used for the Zapier webhook URL
        $this->webhookUrl = $config['base_url'] ?? ''; 
    }

    /**
     * Tests the Zapier connection by sending a small test payload to the webhook URL.
     * A successful response (HTTP 200) from Zapier usually indicates the webhook is active.
     */
    public function testConnection(): bool {
        if (empty($this->webhookUrl) || !filter_var($this->webhookUrl, FILTER_VALIDATE_URL)) {
            $this->lastError = 'Zapier Webhook URL is invalid or missing.';
            return false;
        }

        try {
            $response = $this->makeRequest(
                $this->webhookUrl,
                'POST',
                ['event' => 'test_connection', 'timestamp' => date('Y-m-d H:i:s')],
                ['Content-Type: application/json']
            );

            // Zapier webhooks typically return a 'success' message or an empty JSON object on success.
            // Check for common success indicators.
            return isset($response['status']) && $response['status'] === 'success' || empty($response);
        } catch (Exception $e) {
            $this->lastError = 'Zapier Connection Test Failed: ' . $e->getMessage();
            return false;
        }
    }

    /**
     * For Zapier, fetching contacts is not a direct operation.
     * This method will throw an exception, as Zapier is an outbound integration.
     */
    public function fetchContacts(array $filters = []): array {
        throw new Exception('Fetching contacts is not supported for Zapier integration. Zapier acts as a webhook target for sending data from your platform.');
    }

    /**
     * Triggers a Zapier webhook with the provided data.
     * This is the primary function for sending data to Zapier.
     * @param array $data The payload to send to the Zapier webhook.
     * @return array|null The response from the Zapier webhook.
     */
    public function triggerWebhook(array $data): ?array {
        if (empty($this->webhookUrl) || !filter_var($this->webhookUrl, FILTER_VALIDATE_URL)) {
            $this->lastError = 'Zapier Webhook URL is invalid or missing. Cannot trigger webhook.';
            return null;
        }
        try {
            return $this->makeRequest(
                $this->webhookUrl,
                'POST',
                $data,
                ['Content-Type: application/json', 'Accept: application/json']
            );
        } catch (Exception $e) {
            $this->lastError = 'Zapier Webhook Trigger Failed: ' . $e->getMessage();
            return null;
        }
    }

    /**
     * Makes an HTTP request to the Zapier webhook URL.
     */
    protected function makeRequest(string $url, string $method = 'POST', array $data = [], array $headers = []): ?array {
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_SSL_VERIFYPEER => true, // Recommended for production
            CURLOPT_SSL_VERIFYHOST => 2,   // Recommended for production
        ]);

        $response = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            throw new Exception("cURL Error: " . $curlError);
        }

        $decodedResponse = json_decode($response, true);

        // Zapier webhooks often return 200 even for logic errors within the Zap,
        // but typically have a 'success' or specific structure.
        // For simplicity, we assume 200 is success, and check for a 'status' field later in triggerWebhook.
        if ($status !== 200 && $status !== 201) { // Accept 201 Created as well
            $errorMessage = "Zapier Webhook HTTP Error: HTTP $status - " . ($response ?: 'No response body');
            error_log("Zapier webhook request failed: $errorMessage. URL: $url, Data: " . json_encode($data));
            throw new Exception($errorMessage);
        }

        return $decodedResponse;
    }
}