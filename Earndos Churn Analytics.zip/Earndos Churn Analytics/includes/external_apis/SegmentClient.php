<?php
// includes/external_apis/SegmentClient.php
require_once __DIR__.'/IntegrationBase.php';

class SegmentClient extends IntegrationBase {
    private $writeKey; // Segment Source Write Key

    public function __construct(array $config) {
        parent::__construct($config);
        $this->serviceName = 'segment';
        // Segment Write Key will be stored in the 'api_key' field in external_service_auth
        $this->writeKey = $config['api_key'] ?? ''; 
    }

    /**
     * Tests the connection to Segment by sending a dummy 'track' event.
     * A successful response (typically HTTP 200 or 201 with no body) indicates the key is valid.
     * @return bool True if connection is successful, false otherwise.
     */
    public function testConnection(): bool {
        if (empty($this->writeKey)) {
            $this->lastError = 'Segment Write Key is missing.';
            return false;
        }

        try {
            // Segment's HTTP API endpoint for tracking events
            $endpoint = 'https://api.segment.io/v1/track';
            
            // Minimal dummy event to test
            $testPayload = [
                'event' => 'Test Connection from Churn Analytics',
                'userId' => 'test_user_id_123',
                'properties' => [
                    'source' => 'Churn Analytics Integration Test'
                ]
            ];

            // Segment typically uses Basic Auth with Write Key as username and empty password
            // Or a Bearer token with the Write Key. Let's use Basic Auth.
            $authHeader = 'Basic ' . base64_encode($this->writeKey . ':');

            $response = $this->makeRequest(
                $endpoint,
                'POST',
                $testPayload,
                ['Authorization: ' . $authHeader, 'Content-Type: application/json']
            );
            
            // Segment's track API returns a simple {"success":true} on success.
            return isset($response['success']) && $response['success'] === true;
        } catch (Exception $e) {
            $this->lastError = 'Segment Connection Error: ' . $e->getMessage();
            return false;
        }
    }

    /**
     * Segment.com is a data collection and routing platform, not a direct CRM for fetching contacts.
     * Fetching a list of contacts (customers) is not a primary function of its standard Write Key API.
     * This method is not applicable for this type of integration and will throw an exception.
     * @param array $filters Not used.
     * @throws Exception Always throws.
     */
    public function fetchContacts(array $filters = []): array {
        throw new Exception('Fetching contacts is not supported for Segment.com integration via Write Key. Segment is designed for collecting and routing data.');
    }

    /**
     * Segment.com Write Key authentication does not use OAuth.
     * This method is not applicable and will throw an exception.
     */
    public function getAuthorizationUrl(string $redirectUri, string $state): string {
        throw new Exception('Segment.com Write Key authentication does not use OAuth authorization URLs.');
    }

    /**
     * Segment.com Write Key authentication does not use OAuth.
     * This method is not applicable and will throw an exception.
     */
    public function exchangeCodeForTokens(string $code, string $redirectUri): array {
        throw new Exception('Segment.com Write Key authentication does not use OAuth token exchange.');
    }

    /**
     * Segment.com Write Key authentication does not use OAuth.
     * This method is not applicable and will throw an exception.
     */
    public function refreshAccessToken(string $refreshToken): array {
        throw new Exception('Segment.com Write Key authentication does not use OAuth refresh tokens.');
    }

    /**
     * Makes an HTTP request to the Segment.com API.
     * Uses HTTP Basic Authentication with Write Key as username and empty password.
     */
    protected function makeRequest(string $url, string $method = 'POST', array $data = [], array $headers = []): ?array {
        $ch = curl_init();
        
        // Segment Basic Auth: Write Key as username, empty password
        $authHeader = 'Basic ' . base64_encode($this->writeKey . ':'); 
        $standardHeaders = [
            'Authorization: ' . $authHeader,
            'Content-Type: application/json'
        ];
        $finalHeaders = array_merge($standardHeaders, $headers);

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $finalHeaders,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);

        if (!empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            throw new Exception("cURL Error: " . $curlError);
        }

        $decodedResponse = json_decode($response, true);

        // Segment's track API returns 200/201 and {"success":true} or an error object.
        if ($status >= 400 || (isset($decodedResponse['success']) && $decodedResponse['success'] === false)) {
            $errorMessage = "Segment API Error: HTTP {$status} - " . ($decodedResponse['message'] ?? $response);
            error_log("Segment API request failed: {$errorMessage}. URL: {$url}, Method: {$method}, Data: " . json_encode($data));
            throw new Exception($errorMessage);
        }

        return $decodedResponse;
    }

    /**
     * Sends a 'track' event to Segment. This is a common outbound action.
     * @param string $eventName The name of the event (e.g., 'Churn Risk Increased').
     * @param string $userId The user ID for the event.
     * @param array $properties Event properties.
     * @param string|null $anonymousId Anonymous ID if available.
     * @return array|null Response from Segment.
     * @throws Exception If Segment API call fails.
     */
    public function sendTrackEvent(string $eventName, string $userId, array $properties = [], ?string $anonymousId = null): ?array {
        if (empty($this->writeKey)) {
            throw new Exception('Segment Write Key is missing. Cannot send track event.');
        }

        $payload = [
            'event' => $eventName,
            'userId' => $userId,
            'properties' => $properties,
            'timestamp' => date('c'), // ISO 8601 format
            'context' => [
                'library' => [
                    'name' => 'ChurnAnalytics-Backend',
                    'version' => '1.0.0'
                ]
            ]
        ];
        if ($anonymousId) {
            $payload['anonymousId'] = $anonymousId;
        }

        $endpoint = 'https://api.segment.io/v1/track';
        
        try {
            return $this->makeRequest(
                $endpoint,
                'POST',
                $payload,
                ['Authorization: Basic ' . base64_encode($this->writeKey . ':'), 'Content-Type: application/json']
            );
        } catch (Exception $e) {
            $this->lastError = 'Segment Send Track Event Error: ' . $e->getMessage();
            throw $e;
        }
    }
    
    /**
     * Sends an 'identify' call to Segment.
     * @param string $userId The user ID.
     * @param array $traits User traits/properties.
     * @return array|null Response from Segment.
     * @throws Exception If Segment API call fails.
     */
    public function sendIdentifyEvent(string $userId, array $traits = []): ?array {
        if (empty($this->writeKey)) {
            throw new Exception('Segment Write Key is missing. Cannot send identify event.');
        }

        $payload = [
            'userId' => $userId,
            'traits' => $traits,
            'timestamp' => date('c'),
            'context' => [
                'library' => [
                    'name' => 'ChurnAnalytics-Backend',
                    'version' => '1.0.0'
                ]
            ]
        ];

        $endpoint = 'https://api.segment.io/v1/identify';
        
        try {
            return $this->makeRequest(
                $endpoint,
                'POST',
                $payload,
                ['Authorization: Basic ' . base64_encode($this->writeKey . ':'), 'Content-Type: application/json']
            );
        } catch (Exception $e) {
            $this->lastError = 'Segment Send Identify Event Error: ' . $e->getMessage();
            throw $e;
        }
    }
}