<?php
// includes/external_apis/ChargebeeClient.php
require_once __DIR__.'/IntegrationBase.php';

class ChargebeeClient extends IntegrationBase {
    private $apiKey;
    private $siteName; // The subdomain used for Chargebee API calls (e.g., your-site.chargebee.com)
    private $baseUrl; // Constructed from siteName

    public function __construct(array $config) {
        parent::__construct($config);
        $this->serviceName = 'chargebee';
        $this->apiKey = $config['api_key'] ?? '';
        $this->siteName = $config['site_name'] ?? ''; // Expecting a 'site_name' in config
        // Construct the base API URL from the siteName
        if (!empty($this->siteName)) {
            $this->baseUrl = 'https://' . rtrim($this->siteName, '/') . '.chargebee.com/api/v2';
        } else {
            $this->baseUrl = ''; // Will cause errors if not set
        }
    }

    /**
     * Tests the connection to Chargebee by attempting to retrieve a limited number of customers.
     * @return bool True if connection is successful, false otherwise.
     */
    public function testConnection(): bool {
        if (empty($this->apiKey)) {
            $this->lastError = 'Chargebee API Key is missing.';
            return false;
        }
        if (empty($this->siteName)) {
            $this->lastError = 'Chargebee Site Name (subdomain) is missing.';
            return false;
        }
        if (empty($this->baseUrl)) {
            $this->lastError = 'Chargebee Base URL could not be constructed. Check site name.';
            return false;
        }

        try {
            // Use a simple, low-privilege endpoint, e.g., list customers with a limit of 1.
            $response = $this->makeRequest(
                '/customers?limit=1', // Relative path to customers endpoint
                'GET'
            );
            
            // If the request succeeds, even if data is empty, it indicates a valid connection.
            return isset($response['list']) && is_array($response['list']);
        } catch (Exception $e) {
            $this->lastError = 'Chargebee Connection Error: ' . $e->getMessage();
            return false;
        }
    }

    /**
     * Fetches customers from Chargebee.
     * Chargebee API offers various resources (customers, subscriptions, invoices).
     * We'll focus on 'customers' for contact representation.
     * @param array $filters Optional filters like 'limit', 'offset', 'email'.
     * @return array An array of contacts.
     */
    public function fetchContacts(array $filters = []): array {
        if (empty($this->apiKey) || empty($this->siteName) || empty($this->baseUrl)) {
            throw new Exception('Chargebee API Key, Site Name, or Base URL is missing. Cannot fetch contacts.');
        }

        $limit = $filters['limit'] ?? 100; // Chargebee default limit is 100, max 100
        $offset = $filters['offset'] ?? null; // For pagination
        $email = $filters['email'] ?? null; // Search by email

        $endpoint = '/customers?limit=' . (int)$limit;
        if ($offset) {
            $endpoint .= '&offset=' . urlencode($offset);
        }
        if ($email) {
            $endpoint .= '&email=' . urlencode($email);
        }

        try {
            $response = $this->makeRequest(
                $endpoint,
                'GET'
            );

            $contacts = [];
            if (isset($response['list']) && is_array($response['list'])) {
                foreach ($response['list'] as $item) {
                    $customer = $item['customer'] ?? [];
                    if (!empty($customer)) {
                        $contacts[] = [
                            'id' => $customer['id'],
                            'email' => $customer['email'] ?? null,
                            'name' => $customer['first_name'] . ' ' . $customer['last_name'] ?? ($customer['email'] ?? 'N/A'),
                            'custom_data' => $customer // Store all Chargebee customer data
                        ];
                    }
                }
            }
            return $contacts;
        } catch (Exception $e) {
            $this->lastError = 'Chargebee Fetch Contacts Error: ' . $e->getMessage();
            return [];
        }
    }

    /**
     * Chargebee API Key authentication does not use OAuth.
     * This method is not applicable and will throw an exception.
     */
    public function getAuthorizationUrl(string $redirectUri, string $state): string {
        throw new Exception('Chargebee API Key authentication does not use OAuth authorization URLs.');
    }

    /**
     * Chargebee API Key authentication does not use OAuth.
     * This method is not applicable and will throw an exception.
     */
    public function exchangeCodeForTokens(string $code, string $redirectUri): array {
        throw new Exception('Chargebee API Key authentication does not use OAuth token exchange.');
    }

    /**
     * Chargebee API Key authentication does not use OAuth.
     * This method is not applicable and will throw an exception.
     */
    public function refreshAccessToken(string $refreshToken): array {
        throw new Exception('Chargebee API Key authentication does not use OAuth refresh tokens.');
    }

    /**
     * Makes an HTTP request to the Chargebee API.
     * Uses HTTP Basic Authentication with API Key as username and empty password.
     */
    protected function makeRequest(string $endpoint, string $method = 'GET', array $data = [], array $headers = []): ?array {
        if (empty($this->baseUrl)) {
            throw new Exception("Chargebee Base URL is not set. Check site name.");
        }

        $url = $this->baseUrl . $endpoint; // Append endpoint to base URL

        $ch = curl_init();
        
        // Chargebee uses Basic Auth with API Key as username and empty password
        $authHeader = base66_encode($this->apiKey . ':'); 
        $standardHeaders = [
            'Authorization: Basic ' . $authHeader,
            'Content-Type: application/json' // Chargebee usually prefers JSON for data payloads
        ];
        $finalHeaders = array_merge($standardHeaders, $headers);

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $finalHeaders,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);

        if (!empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            throw new Exception("cURL Error: " . $curlError);
        }

        $decodedResponse = json_decode($response, true);

        if ($status >= 400) {
            $errorMessage = "Chargebee API Error: HTTP {$status} - " . ($decodedResponse['message'] ?? $response);
            error_log("Chargebee API request failed: {$errorMessage}. URL: {$url}, Method: {$method}, Data: " . json_encode($data));
            throw new Exception($errorMessage);
        }

        return $decodedResponse;
    }
}