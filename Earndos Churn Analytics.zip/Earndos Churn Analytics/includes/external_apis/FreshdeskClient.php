<?php
// includes/external_apis/FreshdeskClient.php
require_once __DIR__.'/IntegrationBase.php';

class FreshdeskClient extends IntegrationBase {
    private $apiKey;      // Freshdesk API Key
    private $domain;      // Freshdesk Domain (e.g., yourcompany.freshdesk.com)
    private $baseUrl;     // Constructed from domain

    public function __construct(array $config) {
        parent::__construct($config);
        $this->serviceName = 'freshdesk';
        // We'll use 'api_key' for the Freshdesk API Key
        $this->apiKey = $config['api_key'] ?? '';
        // Expecting a 'domain' in the config
        $this->domain = $config['domain'] ?? '';
        // Construct the base API URL from the domain
        if (!empty($this->domain)) {
            // Ensure the domain has no trailing slash and Freshdesk API v2 path is correct
            $this->baseUrl = 'https://' . rtrim($this->domain, '/') . '/api/v2';
        } else {
            $this->baseUrl = ''; // Will cause errors if not set
        }
    }

    /**
     * Tests the connection to Freshdesk by attempting to retrieve a limited number of contacts.
     * @return bool True if connection is successful, false otherwise.
     */
    public function testConnection(): bool {
        if (empty($this->apiKey)) {
            $this->lastError = 'Freshdesk API Key is missing.';
            return false;
        }
        if (empty($this->domain)) {
            $this->lastError = 'Freshdesk Domain is missing.';
            return false;
        }
        if (empty($this->baseUrl)) {
            $this->lastError = 'Freshdesk Base URL could not be constructed. Check domain.';
            return false;
        }

        try {
            // Use a simple, low-privilege endpoint, e.g., list contacts with a limit of 1.
            $response = $this->makeRequest(
                '/contacts?per_page=1', // Freshdesk uses 'per_page' for limit
                'GET'
            );
            
            // If the request succeeds, even if data is empty, it indicates a valid connection.
            return isset($response['contacts']) && is_array($response['contacts']);
        } catch (Exception $e) {
            $this->lastError = 'Freshdesk Connection Error: ' . $e->getMessage();
            return false;
        }
    }

    /**
     * Fetches contacts from Freshdesk.
     * @param array $filters Optional filters like 'per_page', 'page', 'email'.
     * @return array An array of contacts.
     */
    public function fetchContacts(array $filters = []): array {
         if (empty($this->apiKey) || empty($this->domain) || empty($this->baseUrl)) {
            throw new Exception('Freshdesk API Key, Domain, or Base URL is missing. Cannot fetch contacts.');
        }

        $perPage = $filters['per_page'] ?? 100; // Freshdesk default is 30, max 100
        $page = $filters['page'] ?? 1; // For pagination
        $email = $filters['email'] ?? null; // Search by email

        $endpoint = '/contacts?per_page=' . (int)$perPage . '&page=' . (int)$page;
        if ($email) {
            // Freshdesk's search is typically /search/contacts?query="email:'test@example.com'"
            // For simple fetch, we'll try to rely on their filtering capabilities if available,
            // or search manually through results if not a direct parameter.
            // For now, let's keep it simple and assume direct filtering like this.
            // A more robust solution might use /search/contacts endpoint.
            $endpoint .= '&email=' . urlencode($email); 
        }

        try {
            $response = $this->makeRequest(
                $endpoint,
                'GET'
            );

            $contacts = [];
            if (isset($response['contacts']) && is_array($response['contacts'])) {
                foreach ($response['contacts'] as $contact) {
                    $contacts[] = [
                        'id' => $contact['id'],
                        'email' => $contact['email'] ?? null,
                        'name' => $contact['name'] ?? ($contact['email'] ?? 'N/A'),
                        'custom_data' => $contact // Store all Freshdesk contact data
                    ];
                }
            }
            return $contacts;
        } catch (Exception $e) {
            $this->lastError = 'Freshdesk Fetch Contacts Error: ' . $e->getMessage();
            return [];
        }
    }

    /**
     * Freshdesk API Key authentication does not use OAuth.
     * This method is not applicable and will throw an exception.
     */
    public function getAuthorizationUrl(string $redirectUri, string $state): string {
        throw new Exception('Freshdesk API Key authentication does not use OAuth authorization URLs.');
    }

    /**
     * Freshdesk API Key authentication does not use OAuth.
     * This method is not applicable and will throw an exception.
     */
    public function exchangeCodeForTokens(string $code, string $redirectUri): array {
        throw new Exception('Freshdesk API Key authentication does not use OAuth token exchange.');
    }

    /**
     * Freshdesk API Key authentication does not use OAuth.
     * This method is not applicable and will throw an exception.
     */
    public function refreshAccessToken(string $refreshToken): array {
        throw new Exception('Freshdesk API Key authentication does not use OAuth refresh tokens.');
    }

    /**
     * Makes an HTTP request to the Freshdesk API.
     * Uses HTTP Basic Authentication with API Key as username and 'X' as password.
     */
    protected function makeRequest(string $endpoint, string $method = 'GET', array $data = [], array $headers = []): ?array {
        if (empty($this->baseUrl)) {
            throw new Exception("Freshdesk Base URL is not set. Check domain.");
        }

        $url = $this->baseUrl . $endpoint; // Append endpoint to base URL

        $ch = curl_init();
        
        // Freshdesk Basic Auth: API Key as username, 'X' as dummy password
        $authHeader = base64_encode($this->apiKey . ':X'); 
        $standardHeaders = [
            'Authorization: Basic ' . $authHeader,
            'Content-Type: application/json' // Freshdesk usually prefers JSON for data payloads
        ];
        $finalHeaders = array_merge($standardHeaders, $headers);

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $finalHeaders,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);

        if (!empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            throw new Exception("cURL Error: " . $curlError);
        }

        $decodedResponse = json_decode($response, true);

        if ($status >= 400) {
            $errorMessage = "Freshdesk API Error: HTTP {$status} - " . ($decodedResponse['message'] ?? $response);
            error_log("Freshdesk API request failed: {$errorMessage}. URL: {$url}, Method: {$method}, Data: " . json_encode($data));
            throw new Exception($errorMessage);
        }

        return $decodedResponse;
    }
}