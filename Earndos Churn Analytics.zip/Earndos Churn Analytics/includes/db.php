<?php
// includes/db.php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'churn_analytics_db');
define('DB_USER', 'churn_analytics');
define('DB_PASS', 'password');

// Base URL configuration
define('BASE_URL', 'https://earndos.com/');

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Store base URL in config table if not exists
    $stmt = $pdo->query("SELECT value FROM config WHERE setting = 'base_url'");
    if (!$stmt->fetch()) {
        $pdo->query("INSERT INTO config (setting, value) VALUES ('base_url', '".BASE_URL."')");
    }
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>