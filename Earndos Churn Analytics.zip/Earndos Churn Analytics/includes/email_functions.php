<?php
// includes/email_functions.php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Ensure db.php is available as it's needed for $pdo and BASE_URL in get_base_url()
// Note: send_email function explicitly requires db.php, but it's good practice
// to ensure global $pdo is accessible throughout this file if functions directly query it.
// For example, get_base_url() requires $pdo.

/**
 * Sends an invitation email for a team.
 * This function retrieves the template from the 'config' table or uses a default.
 *
 * @param string $email The recipient's email address.
 * @param string $team_name The name of the team.
 * @param string $inviter_name The name of the user who sent the invite.
 * @param string $token The unique token for accepting the invite.
 * @return bool True on success, false on failure.
 */
function send_team_invite_email($email, $team_name, $inviter_name, $token) {
    global $pdo; // Access the PDO object

    // Build invite URL
    $base_url = get_base_url();
    if (!$base_url) {
        error_log("EMAIL ERROR: BASE_URL is not configured. Cannot send team invite email.");
        return false;
    }
    $invite_url = $base_url . "/team_invites.php?token=$token";

    // Attempt to get email template from config
    $template_stmt = $pdo->prepare("SELECT value FROM config WHERE setting = 'team_invite_template'");
    $template_stmt->execute();
    $template = $template_stmt->fetchColumn();

    // If template is not found or empty in DB, use a default HTML template
    if (empty($template)) {
        error_log("EMAIL INFO: 'team_invite_template' not found or empty in config table. Using default template.");
        $template = "
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ddd; border-radius: 8px; background-color: #f9f9f9; }
                    h2 { color: #3ac3b8; }
                    p { margin-bottom: 10px; }
                    .button {
                        display: inline-block;
                        padding: 10px 20px;
                        background-color: #3ac3b8;
                        color: white !important; /* Important to override link styles */
                        text-decoration: none;
                        border-radius: 5px;
                        margin-top: 15px;
                        font-weight: bold;
                    }
                    .footer { font-size: 0.9em; color: #777; margin-top: 20px; border-top: 1px solid #eee; padding-top: 10px; }
                </style>
            </head>
            <body>
                <div class='container'>
                    <h2>Invitation to join " . htmlspecialchars($team_name) . " on Churn Analytics</h2>
                    <p>Hello,</p>
                    <p>You have been invited by <strong>" . htmlspecialchars($inviter_name) . "</strong> to join the team <strong>" . htmlspecialchars($team_name) . "</strong> on Churn Analytics.</p>
                    <p>This team uses Churn Analytics to gain insights and manage customer churn for their projects.</p>
                    <p>To accept this invitation and join the team, please click the button below:</p>
                    <a href='" . htmlspecialchars($invite_url) . "' class='button'>Accept Invitation</a>
                    <p>If the button above does not work, please copy and paste the following link into your web browser:</p>
                    <p><small><a href='" . htmlspecialchars($invite_url) . "'>" . htmlspecialchars($invite_url) . "</a></small></p>
                    <p>We look forward to having you!</p>
                    <p class='footer'>Sincerely,<br>The Churn Analytics Team</p>
                </div>
            </body>
            </html>
        ";
    } else {
        // Use the template from the database, and replace its placeholders
        $template = str_replace(
            ['{team_name}', '{inviter_name}', '{invite_url}'],
            [htmlspecialchars($team_name), htmlspecialchars($inviter_name), htmlspecialchars($invite_url)],
            $template
        );
    }

    $subject = "Invitation to join team " . htmlspecialchars($team_name) . " on Churn Analytics";
    return send_email($email, $subject, $template);
}


/**
 * Retrieves the base URL from the 'config' table in the database.
 *
 * @return string|false The base URL if found, false otherwise.
 */
function get_base_url() {
    global $pdo; // Access the PDO object
    try {
        $stmt = $pdo->query("SELECT value FROM config WHERE setting = 'base_url'");
        $base_url = $stmt->fetchColumn();
        if ($base_url === false) {
            error_log("CONFIG ERROR: 'base_url' setting not found in the database.");
            return false;
        }
        return $base_url;
    } catch (PDOException $e) {
        error_log("DATABASE ERROR in get_base_url(): " . $e->getMessage());
        return false;
    }
}

/**
 * Sends an account activation email to a new user.
 *
 * @param string $email The recipient's email address.
 * @param string $username The username of the new user.
 * @param string $activation_link The unique activation link.
 * @return bool True on success, false on failure.
 */
function send_activation_email($email, $username, $activation_link) {
    $subject = "Account Activation Required for Churn Analytics";
    $message = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ddd; border-radius: 8px; background-color: #f9f9f9; }
            h2 { color: #3ac3b8; }
            p { margin-bottom: 10px; }
            .button { 
                display: inline-block; 
                padding: 10px 20px; 
                background-color: #3ac3b8; 
                color: white !important;
                text-decoration: none; 
                border-radius: 5px; 
                margin-top: 15px;
                font-weight: bold;
            }
            .footer { font-size: 0.9em; color: #777; margin-top: 20px; border-top: 1px solid #eee; padding-top: 10px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <h2>Welcome to Earndos Churn Insights, " . htmlspecialchars($username) . "! 🎉🤩</h2>
            <p>Thank you for registering with Churn Analytics. To activate your account and start managing your churn data, please click the button below:</p>
            <a href='" . htmlspecialchars($activation_link) . "' class='button'>Activate Account</a>
            <p>If the button doesn't work, copy and paste this link into your browser:</p>
            <p><small><a href='" . htmlspecialchars($activation_link) . "'>" . htmlspecialchars($activation_link) . "</a></small></p>
            <p>If you did not register for an account, please disregard this email.</p>
            <p class='footer'>Sincerely,<br>The Churn Analytics Team</p>
        </div>
    </body>
    </html>
    ";

    return send_email($email, $subject, $message);
}

/**
 * Renders an email template from a file, replacing placeholders.
 * This is typically used for more complex, user-defined templates.
 *
 * @param string $template_name The base name of the HTML template file (e.g., 'welcome_email').
 * @param array $data An associative array of data for placeholder replacement.
 * @return string The rendered HTML content.
 * @throws Exception If the template file is not found.
 */
function render_email_template($template_name, $data) {
    // __DIR__ refers to the directory of the current file (email_functions.php)
    // ../ moves up one directory to the project root (e.g., /io/)
    // templates/emails/ is the path to your email templates
    $template_path = __DIR__ . "/../templates/emails/{$template_name}.html";
    
    if (!file_exists($template_path)) {
        error_log("EMAIL ERROR: Email template file not found at: " . $template_path);
        throw new Exception("Email template not found: {$template_name}");
    }
    
    $template = file_get_contents($template_path);
    
    // Default replacements, HTML escaped for safety in case of user-supplied data
    $replacements = [
        '{subject}' => htmlspecialchars($data['title'] ?? 'Notification Alert'),
        '{threshold}' => htmlspecialchars(number_format($data['threshold'] ?? 0, 2)),
        '{contact.username}' => htmlspecialchars($data['contacts'][0]['username'] ?? ''),
        '{contact.id}' => htmlspecialchars($data['contacts'][0]['id'] ?? ''),
        '{contact.score}' => htmlspecialchars(number_format($data['contacts'][0]['score'] ?? 0, 2)),
        // Assuming risk_class is an internal determination, not user-provided
        '{risk_class}' => htmlspecialchars(($data['contacts'][0]['score'] ?? 0) > 70 ? 'risk-high' : 'risk-medium'),
        '{stream_name}' => htmlspecialchars($data['stream_name'] ?? 'All Streams'),
        '{stream_id}' => htmlspecialchars($data['stream_id'] ?? ''),
        '{base_url}' => htmlspecialchars(BASE_URL ?? ''), // Ensure BASE_URL is defined globally
        '{notification_id}' => htmlspecialchars($data['notification_id'] ?? '')
    ];
    
    // Handle other contacts list - be careful with HTML injection if contacts data is user-supplied
    $other_contacts_html = '';
    if (!empty($data['contacts']) && count($data['contacts']) > 1) {
        foreach (array_slice($data['contacts'], 1, 5) as $contact) { // Limit to first 5 for emails
            $other_contacts_html .= "<li>" . htmlspecialchars($contact['username']) . " (" . htmlspecialchars(number_format($contact['score'] ?? 0, 2)) . "%)</li>";
        }
        // Remove conditional comments/placeholders that wrap the loop in the template
        $template = preg_replace('/\{if other_contacts\}.*?\{loop other_contacts\}/s', '', $template);
        $template = str_replace('{endloop}', '', $template);
        $template = str_replace('{endif}', '', $template);
        // Replace the loop content with the generated HTML list
        $template = str_replace('{loop other_contacts}', $other_contacts_html, $template);
    } else {
        // If no other contacts, remove the entire conditional block
        $template = preg_replace('/\{if other_contacts\}.*?\{endif\}/s', '', $template);
    }
    
    // Perform all replacements
    return str_replace(array_keys($replacements), array_values($replacements), $template);
}


/**
 * Sends a password reset email.
 *
 * @param string $email The recipient's email address.
 * @param string $reset_link The unique password reset link.
 * @return bool True on success, false on failure.
 */
function send_password_reset_email($email, $reset_link) {
    $subject = "Password Reset Request for Churn Analytics";
    $message = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ddd; border-radius: 8px; background-color: #f9f9f9; }
            h2 { color: #3ac3b8; }
            p { margin-bottom: 10px; }
            .button { 
                display: inline-block; 
                padding: 10px 20px; 
                background-color: #3ac3b8; 
                color: white !important;
                text-decoration: none; 
                border-radius: 5px; 
                margin-top: 15px;
                font-weight: bold;
            }
            .warning { color: #e53e3e; font-weight: bold; }
            .footer { font-size: 0.9em; color: #777; margin-top: 20px; border-top: 1px solid #eee; padding-top: 10px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <h2>Password Reset Request</h2>
            <p>We received a request to reset the password for your Churn Analytics account. Click the button below to proceed:</p>
            <a href='" . htmlspecialchars($reset_link) . "' class='button'>Reset Password</a>
            <p>If you didn't request this, please ignore this email. Your password will remain unchanged.</p>
            <p class='warning'>This link will expire in 1 hour.</p>
            <p>If the button doesn't work, copy and paste this link into your browser:</p>
            <p><small><a href='" . htmlspecialchars($reset_link) . "'>" . htmlspecialchars($reset_link) . "</a></small></p>
            <p class='footer'>Sincerely,<br>The Churn Analytics Team</p>
        </div>
    </body>
    </html>
    ";

    return send_email($email, $subject, $message);
}

/**
 * Core email sending function. Handles both PHP mail() and SMTP.
 * Requires PHPMailer to be installed via Composer for SMTP functionality.
 *
 * @param string $to The recipient's email address.
 * @param string $subject The subject line of the email.
 * @param string $body The HTML content of the email.
 * @return bool True on successful sending, false otherwise.
 */
function send_email($to, $subject, $body) {
    // Ensure db.php is required within this function if it's not guaranteed to be required globally
    // or if this function might be called from contexts where db.php isn't active.
    // Given the structure, it's safer to ensure $pdo is accessible (via global $pdo or by passing it).
    // The problem description implies db.php is required once at the top of the main script,
    // so `global $pdo;` should suffice if $pdo is set up there.
    global $pdo;

    // Get email settings from config
    $stmt = $pdo->query("SELECT setting, value FROM config WHERE setting LIKE 'email_%' OR setting LIKE 'smtp_%'");
    $config = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    // Set default 'From' details
    $from_address = $config['email_from_address'] ?? 'no-reply@' . parse_url(BASE_URL, PHP_URL_HOST);
    $from_name = $config['email_from_name'] ?? 'Churn Analytics';

    if (($config['email_method'] ?? 'phpmail') === 'smtp') {
        // Send using SMTP (requires PHPMailer)
        // Ensure PHPMailer classes are available
        require_once __DIR__ . '/../vendor/autoload.php'; // Adjust path if needed

        $mail = new PHPMailer();
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = $config['smtp_host'] ?? '';
            $mail->SMTPAuth = true;
            $mail->Username = $config['smtp_username'] ?? '';
            $mail->Password = $config['smtp_password'] ?? '';
            $mail->Port = $config['smtp_port'] ?? 587; // Default SMTP port
            
            // Set SMTPSecure based on config value
            switch (strtolower($config['smtp_secure'] ?? 'tls')) {
                case 'ssl':
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                    break;
                case 'tls':
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    break;
                default:
                    $mail->SMTPSecure = ''; // No encryption
                    break;
            }
            
            // Recipients
            $mail->setFrom($from_address, $from_name);
            $mail->addAddress($to);

            // Content
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $body;
            $mail->AltBody = strip_tags($body); // Plain text for non-HTML clients

            if ($mail->send()) {
                return true;
            } else {
                error_log("PHPMailer Error to $to: " . $mail->ErrorInfo);
                return false;
            }
        } catch (Exception $e) {
            error_log("PHPMailer Exception to $to: " . $e->getMessage() . " (Mailer Error: " . $mail->ErrorInfo . ")");
            return false;
        }
    } else {
        // Fallback to PHP mail()
        $headers_array = [
            'MIME-Version: 1.0',
            'Content-type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_address . '>',
            'X-Mailer: PHP/' . phpversion() // Good practice for identification
        ];
        $headers = implode("\r\n", $headers_array);

        if (mail($to, $subject, $body, $headers)) {
            return true;
        } else {
            error_log("PHP mail() failed to send email to: $to. Subject: $subject");
            return false;
        }
    }
}