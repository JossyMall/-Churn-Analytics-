<?php
// includes/auth_functions.php

/**
 * Check if user is logged in
 */
function is_logged_in() {
    // Check session first
    if (isset($_SESSION['user_id'])) {
        return true;
    }
    
    // Check remember token cookie
    if (isset($_COOKIE['remember_token'])) {
        require_once 'db.php';
        global $pdo;
        
        $stmt = $pdo->prepare("SELECT id FROM users WHERE remember_token = ?");
        $stmt->execute([$_COOKIE['remember_token']]);
        $user = $stmt->fetch();
        
        if ($user) {
            $_SESSION['user_id'] = $user['id'];
            return true;
        }
    }
    
    return false;
}

/**
 * Require authentication
 */
function require_auth() {
    if (!is_logged_in()) {
        $_SESSION['redirect_url'] = current_url();
        redirect('/auth/login.php');
    }
}

/**
 * Require admin privileges
 */
function require_admin() {
    require_auth();
    
    if (!is_admin()) {
        $_SESSION['error'] = 'Admin privileges required';
        redirect('/dashboard.php');
    }
}

/**
 * Get current user ID
 */
function current_user_id() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get current user data
 */
function current_user() {
    if (!is_logged_in()) return null;
    
    require_once 'db.php';
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([current_user_id()]);
    return $stmt->fetch();
}

/**
 * Validate password strength
 */
function validate_password($password) {
    return strlen($password) >= 8; // At least 8 characters
}

/**
 * Verify user password
 */
function verify_password($password, $hashed_password) {
    return password_verify($password, $hashed_password);
}

/**
 * Hash password
 */
function hash_password($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Logout user
 */
function logout() {
    // Unset session variables
    $_SESSION = array();
    
    // Destroy session
    session_destroy();
    
    // Delete remember token
    if (isset($_COOKIE['remember_token'])) {
        setcookie('remember_token', '', time() - 3600, '/');
    }
}