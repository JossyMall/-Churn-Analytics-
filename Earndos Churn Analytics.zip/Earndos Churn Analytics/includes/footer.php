<?php
/**
 * Footer template for Earndos Business Intelligence
 * Location: includes/footer.php
 */
?>

<footer class="footer">
    <div class="footer-content">
        <div class="copyright">
            &copy; <?php echo date("Y"); ?> Earndos Business Intelligence. All Rights Reserved.
        </div>
        <div class="logout">
            <a href="../io/auth/logout.php" class="logout-link">
                <strong><i class="fas fa-sign-out-alt"></i> Logout</strong>
            </a>
        </div>
    </div>
</footer>

<!-- Make sure Font Awesome is included in your project -->
<?php if (!isset($fontawesome_loaded)): ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js" 
        integrity="sha512-Tn2m0TIpgVyTzzvmxLNuqbSJH3JP8jm+Cy3hvHrW7ndTDcJ1w5mBiksqDBb8GpE2ksktFvDB/ykZ0mDpsZj20w==" 
        crossorigin="anonymous" 
        referrerpolicy="no-referrer"></script>
<?php endif; ?>

<style>
    .footer {
        padding: 15px 0;
        margin-top: 20px;
    }
    
    .footer-content {
        max-width: 1200px;
        margin: 0 auto;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 15px;
    }
    
    .copyright {
        color: #6c757d;
    }
    
    .logout-link {
        color: #dc3545;
        text-decoration: none;
        transition: color 0.3s;
    }
    
    .logout-link:hover {
        color: #c82333;
    }
</style>