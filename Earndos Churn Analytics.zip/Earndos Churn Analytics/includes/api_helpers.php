<?php
// includes/api_helpers.php
// This file contains all the helper functions for API operations.
// It is intended to be included by api/index.php and api/webhooks_listener.php.

// Ensure IntegrationManager is available for external API calls
require_once __DIR__ . '/external_apis/IntegrationManager.php';

// --- Helper Functions for Authentication and Authorization ---

/**
 * Fetches the user's current membership details for limits enforcement.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @return array Associative array with 'max_streams', 'max_contacts', 'allow_sms_alerts', and other membership properties.
 */
function getUserMembershipDetails(PDO $pdo, int $user_id): array {
    $default_limits = [
        'max_streams' => 1, // Default for no active membership
        'max_contacts' => 50, // Default for no active membership
        'allow_sms_alerts' => 0 // Default for no active membership
    ];

    try {
        $stmt = $pdo->prepare("
            SELECT ml.max_streams, ml.max_contacts, ml.allow_sms_alerts
            FROM user_subscriptions us
            JOIN membership_levels ml ON us.membership_id = ml.id
            WHERE us.user_id = :user_id AND us.is_active = 1 AND us.end_date > NOW()
            ORDER BY us.end_date DESC LIMIT 1
        ");
        $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        $membership = $stmt->fetch(PDO::FETCH_ASSOC);

        return $membership ?: $default_limits;
    } catch (PDOException $e) {
        error_log("getUserMembershipDetails Error: " . $e->getMessage());
        return $default_limits; // Return default limits on error
    }
}

/**
 * Verifies that a stream belongs to a specific user.
 * @param PDO $pdo The PDO database connection.
 * @param int $stream_id The ID of the stream to check.
 * @param int $user_id The ID of the user.
 * @return bool True if the stream belongs to the user, false otherwise.
 */
function verifyStreamOwnership(PDO $pdo, int $stream_id, int $user_id): bool {
    $stmt = $pdo->prepare("SELECT id FROM streams WHERE id = :stream_id AND user_id = :user_id");
    $stmt->bindValue(':stream_id', $stream_id, PDO::PARAM_INT);
    $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    return (bool)$stmt->fetch();
}

/**
 * Verifies that a contact belongs to a specific user via their stream ownership.
 * @param PDO $pdo The PDO database connection.
 * @param int $contact_id The ID of the contact to check.
 * @param int $user_id The ID of the user.
 * @return bool True if the contact belongs to the user, false otherwise.
 */
function verifyContactOwnership(PDO $pdo, int $contact_id, int $user_id): bool {
    $stmt = $pdo->prepare("SELECT c.id FROM contacts c JOIN streams s ON c.stream_id = s.id WHERE c.id = :contact_id AND s.user_id = :user_id");
    $stmt->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
    $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    return (bool)$stmt->fetch();
}

/**
 * Verifies that a cohort belongs to a specific user, and optionally to a specific stream.
 * @param PDO $pdo The PDO database connection.
 * @param int $cohort_id The ID of the cohort to check.
 * @param int $user_id The ID of the user.
 * @param int|null $stream_id Optional stream ID to further restrict ownership.
 * @return bool True if the cohort belongs to the user (and stream if specified), false otherwise.
 */
function verifyCohortOwnership(PDO $pdo, int $cohort_id, int $user_id, ?int $stream_id = null): bool {
    $query = "SELECT id FROM cohorts WHERE id = :cohort_id AND created_by = :user_id";
    $params = [':cohort_id' => $cohort_id, ':user_id' => $user_id];
    if ($stream_id !== null) {
        $query .= " AND stream_id = :stream_id";
        $params[':stream_id'] = $stream_id;
    }
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    return (bool)$stmt->fetch();
}

// --- GET Request Handlers ---

/**
 * Retrieves all streams belonging to the user.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @return array List of streams.
 */
function getStreams(PDO $pdo, int $user_id): array {
    $stmt = $pdo->prepare("SELECT id, name, website_url, is_app, description, color_code, niche_id, tracking_code, acquisition_cost, cover_image, marketing_channel, revenue_per_user, currency FROM streams WHERE user_id = :user_id");
    $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Retrieves cohorts belonging to the user, optionally filtered by stream.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int|null $stream_id Optional stream ID to filter cohorts.
 * @return array List of cohorts.
 * @throws Exception If stream_id is provided but not owned by the user.
 */
function getCohorts(PDO $pdo, int $user_id, ?int $stream_id = null): array {
    $query = "SELECT id, name, description, cost_per_user, revenue_per_user, stream_id FROM cohorts WHERE created_by = :user_id";
    $params = [':user_id' => $user_id];

    if ($stream_id !== null) {
        if (!verifyStreamOwnership($pdo, $stream_id, $user_id)) {
            throw new Exception('Stream not found or not owned by user');
        }
        $query .= " AND stream_id = :stream_id";
        $params[':stream_id'] = $stream_id;
    }
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Retrieves features for a stream owned by the user.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int $target_stream_id The ID of the stream for which to get features.
 * @param bool $is_tracking_request Indicates if the request came via tracking code (ownership already verified).
 * @return array List of features.
 * @throws Exception If stream is not found or not owned by the user.
 */
function getFeatures(PDO $pdo, int $user_id, int $target_stream_id, bool $is_tracking_request): array {
    if (!$is_tracking_request && !verifyStreamOwnership($pdo, $target_stream_id, $user_id)) {
        throw new Exception('Stream not found or not owned by user');
    }
    $stmt = $pdo->prepare("SELECT id, name, url, tags FROM features WHERE stream_id = :stream_id");
    $stmt->bindValue(':stream_id', $target_stream_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Retrieves competitors for a stream owned by the user.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int $target_stream_id The ID of the stream for which to get competitors.
 * @param bool $is_tracking_request Indicates if the request came via tracking code.
 * @return array List of competitors.
 * @throws Exception If stream is not found or not owned by the user.
 */
function getCompetitors(PDO $pdo, int $user_id, int $target_stream_id, bool $is_tracking_request): array {
    if (!$is_tracking_request && !verifyStreamOwnership($pdo, $target_stream_id, $user_id)) {
        throw new Exception('Stream not found or not owned by user');
    }
    $stmt = $pdo->prepare("SELECT id, name, url, is_pricing FROM competitors WHERE stream_id = :stream_id");
    $stmt->bindValue(':stream_id', $target_stream_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Retrieves contacts for a user, with optional filters and pagination.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int|null $stream_id Optional stream ID to filter contacts.
 * @param int|null $cohort_id Optional cohort ID to filter contacts.
 * @param string|null $search Optional search query for username/email.
 * @param int $limit Max number of records to return.
 * @param int $offset Offset for pagination.
 * @return array List of contacts.
 * @throws Exception If stream/cohort are provided but not owned by the user.
 */
function getContacts(PDO $pdo, int $user_id, ?int $stream_id = null, ?int $cohort_id = null, ?string $search = null, int $limit = 20, int $offset = 0): array {
    $query = "SELECT c.id, c.username, c.email, c.external_id, c.last_activity, c.custom_data, s.name AS stream_name
              FROM contacts c
              JOIN streams s ON c.stream_id = s.id
              WHERE s.user_id = :user_id";
    $params = [':user_id' => $user_id];

    if ($stream_id !== null) {
        if (!verifyStreamOwnership($pdo, $stream_id, $user_id)) {
            throw new Exception('Stream not found or not owned by user');
        }
        $query .= " AND c.stream_id = :stream_id";
        $params[':stream_id'] = $stream_id;
    }

    if ($cohort_id !== null) {
        if (!verifyCohortOwnership($pdo, $cohort_id, $user_id)) {
             throw new Exception('Cohort not found or not owned by user');
        }
        $query .= " AND c.id IN (SELECT contact_id FROM contact_cohorts WHERE cohort_id = :cohort_id)";
        $params[':cohort_id'] = $cohort_id;
    }

    if (!empty($search)) {
        $query .= " AND (c.username LIKE :search_username OR c.email LIKE :search_email)";
        $params[':search_username'] = '%' . $search . '%';
        $params[':search_email'] = '%' . $search . '%';
    }

    $query .= " ORDER BY c.created_at DESC LIMIT :limit OFFSET :offset";
    $params[':limit'] = (int)$limit;
    $params[':offset'] = (int)$offset;

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Retrieves all metric data for a specific contact.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int $contact_id The ID of the contact whose metrics to retrieve.
 * @return array List of metric data entries.
 * @throws Exception If contact is not found or not owned by the user.
 */
function getContactMetrics(PDO $pdo, int $user_id, int $contact_id): array {
    if (!verifyContactOwnership($pdo, $contact_id, $user_id)) {
        throw new Exception('Contact not found or not owned by user');
    }

    $stmt = $pdo->prepare("
        SELECT cm.name AS metric_name, md.value, md.recorded_at, md.source, 'predefined' as type
        FROM metric_data md
        JOIN churn_metrics cm ON md.metric_id = cm.id
        WHERE md.contact_id = :contact_id
        UNION ALL
        SELECT csm.name AS metric_name, md.value, md.recorded_at, md.source, 'custom' as type
        FROM metric_data md
        JOIN custom_metrics csm ON md.custom_metric_id = csm.id
        WHERE md.contact_id = :contact_id
        ORDER BY recorded_at DESC
    ");
    $stmt->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Retrieves churn scores for contacts, filtered by stream or individual contact.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int|null $stream_id Optional stream ID filter.
 * @param int|null $contact_id Optional contact ID filter.
 * @return array List of churn scores.
 * @throws Exception If neither stream_id nor contact_id is provided, or if not owned.
*/
function getChurnScores(PDO $pdo, int $user_id, ?int $stream_id = null, ?int $contact_id = null): array {
    $query = "SELECT c.id AS contact_id, c.username, c.email, cs.score, cs.scored_at, cs.report
              FROM contacts c
              JOIN churn_scores cs ON cs.contact_id = c.id
              WHERE c.stream_id IN (SELECT id FROM streams WHERE user_id = :user_id)";
    $params = [':user_id' => $user_id];

    if ($stream_id !== null) {
        if (!verifyStreamOwnership($pdo, $stream_id, $user_id)) {
            throw new Exception('Stream not found or not owned by user');
        }
        $query .= " AND c.stream_id = :stream_id";
        $params[':stream_id'] = $stream_id;
    } elseif ($contact_id !== null) {
        if (!verifyContactOwnership($pdo, $contact_id, $user_id)) {
            throw new Exception('Contact not found or not owned by user');
        }
        $query .= " AND c.id = :contact_id";
        $params[':contact_id'] = $contact_id;
    } else {
        throw new Exception('stream_id or contact_id parameter required');
    }
    $query .= " ORDER BY cs.scored_at DESC";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Retrieves contacts with a churn score above a given threshold.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param float $threshold The minimum churn score for a contact to be considered high-risk.
 * @param int|null $stream_id Optional stream ID to filter.
 * @return array List of high-risk contacts.
 * @throws Exception If stream_id is provided but not owned by the user.
 */
function getHighRiskContacts(PDO $pdo, int $user_id, float $threshold = 70.0, ?int $stream_id = null): array {
    $query = "SELECT c.id, c.username, c.email, cs.score, cs.scored_at
              FROM contacts c
              JOIN churn_scores cs ON cs.contact_id = c.id
              WHERE cs.score >= :threshold
              AND c.stream_id IN (SELECT id FROM streams WHERE user_id = :user_id)";
    $params = [':threshold' => $threshold, ':user_id' => $user_id];

    if ($stream_id !== null) {
        if (!verifyStreamOwnership($pdo, $stream_id, $user_id)) {
            throw new Exception('Stream not found or not owned by user');
        }
        $query .= " AND c.stream_id = :stream_id";
        $params[':stream_id'] = $stream_id;
    }
    $query .= " ORDER BY cs.score DESC";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Retrieves contacts marked as churned for the user.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int|null $stream_id Optional stream ID to filter.
 * @param int $days Optional number of days to look back for churned_at date.
 * @return array List of churned contacts.
 * @throws Exception If stream_id is provided but not owned by the user.
 */
function getChurnedUsers(PDO $pdo, int $user_id, ?int $stream_id = null, int $days = 0): array {
    $query = "SELECT c.id, c.username, c.email, cu.churned_at, cu.reason
              FROM churned_users cu
              JOIN contacts c ON cu.contact_id = c.id
              WHERE c.stream_id IN (SELECT id FROM streams WHERE user_id = :user_id)";
    $params = [':user_id' => $user_id];

    if ($stream_id !== null) {
        if (!verifyStreamOwnership($pdo, $stream_id, $user_id)) {
            throw new Exception('Stream not found or not owned by user');
        }
        $query .= " AND c.stream_id = :stream_id";
        $params[':stream_id'] = $stream_id;
    }
    if ($days > 0) {
        $query .= " AND cu.churned_at >= DATE_SUB(NOW(), INTERVAL :days DAY)";
        $params[':days'] = $days;
    }
    $query .= " ORDER BY cu.churned_at DESC";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Retrieves contacts marked as resurrected for the user.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int|null $stream_id Optional stream ID to filter.
 * @param int $days Optional number of days to look back for resurrected_at date.
 * @return array List of resurrected contacts.
 * @throws Exception If stream_id is provided but not owned by the user.
 */
function getResurrectedUsers(PDO $pdo, int $user_id, ?int $stream_id = null, int $days = 0): array {
    $query = "SELECT c.id, c.username, c.email, ru.resurrected_at, ru.churned_at
              FROM resurrected_users ru
              JOIN contacts c ON ru.contact_id = c.id
              WHERE c.stream_id IN (SELECT id FROM streams WHERE user_id = :user_id)";
    $params = [':user_id' => $user_id];

    if ($stream_id !== null) {
        if (!verifyStreamOwnership($pdo, $stream_id, $user_id)) {
            throw new Exception('Stream not found or not owned by user');
        }
        $query .= " AND c.stream_id = :stream_id";
        $params[':stream_id'] = $stream_id;
    }
    if ($days > 0) {
        $query .= " AND ru.resurrected_at >= DATE_SUB(NOW(), INTERVAL :days DAY)";
        $params[':days'] = $days;
    }
    $query .= " ORDER BY ru.resurrected_at DESC";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Retrieves notifications for the user.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @return array List of notifications.
 */
function getNotifications(PDO $pdo, int $user_id): array {
    $stmt = $pdo->prepare("SELECT id, title, message, is_read, created_at, read_at, type FROM notifications WHERE user_id = :user_id ORDER BY created_at DESC");
    $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Retrieves the authenticated user's full profile details.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @return array Associative array of user profile data.
 */
function getUserProfile(PDO $pdo, int $user_id): array {
    // This query now selects *all* columns from `user_profiles` (`up.*`)
    // to ensure existing integration keys are fetched for display on the UI.
    $stmt = $pdo->prepare("SELECT u.username, u.email, up.* FROM users u LEFT JOIN user_profiles up ON u.id = up.user_id WHERE u.id = :user_id");
    $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $profile = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($profile) {
        unset($profile['password']); // Never expose password hash
    }
    return $profile ?: [];
}

/**
 * Retrieves the authenticated user's settings including API keys, payment methods, and tracking method.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @return array Associative array of user settings.
 */
function getUserSettings(PDO $pdo, int $user_id): array {
    $settings = [];

    // API Keys (user_api_keys table remains, as it's for our internal API key)
    $stmt = $pdo->prepare("SELECT id, api_key, created_at, last_used, tracking_method FROM user_api_keys WHERE user_id = :user_id ORDER BY created_at DESC");
    $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $settings['api_keys'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Payment Methods (remains unchanged as it's a core feature)
    $stmt = $pdo->prepare("SELECT method, paypal_email, bank_name, account_name, account_number, routing_number, usdt_wallet FROM user_payment_methods WHERE user_id = :user_id");
    $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $settings['payment_methods'] = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

    return $settings;
}

/**
 * Retrieves a list of all predefined and custom churn metrics.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user (for custom metrics).
 * @return array Associative array with 'predefined' and 'custom' metric lists.
 */
function getAvailableMetrics(PDO $pdo, int $user_id): array {
    $stmt = $pdo->query("SELECT id, name, category, description FROM churn_metrics");
    $predefined_metrics = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("SELECT id, name, description FROM custom_metrics WHERE user_id = :user_id");
    $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $custom_metrics = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return ['predefined' => $predefined_metrics, 'custom' => $custom_metrics];
}

/**
 * Fetches contacts from a specified external service using the IntegrationManager.
 * This function is now fully re-implemented to support fetching contacts from supported services.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param string $service_name The name of the external service (e.g., 'stripe', 'chargebee', 'zendesk', 'freshdesk').
 * @param array $filters Optional filters to pass to the external service's API.
 * @return array List of contacts from the external service.
 * @throws Exception If service is not supported for fetching contacts, not configured, or fetching fails.
 */
function fetchExternalServiceContactsAPI(PDO $pdo, int $user_id, string $service_name, array $filters = []): array {
    $integrationManager = new IntegrationManager($pdo);
    // The IntegrationManager's fetchExternalContacts method will handle specific client calls
    // and throw exceptions if a client does not support contact fetching (e.g., Segment, Zapier).
    return $integrationManager->fetchExternalContacts($service_name, $user_id, $filters);
}


// --- POST Request Handlers (Create/Submit) ---

/**
 * Processes incoming tracking events (page_view, feature_usage, competitor_visit, custom_event).
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the user owning the stream (from tracking code).
 * @param bool $is_tracking_request True if auth was via tracking code.
 * @param int $tracking_stream_id The stream ID from tracking code (if $is_tracking_request is true).
 * @param array $input_data The decoded JSON input payload.
 * @return array Success message.
 * @throws Exception For missing fields, invalid stream/contact IDs, or unknown event types.
 */
function processTrackingEvent(PDO $pdo, int $user_id, bool $is_tracking_request, int $tracking_stream_id, array $input_data): array {
    if (empty($input_data['event'])) {
        throw new Exception('Event type required');
    }

    $target_stream_id = $is_tracking_request ? $tracking_stream_id : ($input_data['stream_id'] ?? 0);
    if (empty($target_stream_id)) {
        throw new Exception('Stream ID required');
    }

    if (!$is_tracking_request && !verifyStreamOwnership($pdo, $target_stream_id, $user_id)) {
        throw new Exception('Invalid stream ID or not owned by user');
    }

    $contact_id = $input_data['contact_id'] ?? null;
    if ($contact_id) {
        if (!verifyContactOwnership($pdo, $contact_id, $user_id)) {
             throw new Exception('Invalid contact ID for the given user');
        }
        // Update contact's last_activity if contact_id is provided
        $stmt_update_activity = $pdo->prepare("UPDATE contacts SET last_activity = NOW() WHERE id = :contact_id");
        $stmt_update_activity->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
        $stmt_update_activity->execute();
    }

    // Determine if it's a predefined metric or custom metric
    $metric_id = null;
    $custom_metric_id = null;
    $metric_name = $input_data['event']; // Event name is typically the metric name

    // Check if it's a predefined metric
    $stmt_predefined = $pdo->prepare("SELECT id FROM churn_metrics WHERE name = :name");
    $stmt_predefined->bindValue(':name', $metric_name);
    $stmt_predefined->execute();
    $predefined_metric = $stmt_predefined->fetch(PDO::FETCH_ASSOC);

    if ($predefined_metric) {
        $metric_id = $predefined_metric['id'];
    } else {
        // Check if it's a custom metric. If not found, create it (assuming automatic creation for tracking).
        $stmt_custom = $pdo->prepare("SELECT id FROM custom_metrics WHERE name = :name AND user_id = :user_id");
        $stmt_custom->bindValue(':name', $metric_name);
        $stmt_custom->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt_custom->execute();
        $custom_metric = $stmt_custom->fetch(PDO::FETCH_ASSOC);

        if ($custom_metric) {
            $custom_metric_id = $custom_metric['id'];
        } else {
            // Create new custom metric if not found
            $stmt_create_custom = $pdo->prepare("INSERT INTO custom_metrics (user_id, name, description) VALUES (:user_id, :name, :description)");
            $stmt_create_custom->bindValue(':user_id', $user_id, PDO::PARAM_INT);
            $stmt_create_custom->bindValue(':name', $metric_name);
            $stmt_create_custom->bindValue(':description', 'Auto-created from tracking event: ' . $metric_name);
            $stmt_create_custom->execute();
            $custom_metric_id = $pdo->lastInsertId();
        }
    }

    // Insert into metric_data
    $stmt_insert = $pdo->prepare("INSERT INTO metric_data (contact_id, metric_id, custom_metric_id, value, recorded_at, source)
                                     VALUES (:contact_id, :metric_id, :custom_metric_id, :value, NOW(), 'tracking')");
    $stmt_insert->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
    $stmt_insert->bindValue(':metric_id', $metric_id, PDO::PARAM_INT);
    $stmt_insert->bindValue(':custom_metric_id', $custom_metric_id, PDO::PARAM_INT);
    $stmt_insert->bindValue(':value', $input_data['value'] ?? '');
    $stmt_insert->execute();

    return ['success' => true, 'message' => 'Tracking event recorded'];
}


/**
 * Creates a new stream.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $user_membership User's membership details for limits.
 * @param array $input_data The decoded JSON input payload.
 * @return array Success message and stream_id.
 * @throws Exception For missing required fields or exceeding membership limits.
 */
function createStream(PDO $pdo, int $user_id, array $user_membership, array $input_data): array {
    if (empty($input_data['name']) || empty($input_data['description']) || empty($input_data['color_code'])) {
        throw new Exception('Name, description, and color code are required.');
    }
    if (!isset($input_data['is_app']) && empty($input_data['website_url'])) { // If not an app, website_url is required
        throw new Exception('Website URL is required for non-app streams.');
    }

    // Check max_streams limit
    $stmt_count_streams = $pdo->prepare("SELECT COUNT(id) FROM streams WHERE user_id = :user_id");
    $stmt_count_streams->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_count_streams->execute();
    $current_streams_count = $stmt_count_streams->fetchColumn();

    if ($current_streams_count >= $user_membership['max_streams']) {
        http_response_code(402); // Payment Required
        throw new Exception('Maximum number of streams reached for your membership level.');
    }

    $tracking_code = bin2hex(random_bytes(16)); // Generate a unique 32-char hex tracking code

    $stmt = $pdo->prepare("INSERT INTO streams (user_id, name, website_url, is_app, description, color_code, niche_id, tracking_code, acquisition_cost, cover_image, marketing_channel, revenue_per_user, currency)
                               VALUES (:user_id, :name, :website_url, :is_app, :description, :color_code, :niche_id, :tracking_code, :acquisition_cost, :cover_image, :marketing_channel, :revenue_per_user, :currency)");
    $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindValue(':name', $input_data['name']);
    $stmt->bindValue(':website_url', $input_data['website_url'] ?? null);
    $stmt->bindValue(':is_app', $input_data['is_app'] ?? 0, PDO::PARAM_INT);
    $stmt->bindValue(':description', $input_data['description']);
    $stmt->bindValue(':color_code', $input_data['color_code']);
    $stmt->bindValue(':niche_id', $input_data['niche_id'] ?? null, PDO::PARAM_INT); // Assuming niche_id is passed
    $stmt->bindValue(':tracking_code', $tracking_code);
    $stmt->bindValue(':acquisition_cost', $input_data['acquisition_cost'] ?? 0.00);
    $stmt->bindValue(':cover_image', $input_data['cover_image'] ?? null);
    $stmt->bindValue(':marketing_channel', $input_data['marketing_channel'] ?? null);
    $stmt->bindValue(':revenue_per_user', $input_data['revenue_per_user'] ?? 0.00);
    $stmt->bindValue(':currency', $input_data['currency'] ?? 'USD');
    $stmt->execute();

    return ['success' => true, 'stream_id' => $pdo->lastInsertId(), 'tracking_code' => $tracking_code];
}

/**
 * Creates a new cohort.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $input_data The decoded JSON input payload.
 * @return array Success message and cohort_id.
 * @throws Exception For missing required fields or invalid stream ID.
 */
function createCohort(PDO $pdo, int $user_id, array $input_data): array {
    if (empty($input_data['stream_id']) || empty($input_data['name'])) {
        throw new Exception('Stream ID and Name are required.');
    }
    if (!verifyStreamOwnership($pdo, $input_data['stream_id'], $user_id)) {
        throw new Exception('Stream not found or not owned by user.');
    }

    $stmt = $pdo->prepare("INSERT INTO cohorts (stream_id, name, description, cost_per_user, revenue_per_user, created_by)
                               VALUES (:stream_id, :name, :description, :cost_per_user, :revenue_per_user, :created_by)");
    $stmt->bindValue(':stream_id', $input_data['stream_id'], PDO::PARAM_INT);
    $stmt->bindValue(':name', $input_data['name']);
    $stmt->bindValue(':description', $input_data['description'] ?? null);
    $stmt->bindValue(':cost_per_user', $input_data['cost_per_user'] ?? 0.00);
    $stmt->bindValue(':revenue_per_user', $input_data['revenue_per_user'] ?? 0.00);
    $stmt->bindValue(':created_by', $user_id, PDO::PARAM_INT);
    $stmt->execute();

    return ['success' => true, 'cohort_id' => $pdo->lastInsertId()];
}

/**
 * Creates a new feature.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $input_data The decoded JSON input payload.
 * @return array Success message and feature_id.
 * @throws Exception For missing required fields or invalid stream ID.
 */
function createFeature(PDO $pdo, int $user_id, array $input_data): array {
    if (empty($input_data['stream_id']) || empty($input_data['name'])) {
        throw new Exception('Stream ID and Name are required.');
    }
    if (!verifyStreamOwnership($pdo, $input_data['stream_id'], $user_id)) {
        throw new Exception('Stream not found or not owned by user.');
    }

    $stmt = $pdo->prepare("INSERT INTO features (stream_id, name, url, tags)
                               VALUES (:stream_id, :name, :url, :tags)");
    $stmt->bindValue(':stream_id', $input_data['stream_id'], PDO::PARAM_INT);
    $stmt->bindValue(':name', $input_data['name']);
    $stmt->bindValue(':url', $input_data['url'] ?? null);
    $stmt->bindValue(':tags', $input_data['tags'] ?? null); // Expect comma-separated string
    $stmt->execute();

    return ['success' => true, 'feature_id' => $pdo->lastInsertId()];
}

/**
 * Creates a new competitor.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $input_data The decoded JSON input payload.
 * @return array Success message and competitor_id.
 * @throws Exception For missing required fields or invalid stream ID.
 */
function createCompetitor(PDO $pdo, int $user_id, array $input_data): array {
    if (empty($input_data['stream_id']) || empty($input_data['name']) || empty($input_data['url'])) {
        throw new Exception('Stream ID, Name, and URL are required.');
    }
    if (!verifyStreamOwnership($pdo, $input_data['stream_id'], $user_id)) {
        throw new Exception('Stream not found or not owned by user.');
    }

    $stmt = $pdo->prepare("INSERT INTO competitors (stream_id, name, url, is_pricing)
                               VALUES (:stream_id, :name, :url, :is_pricing)");
    $stmt->bindValue(':stream_id', $input_data['stream_id'], PDO::PARAM_INT);
    $stmt->bindValue(':name', $input_data['name']);
    $stmt->bindValue(':url', $input_data['url']);
    $stmt->bindValue(':is_pricing', $input_data['is_pricing'] ?? 0, PDO::PARAM_INT);
    $stmt->execute();

    return ['success' => true, 'competitor_id' => $pdo->lastInsertId()];
}

/**
 * Creates a new contact.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $user_membership User's membership details for limits.
 * @param array $input_data The decoded JSON input payload.
 * @return array Success message and contact_id.
 * @throws Exception For missing required fields, exceeding limits, or invalid stream/cohort IDs.
 */
function createContact(PDO $pdo, int $user_id, array $user_membership, array $input_data): array {
    if (empty($input_data['stream_id']) || empty($input_data['email'])) {
        throw new Exception('Stream ID and Email are required.');
    }
    if (!verifyStreamOwnership($pdo, $input_data['stream_id'], $user_id)) {
        throw new Exception('Invalid stream ID or not owned by user.');
    }

    // Check max_contacts limit
    $stmt_count_contacts = $pdo->prepare("SELECT COUNT(c.id) FROM contacts c JOIN streams s ON c.stream_id = s.id WHERE s.user_id = :user_id");
    $stmt_count_contacts->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_count_contacts->execute();
    $current_contacts_count = $stmt_count_contacts->fetchColumn();

    if ($current_contacts_count >= $user_membership['max_contacts']) {
        http_response_code(402); // Payment Required
        throw new Exception('Maximum number of contacts reached for your membership level.');
    }

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("INSERT INTO contacts (stream_id, username, email, external_id, custom_data, created_at, last_activity)
                                     VALUES (:stream_id, :username, :email, :external_id, :custom_data, NOW(), NOW())"); // Set created_at and last_activity
        $stmt->bindValue(':stream_id', $input_data['stream_id'], PDO::PARAM_INT);
        $stmt->bindValue(':username', $input_data['username'] ?? null);
        $stmt->bindValue(':email', $input_data['email']);
        $stmt->bindValue(':external_id', $input_data['external_id'] ?? null);
        $stmt->bindValue(':custom_data', json_encode($input_data['custom_data'] ?? []));
        $stmt->execute();
        $contact_id = $pdo->lastInsertId();

        // Assign to cohorts if provided
        if (!empty($input_data['cohort_ids']) && is_array($input_data['cohort_ids'])) {
            foreach ($input_data['cohort_ids'] as $cohort_id) {
                if (verifyCohortOwnership($pdo, $cohort_id, $user_id, $input_data['stream_id'])) {
                    $stmt_assign_cohort = $pdo->prepare("INSERT IGNORE INTO contact_cohorts (contact_id, cohort_id) VALUES (:contact_id, :cohort_id)");
                    $stmt_assign_cohort->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
                    $stmt_assign_cohort->bindValue(':cohort_id', $cohort_id, PDO::PARAM_INT);
                    $stmt_assign_cohort->execute();
                } else {
                    error_log("Attempted to assign new contact " . $contact_id . " to invalid cohort " . $cohort_id . " for user " . $user_id . " (Stream ID: " . ($input_data['stream_id'] ?? 'N/A') . ")");
                }
            }
        }
        $pdo->commit();
        return ['success' => true, 'contact_id' => $contact_id];
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Submits data for a predefined or custom metric.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $input_data The decoded JSON input payload.
 * @return array Success message.
 * @throws Exception For missing fields or invalid contact ID.
 */
function submitMetricData(PDO $pdo, int $user_id, array $input_data): array {
    if (empty($input_data['contact_id']) || empty($input_data['metric_name']) || !isset($input_data['value'])) {
        throw new Exception('Missing required fields: contact_id, metric_name, value.');
    }
    if (!verifyContactOwnership($pdo, $input_data['contact_id'], $user_id)) {
        throw new Exception('Invalid contact ID or not owned by user.');
    }

    $metric_id = null;
    $custom_metric_id = null;

    // Check if it's a predefined metric
    $stmt_predefined = $pdo->prepare("SELECT id FROM churn_metrics WHERE name = :name");
    $stmt_predefined->bindValue(':name', $input_data['metric_name']);
    $stmt_predefined->execute();
    $predefined_metric = $stmt_predefined->fetch(PDO::FETCH_ASSOC);

    if ($predefined_metric) {
        $metric_id = $predefined_metric['id'];
    } else {
        // Check if it's a custom metric. If not found, create it.
        $stmt_custom = $pdo->prepare("SELECT id FROM custom_metrics WHERE name = :name AND user_id = :user_id");
        $stmt_custom->bindValue(':name', $input_data['metric_name']);
        $stmt_custom->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt_custom->execute();
        $custom_metric = $stmt_custom->fetch(PDO::FETCH_ASSOC);

        if ($custom_metric) {
            $custom_metric_id = $custom_metric['id'];
        } else {
            // Create new custom metric if not found
            $stmt_create_custom = $pdo->prepare("INSERT INTO custom_metrics (user_id, name, description) VALUES (:user_id, :name, :description)");
            $stmt_create_custom->bindValue(':user_id', $user_id, PDO::PARAM_INT);
            $stmt_create_custom->bindValue(':name', $input_data['metric_name']);
            $stmt_create_custom->bindValue(':description', 'User-submitted custom metric: ' . $input_data['metric_name']);
            $stmt_create_custom->execute();
            $custom_metric_id = $pdo->lastInsertId();
        }
    }

    // Insert into metric_data
    $stmt_insert = $pdo->prepare("INSERT INTO metric_data (contact_id, metric_id, custom_metric_id, value, recorded_at, source)
                                     VALUES (:contact_id, :metric_id, :custom_metric_id, :value, NOW(), 'api')");
    $stmt_insert->bindValue(':contact_id', $input_data['contact_id'], PDO::PARAM_INT);
    $stmt_insert->bindValue(':metric_id', $metric_id, PDO::PARAM_INT);
    $stmt_insert->bindValue(':custom_metric_id', $custom_metric_id, PDO::PARAM_INT);
    $stmt_insert->bindValue(':value', $input_data['value']);
    $stmt_insert->execute();

    return ['success' => true, 'metric_data_id' => $pdo->lastInsertId()];
}

/**
 * Marks a contact as churned.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $input_data The decoded JSON input payload.
 * @return array Success message.
 * @throws Exception For missing contact ID or invalid contact.
 */
function markContactChurned(PDO $pdo, int $user_id, array $input_data): array {
    if (empty($input_data['contact_id'])) {
        throw new Exception('Missing contact ID.');
    }
    if (!verifyContactOwnership($pdo, $input_data['contact_id'], $user_id)) {
        throw new Exception('Invalid contact ID or not owned by user.');
    }

    $stmt = $pdo->prepare("INSERT INTO churned_users (contact_id, reason)
                                     VALUES (:contact_id, :reason)
                                     ON DUPLICATE KEY UPDATE reason = :reason_update, churned_at = NOW()"); // Update churned_at on re-churn
    $stmt->bindValue(':contact_id', $input_data['contact_id'], PDO::PARAM_INT);
    $stmt->bindValue(':reason', $input_data['reason'] ?? null);
    $stmt->bindValue(':reason_update', $input_data['reason'] ?? null);
    $stmt->execute();

    return ['success' => true, 'message' => 'Contact marked as churned.'];
}

/**
 * Marks a contact as resurrected (removed from churned_users, added to resurrected_users).
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $input_data The decoded JSON input payload.
 * @return array Success message.
 * @throws Exception For missing contact ID, invalid contact, or if contact was not previously churned.
 */
function markContactResurrected(PDO $pdo, int $user_id, array $input_data): array {
    if (empty($input_data['contact_id'])) {
        throw new Exception('Missing contact ID.');
    }
    if (!verifyContactOwnership($pdo, $input_data['contact_id'], $user_id)) {
        throw new Exception('Invalid contact ID or not owned by user.');
    }

    $pdo->beginTransaction();
    try {
        // Get churned_at from churned_users before deleting, to insert into resurrected_users
        $stmt_churned_at = $pdo->prepare("SELECT churned_at FROM churned_users WHERE contact_id = :contact_id");
        $stmt_churned_at->bindValue(':contact_id', $input_data['contact_id'], PDO::PARAM_INT);
        $stmt_churned_at->execute();
        $churned_record = $stmt_churned_at->fetch(PDO::FETCH_ASSOC);

        if (!$churned_record) {
            throw new Exception('Contact was not previously marked as churned.');
        }

        // Insert into resurrected_users (handle ON DUPLICATE KEY UPDATE in case they resurrect multiple times)
        $stmt_resurrect = $pdo->prepare("INSERT INTO resurrected_users (contact_id, churned_at, resurrected_at)
                                                 VALUES (:contact_id, :churned_at, NOW())
                                                 ON DUPLICATE KEY UPDATE resurrected_at = NOW(), churned_at = :churned_at_update");
        $stmt_resurrect->bindValue(':contact_id', $input_data['contact_id'], PDO::PARAM_INT);
        $stmt_resurrect->bindValue(':churned_at', $churned_record['churned_at']);
        $stmt_resurrect->bindValue(':churned_at_update', $churned_record['churned_at']); // Update churned_at too, to keep it current with the 'source' churn event
        $stmt_resurrect->execute();

        // Delete from churned_users
        $stmt_delete_churned = $pdo->prepare("DELETE FROM churned_users WHERE contact_id = :contact_id");
        $stmt_delete_churned->bindValue(':contact_id', $input_data['contact_id'], PDO::PARAM_INT);
        $stmt_delete_churned->execute();

        $pdo->commit();
        return ['success' => true, 'message' => 'Contact marked as resurrected.'];
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Calculates churn score for a single contact (API callable, e.g., for testing or manual trigger).
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $input_data The decoded JSON input payload (must contain 'contact_id').
 * @return array Result of the churn score calculation.
 * @throws Exception If contact is invalid or no metrics found.
 */
function calculateChurnScoreAPI(PDO $pdo, int $user_id, array $input_data): array {
    if (empty($input_data['contact_id'])) {
        throw new Exception('contact_id is required.');
    }
    if (!verifyContactOwnership($pdo, $input_data['contact_id'], $user_id)) {
        throw new Exception('Invalid contact ID or not owned by user.');
    }

    // Get recent metrics for the contact
    $stmt_metrics = $pdo->prepare("
        SELECT cm.name, md.value, md.recorded_at
        FROM metric_data md
        JOIN churn_metrics cm ON md.metric_id = cm.id
        WHERE md.contact_id = :contact_id
        ORDER BY md.recorded_at DESC
        LIMIT 50
    ");
    $stmt_metrics->bindValue(':contact_id', $input_data['contact_id'], PDO::PARAM_INT);
    $stmt_metrics->execute();
    $metrics = $stmt_metrics->fetchAll(PDO::FETCH_ASSOC);

    if (empty($metrics)) {
        throw new Exception('No metrics found for this contact to calculate churn score.');
    }

    // Placeholder for AI model selection (from config table)
    $stmt_ai_config = $pdo->query("SELECT value FROM config WHERE setting = 'ai_model_for_churn_scoring'");
    $ai_model_name = $stmt_ai_config->fetchColumn() ?: 'gemini-2.0-flash';

    // Call the internal churn score/report generation functions
    $score = calculateChurnScore($metrics); // Defined below
    $report_json = generateChurnReport($metrics, $score); // Defined below

    // Store the score
    $stmt_store_score = $pdo->prepare("
        INSERT INTO churn_scores (contact_id, score, report, model_used)
        VALUES (:contact_id, :score, :report, :model_used)
        ON DUPLICATE KEY UPDATE
            score = :score_update, report = :report_update, model_used = :model_used_update, scored_at = NOW()
    ");
    $stmt_store_score->bindValue(':contact_id', $input_data['contact_id'], PDO::PARAM_INT);
    $stmt_store_score->bindValue(':score', $score);
    $stmt_store_score->bindValue(':report', $report_json);
    $stmt_store_score->bindValue(':model_used', $ai_model_name);
    $stmt_store_score->bindValue(':score_update', $score);
    $stmt_store_score->bindValue(':report_update', $report_json);
    $stmt_store_score->bindValue(':model_used_update', $ai_model_name);
    $stmt_store_score->execute();

    return [
        'success' => true,
        'contact_id' => $input_data['contact_id'],
        'score' => $score,
        'report' => json_decode($report_json, true),
        'model_used' => $ai_model_name
    ];
}

/**
 * Calculates churn scores for multiple contacts within a stream (for cron jobs or batch API triggers).
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $input_data The decoded JSON input payload (must contain 'stream_id').
 * @return array Summary of processed contacts.
 * @throws Exception If stream is invalid or not owned by user.
 */
function calculateBatchChurnScoresAPI(PDO $pdo, int $user_id, array $input_data): array {
    if (empty($input_data['stream_id'])) {
        throw new Exception('stream_id is required.');
    }
    if (!verifyStreamOwnership($pdo, $input_data['stream_id'], $user_id)) {
        throw new Exception('Invalid stream ID or not owned by user.');
    }

    // Get contacts that need scoring (those with no score, or old score, or new metrics since last score)
    $stmt_contacts_to_score = $pdo->prepare("
        SELECT c.id AS contact_id
        FROM contacts c
        LEFT JOIN churn_scores cs ON cs.contact_id = c.id
        WHERE c.stream_id = :stream_id
        AND (
            cs.contact_id IS NULL OR
            cs.scored_at < DATE_SUB(NOW(), INTERVAL 7 DAY) OR -- Score older than 7 days
            EXISTS (
                SELECT 1 FROM metric_data md
                WHERE md.contact_id = c.id
                AND md.recorded_at > COALESCE(cs.scored_at, '1970-01-01 00:00:00') -- New metrics since last score
            )
        )
        LIMIT 100 -- Process in batches
    ");
    $stmt_contacts_to_score->bindValue(':stream_id', $input_data['stream_id'], PDO::PARAM_INT);
    $stmt_contacts_to_score->execute();
    $contacts_to_score = $stmt_contacts_to_score->fetchAll(PDO::FETCH_COLUMN);

    $results = [];
    $ai_model_name = $pdo->query("SELECT value FROM config WHERE setting = 'ai_model_for_churn_scoring'")->fetchColumn() ?: 'gemini-2.0-flash';

    foreach ($contacts_to_score as $contact_id) {
        try {
            // Get recent metrics for current contact
            $stmt_metrics = $pdo->prepare("
                SELECT cm.name, md.value, md.recorded_at
                FROM metric_data md
                JOIN churn_metrics cm ON md.metric_id = cm.id
                WHERE md.contact_id = :contact_id
                ORDER BY md.recorded_at DESC
                LIMIT 50
            ");
            $stmt_metrics->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
            $stmt_metrics->execute();
            $metrics = $stmt_metrics->fetchAll(PDO::FETCH_ASSOC);

            if (empty($metrics)) {
                $results[] = ['contact_id' => $contact_id, 'status' => 'skipped', 'reason' => 'No metrics found'];
                continue;
            }

            // Calculate score and report (placeholder for AI call)
            $score = calculateChurnScore($metrics);
            $report_json = generateChurnReport($metrics, $score);

            // Store the score
            $stmt_store_score = $pdo->prepare("
                INSERT INTO churn_scores (contact_id, score, report, model_used)
                VALUES (:contact_id, :score, :report, :model_used)
                ON DUPLICATE KEY UPDATE
                    score = :score_update, report = :report_update, model_used = :model_used_update, scored_at = NOW()
            ");
            $stmt_store_score->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
            $stmt_store_score->bindValue(':score', $score);
            $stmt_store_score->bindValue(':report', $report_json);
            $stmt_store_score->bindValue(':model_used', $ai_model_name);
            $stmt_store_score->bindValue(':score_update', $score);
            $stmt_store_score->bindValue(':report_update', $report_json);
            $stmt_store_score->bindValue(':model_used_update', $ai_model_name);
            $stmt_store_score->execute();

            $results[] = [
                'contact_id' => $contact_id,
                'score' => $score,
                'status' => 'success'
            ];
        } catch (Exception $e) {
            $results[] = ['contact_id' => $contact_id, 'status' => 'failed', 'reason' => $e->getMessage()];
            error_log("Batch churn calculation for contact " . $contact_id . " failed: " . $e->getMessage());
        }
    }

    return [
        'success' => true,
        'processed_contacts' => count($results),
        'results' => $results
    ];
}

/**
 * Generates and stores win-back suggestions for a contact.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $input_data The decoded JSON input payload (must contain 'contact_id').
 * @return array List of generated suggestions.
 * @throws Exception If contact is invalid or no churn score found.
 */
function generateWinbackSuggestionsAPI(PDO $pdo, int $user_id, array $input_data): array {
    if (empty($input_data['contact_id'])) {
        throw new Exception('contact_id is required.');
    }
    if (!verifyContactOwnership($pdo, $input_data['contact_id'], $user_id)) {
        throw new Exception('Invalid contact ID or not owned by user.');
    }

    $stmt_score = $pdo->prepare("SELECT score, report FROM churn_scores WHERE contact_id = :contact_id ORDER BY scored_at DESC LIMIT 1");
    $stmt_score->bindValue(':contact_id', $input_data['contact_id'], PDO::PARAM_INT);
    $stmt_score->execute();
    $score_data = $stmt_score->fetch(PDO::FETCH_ASSOC);

    if (!$score_data) {
        throw new Exception('No churn score found for this contact.');
    }

    $stmt_metrics = $pdo->prepare("
        SELECT cm.name, md.value, md.recorded_at
        FROM metric_data md
        JOIN churn_metrics cm ON md.metric_id = cm.id
        WHERE md.contact_id = :contact_id
        ORDER BY md.recorded_at DESC
    ");
    $stmt_metrics->bindValue(':contact_id', $input_data['contact_id'], PDO::PARAM_INT);
    $stmt_metrics->execute();
    $metrics = $stmt_metrics->fetchAll(PDO::FETCH_ASSOC);

    $suggestions = generateWinbackSuggestions($score_data['score'], $metrics); // Placeholder function

    $pdo->beginTransaction();
    try {
        $stmt_delete = $pdo->prepare("DELETE FROM winback_suggestions WHERE contact_id = :contact_id");
        $stmt_delete->bindValue(':contact_id', $input_data['contact_id'], PDO::PARAM_INT);
        $stmt_delete->execute();

        $stmt_insert = $pdo->prepare("INSERT INTO winback_suggestions (contact_id, suggestion) VALUES (:contact_id, :suggestion)");
        $stmt_insert->bindValue(':contact_id', $input_data['contact_id'], PDO::PARAM_INT);
        foreach ($suggestions as $suggestion) {
            $stmt_insert->bindValue(':suggestion', $suggestion);
            $stmt_insert->execute();
        }

        $pdo->commit();
        return ['success' => true, 'suggestions' => $suggestions];
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Handles the OAuth authorization request by generating the provider's authorization URL.
 * Re-introduced to support OAuth services like Mautic/Hubspot/Salesforce.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $input_data The decoded JSON input payload (service, redirect_uri, client_id, client_secret).
 * @return array Success status and authorization URL or error.
 * @throws Exception For unsupported service or missing parameters.
 */
function handleOAuthAuthorizeRequest(PDO $pdo, int $user_id, array $input_data): array {
    if (empty($input_data['service']) || empty($input_data['redirect_uri'])) {
        throw new Exception('Service and redirect_uri are required for OAuth authorization.');
    }

    $service = $input_data['service'];
    $redirectUri = $input_data['redirect_uri'];
    $clientId = $input_data['client_id'] ?? null; // For Mautic/HubSpot/Salesforce static client_id
    $clientSecret = $input_data['client_secret'] ?? null; // For Mautic/HubSpot/Salesforce static client_secret
    $baseUrl = $input_data['base_url'] ?? null; // For Mautic base URL or Salesforce instance URL for authorization

    // Generate a unique state token for CSRF protection
    $state = bin2hex(random_bytes(16));
    // Store the state token in the user's session or database associated with the user_id
    $_SESSION['oauth_state_' . $service] = $state;

    try {
        $integrationManager = new IntegrationManager($pdo);
        // We temporarily save the client_id, client_secret, and base_url.
        // These are application-level credentials for the OAuth process, not user tokens.
        // They should be stored in the metadata column for the user's specific service entry.
        $integrationManager->updateServiceConfig($user_id, $service, [
            'auth_type' => 'oauth', // Mark as OAuth type
            'metadata' => [
                'client_id' => $clientId,
                'client_secret' => $clientSecret,
            ],
            'base_url' => $baseUrl // Can also save base_url here if it's the consistent API entry point
        ]);
        
        $result = $integrationManager->getAuthorizationUrl($service, $user_id, $redirectUri, $state);

        if ($result['success']) {
            return $result;
        } else {
            throw new Exception("Failed to get authorization URL: " . ($result['error'] ?? 'Unknown error'));
        }
    } catch (Exception $e) {
        error_log("OAuth Authorization Error (User ID: {$user_id}, Service: {$service}): " . $e->getMessage());
        throw $e;
    }
}

/**
 * Handles the OAuth token exchange (callback from provider).
 * Re-introduced to support OAuth services like Mautic/Hubspot/Salesforce.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $input_data The decoded JSON input payload (service, code, redirect_uri, state).
 * @return array Success status and message.
 * @throws Exception For invalid state, missing parameters, or token exchange failure.
 */
function handleOAuthTokenExchange(PDO $pdo, int $user_id, array $input_data): array {
    if (empty($input_data['service']) || empty($input_data['code']) || empty($input_data['redirect_uri'])) {
        throw new Exception('Service, code, and redirect_uri are required for OAuth token exchange.');
    }
    
    $service = $input_data['service'];
    $code = $input_data['code'];
    $redirectUri = $input_data['redirect_uri'];
    $receivedState = $input_data['state'] ?? null;

    // Verify state for CSRF protection
    $expectedState = $_SESSION['oauth_state_' . $service] ?? null;
    unset($_SESSION['oauth_state_' . $service]); // Consume the state token

    if (empty($receivedState) || $receivedState !== $expectedState) {
        error_log("CSRF Warning: Mismatched OAuth state for user $user_id and service $service. Received: " . ($receivedState ?? 'null') . ", Expected: " . ($expectedState ?? 'null'));
        throw new Exception('Invalid or missing OAuth state. Possible CSRF attack or session expired.');
    }

    try {
        $integrationManager = new IntegrationManager($pdo);
        $result = $integrationManager->exchangeCodeForTokens($service, $user_id, $code, $redirectUri);

        if ($result['success']) {
            return $result;
        } else {
            throw new Exception("Token exchange failed: " . ($result['error'] ?? 'Unknown error'));
        }
    } catch (Exception $e) {
        error_log("OAuth Token Exchange Error (User ID: {$user_id}, Service: {$service}): " . $e->getMessage());
        throw $e;
    }
}


// --- PUT Request Handlers (Update) ---

/**
 * Updates an existing contact's details and/or cohort assignments.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int $contact_id The ID of the contact to update.
 * @param array $input_data The decoded JSON input payload.
 * @return array Success message.
 * @throws Exception For invalid contact ID, email conflicts, or missing fields.
 */
function updateContact(PDO $pdo, int $user_id, int $contact_id, array $input_data): array {
    if (empty($contact_id)) {
        throw new Exception('Contact ID is required.');
    }
    if (!verifyContactOwnership($pdo, $contact_id, $user_id)) {
        throw new Exception('Invalid contact ID or not owned by user.');
    }

    $stmt_get_contact_stream = $pdo->prepare("SELECT stream_id FROM contacts WHERE id = :contact_id");
    $stmt_get_contact_stream->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
    $stmt_get_contact_stream->execute();
    $stream_id_of_contact = $stmt_get_contact_stream->fetchColumn();


    $pdo->beginTransaction();
    try {
        $updates = [];
        $params = [':contact_id' => $contact_id];

        if (isset($input_data['username'])) {
            $updates[] = 'username = :username';
            $params[':username'] = $input_data['username'];
        }
        if (isset($input_data['email'])) {
            // Check if email is being changed to an existing one within the same stream
            $stmt = $pdo->prepare("SELECT id FROM contacts WHERE email = :email AND stream_id = :stream_id AND id != :contact_id");
            $stmt->bindValue(':email', $input_data['email']);
            $stmt->bindValue(':stream_id', $stream_id_of_contact, PDO::PARAM_INT);
            $stmt->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
            $stmt->execute();
            if ($stmt->fetch()) {
                throw new Exception('Another contact with this email already exists in the stream.');
            }
            $updates[] = 'email = :email';
            $params[':email'] = $input_data['email'];
        }
        if (isset($input_data['external_id'])) {
            $updates[] = 'external_id = :external_id';
            $params[':external_id'] = $input_data['external_id'];
        }
        if (isset($input_data['custom_data'])) {
            $updates[] = 'custom_data = :custom_data';
            $params[':custom_data'] = json_encode($input_data['custom_data']);
        }

        // Only perform the UPDATE query if there are actual fields to update on the contacts table itself
        if (!empty($updates)) {
            $query = "UPDATE contacts SET " . implode(', ', $updates) . " WHERE id = :contact_id";
            $stmt = $pdo->prepare($query);
            $stmt->execute($params);
        }

        // Update individual custom fields if provided (replaces existing entries or inserts new)
        if (isset($input_data['update_custom_fields']) && is_array($input_data['update_custom_fields'])) {
             foreach ($input_data['update_custom_fields'] as $field_name => $field_value) {
                 // Upsert logic: attempt to update, if no rows affected, then insert
                 $stmt_upsert = $pdo->prepare("
                     INSERT INTO contact_custom_fields (contact_id, field_name, field_value)
                     VALUES (:contact_id, :field_name, :field_value)
                     ON DUPLICATE KEY UPDATE field_value = VALUES(field_value)
                 ");
                 $stmt_upsert->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
                 $stmt_upsert->bindValue(':field_name', $field_name);
                 $stmt_upsert->bindValue(':field_value', $field_value);
                 $stmt_upsert->execute();
             }
        }
        // Handle deletion of custom fields if requested (e.g., delete_custom_fields: ['old_field'])
        if (isset($input_data['delete_custom_fields']) && is_array($input_data['delete_custom_fields'])) {
            $placeholders = implode(',', array_fill(0, count($input_data['delete_custom_fields']), '?'));
            $stmt_delete_fields = $pdo->prepare("DELETE FROM contact_custom_fields WHERE contact_id = ? AND field_name IN ($placeholders)");
            $stmt_delete_fields->execute(array_merge([$contact_id], $input_data['delete_custom_fields']));
        }


        // Handle cohort additions/removals
        if (isset($input_data['add_to_cohorts']) && is_array($input_data['add_to_cohorts'])) {
            foreach ($input_data['add_to_cohorts'] as $cohort_id) {
                if (verifyCohortOwnership($pdo, $cohort_id, $user_id, $stream_id_of_contact)) {
                    $stmt_add_cohort = $pdo->prepare("INSERT IGNORE INTO contact_cohorts (contact_id, cohort_id) VALUES (:contact_id, :cohort_id)");
                    $stmt_add_cohort->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
                    $stmt_add_cohort->bindValue(':cohort_id', $cohort_id, PDO::PARAM_INT);
                    $stmt_add_cohort->execute();
                } else {
                    error_log("Attempted to add contact " . $contact_id . " to invalid cohort " . $cohort_id . " for user " . $user_id . " (Stream ID: " . ($input_data['stream_id'] ?? 'N/A') . ")");
                }
            }
        }
        if (isset($input_data['remove_from_cohorts']) && is_array($input_data['remove_from_cohorts'])) {
            foreach ($input_data['remove_from_cohorts'] as $cohort_id) {
                if (verifyCohortOwnership($pdo, $cohort_id, $user_id, $stream_id_of_contact)) {
                    $stmt_remove_cohort = $pdo->prepare("DELETE FROM contact_cohorts WHERE contact_id = :contact_id AND cohort_id = :cohort_id");
                    $stmt_remove_cohort->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
                    $stmt_remove_cohort->bindValue(':cohort_id', $cohort_id, PDO::PARAM_INT);
                    $stmt_remove_cohort->execute();
                } else {
                    error_log("Attempted to remove contact " . $contact_id . " from invalid cohort " . $cohort_id . " for user " . $user_id . " (Stream ID: " . ($stream_id_of_contact ?? 'N/A') . ")");
                }
            }
        }
        $pdo->commit();
        return ['success' => true, 'message' => 'Contact updated.'];
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Updates the authenticated user's profile details.
 * This function will continue to manage ALL fields from `user_profiles` including existing integration keys.
 * Data for these keys will be displayed if present and saved if changed.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $input_data The decoded JSON input payload.
 * @return array Success message.
 * @throws Exception For no fields to update.
 */
function updateUserProfile(PDO $pdo, int $user_id, array $input_data): array {
    // These are the fields existing in user_profiles. Keep them all for now to avoid data loss.
    // The UI (external_integrations.php) will decide which ones to show.
    $profile_fields_to_update = [
        'profile_pic', 'company_name', 'industry', 'company_size', 'company_info', 'full_name',
        'alert_is_email', 'alert_is_sms', 'phone_number',
        'webhook_type', 'webhook_url', // General webhooks (e.g., Slack/Teams/Discord)
        'stripe_key', 'chargebee_key', 'segment_key', 'zendesk_key', 'freshdesk_key',
        'zapier_webhook', // Older Zapier field if it exists
        'webhook_slack', 'webhook_teams', 'webhook_discord' // Specific webhook URLs for notification types
    ];

    $set_clauses = [];
    $bind_params = [];

    foreach ($profile_fields_to_update as $field) {
        if (isset($input_data[$field])) {
            $set_clauses[] = "$field = :$field";
            // Handle boolean fields explicitly as integers
            if (in_array($field, ['alert_is_email', 'alert_is_sms'])) {
                $bind_params[":$field"] = (int)$input_data[$field];
            } else {
                $bind_params[":$field"] = $input_data[$field];
            }
        }
    }

    if (empty($set_clauses)) {
        throw new Exception('No profile fields provided for update.');
    }

    $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM user_profiles WHERE user_id = :user_id");
    $stmt_check->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_check->execute();
    $profile_exists = $stmt_check->fetchColumn();

    $bind_params[':user_id'] = $user_id; // Add user_id to bind params for the query itself

    if ($profile_exists) {
        $query = "UPDATE user_profiles SET " . implode(', ', $set_clauses) . " WHERE user_id = :user_id";
        $stmt = $pdo->prepare($query);
    } else {
        // For INSERT, we need to carefully construct column names and placeholders.
        // Ensure that only columns for which data is available in $bind_params (and user_id) are included.
        $insert_col_names = ['user_id'];
        $insert_placeholders = [':user_id'];
        foreach ($bind_params as $param_name => $param_value) {
            if ($param_name !== ':user_id') {
                $insert_col_names[] = ltrim($param_name, ':');
                $insert_placeholders[] = $param_name;
            }
        }
        $query = "INSERT INTO user_profiles (" . implode(', ', $insert_col_names) . ") VALUES (" . implode(', ', $insert_placeholders) . ")";
        $stmt = $pdo->prepare($query);
    }
    
    foreach ($bind_params as $param_name => $param_value) {
        $type = PDO::PARAM_STR;
        if (in_array(ltrim($param_name, ':'), ['alert_is_email', 'alert_is_sms']) || $param_name === ':user_id') {
            $type = PDO::PARAM_INT;
        }
        $stmt->bindValue($param_name, $param_value, $type);
    }

    $stmt->execute();
    return ['success' => true, 'message' => 'Profile updated.'];
}

/**
 * Updates the authenticated user's settings (API keys, tracking method, payment method details).
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param array $input_data The decoded JSON input payload.
 * @return array Success message.
 * @throws Exception For invalid tracking method or payment method type.
 */
function updateUserSettings(PDO $pdo, int $user_id, array $input_data): array {
    // Handle tracking_method update (assuming stored in user_api_keys for current key)
    if (isset($input_data['tracking_method'])) {
        if (!in_array($input_data['tracking_method'], ['gdpr', 'non_gdpr', 'hybrid'])) {
            throw new Exception('Invalid tracking method. Must be gdpr, non_gdpr, or hybrid.');
        }
        $stmt = $pdo->prepare("UPDATE user_api_keys SET tracking_method = :tracking_method WHERE user_id = :user_id");
        $stmt->bindValue(':tracking_method', $input_data['tracking_method']);
        $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
    }

    // Handle payment_method update
    if (isset($input_data['payment_method']) && is_array($input_data['payment_method'])) {
        $method_type = $input_data['payment_method']['method'] ?? '';
        if (!in_array($method_type, ['paypal', 'bank', 'usdt'])) {
            throw new Exception('Invalid payment method type.');
        }

        $paypal_email = $input_data['payment_method']['paypal_email'] ?? null;
        $bank_name = $input_data['payment_method']['bank_name'] ?? null;
        $account_name = $input_data['payment_method']['account_name'] ?? null;
        $account_number = $input_data['payment_method']['account_number'] ?? null;
        $routing_number = $input_data['payment_method']['routing_number'] ?? null;
        $usdt_wallet = $input_data['payment_method']['usdt_wallet'] ?? null;

        $stmt_check_payment = $pdo->prepare("SELECT COUNT(*) FROM user_payment_methods WHERE user_id = :user_id");
        $stmt_check_payment->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt_check_payment->execute();
        $payment_method_exists = $stmt_check_payment->fetchColumn();

        if ($payment_method_exists) {
            $stmt = $pdo->prepare("
                UPDATE user_payment_methods SET
                    method = :method,
                    paypal_email = :paypal_email,
                    bank_name = :bank_name,
                    account_name = :account_name,
                    account_number = :account_number,
                    routing_number = :routing_number,
                    usdt_wallet = :usdt_wallet
                WHERE user_id = :user_id
            ");
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO user_payment_methods (user_id, method, paypal_email, bank_name, account_name, account_number, routing_number, usdt_wallet)
                VALUES (:user_id, :method, :paypal_email, :bank_name, :account_name, :account_number, :routing_number, :usdt_wallet)
            ");
            $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        }

        $stmt->bindValue(':method', $method_type);
        $stmt->bindValue(':paypal_email', $paypal_email);
        $stmt->bindValue(':bank_name', $bank_name);
        $stmt->bindValue(':account_name', $account_name);
        $stmt->bindValue(':account_number', $account_number);
        $stmt->bindValue(':routing_number', $routing_number);
        $stmt->bindValue(':usdt_wallet', $usdt_wallet);
        $stmt->execute();
    }

    return ['success' => true, 'message' => 'Settings updated.'];
}

/**
 * Marks a notification as read.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int $notification_id The ID of the notification to mark as read.
 * @return array Success message.
 * @throws Exception If notification is not found or not owned by the user.
 */
function markNotificationAsRead(PDO $pdo, int $user_id, int $notification_id): array {
    if (empty($notification_id)) {
        throw new Exception('Notification ID is required.');
    }
    // Verify notification belongs to user
    $stmt_check = $pdo->prepare("SELECT id FROM notifications WHERE id = :notification_id AND user_id = :user_id");
    $stmt_check->bindValue(':notification_id', $notification_id, PDO::PARAM_INT);
    $stmt_check->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_check->execute();
    if (!$stmt_check->fetch()) {
        throw new Exception('Notification not found or not owned by user.');
    }

    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1, read_at = NOW() WHERE id = :id");
    $stmt->bindValue(':id', $notification_id, PDO::PARAM_INT);
    $stmt->execute();
    return ['success' => true, 'message' => 'Notification marked as read.'];
}


// --- DELETE Request Handlers ---

/**
 * Deletes a contact and all related data.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int $contact_id The ID of the contact to delete.
 * @return array Success message.
 * @throws Exception For invalid contact ID or if not owned by the user.
 */
function deleteContact(PDO $pdo, int $user_id, int $contact_id): array {
    if (empty($contact_id)) {
        throw new Exception('Contact ID is required.');
    }
    if (!verifyContactOwnership($pdo, $contact_id, $user_id)) {
        throw new Exception('Contact not found or not owned by user.');
    }

    $pdo->beginTransaction();
    try {
        // Delete related data first for referential integrity
        $stmt_delete_fields = $pdo->prepare("DELETE FROM contact_custom_fields WHERE contact_id = :contact_id");
        $stmt_delete_fields->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
        $stmt_delete_fields->execute();

        $stmt_delete_cohorts = $pdo->prepare("DELETE FROM contact_cohorts WHERE contact_id = :contact_id");
        $stmt_delete_cohorts->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
        $stmt_delete_cohorts->execute();

        $stmt_delete_metrics = $pdo->prepare("DELETE FROM metric_data WHERE contact_id = :contact_id");
        $stmt_delete_metrics->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
        $stmt_delete_metrics->execute();

        $stmt_delete_scores = $pdo->prepare("DELETE FROM churn_scores WHERE contact_id = :contact_id");
        $stmt_delete_scores->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
        $stmt_delete_scores->execute();

        $stmt_delete_churned = $pdo->prepare("DELETE FROM churned_users WHERE contact_id = :contact_id");
        $stmt_delete_churned->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
        $stmt_delete_churned->execute();

        $stmt_delete_resurrected = $pdo->prepare("DELETE FROM resurrected_users WHERE contact_id = :contact_id");
        $stmt_delete_resurrected->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
        $stmt_delete_resurrected->execute();

        $stmt_delete_suggestions = $pdo->prepare("DELETE FROM winback_suggestions WHERE contact_id = :contact_id");
        $stmt_delete_suggestions->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
        $stmt_delete_suggestions->execute();

        // Finally delete the contact
        $stmt_delete_contact = $pdo->prepare("DELETE FROM contacts WHERE id = :contact_id");
        $stmt_delete_contact->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
        $stmt_delete_contact->execute();

        $pdo->commit();
        return ['success' => true, 'message' => 'Contact and all related data deleted.'];
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Deletes a stream and all its associated data (contacts, features, competitors, cohorts tied to stream).
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int $stream_id The ID of the stream to delete.
 * @return array Success message.
 * @throws Exception For invalid stream ID or if not owned by the user.
 */
function deleteStream(PDO $pdo, int $user_id, int $stream_id): array {
    if (empty($stream_id)) {
        throw new Exception('Stream ID is required.');
    }
    if (!verifyStreamOwnership($pdo, $stream_id, $user_id)) {
        throw new Exception('Stream not found or not owned by user.');
    }

    $pdo->beginTransaction();
    try {
        // Get all contact IDs associated with this stream for cascading deletions
        $stmt_get_contact_ids = $pdo->prepare("SELECT id FROM contacts WHERE stream_id = :stream_id");
        $stmt_get_contact_ids->bindValue(':stream_id', $stream_id, PDO::PARAM_INT);
        $stmt_get_contact_ids->execute();
        $contact_ids = $stmt_get_contact_ids->fetchAll(PDO::FETCH_COLUMN);

        foreach ($contact_ids as $contact_id) {
            deleteContact($pdo, $user_id, $contact_id);
        }

        // Delete features, competitors, and cohorts directly linked to the stream
        $stmt_del_features = $pdo->prepare("DELETE FROM features WHERE stream_id = :stream_id");
        $stmt_del_features->bindValue(':stream_id', $stream_id, PDO::PARAM_INT);
        $stmt_del_features->execute();

        $stmt_del_competitors = $pdo->prepare("DELETE FROM competitors WHERE stream_id = :stream_id");
        $stmt_del_competitors->bindValue(':stream_id', $stream_id, PDO::PARAM_INT);
        $stmt_del_competitors->execute();

        $stmt_del_cohorts = $pdo->prepare("DELETE FROM cohorts WHERE stream_id = :stream_id");
        $stmt_del_cohorts->bindValue(':stream_id', $stream_id, PDO::PARAM_INT);
        $stmt_del_cohorts->execute();

        // Finally delete the stream itself
        $stmt_del_stream = $pdo->prepare("DELETE FROM streams WHERE id = :stream_id");
        $stmt_del_stream->bindValue(':stream_id', $stream_id, PDO::PARAM_INT);
        $stmt_del_stream->execute();

        $pdo->commit();
        return ['success' => true, 'message' => 'Stream and all related data deleted.'];
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Deletes a cohort.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int $cohort_id The ID of the cohort to delete.
 * @return array Success message.
 * @throws Exception For invalid cohort ID or if not owned by the user.
 */
function deleteCohort(PDO $pdo, int $user_id, int $cohort_id): array {
    if (empty($cohort_id)) {
        throw new Exception('Cohort ID is required.');
    }
    if (!verifyCohortOwnership($pdo, $cohort_id, $user_id)) {
        throw new Exception('Cohort not found or not owned by user.');
    }

    $pdo->beginTransaction();
    try {
        // Remove contacts from this cohort first (break association)
        $stmt_remove_contacts = $pdo->prepare("DELETE FROM contact_cohorts WHERE cohort_id = :cohort_id");
        $stmt_remove_contacts->bindValue(':cohort_id', $cohort_id, PDO::PARAM_INT);
        $stmt_remove_contacts->execute();

        // Delete the cohort itself
        $stmt_del_cohort = $pdo->prepare("DELETE FROM cohorts WHERE id = :cohort_id");
        $stmt_del_cohort->bindValue(':cohort_id', $cohort_id, PDO::PARAM_INT);
        $stmt_del_cohort->execute();

        $pdo->commit();
        return ['success' => true, 'message' => 'Cohort deleted.'];
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Deletes a feature.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int $feature_id The ID of the feature to delete.
 * @return array Success message.
 * @throws Exception For invalid feature ID or if not owned by the user.
 */
function deleteFeature(PDO $pdo, int $user_id, int $feature_id): array {
    if (empty($feature_id)) {
        throw new Exception('Feature ID is required.');
    }
    // Verify feature ownership through stream
    $stmt_feature_check = $pdo->prepare("SELECT f.id FROM features f JOIN streams s ON f.stream_id = s.id WHERE f.id = :feature_id AND s.user_id = :user_id");
    $stmt_feature_check->bindValue(':feature_id', $feature_id, PDO::PARAM_INT);
    $stmt_feature_check->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_feature_check->execute();
    if (!$stmt_feature_check->fetch()) {
        throw new Exception('Feature not found or not owned by user.');
    }

    $stmt = $pdo->prepare("DELETE FROM features WHERE id = :feature_id");
    $stmt->bindValue(':feature_id', $feature_id, PDO::PARAM_INT);
    $stmt->execute();
    return ['success' => true, 'message' => 'Feature deleted.'];
}

/**
 * Deletes a competitor.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The ID of the authenticated user.
 * @param int $competitor_id The ID of the competitor to delete.
 * @return array Success message.
 * @throws Exception For invalid competitor ID or if not owned by the user.
 */
function deleteCompetitor(PDO $pdo, int $user_id, int $competitor_id): array {
    if (empty($competitor_id)) {
        throw new Exception('Competitor ID is required.');
    }
    // Verify competitor ownership through stream
    $stmt_competitor_check = $pdo->prepare("SELECT comp.id FROM competitors comp JOIN streams s ON comp.stream_id = s.id WHERE comp.id = :competitor_id AND s.user_id = :user_id");
    $stmt_competitor_check->bindValue(':competitor_id', $competitor_id, PDO::PARAM_INT);
    $stmt_competitor_check->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_competitor_check->execute();
    if (!$stmt_competitor_check->fetch()) {
        throw new Exception('Competitor not found or not owned by user.');
    }

    $stmt = $pdo->prepare("DELETE FROM competitors WHERE id = :competitor_id");
    $stmt->bindValue(':competitor_id', $competitor_id, PDO::PARAM_INT);
    $stmt->execute();
    return ['success' => true, 'message' => 'Competitor deleted.'];
}


// --- Internal AI/Churn Helper Functions (originally from api/churn.php) ---
// These are not directly exposed as API endpoints but are used by other API functions.

/**
 * Placeholder: Calculates a churn score based on provided metrics.
 * In a real application, this would integrate with an AI/ML model.
 * @param array $metrics An array of metric data for a contact.
 * @return float The calculated churn score (0-100).
 */
function calculateChurnScore(array $metrics): float {
    $score = 0;
    // Example logic based on common churn indicators
    foreach ($metrics as $metric) {
        switch ($metric['name']) {
            case 'last_login_date':
                $days_since_login = (time() - strtotime($metric['value'])) / (60 * 60 * 24);
                if ($days_since_login > 60) $score += 40; // Very high inactivity
                elseif ($days_since_login > 30) $score += 25;
                elseif ($days_since_login > 14) $score += 10;
                break;

            case 'feature_usage':
                $value = is_numeric($metric['value']) ? (float)$metric['value'] : 0;
                if ($value < 1) $score += 20; // No usage
                elseif ($value < 5) $score += 10; // Low usage
                $score -= min(15, $value * 2); // Higher usage reduces churn risk
                break;

            case 'support_tickets':
                $value = is_numeric($metric['value']) ? (int)$metric['value'] : 0;
                if ($value > 5) $score += 20; // Many tickets
                elseif ($value > 2) $score += 10; // Few tickets
                break;

            case 'payment_status':
                if ($metric['value'] === 'failed') $score += 35; // Significant impact
                break;

            case 'cancellation_date': // Direct indication of churn
                if (!empty($metric['value'])) $score = 100;
                break;
            case 'subscription_end_date': // Direct indication of churn soon or already
                if (!empty($metric['value']) && strtotime($metric['value']) < time()) $score = 90;
                break;

            case 'nps_score': // Assuming 0-10 scale, lower is worse
                $nps = is_numeric($metric['value']) ? (float)$metric['value'] : 10;
                if ($nps <= 6) $score += 20;
                elseif ($nps <= 8) $score += 5;
                break;

            case 'competitor_visit':
                $value = is_numeric($metric['value']) ? (int)$metric['value'] : 0;
                if ($value > 0) $score += 15; // Visited competitor
                break;

            // Add more cases for other relevant metrics
        }
    }

    return max(0, min(100, $score)); // Ensure score is between 0-100
}

/**
 * Placeholder: Generates a churn report based on score and metrics.
 * In a real application, this would be more sophisticated (e.g., AI-generated insights).
 * @param array $metrics An array of metric data.
 * @param float $score The calculated churn score.
 * @return string JSON-encoded report.
 */
function generateChurnReport(array $metrics, float $score): string {
    $report_details = [
        'score' => $score,
        'factors' => [],
        'summary' => ''
    ];

    if ($score >= 70) {
        $report_details['summary'] = "High risk of churn. Immediate intervention recommended.";
    } elseif ($score >= 40) {
        $report_details['summary'] = "Moderate risk of churn. Monitor engagement closely.";
    } else {
        $report_details['summary'] = "Low risk of churn. Maintain engagement.";
    }

    foreach ($metrics as $metric) {
        if ($metric['name'] === 'last_login_date') {
            $days_since_login = floor((time() - strtotime($metric['value'])) / (60 * 60 * 24));
            if ($days_since_login > 14) {
                $report_details['factors'][] = "Inactivity: User last logged in {$days_since_login} days ago.";
            }
        }
        if ($metric['name'] === 'support_tickets' && is_numeric($metric['value']) && (int)$metric['value'] > 2) {
            $report_details['factors'][] = "High Support Ticket Volume: User has opened {$metric['value']} support tickets recently.";
        }
        if ($metric['name'] === 'payment_status' && $metric['value'] === 'failed') {
            $report_details['factors'][] = "Billing Issue: Latest payment failed.";
        }
        if ($metric['name'] === 'competitor_visit' && is_numeric($metric['value']) && (int)$metric['value'] > 0) {
            $report_details['factors'][] = "Competitor Exploration: User has visited competitor sites.";
        }
    }
    return json_encode($report_details);
}

/**
 * Placeholder: Generates win-back suggestions based on churn score and metrics.
 * In a real application, this would be more sophisticated and dynamic.
 * @param float $score The calculated churn score.
 * @param array $metrics An array of metric data.
 * @return array List of unique win-back suggestions.
 */
function generateWinbackSuggestions(float $score, array $metrics): array {
    $suggestions = [];
    if ($score >= 70) {
        $suggestions[] = "Offer a personalized discount (e.g., 20% off next month's subscription).";
        $suggestions[] = "Initiate direct human outreach (e.g., call from a success manager).";
    }
    if ($score >= 40) {
        $suggestions[] = "Send an email highlighting a key feature they haven't used recently.";
        $suggestions[] = "Invite them to a free webinar or training session on advanced usage.";
    }
    // Metric-specific suggestions
    foreach ($metrics as $metric) {
        if ($metric['name'] === 'payment_status' && $metric['value'] === 'failed') {
            $suggestions[] = "Provide clear instructions and support for updating payment methods.";
        }
        if ($metric['name'] === 'support_tickets' && is_numeric($metric['value']) && (int)$metric['value'] > 2) {
            $suggestions[] = "Reach out to confirm all recent support issues are fully resolved and user is satisfied.";
        }
        if ($metric['name'] === 'competitor_visit' && is_numeric($metric['value']) && (int)$metric['value'] > 0) {
            $suggestions[] = "Emphasize unique selling propositions and competitive advantages of your product.";
        }
    }
    return array_unique(array_slice($suggestions, 0, 5)); // Ensure uniqueness and limit to top 5
}

// --- Webhook Event Processing Functions (called by api/webhooks_listener.php) ---
// These functions remain as they are crucial for receiving data from various services.

/**
 * Processes an incoming 'churn_alert' webhook event.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The user ID associated with the webhook configuration.
 * @param array $payload The decoded webhook payload.
 */
function processWebhookChurnAlert(PDO $pdo, int $user_id, array $payload): void {
    // Example: Payload might contain 'contact_email', 'stream_id', 'score', 'report'
    $contact_email = $payload['contact_email'] ?? null;
    $stream_id_from_payload = $payload['stream_id'] ?? null;
    $churn_score = $payload['score'] ?? null;
    $report_details = $payload['report'] ?? null;

    if (!$contact_email || !$stream_id_from_payload || $churn_score === null) {
        error_log("Missing data for churn_alert webhook for user $user_id. Payload: " . json_encode($payload));
        return; // Or throw a specific exception for invalid payload
    }

    // Verify stream ownership (important for multi-tenant systems)
    if (!verifyStreamOwnership($pdo, $stream_id_from_payload, $user_id)) {
        error_log("Churn alert webhook for user $user_id: Stream $stream_id_from_payload not owned. Payload: " . json_encode($payload));
        return;
    }

    // Find the contact ID from the email and stream_id
    $stmt_contact = $pdo->prepare("SELECT id FROM contacts WHERE email = :email AND stream_id = :stream_id");
    $stmt_contact->bindValue(':email', $contact_email);
    $stmt_contact->bindValue(':stream_id', $stream_id_from_payload, PDO::PARAM_INT);
    $stmt_contact->execute();
    $contact_id = $stmt_contact->fetchColumn();

    if ($contact_id) {
        // Here, you would typically:
        // 1. Update churn_scores table with the new score/report if it's external AI source
        //    (Or, if this webhook *is* the AI output, this is where you'd store the score).
        //    Assuming `api/index.php`'s churn-calculate route already handles storing, this might be redundant.
        //    Let's assume this webhook is just an alert to *log* and *notify* the user.
        // 2. Insert a notification for the user about the high-risk contact
        $stmt_notify = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type, related_id) VALUES (:user_id, :title, :message, 'churn', :contact_id)");
        $stmt_notify->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt_notify->bindValue(':title', "High Churn Risk for " . htmlspecialchars($contact_email));
        $stmt_notify->bindValue(':message', "Contact " . htmlspecialchars($contact_email) . " in stream " . $stream_id_from_payload . " has a churn score of {$churn_score}%. Report: " . json_encode($report_details));
        $stmt_notify->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
        $stmt_notify->execute();

        // 3. Potentially trigger outgoing actions (e.g., send to Slack/Teams/Discord if user configured it in profile)
        //    This would involve reading user_profiles for webhook_url.
        //    This part would likely happen via a separate background job or a dedicated notification service.
        //    For simplicity, we'll just log the notification here.

        error_log("Processed churn_alert for user $user_id, contact $contact_id.");
    } else {
        error_log("Churn alert webhook for user $user_id: Contact not found for email $contact_email in stream $stream_id_from_payload.");
    }
}

/**
 * Processes an incoming 'feature_usage' webhook event.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The user ID associated with the webhook configuration.
 * @param array $payload The decoded webhook payload.
 */
function processWebhookFeatureUsage(PDO $pdo, int $user_id, array $payload): void {
    $contact_email = $payload['contact_email'] ?? null;
    $stream_id_from_payload = $payload['stream_id'] ?? null;
    $feature_name = $payload['feature_name'] ?? null;
    $usage_value = $payload['value'] ?? 1; // Default to 1 if just a trigger

    if (!$contact_email || !$stream_id_from_payload || !$feature_name) {
        error_log("Missing data for feature_usage webhook for user $user_id. Payload: " . json_encode($payload));
        return;
    }

    if (!verifyStreamOwnership($pdo, $stream_id_from_payload, $user_id)) {
        error_log("Feature usage webhook for user $user_id: Stream $stream_id_from_payload not owned. Payload: " . json_encode($payload));
        return;
    }

    $stmt_contact = $pdo->prepare("SELECT id FROM contacts WHERE email = :email AND stream_id = :stream_id");
    $stmt_contact->bindValue(':email', $contact_email);
    $stmt_contact->bindValue(':stream_id', $stream_id_from_payload, PDO::PARAM_INT);
    $stmt_contact->execute();
    $contact_id = $stmt_contact->fetchColumn();

    if ($contact_id) {
        // Find or create the predefined 'feature_usage' metric
        $stmt_metric = $pdo->prepare("SELECT id FROM churn_metrics WHERE name = 'feature_usage'");
        $stmt_metric->execute();
        $metric_id = $stmt_metric->fetchColumn();

        if ($metric_id) {
            // Insert into metric_data for the relevant contact
            $stmt_insert = $pdo->prepare("INSERT INTO metric_data (contact_id, metric_id, value, recorded_at, source) VALUES (:contact_id, :metric_id, :value, NOW(), 'webhook')");
            $stmt_insert->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
            $stmt_insert->bindValue(':metric_id', $metric_id, PDO::PARAM_INT);
            $stmt_insert->bindValue(':value', $feature_name . ':' . $usage_value); // Store feature name and value/count
            $stmt_insert->execute();
            error_log("Processed feature_usage for user $user_id, contact $contact_id. Feature: $feature_name.");
        } else {
            error_log("Predefined 'feature_usage' metric ID not found for webhook processing.");
        }
    } else {
        error_log("Feature usage webhook for user $user_id: Contact not found for email $contact_email in stream $stream_id_from_payload.");
    }
}

/**
 * Processes an incoming 'competitor_visit' webhook event.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The user ID associated with the webhook configuration.
 * @param array $payload The decoded webhook payload.
 */
function processWebhookCompetitorVisit(PDO $pdo, int $user_id, array $payload): void {
    $contact_email = $payload['contact_email'] ?? null;
    $stream_id_from_payload = $payload['stream_id'] ?? null;
    $competitor_url = $payload['competitor_url'] ?? null;

    if (!$contact_email || !$stream_id_from_payload || !$competitor_url) {
        error_log("Missing data for competitor_visit webhook for user $user_id. Payload: " . json_encode($payload));
        return;
    }

    if (!verifyStreamOwnership($pdo, $stream_id_from_payload, $user_id)) {
        error_log("Competitor visit webhook for user $user_id: Stream $stream_id_from_payload not owned. Payload: " . json_encode($payload));
        return;
    }

    $stmt_contact = $pdo->prepare("SELECT id FROM contacts WHERE email = :email AND stream_id = :stream_id");
    $stmt_contact->bindValue(':email', $contact_email);
    $stmt_contact->bindValue(':stream_id', $stream_id_from_payload, PDO::PARAM_INT);
    $stmt_contact->execute();
    $contact_id = $stmt_contact->fetchColumn();

    if ($contact_id) {
        // Find the predefined 'competitor_visit' metric
        $stmt_metric = $pdo->prepare("SELECT id FROM churn_metrics WHERE name = 'competitor_visit'");
        $stmt_metric->execute();
        $metric_id = $stmt_metric->fetchColumn();

        if ($metric_id) {
            // Insert into metric_data
            $stmt_insert = $pdo->prepare("INSERT INTO metric_data (contact_id, metric_id, value, recorded_at, source) VALUES (:contact_id, :metric_id, :value, NOW(), 'webhook')");
            $stmt_insert->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
            $stmt_insert->bindValue(':metric_id', $metric_id, PDO::PARAM_INT);
            $stmt_insert->bindValue(':value', $competitor_url);
            $stmt_insert->execute();

            // Potentially add a notification if this is a critical alert
            $stmt_notify = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type, related_id) VALUES (:user_id, :title, :message, 'system', :contact_id)");
            $stmt_notify->bindValue(':user_id', $user_id, PDO::PARAM_INT);
            $stmt_notify->bindValue(':title', "Competitor Visit Alert for " . htmlspecialchars($contact_email));
            $stmt_notify->bindValue(':message', "Contact " . htmlspecialchars($contact_email) . " visited: " . htmlspecialchars($competitor_url));
            $stmt_notify->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
            $stmt_notify->execute();

            error_log("Processed competitor_visit for user $user_id, contact $contact_id. URL: $competitor_url.");
        } else {
            error_log("Predefined 'competitor_visit' metric ID not found for webhook processing.");
        }
    } else {
        error_log("Competitor visit webhook for user $user_id: Contact not found for email $contact_email in stream $stream_id_from_payload.");
    }
}

/**
 * Processes an incoming 'payment_failed' webhook event.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The user ID associated with the webhook configuration.
 * @param array $payload The decoded webhook payload.
 */
function processWebhookPaymentFailed(PDO $pdo, int $user_id, array $payload): void {
    $contact_email = $payload['contact_email'] ?? null;
    $stream_id_from_payload = $payload['stream_id'] ?? null; // Optional, might be direct user ID
    $transaction_id = $payload['transaction_id'] ?? null;
    $reason = $payload['reason'] ?? 'Unknown reason';

    if (!$contact_email || !$transaction_id) {
        error_log("Missing data for payment_failed webhook for user $user_id. Payload: " . json_encode($payload));
        return;
    }

    // Attempt to find contact. This webhook might not be stream-specific, but linked to a user's contact.
    $contact_id = null;
    if ($stream_id_from_payload) {
        $stmt_contact = $pdo->prepare("SELECT id FROM contacts WHERE email = :email AND stream_id = :stream_id");
        $stmt_contact->bindValue(':email', $contact_email);
        $stmt_contact->bindValue(':stream_id', $stream_id_from_payload, PDO::PARAM_INT);
        $stmt_contact->execute();
        $contact_id = $stmt_contact->fetchColumn();
        if (!$contact_id && !verifyStreamOwnership($pdo, $stream_id_from_payload, $user_id)) {
            // If stream_id is provided but not owned, or contact not found in it, log and exit
            error_log("Payment failed webhook for user $user_id: Stream $stream_id_from_payload not owned or contact not found. Payload: " . json_encode($payload));
            return;
        }
    } else {
        // Try to find the contact by email across all streams owned by the user
        $stmt_contact = $pdo->prepare("SELECT c.id FROM contacts c JOIN streams s ON c.stream_id = s.id WHERE c.email = :email AND s.user_id = :user_id");
        $stmt_contact->bindValue(':email', $contact_email);
        $stmt_contact->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt_contact->execute();
        $contact_id = $stmt_contact->fetchColumn();
    }


    if ($contact_id) {
        // Find the predefined 'payment_status' metric
        $stmt_metric = $pdo->prepare("SELECT id FROM churn_metrics WHERE name = 'payment_status'");
        $stmt_metric->execute();
        $metric_id = $stmt_metric->fetchColumn();

        if ($metric_id) {
            // Insert into metric_data (value could be 'failed' or error code)
            $stmt_insert = $pdo->prepare("INSERT INTO metric_data (contact_id, metric_id, value, recorded_at, source) VALUES (:contact_id, :metric_id, :value, NOW(), 'webhook')");
            $stmt_insert->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
            $stmt_insert->bindValue(':metric_id', $metric_id, PDO::PARAM_INT);
            $stmt_insert->bindValue(':value', 'failed:' . $reason);
            $stmt_insert->execute();

            // Add a notification for the user
            $stmt_notify = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type, related_id) VALUES (:user_id, :title, :message, 'payment', :contact_id)");
            $stmt_notify->bindValue(':user_id', $user_id, PDO::PARAM_INT);
            $stmt_notify->bindValue(':title', "Payment Failed for " . htmlspecialchars($contact_email));
            $stmt_notify->bindValue(':message', "Transaction ID: " . htmlspecialchars($transaction_id) . " failed. Reason: " . htmlspecialchars($reason));
            $stmt_notify->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
            $stmt_notify->execute();

            error_log("Processed payment_failed for user $user_id, contact $contact_id. Transaction: $transaction_id.");
        } else {
            error_log("Predefined 'payment_status' metric ID not found for webhook processing.");
        }
    } else {
        error_log("Payment failed webhook for user $user_id: Contact not found for email $contact_email.");
    }
}

/**
 * Processes a generic custom webhook event.
 * @param PDO $pdo The PDO database connection.
 * @param int $user_id The user ID associated with the webhook configuration.
 * @param array $payload The decoded webhook payload.
 * @param string $event_type The original event type from the payload.
 */
function processWebhookCustomEvent(PDO $pdo, int $user_id, array $payload, string $event_type): void {
    // This is a fallback for events not explicitly handled.
    // You might log the entire payload as a custom metric or in a generic webhook_logs table.

    $contact_email = $payload['contact_email'] ?? null;
    $contact_id = null;
    if ($contact_email) {
        $stmt_contact = $pdo->prepare("SELECT c.id FROM contacts c JOIN streams s ON c.stream_id = s.id WHERE c.email = :email AND s.user_id = :user_id");
        $stmt_contact->bindValue(':email', $contact_email);
        $stmt_contact->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt_contact->execute();
        $contact_id = $stmt_contact->fetchColumn();
    }

    // Find or create a custom metric for this event type
    $stmt_custom_metric = $pdo->prepare("SELECT id FROM custom_metrics WHERE name = :name AND user_id = :user_id");
    $stmt_custom_metric->bindValue(':name', $event_type);
    $stmt_custom_metric->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_custom_metric->execute();
    $custom_metric = $stmt_custom_metric->fetch(PDO::FETCH_ASSOC);

    $custom_metric_id = null;
    if ($custom_metric) {
        $custom_metric_id = $custom_metric['id'];
    } else {
        $stmt_create_custom = $pdo->prepare("INSERT INTO custom_metrics (user_id, name, description) VALUES (:user_id, :name, :description)");
        $stmt_create_custom->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt_create_custom->bindValue(':name', $event_type);
        $stmt_create_custom->bindValue(':description', 'Auto-created custom event metric from webhook: ' . $event_type);
        $stmt_create_custom->execute();
        $custom_metric_id = $pdo->lastInsertId();
    }

    if ($contact_id && $custom_metric_id) {
        // Insert into metric_data with the full payload as value (or a summary)
        $stmt_insert = $pdo->prepare("INSERT INTO metric_data (contact_id, custom_metric_id, value, recorded_at, source) VALUES (:contact_id, :custom_metric_id, :value, NOW(), 'webhook_custom')");
        $stmt_insert->bindValue(':contact_id', $contact_id, PDO::PARAM_INT);
        $stmt_insert->bindValue(':custom_metric_id', $custom_metric_id, PDO::PARAM_INT);
        $stmt_insert->bindValue(':value', json_encode($payload)); // Store full payload or a subset
        $stmt_insert->execute();
        error_log("Processed custom webhook event '$event_type' for user $user_id, contact $contact_id.");
    } else {
        error_log("Processed custom webhook event '$event_type' for user $user_id. No associated contact found or metric not created.");
    }
}