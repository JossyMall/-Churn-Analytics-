<?php
// includes/header.php

// Removed session_start() and require_once 'db.php';
// These should now be handled by the main script (e.g., contacts.php, dashboard.php).

// Ensure BASE_URL is defined if this header might be used independently.
// In our current setup, contacts.php includes db.php which defines it.
if (!defined('BASE_URL')) {
    define('BASE_URL', 'https://earndos.com/io');
}

// Assume $pdo is available here because the main script has included db.php
// Assume session has been started and $_SESSION['user_id'] is set by the main script.

// --- Redirect if user is NOT logged in ---
// This check now relies on the main script's session_start()
// and should ideally be handled at the very top of each main page.
// However, if a main page forgets, this acts as a fallback.
if (!isset($_SESSION['user_id']) || !isset($pdo)) { // Added check for $pdo availability
    // Store the intended URL before redirecting to login
    // Check if the current request is not already the login page to avoid infinite redirects or storing login page as intended
    if (strpos($_SERVER['REQUEST_URI'], '/auth/login.php') === false) {
        $_SESSION['intended_url'] = $_SERVER['REQUEST_URI'];
    }
    header('Location: ' . BASE_URL . '/auth/login.php'); // Redirect to the base URL's login
    exit; // Stop script execution
}
// --- End Redirect Logic ---

$is_logged_in = true; // If we reach here, the user is logged in
$user_data = [];
$profile_pic = BASE_URL . '/assets/images/user.png'; // Default profile picture
$unread_notifications_count = 0;

// Fetch user data
// This now correctly assumes $pdo is available.
$stmt = $pdo->prepare("SELECT username, email, is_admin FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user_data = $stmt->fetch(PDO::FETCH_ASSOC); // Fetch as associative array

// Get profile picture if exists
$stmt = $pdo->prepare("SELECT profile_pic FROM user_profiles WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$profile = $stmt->fetch(PDO::FETCH_ASSOC); // Fetch as associative array
// Ensure profile picture path is correctly formed relative to BASE_URL
if ($profile && !empty($profile['profile_pic'])) {
    $profile_pic = BASE_URL . '/' . ltrim($profile['profile_pic'], '/');
}

// Get unread notifications count
$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->execute([$_SESSION['user_id']]);
$result = $stmt->fetch(PDO::FETCH_ASSOC); // Fetch as associative array
$unread_notifications_count = $result['count'];

// Format notification count for display
$notification_badge = '';
if ($unread_notifications_count > 0) {
    if ($unread_notifications_count < 1000) {
        $notification_badge = $unread_notifications_count;
    } else {
        $thousands = floor($unread_notifications_count / 1000);
        $remainder = $unread_notifications_count % 1000;
        if ($remainder == 0) {
            $notification_badge = $thousands . 'k';
        } else {
            $remainder_hundreds = floor($remainder / 100);
            $notification_badge = $thousands . '.' . $remainder_hundreds . 'k+';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title><?= isset($page_title) ? htmlspecialchars($page_title) : 'Churn Analytics' ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            background-color: #f1f1f1; /* Main background color */
            padding-bottom: 60px; /* Space for a fixed footer if used globally */
            overflow-x: hidden;
            /* Flex properties for sticky footer if header is the top-level wrapper */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* --- Header Specific Styles --- */
        .header-container {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background-color: #f1f1f1; /* Header background */
            z-index: 100;
            padding: 0.5rem 2rem;
            height: 42px; /* Height on desktop */
            display: flex;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05); /* Subtle shadow */
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
        }

        .left-icons {
            position: relative;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .logo-desktop {
            height: 40px;
            display: none; /* Hidden by default, shown on desktop */
        }

        .menu-toggle {
            width: 28px;
            height: 28px;
            cursor: pointer;
            transition: transform 0.2s ease;
        }

        .menu-toggle:hover {
            transform: scale(1.1);
        }

        .menu-icons {
            display: flex;
            gap: 4.5rem; /* Space between central menu icons */
            justify-content: center;
            align-items: center;
        }

        .menu-icon {
            width: 25px;
            height: 25px;
            object-fit: contain;
            cursor: pointer;
            transition: transform 0.2s ease;
            position: relative;
        }

        .menu-icon:hover {
            transform: scale(1.1);
        }

        .notification-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background-color: #3ac3b8; /* Primary color */
            color: white;
            font-size: 10px;
            font-weight: bold;
            padding: 2px 5px;
            border-radius: 10px;
            min-width: 18px;
            text-align: center;
            line-height: 1;
        }

        .right-section {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            position: relative;
        }

        .profile-container {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            overflow: hidden;
            border: 2px solid #e0e0e0;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
        }

        .profile-container:hover {
            border-color: #3ac3b8; /* Primary color on hover */
            transform: scale(1.05);
        }

        .profile-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .top-menu {
            display: flex;
            gap: 1.5rem;
            margin-right: 1.5rem;
        }

        .top-menu a {
            text-decoration: none;
            color: #333;
            font-weight: 900;
            font-size: 14px;
            transition: color 0.2s ease;
            position: relative;
        }

        .top-menu a:hover {
            color: #3ac3b8; /* Primary color on hover */
        }

        .new-badge {
            position: absolute;
            top: -8px;
            right: -15px;
            background-color: #7c00ff;
            color: white;
            font-size: 9px;
            font-weight: bold;
            padding: 2px 4px;
            border-radius: 4px;
            line-height: 1;
        }

        /* --- Content Layout --- */
        .content-container {
            display: flex;
            margin-top: 70px; /* Space for fixed header */
            min-height: calc(100vh - 70px); /* Fill remaining viewport height */
            flex-grow: 1; /* Allow content to grow */
        }

        .left-container {
            display: flex; /* Holds icon-sidebar and left-sidebar */
            width: 290px; /* Fixed width for the entire left panel */
        }

        .icon-sidebar {
            width: 55px; /* Fixed width for icon-only sidebar */
            padding: 1rem 0.5rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.8rem;
            position: fixed;
            top: 70px; /* Below the header */
            height: calc(100vh - 70px);
            z-index: 90;
            overflow-y: auto;
            overflow-x: hidden;
            scrollbar-width: none !important; /* Firefox */
        }
        
        .icon-sidebar::-webkit-scrollbar {
            width: 0px; /* Chrome, Safari, Edge */
        }
        
        .icon-sidebar::-webkit-scrollbar-track {
            background: transparent;
        }
        
        .icon-sidebar::-webkit-scrollbar-thumb {
            background: transparent;
        }
        
        .icon-sidebar::-webkit-scrollbar-button {
            display: none;
        }

        .icon-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: #333;
            font-size: 0.6rem;
            padding: 4px 8px;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .icon-item:hover {
            color: #3ac3b8; /* Primary color on hover */
        }

        .icon-img {
            width: 20px;
            height: 20px;
            margin-bottom: 0px;
        }

        .left-sidebar {
            width: 250px;
            background-color: #f1f1f1;
            padding: 1rem;
            color: #666;
            overflow-y: auto;
            margin-left: 55px;
            height: calc(100vh - 70px);
            position: fixed;
            top: 70px;
            left: 0;
            z-index: 80;
            /* Custom scrollbar styles */
            scrollbar-width: thin; /* For Firefox */
            scrollbar-color: rgba(0,0,0,0.2) transparent; /* For Firefox */
        }

        /* Custom scrollbar for Chrome/Safari */
        .left-sidebar::-webkit-scrollbar {
            width: 4px; /* Very thin scrollbar */
        }

        .left-sidebar::-webkit-scrollbar-track {
            background: transparent; /* Transparent track */
        }

        .left-sidebar::-webkit-scrollbar-thumb {
            background-color: rgba(0,0,0,0.2); /* Subtle scroll thumb */
            border-radius: 2px; /* Rounded corners */
        }

        .left-sidebar::-webkit-scrollbar-thumb:hover {
            background-color: rgba(0,0,0,0.3); /* Slightly darker on hover */
        }

        /* NEW: Styles for the banner inside the left sidebar */
        .left-sidebar .banner-link {
            display: block; /* Make the anchor a block element for full width */
            text-align: center; /* Center the image within the link */
            margin-bottom: 20px; /* Add some space below the banner */
            line-height: 0; /* Remove extra space below the image */
        }
        .left-sidebar .banner-link img {
            max-width: 100%; /* Ensure the image fits within the sidebar's width */
            height: auto; /* Maintain aspect ratio */
            display: block; /* Remove any inline-block spacing */
            border-radius: 5px; /* Optional: subtle rounded corners for the banner */
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); /* Optional: subtle shadow for the banner */
        }


        .main-content {
            flex: 1; /* Takes remaining horizontal space */
            background-color: #f1f1f1; /* Main content background */
            margin: 0 1rem; /* Margins for spacing */
            padding: 2px;
        }

        /* --- Mobile Specific Styles --- */
        .mobile-sidebar {
            position: fixed;
            top: 70px; /* Below the header */
            left: -300px; /* Off-screen by default */
            width: 300px;
            height: calc(100vh - 70px);
            background-color: white;
            z-index: 1000;
            transition: left 0.3s ease;
            overflow-y: auto;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            scrollbar-width: none;
        }
        
        .mobile-sidebar::-webkit-scrollbar {
            width: 0px;
        }
        
        .mobile-sidebar::-webkit-scrollbar-track {
            background: transparent;
        }
        
        .mobile-sidebar::-webkit-scrollbar-thumb {
            background: transparent;
        }
        
        .mobile-sidebar::-webkit-scrollbar-button {
            display: none;
        }

        .mobile-sidebar.show {
            left: 0; /* Slide in */
        }

        .mobile-sidebar ul {
            list-style: none;
            padding: 1rem;
        }

        .mobile-sidebar li {
            padding: 0.8rem 0;
            border-bottom: 1px solid #eee;
            font-size: 0.95rem;
        }

        .mobile-sidebar li:last-child {
            border-bottom: none;
        }

        .overlay {
            display: none;
            position: fixed;
            top: 70px;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999;
        }

        .overlay.show {
            display: block;
        }

        @media (max-width: 768px) {
            .header-container {
                height: 70px; /* Taller header on mobile */
                padding: 0.5rem 1rem;
            }
            .logo-desktop {
                display: none !important; /* Hide desktop logo */
            }
            .menu-toggle {
                display: block; /* Show mobile menu toggle */
            }
            .menu-icons {
                display: none; /* Hide desktop menu icons */
            }
            .top-menu {
                display: none; /* Hide desktop top menu */
            }
            .content-container {
                flex-direction: column; /* Stack content vertically */
                margin-top: 70px; /* Adjust margin for mobile header */
            }
            .left-container, /* Hide the fixed desktop sidebars */
            .left-sidebar,
            .icon-sidebar {
                display: none;
            }
            .main-content {
                width: 100%; /* Full width on mobile */
                margin: 0;
                margin-bottom: 1rem; /* Space before footer on mobile */
            }
        }

        @media (min-width: 769px) {
            .menu-toggle {
                display: none; /* Hide mobile toggle on desktop */
            }
            .logo-desktop {
                display: block; /* Show desktop logo */
            }
            .mobile-sidebar, /* Hide mobile sidebar and overlay on desktop */
            .overlay {
                display: none !important;
            }
        }
    </style>
</head>
<body>
    <div class="header-container">
        <div class="top-bar">
            <div class="left-icons">
                <img src="<?= BASE_URL ?>/logo1.png" alt="Logo" class="logo-desktop">
                <img src="<?= BASE_URL ?>/assets/images/menu.png" alt="Menu" class="menu-toggle" id="mobileMenuToggle">
            </div>
            <div class="menu-icons">
                <a href="<?= BASE_URL ?>/dashboard.php">
                    <img src="<?= BASE_URL ?>/assets/images/home.png" alt="Home" class="menu-icon" title="Home">
                </a>
                <a href="<?= BASE_URL ?>/cohorts.php">
                    <img src="<?= BASE_URL ?>/assets/images/stack.png" alt="Segments" class="menu-icon" title="Segments">
                </a>
                <a href="<?= BASE_URL ?>/documentation/index.php">
                    <img src="<?= BASE_URL ?>/assets/images/code.png" alt="SDKs" class="menu-icon" title="SDKs">
                </a>
                <a href="<?= BASE_URL ?>/notifications.php" style="position: relative;">
                    <img src="<?= BASE_URL ?>/assets/images/notification.png" alt="Notifications" class="menu-icon" title="Notifications">
                    <?php if ($unread_notifications_count > 0): ?>
                        <span class="notification-badge"><?= htmlspecialchars($notification_badge) ?></span>
                    <?php endif; ?>
                </a>
                <a href="<?= BASE_URL ?>/explore.php">
                    <img src="<?= BASE_URL ?>/assets/images/trend.png" alt="Forecasting" class="menu-icon" title="Forecasting">
                </a>
                   <a href="<?= BASE_URL ?>/experiment">
                    <img src="<?= BASE_URL ?>/assets/images/ab-testing.png" alt="Experiments" class="menu-icon" title="Experiments">
                </a>
            </div>
            
            <div class="right-section">
                <div class="top-menu">
                    <a href="<?= BASE_URL ?>/niches.php">Niches<span class="new-badge">Research🚀</span></a>
                    <a href="<?= BASE_URL ?>/retention.php">Retention</a>
                    <a href="<?= BASE_URL ?>/profile.php">Profile</a>
                    <a href="<?= BASE_URL ?>/teams.php">Teams</a>
                    <a href="<?= BASE_URL ?>/streams.php">Streams</a>
                    <a href="<?= BASE_URL ?>/settings.php">Settings</a>
                    <a href="<?= BASE_URL ?>/tracking.php">Tracking<span class="new-badge">NEW💥</span></a>
                    <a href="<?= BASE_URL ?>/trends.php">Trends</a>
                </div>
                <a href="<?= BASE_URL ?>/settings.php" class="profile-container">
                    <img src="<?= $profile_pic ?>" alt="Profile" class="profile-img" title="Profile">
                </a>
            </div>
        </div>
    </div>

    <div class="overlay" id="overlay"></div>
    <div class="mobile-sidebar" id="mobileSidebar">
        <ul>
            <li>🚨 AI-Powered Churn Risk Scoring</li>
            <li>🖱️ Feature Usage Tracking (SDK/API)</li>
            <li>📢 Real-Time Alerts (Slack/Email/SMS)</li>
            <li>🤖 Automated "Save Campaigns"</li>
            <li>🕵️ Competitor Visit Tracking</li>
            <li>📊 Cohort-Based Churn Analysis</li>
            <li>💰 Revenue Impact Forecasting</li>
            <li>🔍 Root-Cause Detection</li>
            <li>🛠️ CRM Sync (HubSpot/Salesforce)</li>
            <li>✉️ Email Campaigns</li>
            <li>🍪 Hybrid Tracking (Cookies + Cookieless)</li>
            <li>🛡️ Anonymized Data Storage</li>
            <li>📥 One-Click Cloud Integrations</li>
            <li>🎥 Session Recording</li>
            <li>📉 Cancelation Flow</li>
        </ul>
    </div>

    <div class="content-container">
        <div class="left-container">
            <div class="icon-sidebar">
                <a href="<?= BASE_URL ?>/helpdesk.php" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/chat.png" alt="Support" class="icon-img">
                    <span>Support</span>
                </a>
                <a href="<?= BASE_URL ?>/contacts.php" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/contacts.png" alt="Contacts" class="icon-img">
                    <span>Contacts</span>
                </a>
                <a href="<?= BASE_URL ?>/winback.php" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/survey.png" alt="Win-Back" class="icon-img">
                    <span>Win-Back</span>
                </a>
                <a href="<?= BASE_URL ?>/rank.php" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/rank.png" alt="Rank" class="icon-img">
                    <span>Rank</span>
                </a>
                <a href="<?= BASE_URL ?>/teams.php" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/teams.png" alt="Teams" class="icon-img">
                    <span>Teams</span>
                </a>
                <a href="<?= BASE_URL ?>/explore.php" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/compass.png" alt="Compass" class="icon-img">
                    <span>Explore!</span>
                </a>
                <a href="<?= BASE_URL ?>/competitors.php" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/competitors.png" alt="Competitors" class="icon-img">
                    <span>Competitors</span>
                </a>
                <a href="<?= BASE_URL ?>/external_integrations.php" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/external.png" alt="External" class="icon-img">
                    <span>External</span>
                </a>
                <a href="<?= BASE_URL ?>/features.php" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/features.png" alt="Features" class="icon-img">
                    <span>Features</span>
                </a>
                <a href="<?= BASE_URL ?>/gift_membership.php" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/gift.png" alt="Gift" class="icon-img">
                    <span>Gift</span>
                </a>
                <a href="<?= BASE_URL ?>/membership.php" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/pricing.png" alt="Pricing" class="icon-img">
                    <span>Pricing</span>
                </a>
                <a href="<?= BASE_URL ?>/templates.php" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/email.png" alt="Email" class="icon-img">
                    <span>Email</span>
                </a>
                <a href="<?= BASE_URL ?>/automations.php" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/rpa.png" alt="Win-Back" class="icon-img">
                    <span>Automation</span>
                </a>
                <a href="<?= BASE_URL ?>/slides" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/images.png" alt="Images" class="icon-img">
                    <span>Onboard!</span>
                </a>
                <a href="<?= BASE_URL ?>/documentation" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/documentation.png" alt="Documentation" class="icon-img">
                    <span>Docs</span>
                </a>
                <a href="<?= BASE_URL ?>/documentation/api.php" class="icon-item">
                    <img src="<?= BASE_URL ?>/assets/images/api.png" alt="API" class="icon-img">
                    <span>API</span>
                </a>
            </div>
            <div class="left-sidebar">
                <a href="https://earndos.com/io/affiliate.php" class="banner-link">
                    <img src="<?= BASE_URL ?>/includes/img/banner.png" alt="Affiliate Banner">
                </a>
            </div>
        </div>

        <div class="main-content">