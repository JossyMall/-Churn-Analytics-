<?php
// includes/get_churn_data.php
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Not authenticated.']);
    exit;
}

require_once 'db.php'; // Assuming db.php handles PDO connection

$user_id = $_SESSION['user_id'];

// --- Data Fetching Logic for Churn Rate Comparison Chart ---
// We need:
// 1. Your overall churn rate (across all your streams/contacts) over time.
// 2. The average churn rate for all other users within niches relevant to your streams.

$data = [
    'labels' => [], // e.g., ['Jan 2024', 'Feb 2024', ...]
    'userChurnRates' => [],
    'nicheAverages' => []
];

// Define the period (e.g., last 12 months)
$num_months = 12;
$current_date = new DateTime();
$months_to_fetch = [];
for ($i = $num_months - 1; $i >= 0; $i--) {
    $date = (clone $current_date)->modify("-{$i} months");
    $months_to_fetch[] = $date->format('Y-m'); // Format as 'YYYY-MM'
    $data['labels'][] = $date->format('M Y'); // Format as 'Mon YYYY' for display
}

// 1. Calculate Your (Logged-in User's) Churn Rate per month
// Churn Rate = (Number of churned contacts in month) / (Number of active contacts at start of month + new contacts in month)
// Or simpler: (Churned contacts in month) / (Total contacts at end of prior month + new contacts in month)
// A common definition: Churn Rate = (Customers Lost in a Period) / (Customers at the Beginning of the Period)

// For simplicity, let's calculate based on `cancellation_date` or `churned_at` vs. total contacts in stream.
// This is a simplified approach, a true churn rate needs to track active customers at start of period.

// Get all contacts associated with the user's streams
$stmt_user_contacts_streams = $pdo->prepare("
    SELECT c.id AS contact_id, s.id AS stream_id, s.niche_id, s.user_id AS stream_owner_id
    FROM contacts c
    JOIN streams s ON c.stream_id = s.id
    WHERE s.user_id = ? OR s.id IN (
        SELECT ts.stream_id FROM team_streams ts JOIN team_members tm ON ts.team_id = tm.team_id WHERE tm.user_id = ?
    )
    GROUP BY c.id -- Ensure unique contacts if a contact belongs to multiple streams/teams
");
$stmt_user_contacts_streams->execute([$user_id, $user_id]);
$user_relevant_streams = $stmt_user_contacts_streams->fetchAll(PDO::FETCH_ASSOC);

$user_streams_ids = array_column($user_relevant_streams, 'stream_id');
$user_relevant_niche_ids = array_column($user_relevant_streams, 'niche_id');
$user_relevant_niche_ids = array_filter(array_unique($user_relevant_niche_ids)); // Get unique non-null niches


// --- Calculate Churn Rates Per Month ---
foreach ($months_to_fetch as $month_str) {
    $start_of_month = new DateTime($month_str . '-01');
    $end_of_month = (clone $start_of_month)->modify('last day of this month')->setTime(23, 59, 59);
    $start_of_period = (clone $start_of_month)->modify('first day of last month')->setTime(0, 0, 0); // For denominator

    // USER CHURN RATE
    // Count total contacts active or acquired by user's streams up to end of previous month
    // plus new contacts in current month
    // Simplified: Total unique contacts the user has or had access to in this stream type (owned/shared)
    // Denominator: Total contacts associated with user's streams up to this month
    $stmt_user_total_contacts = $pdo->prepare("
        SELECT COUNT(DISTINCT c.id)
        FROM contacts c
        JOIN streams s ON c.stream_id = s.id
        WHERE (s.user_id = ? OR s.id IN (
            SELECT ts.stream_id FROM team_streams ts JOIN team_members tm ON ts.team_id = tm.team_id WHERE tm.user_id = ?
        ))
        AND c.created_at <= ? -- Contacts created up to current month
    ");
    $stmt_user_total_contacts->execute([$user_id, $user_id, $end_of_month->format('Y-m-d H:i:s')]);
    $user_total_contacts_for_month = $stmt_user_total_contacts->fetchColumn();

    // Numerator: Count churned contacts in current month for user's streams
    $stmt_user_churned_contacts = $pdo->prepare("
        SELECT COUNT(DISTINCT cu.contact_id)
        FROM churned_users cu
        JOIN contacts c ON cu.contact_id = c.id
        JOIN streams s ON c.stream_id = s.id
        WHERE (s.user_id = ? OR s.id IN (
            SELECT ts.stream_id FROM team_streams ts JOIN team_members tm ON ts.team_id = tm.team_id WHERE tm.user_id = ?
        ))
        AND cu.churned_at >= ? AND cu.churned_at <= ?
    ");
    $stmt_user_churned_contacts->execute([$user_id, $user_id, $start_of_month->format('Y-m-d H:i:s'), $end_of_month->format('Y-m-d H:i:s')]);
    $user_churned_contacts_in_month = $stmt_user_churned_contacts->fetchColumn();

    $user_churn_rate = ($user_total_contacts_for_month > 0) ?
                        ($user_churned_contacts_in_month / $user_total_contacts_for_month) * 100 : 0;
    $data['userChurnRates'][] = round($user_churn_rate, 2);


    // NICHE AVERAGE CHURN RATE
    $niche_average_churn_rate = 0;
    if (!empty($user_relevant_niche_ids)) {
        $niche_placeholders = implode(',', array_fill(0, count($user_relevant_niche_ids), '?'));

        // Denominator: Total contacts in relevant niches (excluding current user's direct streams)
        $stmt_niche_total_contacts = $pdo->prepare("
            SELECT COUNT(DISTINCT c.id)
            FROM contacts c
            JOIN streams s ON c.stream_id = s.id
            WHERE s.niche_id IN ({$niche_placeholders})
            AND s.user_id != ? -- Exclude current user's own streams
            AND c.created_at <= ?
        ");
        $params_niche_total = array_merge($user_relevant_niche_ids, [$user_id, $end_of_month->format('Y-m-d H:i:s')]);
        $stmt_niche_total_contacts->execute($params_niche_total);
        $niche_total_contacts_for_month = $stmt_niche_total_contacts->fetchColumn();

        // Numerator: Churned contacts in relevant niches (excluding current user's direct streams)
        $stmt_niche_churned_contacts = $pdo->prepare("
            SELECT COUNT(DISTINCT cu.contact_id)
            FROM churned_users cu
            JOIN contacts c ON cu.contact_id = c.id
            JOIN streams s ON c.stream_id = s.id
            WHERE s.niche_id IN ({$niche_placeholders})
            AND s.user_id != ? -- Exclude current user's own streams
            AND cu.churned_at >= ? AND cu.churned_at <= ?
        ");
        $params_niche_churned = array_merge($user_relevant_niche_ids, [$user_id, $start_of_month->format('Y-m-d H:i:s'), $end_of_month->format('Y-m-d H:i:s')]);
        $stmt_niche_churned_contacts->execute($params_niche_churned);
        $niche_churned_contacts_in_month = $stmt_niche_churned_contacts->fetchColumn();

        $niche_average_churn_rate = ($niche_total_contacts_for_month > 0) ?
                                    ($niche_churned_contacts_in_month / $niche_total_contacts_for_month) * 100 : 0;
    }
    $data['nicheAverages'][] = round($niche_average_churn_rate, 2);
}

echo json_encode($data);
?>