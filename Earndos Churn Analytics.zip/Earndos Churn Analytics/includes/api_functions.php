<?php
// includes/api_functions.php

/**
 * Validate API key and return user ID
 */
function validate_api_key($api_key) {
    require_once 'db.php';
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT user_id FROM user_api_keys WHERE api_key = ?");
    $stmt->execute([$api_key]);
    $result = $stmt->fetch();
    
    return $result ? $result['user_id'] : false;
}

/**
 * Generate new API key for user
 */
function generate_api_key($user_id) {
    require_once 'db.php';
    global $pdo;
    
    // Delete any existing API key for this user
    $pdo->prepare("DELETE FROM user_api_keys WHERE user_id = ?")->execute([$user_id]);
    
    // Generate new key
    $api_key = bin2hex(random_bytes(32));
    
    $stmt = $pdo->prepare("INSERT INTO user_api_keys (user_id, api_key) VALUES (?, ?)");
    $stmt->execute([$user_id, $api_key]);
    
    return $api_key;
}

/**
 * API response formatter
 */
function api_response($data, $status = 200, $message = '') {
    header('Content-Type: application/json');
    http_response_code($status);
    
    $response = [
        'status' => $status,
        'message' => $message,
        'data' => $data,
        'timestamp' => time()
    ];
    
    echo json_encode($response);
    exit;
}

/**
 * Validate API request
 */
function validate_api_request() {
    $headers = getallheaders();
    
    // Check for API key in headers or GET parameters
    $api_key = $_GET['api_key'] ?? $headers['X-API-Key'] ?? $headers['Authorization'] ?? null;
    
    if (!$api_key) {
        api_response(null, 401, 'API key required');
    }
    
    $user_id = validate_api_key($api_key);
    
    if (!$user_id) {
        api_response(null, 403, 'Invalid API key');
    }
    
    return $user_id;
}

/**
 * Get request payload (JSON input)
 */
function get_json_payload() {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        api_response(null, 400, 'Invalid JSON payload');
    }
    
    return $data;
}

/**
 * Rate limit API requests
 */
function api_rate_limit($user_id, $requests_per_minute = 60) {
    require_once 'db.php';
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM api_logs 
                          WHERE user_id = ? AND timestamp > DATE_SUB(NOW(), INTERVAL 1 MINUTE)");
    $stmt->execute([$user_id]);
    $count = $stmt->fetchColumn();
    
    if ($count >= $requests_per_minute) {
        api_response(null, 429, 'Too many requests');
    }
    
    // Log the request
    $pdo->prepare("INSERT INTO api_logs (user_id, endpoint) VALUES (?, ?)")
        ->execute([$user_id, $_SERVER['REQUEST_URI']]]);
}

/**
 * Check API permissions
 */
function check_api_permission($user_id, $permission) {
    require_once 'db.php';
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_permissions 
                          WHERE user_id = ? AND permission = ?");
    $stmt->execute([$user_id, $permission]);
    
    if ($stmt->fetchColumn() == 0) {
        api_response(null, 403, 'Permission denied');
    }
}